/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * For each MGE collection agency referral, create an entry in the temp 
 * table so the record can be extracted on the reconciliation file that tells
 * DebtNext who the current agency is. 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2015-07-14   SMiran     SF-3198240. Initial version.
 * 2015-09-28   SMiran     SF-3311570. Change batch program
 * 							- Add MAX_ERRORS soft parameter
 * 							- Removed RELATED_SA_CHAR_TYPE parameter
 * 							- Removed ACCT_ID_HIGH and ACCT_ID_LOW parameters
 * 							- Make this batch available for LGC accounts; no
 * 							need to populate COLL_AGY_REF_ID_OLD field
 * 							- Before retrieving records to process, delete
 * 							records from CM_COLL_AGY_REF_STG_TMP (only for 
 * 							the CIS Division being processed)  
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation.
 * 2021-06-15   EQuint     SA-368912. Add premise ID in staging table
 * 2021-12-16  JHERNA      Mercury#47161 / B-20309. Add data status field
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;








import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffEventStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusLookup;
import com.splwg.ccb.domain.admin.writeOffProcessTemplate.entity.WriteOffProcessTemplate;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging_DTO;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90723
 *
 @BatchJob (rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = writeOffProcessTemplate, name = RESTART_WO_PROC, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmMGECollectionAgencyReferralCleanupBatch extends
        CmMGECollectionAgencyReferralCleanupBatch_Gen {
	
	// 2015-09-28. SMiran. SF-3311570. Start Delete
	//private String accountIdLow = "";
	//private String accountIdHigh = "";
	// 2015-09-28. SMiran. SF-3311570. End Delete

    public JobWork getJobWork() {
    	
    	// 2015-09-28. SMiran. SF-3311570. Start Add
    	truncateTable();
    	// 2015-09-28. SMiran. SF-3311570. End Add
    	
    	// 2015-09-28. SMiran. SF-3311570. Start Delete
    	//accountIdLow = getParameters().getACCT_ID_LOW();
    	//accountIdHigh = getParameters().getACCT_ID_HIGH();
    	//if (isEmptyOrNull(accountIdLow)){
    	//	accountIdLow = "0000000000";
    	//}
    	//if (isEmptyOrNull(accountIdHigh)){
    	//	accountIdHigh = "9999999999";
    	//}
    	// 2015-09-28. SMiran. SF-3311570. Start Delete

        ArrayList<ThreadWorkUnit> threadWorkUnitList =  new ArrayList<ThreadWorkUnit>();
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT CAR.COLL_AGY_REF_ID ");
        stringBuilder.append("FROM CI_COLL_AGY_REF CAR, CI_ACCT AC ");
    	// 2015-09-28. SMiran. SF-3311570. Start Change
        //stringBuilder.append("WHERE CAR.ACCT_ID >= :accountIdLow AND CAR.ACCT_ID <= :accountIdHigh ");
        //stringBuilder.append("AND CAR.REF_STATUS_FLG = :referralStatusActive ");
        stringBuilder.append("WHERE CAR.REF_STATUS_FLG = :referralStatusActive ");
    	// 2015-09-28. SMiran. SF-3311570. End Change
        stringBuilder.append("AND AC.ACCT_ID = CAR.ACCT_ID ");
        stringBuilder.append("AND AC.CIS_DIVISION = :cisDivision ");
        
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
    	// 2015-09-28. SMiran. SF-3311570. Start Delete
        //preparedStatement.bindString("accountIdLow", accountIdLow.trim(), "CAR.ACCT_ID");
        //preparedStatement.bindString("accountIdHigh", accountIdHigh.trim(), "CAR.ACCT_ID");
    	// 2015-09-28. SMiran. SF-3311570. End Delete
        preparedStatement.bindLookup("referralStatusActive", ReferralStatusLookup.constants.ACTIVE);
        preparedStatement.bindId("cisDivision", getParameters().getCIS_DIVISION().getId());
        
        List<SQLResultRow> sqlResultRowList = preparedStatement.list();
        
        preparedStatement.close();
        
        for (SQLResultRow sqlResultRow : sqlResultRowList) {
            
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(sqlResultRow.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class));
            threadWorkUnitList.add(threadWorkUnit);
            
        }
        
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        
    }

	// 2015-09-28. SMiran. SF-3311570. Start Add
    private void truncateTable() {
    	
		StringBuilder truncateTableStr = new StringBuilder();
		truncateTableStr.append(" DELETE ");
		truncateTableStr.append("	CM_COLL_AGY_REF_STG_TMP ");
		truncateTableStr.append(" WHERE ");
		truncateTableStr.append("   CIS_DIVISION = :cisDivision ");

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement truncateTablePrepStmt = createPreparedStatement(truncateTableStr.toString());
		PreparedStatement truncateTablePrepStmt = createPreparedStatement(truncateTableStr.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		truncateTablePrepStmt.bindEntity("cisDivision", getParameters().getCIS_DIVISION());
		truncateTablePrepStmt.execute();
		truncateTablePrepStmt.close();
    			
	}
	// 2015-09-28. SMiran. SF-3311570. End Add

	public Class<CmMGECollectionAgencyReferralCleanupBatchWorker> getThreadWorkerClass() {
        return CmMGECollectionAgencyReferralCleanupBatchWorker.class;
    }

    public static class CmMGECollectionAgencyReferralCleanupBatchWorker extends
            CmMGECollectionAgencyReferralCleanupBatchWorker_Gen {
    	
    	//Start add - EQuint - SA-368912 - 2021-06-15
    	private final static CharacteristicType RELATED_SA_CHAR_TYPE = new CharacteristicType_Id("C1-SA").getEntity();
    	//End add - EQuint - SA-368912 - 2021-06-15
    	
    	// 2015-09-28. SMiran. SF-3311570. Start Delete
        //private CharacteristicType relatedSaCharType;
    	// 2015-09-28. SMiran. SF-3311570. End Delete
    	//Start delete - EQuint - SA-368912 - 2021-06-15
        // private CharacteristicType currentAgencyCharType;
        //End delete - EQuint - SA-368912 - 2021-06-15
        
    	// 2015-09-28. SMiran. SF-3311570. Start Add
    	private int maxErrors = 0;
    	private int errorCount = 0;
    	// 2015-09-28. SMiran. SF-3311570. End Add
    	
    	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
    	private WriteOffProcessTemplate restartWoProcTemplate;
    	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
        	// 2015-09-28. SMiran. SF-3311570. Start Delete
        	//relatedSaCharType = getParameters().getRELATED_SA_CHAR_TYPE();
        	// 2015-09-28. SMiran. SF-3311570. End Delete
        	//Start delete - EQuint - SA-368912 - 2021-06-15
        	// currentAgencyCharType = getParameters().getCURRENT_AGENCY_CHAR_TYPE();
        	//End delete - EQuint - SA-368912 - 2021-06-15
        	// 2015-09-28. SMiran. SF-3311570. Start Add
        	maxErrors = this.getParameters().getSoftMaxErrors().intValue(); 
        	// 2015-09-28. SMiran. SF-3311570. End Add
        	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
        	restartWoProcTemplate = this.getParameters().getRESTART_WO_PROC();
        	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
            
            CollectionAgencyReferral collectionAgencyReferral = ((CollectionAgencyReferral_Id) threadWorkUnit.getPrimaryId()).getEntity();
            
            // Get the account from the collection agency referral
            Account account = collectionAgencyReferral.getAccount();
            
            // Get the placement task created for the Collection Agency Referral
            ServiceTask placementTask = getCollectionAgencyPlacement(collectionAgencyReferral);
            
            // Start Delete - EQuint - SA-368912 - 2021-06-15
            // // Get the Current Agency Code from the Placement Task
            // String currentAgencyStr = getPlacementChar(collectionAgencyReferral, placementTask, currentAgencyCharType);
            // End Delete - EQuint - SA-368912 - 2021-06-15
            // 2015-09-28. SMiran. SF-3311570. Start Delete
            // Get one of the WO SAs from Placement Task
            //String woSaStr = getPlacementChar(collectionAgencyReferral, placementTask, relatedSaCharType);

            //// Using the WO SA, get the Old Account Id
            //ServiceAgreement_Id saId = new ServiceAgreement_Id(woSaStr.trim());
            //if (isNull(saId.getEntity())){
            //	addError(CustomMessageRepositoryMGE.sf3198240TaskSAInv(
            //			collectionAgencyReferral.getId().getTrimmedValue(), placementTask.getId().getTrimmedValue(), saId.getTrimmedValue()));
            //}
            //String oldAccountId = saId.getEntity().getOldAccountId();
            //if (isEmptyOrNull(oldAccountId.trim())){
            //	addError(CustomMessageRepositoryMGE.sf3198240TaskSANoOldAcctId(
            //			collectionAgencyReferral.getId().getTrimmedValue(), placementTask.getId().getTrimmedValue(), saId.getTrimmedValue()));
            //}
            // 2015-09-28. SMiran. SF-3311570. End Delete            
            // 2015-09-28. SMiran. SF-3311570. Start Change
            //// Refer to the Initial Referral line on the new Collection Agency Referral for the total Write Off Process amount
            //CollectionAgencyHistory initialReferralCollectionAgencyHistory = collectionAgencyReferral.getCollectionAgencyHistories().iterator().next();
            // Get referral amount from Collection Agency Referral History record with max sequence
            // Start Delete - EQuint - SA-368912 - 2021-06-15
            // BigDecimal referralAmount = getReferralAmount(collectionAgencyReferral);           
            // End Delete - EQuint - SA-368912 - 2021-06-15
            // 2015-09-28. SMiran. SF-3311570. End Change
            // 2015-09-28. SMiran. SF-3311570. Start Change - try-catch block
            try{
            	// Start update - EQuint - SA-368912 - 2021-06-15
            	
            	// // Insert Staging record
            	// CmCollectionAgencyReferralStaging_Id carStgId 
            	// 		// 2015-09-28. SMiran. SF-3311570. Start Change
            	// 		//= new CmCollectionAgencyReferralStaging_Id(account.getId(), oldAccountId);
            	// 		= new CmCollectionAgencyReferralStaging_Id(collectionAgencyReferral.getId(),account.getId());
            	// 		// 2015-09-28. SMiran. SF-3311570. End Change
            
            	// CmCollectionAgencyReferralStaging_DTO carStgDto = createDTO(CmCollectionAgencyReferralStaging.class);
            	// carStgDto.setId(carStgId);
            	// // 2015-09-28. SMiran. SF-3311570. Start Add
            	// carStgDto.setDivisionId(account.getDivisionId());
            	// // 2015-09-28. SMiran. SF-3311570. End Add
            	// // 2015-09-28. SMiran. SF-3311570. Start Change
            	// //carStgDto.setCmCollAgyRefIdNewId(collectionAgencyReferral.getId());
            	// carStgDto.setCmCollAgyRefIdOld("");
            	// // 2015-09-28. SMiran. SF-3311570. End Change
            	// carStgDto.setCollectionAgency(currentAgencyStr.trim());
            	// carStgDto.setStartDate(collectionAgencyReferral.getStartDate());
            	// // 2015-09-28. SMiran. SF-3311570. Start Change
            	// //carStgDto.setArrearsAmount(initialReferralCollectionAgencyHistory.getReferralAmount());
            	// carStgDto.setArrearsAmount(new Money(referralAmount, account.getCurrency().getId()));
            	// // 2015-09-28. SMiran. SF-3311570. End Change
            	// carStgDto.newEntity();
            	
            	BusinessObjectInstance boInstance = BusinessObjectInstance.create(placementTask.getBusinessObject());
    			boInstance.set("serviceTaskId", placementTask.getId().getTrimmedValue());
    			
    			boInstance = BusinessObjectDispatcher.read(boInstance);
    			COTSInstanceNode premiseReferralPlacements = boInstance.getGroup("premiseReferralPlacements");
    			if (notNull(premiseReferralPlacements)) {
    				COTSInstanceList cotsInstanceList = premiseReferralPlacements.getList("premiseReferralPlacement");
        			
        			// find referral placement record with premise ID
        			for (COTSInstanceListNode node : cotsInstanceList) {
        				// Insert Staging record
        				Premise_Id premId = new Premise_Id(node.getString("premise"));
                    	CmCollectionAgencyReferralStaging_Id carStgId = new CmCollectionAgencyReferralStaging_Id(premId, collectionAgencyReferral.getId(),account.getId());
                    	
                    	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
                    	String relatedWriteOffProcess = boInstance.getString("relatedWriteOffProcess");
                    	WriteOffProcess_Id relatedWoProcID = new WriteOffProcess_Id(relatedWriteOffProcess);                    	
                    	String dataStatus = getDataStatus(relatedWoProcID);
                    	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
                    
                    	CmCollectionAgencyReferralStaging_DTO carStgDto = createDTO(CmCollectionAgencyReferralStaging.class);
                    	carStgDto.setId(carStgId);
                    	carStgDto.setDivisionId(account.getDivisionId());
                    	carStgDto.setCmCollAgyRefIdOld("");
                    	carStgDto.setCollectionAgency(node.getString("collectionAgency"));
                    	carStgDto.setStartDate(collectionAgencyReferral.getStartDate());
                    	carStgDto.setArrearsAmount(getPremiseBalance(boInstance, premId));
                    	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
                    	carStgDto.setDataStatus(dataStatus);
                    	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
                    	carStgDto.newEntity();
        			}
    			}
    			
            	
            	// End update - EQuint - SA-368912 - 2021-06-15
            }catch(Exception e){
    			
            	errorCount++;
            	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
    			e.printStackTrace();
            	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
    			if (errorCount > maxErrors){
    				throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
    			}else{
    				addError(CustomMessageRepositoryMGE.commGenericError(e.getMessage()));
    			}
            }
            // 2015-09-28. SMiran. SF-3311570. End Change - try-catch block
            
            return true;
            
        }
        
    	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
        private static final String STATUS_FINAL = "FINAL";
        private static final String STATUS_WO = "WRITE-OFF";
        
    	private String getDataStatus(WriteOffProcess_Id relatedWriteOffProcessID) {
    		
    		// initialized to status final
    		String returnValue = STATUS_FINAL;
    		
    		if (notNull(relatedWriteOffProcessID)
    				&& notNull(relatedWriteOffProcessID.getEntity()))  {
        		StringBuilder stringBuilder = new StringBuilder();    		
        		stringBuilder.append("SELECT WE.WO_PROC_ID, WE.COMPLETION_DT ");
        		stringBuilder.append("FROM CI_WO_PROC WOP, CI_WO_EVT WE ");
        		stringBuilder.append("WHERE WOP.WO_PROC_ID = :woProcID ");
        		stringBuilder.append("AND WOP.WO_PROC_TMPL_CD = :woProcTmplCd "); // Restart Write Off Process Template
        		stringBuilder.append("AND WOP.WO_STATUS_FLG = :inactive "); // inactive write off status
        		stringBuilder.append("AND WOP.WO_PROC_ID = WE.WO_PROC_ID ");
        		stringBuilder.append("AND WE.EVT_SEQ = (SELECT MAX(WE2.EVT_SEQ) ");
        		stringBuilder.append("                  FROM CI_WO_EVT WE2 ");
        		stringBuilder.append("                  WHERE WE2.WO_PROC_ID = WOP.WO_PROC_ID ");
        		stringBuilder.append("                  ) ");
        		stringBuilder.append("AND WE.WO_EVT_STAT_FLG = :complete "); // complete write off event status
        		stringBuilder.append("AND WE.COMPLETION_DT <= :processDate "); // should be completed in the past

        		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getDataStatus==");
        		prepState.setAutoclose(false);
        		prepState.bindId("woProcID", relatedWriteOffProcessID);
        		prepState.bindId("woProcTmplCd", restartWoProcTemplate.getId());
        		prepState.bindLookup("inactive", WriteOffStatusLookup.constants.INACTIVE);
        		prepState.bindLookup("complete", WriteOffEventStatusLookup.constants.COMPLETED);
        		prepState.bindDate("processDate", this.getProcessDateTime().getDate());
        		prepState.execute();
        		
        		/*
        		   data status would be write-off if the write off process which created the collection agency
        		   referral / placement is a WO Restart template and the final event of the write off process
        		   is completed in the past.
        		 */
        		if (notNull(prepState.firstRow())) {
        			returnValue = STATUS_WO;
        		}
        		prepState.close();
    		}
    		return returnValue;
    	}
    	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
    	
        // Start Add - EQuint - SA-368912 - 2021-06-15
        private Money getPremiseBalance(BusinessObjectInstance boInstance, Premise_Id premId) {
        	Money balance = Money.ZERO;
        	COTSInstanceList cotsInstanceList = boInstance.getGroup("serviceTaskCharacteristics").getList("serviceTaskCharacteristic");
        	for (COTSInstanceListNode node: cotsInstanceList) {
        		if (node.getString("characteristicType").compareTo(RELATED_SA_CHAR_TYPE.getId().getTrimmedValue()) == 0) {
        			String saId;
            		if (RELATED_SA_CHAR_TYPE.getCharacteristicType().isPredefinedValue()) {
            			saId = node.getString("characteristicValue");
                    } else if (RELATED_SA_CHAR_TYPE.getCharacteristicType().isForeignKeyValue()) {
                    	saId = node.getString("characteristicValueFk1");
                    } else {
                    	saId = node.getString("adhocCharacteristicValue");
                    }
            		ServiceAgreement sa = new ServiceAgreement_Id(saId).getEntity();
            		if (sa.getPremiseId().compareTo(premId) == 0) {
            			balance = balance.add(sa.getCurrentBalance());
            		}
        		}
        	}
        	return balance;
        }
        // End Add - EQuint - SA-368912 - 2021-06-15
    	
        // Start Delete - EQuint - SA-368912 - 2021-06-15
//        // 2015-09-28. SMiran. SF-3311570. Start Add
//		private BigDecimal getReferralAmount(CollectionAgencyReferral collectionAgencyReferral) {
//			
//			BigDecimal referralAmount = BigDecimal.ZERO;
//			
//			StringBuilder refAmountQueryStr = new StringBuilder();
//			refAmountQueryStr.append(" SELECT  ");
//			refAmountQueryStr.append("	REF_AMT ");
//			refAmountQueryStr.append(" FROM ");
//			refAmountQueryStr.append("	CI_COLL_AGY_HIS ");
//			refAmountQueryStr.append(" WHERE ");
//			refAmountQueryStr.append("	COLL_AGY_REF_ID = :collAgyRefId ");
//			refAmountQueryStr.append("	ORDER BY SEQ_NUM DESC ");
//			
//			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//			//PreparedStatement refAmountPrepStmt = createPreparedStatement(refAmountQueryStr.toString());
//			PreparedStatement refAmountPrepStmt = createPreparedStatement(refAmountQueryStr.toString(), getClass().getName());
//			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//			refAmountPrepStmt.bindId("collAgyRefId", collectionAgencyReferral.getId());
//			
//			SQLResultRow row = refAmountPrepStmt.firstRow();
//			refAmountPrepStmt.close();
//			if (notNull(row)){
//				referralAmount = row.getBigDecimal("REF_AMT");
//			}
//			
//			return referralAmount;
//		}
//    	// 2015-09-28. SMiran. SF-3311570. End Add
		// End Delete - EQuint - SA-368912 - 2021-06-15

		private ServiceTask getCollectionAgencyPlacement(CollectionAgencyReferral collectionAgencyReferral) {
			
	        StringBuilder stringBuilder = new StringBuilder();
	        stringBuilder.append("SELECT ");
	        stringBuilder.append(  "RO.F1_SVC_TASK_ID ");
	        stringBuilder.append("FROM ");
	        stringBuilder.append(  "F1_SVC_TASK_REL_OBJ RO ");
	        stringBuilder.append("WHERE ");
	        stringBuilder.append(  "RO.MAINT_OBJ_CD = 'COLL AGY REF' ");
	        stringBuilder.append(  "AND TRIM(PK_VALUE1) = :collectionAgencyReferralId ");
	        
	        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
	        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
	        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
	        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
	        preparedStatement.bindId("collectionAgencyReferralId", collectionAgencyReferral.getId());
	        
	        SQLResultRow result = preparedStatement.firstRow();
	        
	        preparedStatement.close();
	        
	        if (isNull(result)) {
	            addError(CustomMessageRepositoryMGE.sf3198240CollAgyRefNoPlacement(collectionAgencyReferral.getId().getTrimmedValue()));
	        }
	        
	        return result.getEntity("F1_SVC_TASK_ID", ServiceTask.class);
			
		}
		
		// Start Delete - EQuint - SA-368912 - 2021-06-15
//		private String getPlacementChar(CollectionAgencyReferral referral, ServiceTask placementTask, CharacteristicType charType) {
//
//	        StringBuilder stringBuilder = new StringBuilder();
//	        stringBuilder.append("SELECT ");
//	        stringBuilder.append(  "CH.CHAR_VAL_FK1 ");
//	        stringBuilder.append("FROM ");
//	        stringBuilder.append(  "F1_SVC_TASK_CHAR CH ");
//	        stringBuilder.append("WHERE ");
//	        stringBuilder.append(  "CH.F1_SVC_TASK_ID = :serviceTask ");
//	        stringBuilder.append(  "AND CH.CHAR_TYPE_CD = :charType ");
//	        stringBuilder.append("ORDER BY SEQ_NUM DESC ");
//	        
//	        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//	        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
//	        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
//	        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation	
//	        preparedStatement.bindId("serviceTask", placementTask.getId());
//	        preparedStatement.bindId("charType", charType.getId());
//	        
//	        SQLResultRow row = preparedStatement.firstRow();
//	        
//	        preparedStatement.close();
//	        
//	        if (isNull(row)){
//	        	addError(CustomMessageRepositoryMGE.sf3198240TaskMissingChar(
//	        			referral.getId().getTrimmedValue(), placementTask.getId().getTrimmedValue(), charType.getId().getTrimmedValue()));
//	        }
//	        
//        	return row.getString("CHAR_VAL_FK1");
//	        
//		}
		// End Delete - EQuint - SA-368912 - 2021-06-15

    }

}
