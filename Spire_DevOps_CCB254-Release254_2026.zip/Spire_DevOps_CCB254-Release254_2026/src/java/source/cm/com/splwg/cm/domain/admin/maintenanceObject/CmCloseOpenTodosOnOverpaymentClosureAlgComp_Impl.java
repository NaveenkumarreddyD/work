/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Close Open To dos on Overpayment Closure
 * 
 * This algorithm will close open Todos when the Overpayment SA is closed 
 * and if the payoff amount goes below the amount threshold parameter. 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:			Reason:
 * YYYY-MM-DD   IN			Reason text.
 *
 * 2020-12-21   JVitug		CCB022. Initial Version   
 * 2021-04-22   JVitug      CCB022.Issue2. Added null check for loan SA before
 * 							proceeding. 
 * 2021-05-12   JVitug      CCB022.Issue3. Removed checking for other active
 * 							or stopped overpayment SAs when closing Todos. 
 * 							Updated to add the Threshold amount. To do's are 
 * 							to be closed if the Overpayment SA
 **************************************************************************/

package com.splwg.cm.domain.admin.maintenanceObject;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.EntityId;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObjectAuditAlgorithmSpot;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristics;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;

//Start Change JVitug - CCB022.Issue 3 - 2021-05-12
///**
// * @author jvitug
// *
// @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, required = true, name = todoTypeForOverpayment, type = entity)
// *            , @AlgorithmSoftParameter (name = overpaymentSAType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = loanServiceType, required = true, type = entity)})
// */
/**
 * @author jvitug
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, required = true, name = todoTypeForOverpayment, type = entity)
 *            , @AlgorithmSoftParameter (name = overpaymentSAType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = loanServiceType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = payOffAmountThreshold, required = true, type = decimal)})
 */
//End Change JVitug - CCB022.Issue 3 - 2021-05-12
public class CmCloseOpenTodosOnOverpaymentClosureAlgComp_Impl extends CmCloseOpenTodosOnOverpaymentClosureAlgComp_Gen
implements MaintenanceObjectAuditAlgorithmSpot {

	//hard Parameters
    private MaintenanceObject mo;
    private EntityId entityId; 
    private boolean ignoreFutureAudits;
    private BigDecimal amountThreshold;
    
    //Soft Parameters
    private ToDoType todoTypeForOverpayment;
    private String overpaymentSAType;
    private ServiceType loanServiceType;
    
    //Working variables
    Account account;
    

    public void setEntityId(EntityId arg0) {
        entityId = arg0;

    }

    public void setMaintenanceObject(MaintenanceObject arg0) {
        mo = arg0;

    }

    @Override
	public boolean getIgnoreFutureAudits() {
		return ignoreFutureAudits;
	}

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the Algorithm Parameters
    	todoTypeForOverpayment = getTodoTypeForOverpayment();
    	overpaymentSAType = getOverpaymentSAType();
    	loanServiceType = getLoanServiceType();
    	//Start Add Jvitug - CCB022.Issue3 -2021-05-12
    	amountThreshold = getPayOffAmountThreshold();
    	//End Add Jvitug - CCB022.Issue3 -2021-05-12
    }
    
    public void invoke() {
    	
        ServiceAgreement_Id overpaymentSAId = new ServiceAgreement_Id(entityId.getOrderedPKFieldValues().get(0).toString());
        ServiceAgreement overpaymentSA = overpaymentSAId.getEntity();
        
        //initialize the variable to prevent lazy initialization
        ToDoEntry_Id openTodoId = null;
        ToDoEntry openTodo = null;
        todoTypeForOverpayment = getTodoTypeForOverpayment();
        ToDoEntryCharacteristics todoChars = null;
        //Continue processing if and only if the SA Type of the SA being processed
        //is the same as the SA Type in the algorithm parameters
        if(overpaymentSA.getServiceAgreementType().getId().getSaType().trim().
        		equalsIgnoreCase(overpaymentSAType.trim())) {
        	//Retrieve the account using the overpayment SA
        	account = overpaymentSA.getAccount();
        	//If overpayment SA is closed , 
        	//close the To dos linked to this loan SA 
        	//Start Change JVitug - CCB022.Issue3 - 2021-05-12
        	//if(overpaymentSA.getStatus().isClosed()) {
        	for(ServiceAgreement opSA : getOtherOverpaymentSAs()) {
        		//If even one overpayment SA of the account has its total balance greater than or equal to the
        		//pay-off balance  threshold parameter, halt processing
        		BigDecimal saTotalAmount = opSA.getFinancialBalances().getTotalAmount().getAmount().abs();
        		if(saTotalAmount.compareTo(amountThreshold) >= 0) {
        			return;
        		}
        	} 
        	//End Change JVitug - CCB022.Issue3 - 2021-05-12

        	//Start Delete JVitug - CCB022.Issue3 - 2021-05-012
        	//If there are other Overpayment SAs in pending start
        	//or in stopped Status other than this SA, halt processing
        	//if(getOtherOverpaymentSAs(overpaymentSAId).isTrue()) {
        	//return;
        	//}
        	//End  Delete JVitug - CCB022.Issue3 - 2021-05-012
        	List<SQLResultRow> openTodos = null;
        	ServiceAgreement loanSA = getActiveLoanSA();

        	//Start Add JVitug - CCB022.Issue2 - 2021-04-22
        	if(notNull(loanSA)) {
        		//End Add JVitug - CCB022.Issue2 - 2021-04-22
        		openTodos = getListOfOpenToDos(loanSA);

        		for(SQLResultRow todo : openTodos) {
        			openTodoId = (ToDoEntry_Id) todo.getId("TD_ENTRY_ID" , ToDoEntry.class);
        			openTodo = openTodoId.getEntity();
        			todoChars = openTodo.getCharacteristics();

        			//Iterate through the To do Characteristics to prevent
        			//the lazy initialization exception
        			for(ToDoEntryCharacteristic todoChar : todoChars) {
        				CharacteristicTypeValues charTypeValues = todoChar.fetchIdCharacteristicType().
        						getId().getEntity().getValues();
        			}
        			openTodo.complete(true);
        		}
        		//Start Add JVitug - CCB022.Issue2 - 2021-04-22	
        	}
        	//End Add JVitug - CCB022.Issue2 - 2021-04-22
        	//Start Delete JVitug - CCB022.Issue3 - 2021-05-17
        	//}
        	//End Delete JVitug - CCB022.Issue3 - 2021-05-17

        }
        
        
    }
    
    /**
     * This method will retrieve all the Open To Dos 
     * whose key value is the loan SA supplied to this method
     * @param loanSA
     * @return
     */
    private List<SQLResultRow> getListOfOpenToDos(ServiceAgreement loanSA) {
    	List<SQLResultRow> openTodos = null;
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "TD.TD_ENTRY_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_TD_ENTRY TD, ");
    	sql.append(   "CI_TD_DRLKEY KY ");
    	sql.append("WHERE ");
    	sql.append(   "TD.TD_TYPE_CD = :todoType ");
    	sql.append("AND ");
    	sql.append(   "TD.ENTRY_STATUS_FLG IN (:open , :beingWorkedOn) ");
    	sql.append("AND ");
    	sql.append(   "TD.TD_ENTRY_ID = KY.TD_ENTRY_ID ");
    	sql.append("AND ");
    	sql.append(   "KY.KEY_VALUE = :loanSA ");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("todoType" , todoTypeForOverpayment.getId());
    	stmt.bindLookup("open" , ToDoEntryStatusLookup.constants.OPEN);
    	stmt.bindLookup("beingWorkedOn" , ToDoEntryStatusLookup.constants.BEING_WORKED_ON);
    	stmt.bindId("loanSA", loanSA.getId());
    	
    	openTodos = stmt.list();
    	stmt.close();
    	
    	return openTodos;
    }
    
    /**
     * This method will return an active Loan SA linked to the
     * account being processed.
     * @return
     */
    private ServiceAgreement getActiveLoanSA() {
    	ServiceAgreement loanSA = null;
    	
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "SA.SA_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_SA SA, ");
    	sql.append(   "CI_SA_TYPE SAT ");
    	sql.append("WHERE ");
    	sql.append(   "SA.ACCT_ID = :account ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_STATUS_FLG = :active ");
    	sql.append("AND ");
    	sql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
    	sql.append("AND ");
    	sql.append(   "SAT.SVC_TYPE_CD = :loanServiceType ");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("account" , account.getId());
    	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
    	stmt.bindId("loanServiceType", loanServiceType.getId());
    	
    	SQLResultRow result = stmt.firstRow();
    	stmt.close();
    	
    	if(notNull(result)){
    		loanSA = result.getEntity("SA_ID", ServiceAgreement.class);
    	}
    	
    	return loanSA;
    }
    
  
    /**
     * This method will return other Overpayment SAs linked to the
     * account being processed.
     * @return
     */
    //Start Change JVitug - CCB022.Issue3 - 2021-05-012
    //private Bool getOtherOverpaymentSAs(ServiceAgreement_Id saBeingProcessed) {
    private ArrayList<ServiceAgreement> getOtherOverpaymentSAs() {
    	//Bool hasOtherOverpaymentSAs = Bool.FALSE;
    	ArrayList<ServiceAgreement> otherOverpaymentSAs = new ArrayList<ServiceAgreement>();
    //End Change JVitug - CCB022.Issue3 - 2021-05-012
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "SA.SA_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_SA SA ");
    	sql.append("WHERE ");
    	sql.append(   "SA.ACCT_ID = :account ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_STATUS_FLG in (:pendingStart , :stopped) ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_TYPE_CD = :saType ");
    	//Start Delete JVitug - CCB022.Issue3 - 2021-05-012
    	//sql.append("AND ");
    	//sql.append(   "SA.SA_ID <> :saID ");
    	//End Delete JVitug - CCB022.Issue3 - 2021-05-012
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("account" , account.getId());
    	stmt.bindLookup("pendingStart" , ServiceAgreementStatusLookup.constants.PENDING_START);
    	stmt.bindLookup("stopped" , ServiceAgreementStatusLookup.constants.STOPPED);
    	stmt.bindString("saType" ,overpaymentSAType , "SA_TYPE_CD");
    	//Start Delete JVitug - CCB022.Issue3 - 2021-05-12
    	//stmt.bindId("saID", saBeingProcessed);
    	//End Delete JVitug - CCB022.Issue3 - 2021-05-12
    	
    	List<SQLResultRow> result = stmt.list();
    	stmt.close();
    	
    	if(result.size() > 0){
    		//Start Change JVitug - CCB022.Issue3 - 2021-05-12
    		//hasOtherOverpaymentSAs = Bool.TRUE;
    		for(SQLResultRow row : result) {
    			ServiceAgreement overpaymentSA = row.getEntity("SA_ID" , ServiceAgreement.class);
    			otherOverpaymentSAs.add(overpaymentSA);
    		}
    		//End Change JVitug - CCB022.Issue3 - 2021-05-12
    	}
    	
    	//Start Change JVitug - CCB022.Issue3 - 2021-05-12 
    	//return hasOtherOverpaymentSAs;
    	return otherOverpaymentSAs;
    	//End Change JVitug - CCB022.Issue3 - 2021-05-12
    }
    
  
    
}
