/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will check if the account's collection class is the
 * FCAP collection class, and if so, will use the FCAP threshold to 
 * determine the account's eligibility for collections cancellation. If 
 * the account's collection class is not the FCAP collection class, the 
 * algorithm will use the default threshold to determine the account's 
 * eligibility for collections cancellation.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2018-11-27	JHERNA		SysAid#271016. Initial Version
 * 2025-11-14   EQuint      CCB25.4 Upgrade                                         
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.debtClass.algorithm.collectionProcess;

import java.math.BigInteger;
import java.util.Iterator;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.algorithm.Algorithm_Id;
import com.splwg.ccb.api.lookup.ArrearsCollectionLimitOptionLookup;
import com.splwg.ccb.api.lookup.ArrearsInformationSourceLookup;
import com.splwg.ccb.api.lookup.CollectionStatusLookup;
import com.splwg.ccb.api.lookup.CollectionStatusReasonLookup;
import com.splwg.ccb.api.lookup.DebtClassAlgorithmEntityLookup;
import com.splwg.ccb.cobol.ci.CobolCopybookCICCOARN;
import com.splwg.ccb.cobol.ci.CobolCopybookCICCOARN.OUTPUT_WRK;
import com.splwg.ccb.cobol.ci.CobolCopybookCICCOARN.OUTPUT_WRK.PP_COLL.PPSP_COLL_Row;
import com.splwg.ccb.cobol.ci.CobolCopybookCICCOARN.OUTPUT_WRK.PP_COLL_Row;
import com.splwg.ccb.cobol.ci.CobolProgramCIPCOARN;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass;
import com.splwg.ccb.domain.admin.debtClass.algorithm.collectionProcess.DebtClassCollectionProcessAlgorithmSpot;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass;
import com.splwg.ccb.domain.common.currency.entity.Currency;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoArrearsCollection;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoParameters;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoResults;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlan_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;


/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = collectionClass, name = collectionClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = collectionClassDebtClassThreshold, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = defaultDebtClassThreshold, required = true, type = decimal)})
 */
public class CmLIPCollectionProcessCancellationAlgComp_Impl 
		extends CmLIPCollectionProcessCancellationAlgComp_Gen 
		implements DebtClassCollectionProcessAlgorithmSpot {

	/*HARD PARAMETERS*/
	// Input
	private Account hpAccount;
	private Bool hpCalculateOnlySw;
	private DebtClass hpDebtClass;
	@SuppressWarnings("unused")
	private Bool hpMustUseInputPaymentPlanSw;
	private Date hpPaymentPlanCurrentScheduledDate;
	private Money hpPaymentPlanCurrentTotalAmount;
	private PaymentPlan_DTO hpPaymentPlanDTO;
	private Date hpPaymentPlanFutureScheduledDate;
	private Money hpPaymentPlanFutureTotalAmount;
	// Output
	private Money hpOutputArrearsAmount;
	private Money hpOutputCancellationThresholdAmount;
	private Bool hpOutputDoesActiveCollectionProcessExistsSw;
	// start add - equint - 2025-11-14 - CCB25.4 Upgrade
	private Money hpUnadjustedArrearsAmount;
	// end add - equint - 2025-11-14 - CCB25.4 Upgrade

	/*SOFT PARAMETERS*/
	private CollectionClass parmCollectionClass;
	private BigDecimal parmCollClassDebtClassThreshold;
	private BigDecimal parmDefaultDebtClassThreshold;
	
	/*WORK VARIABLES*/
	private String wAlgorithmCode;
	private Date wProcessDate;
	private Bool wEligibleForCollProcSw;
	private Currency wCurrency;
	
	/*CONSTANTS*/
	private static final Date CI_CONST_MAX_DATE = new Date(4712, 12, 31);	
	
	@Override
	public Money getArrearsAmount() {
		// TODO Auto-generated method stub
		return hpOutputArrearsAmount;
	}

	@Override
	public Money getCancellationThresholdAmount() {
		// TODO Auto-generated method stub
		return hpOutputCancellationThresholdAmount;
	}

	@Override
	public Bool getDoesActiveCollectionProcessExist() {
		// TODO Auto-generated method stub
		return hpOutputDoesActiveCollectionProcessExistsSw;
	}

	@Override
	public void setAccount(Account arg0) {
		hpAccount = arg0;
	}

	@Override
	public void setCalculateOnlySwitch(Bool arg0) {
		hpCalculateOnlySw = arg0;
	}

	@Override
	public void setDebtClas(DebtClass arg0) {
		hpDebtClass = arg0;
	}

	@Override
	public void setMustUseInputPaymentPlan(Bool arg0) {
		hpMustUseInputPaymentPlanSw = arg0;
	}

	@Override
	public void setPaymentPlanCurrentScheduledDate(Date arg0) {
		hpPaymentPlanCurrentScheduledDate = arg0;
	}

	@Override
	public void setPaymentPlanCurrentTotalAmount(Money arg0) {
		hpPaymentPlanCurrentTotalAmount = arg0;
	}

	@Override
	public void setPaymentPlanDTO(PaymentPlan_DTO arg0) {
		hpPaymentPlanDTO = arg0;
	}

	@Override
	public void setPaymentPlanFutureScheduledDate(Date arg0) {
		hpPaymentPlanFutureScheduledDate = arg0;
	}

	@Override
	public void setPaymentPlanFutureTotalAmount(Money arg0) {
		hpPaymentPlanFutureTotalAmount = arg0;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		wAlgorithmCode = this.getAlgorithmId().getTrimmedValue();
		wProcessDate = this.getProcessDateTime().getDate();
		wEligibleForCollProcSw = Bool.FALSE;		
		
		// Retrieve Parameter 10: Collection Class
		parmCollectionClass = this.getCollectionClass();
		// Retrieve and validate Parameter 20: Collection Class Debt Class Threshold Amount
		parmCollClassDebtClassThreshold = this.getCollectionClassDebtClassThreshold();
		if (parmCollClassDebtClassThreshold.compareTo(BigDecimal.ZERO) < 0) {
		    // Algorithm %1's parameter '%2%3' value (%4) must be at least zero
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeAtLeastZero(wAlgorithmCode, "Collection Class Debt Class Treshold Amount", parmCollClassDebtClassThreshold.toString().trim()));
		}
		/// Retrieve and validate Parameter 30: Default Debt Class Threshold Amount
		parmDefaultDebtClassThreshold = this.getDefaultDebtClassThreshold();
		if (parmDefaultDebtClassThreshold.compareTo(BigDecimal.ZERO) < 0) {
		    // Algorithm %1's parameter '%2%3' value (%4) must be at least zero
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeAtLeastZero(wAlgorithmCode, "Default Debt Class Treshold Amount", parmDefaultDebtClassThreshold.toString().trim()));			
		}
	}

	@Override
	public void invoke() {

		wCurrency = hpAccount.getCurrency();
		// Proceed only if a collection process exists for the debt class.
		Iterator<SQLResultRow> collProcs = getEligibleCollectionProcess(hpAccount, hpDebtClass);
		if (isNull(collProcs)
				|| !collProcs.hasNext()) {
			// exit the algorithm if there are no active collection process for the debt class.
			hpOutputDoesActiveCollectionProcessExistsSw = Bool.FALSE;
			return;
		}
		
		/*=========================*/
		/* START NEW FUNCTIONALITY */
		/*=========================*/
		//Retrieve account's current collection class and compare it with parameter
		CollectionClass currentCollClass = hpAccount.getCollectionClassId().getEntity();
		BigDecimal thresholdToUse; 
		if (parmCollectionClass.equals(currentCollClass)) {
			thresholdToUse = parmCollClassDebtClassThreshold;				
		}
		else {
			thresholdToUse = parmDefaultDebtClassThreshold;
		}
		/*=======================*/
		/* END NEW FUNCTIONALTIY */	
		/*=======================*/

		while (collProcs.hasNext()) {

			SQLResultRow sqlRow = collProcs.next();
			
			CollectionProcess_Id collProcID = (CollectionProcess_Id) sqlRow.getId("COLL_PROC_ID", CollectionProcess.class);
			Date collectionArrearsDate = sqlRow.getDate("COLL_ARS_DT");
			
			/*  
			 * From HD200-DETERMINE-MAX-DAY-AGE
			 * MAX DAY AGE = PROCESS-DT - COLL-ARS-DT
			 */
			long diffResult = wProcessDate.difference(collectionArrearsDate).getTotalDays();
			BigInteger maxDayAge = BigInteger.valueOf(diffResult);
			
			// Determine the account/debt class balances
			ArrearsInfoParameters arrsInfoParms = ArrearsInfoParameters.Factory.newInstance();
			arrsInfoParms.setAccount(hpAccount);		
			arrsInfoParms.setDebtClass(hpDebtClass);
			arrsInfoParms.setArrearsSource(ArrearsInformationSourceLookup.constants.DEBT_CLASS);
			arrsInfoParms.setMustExcludeSaInSeverance(Bool.FALSE);
			arrsInfoParms.setReferenceDate(wProcessDate);
			arrsInfoParms.setCreditReferenceDate(CI_CONST_MAX_DATE);
			arrsInfoParms.setOldestBucketAgeDays(maxDayAge);
			arrsInfoParms.setMustReturnCumulativeArrears(Bool.FALSE);
			arrsInfoParms.setMustReturnTotalAmount(Bool.FALSE);
			arrsInfoParms.setMustReturnNewDebits(Bool.FALSE);
			arrsInfoParms.setCollectionLimitOption(ArrearsCollectionLimitOptionLookup.constants.LUMP_ARREARS);
			
			ArrearsInfoResults accountArrearsResult = hpAccount.fetchArrearsInfoForDebtClass(arrsInfoParms);
			
			/*
			 * If Arrears found, subject the account/debt class balances to the Override Arrears Algorithm
			 */
			if (accountArrearsResult.getArrearsDetailsCount().compareTo(BigInteger.ZERO) > 0) {
				
				Algorithm overrideArrearsAlgo = getDebtClassAlgorithm(hpDebtClass, DebtClassAlgorithmEntityLookup.constants.OVERRIDE_ARREARS_DUE_TO_PAY_PLAN);

				if (notNull(overrideArrearsAlgo)) {
					
					/*=================================*/
					/* These sections is from CIPCOARX */
					/*=================================*/
					
					/* Build a list of account's active pay plan(s) */
					/*=========================*/
					/*===HC000-BUILD-PP-COLL===*/
					/*=========================*/
					CobolProgramCIPCOARN cobolCOARN = CobolProgramCIPCOARN.Factory.newInstance();
					CobolCopybookCICCOARN coarn = cobolCOARN.getCobolCopybookCICCOARN();
					coarn.get_INPUT_WRK().set_ACCT_ID(hpAccount.getId().getTrimmedValue());
					coarn.get_INPUT_WRK().set_PP_CURR_SCHED_DT(hpPaymentPlanCurrentScheduledDate);
					coarn.get_INPUT_WRK().set_PP_CURR_TOT_AMT(hpPaymentPlanCurrentTotalAmount.getAmount());
					coarn.get_INPUT_WRK().set_DEBT_CL_CD(hpDebtClass.getId().getTrimmedValue());
					coarn.get_INPUT_WRK().set_PP_FUT_SCHED_DT(hpPaymentPlanFutureScheduledDate);
					coarn.get_INPUT_WRK().set_PP_FUT_TOT_AMT(hpPaymentPlanFutureTotalAmount.getAmount());
					coarn.get_INPUT_WRK().set_PP_ID(hpPaymentPlanDTO.getId().getTrimmedValue());
					// since we are using CIPCOARN then use input PP sw will be turned off. 
					//coarn.get_INPUT_WRK().set_USE_INPUT_PP_SW(hpMustUseInputPaymentPlanSw);
					//coarn.get_INPUT_WRK().set_THRD_PTY_SW(data);
					coarn.get_INPUT_WRK().set_USE_INPUT_PP_SW(Bool.FALSE);
					cobolCOARN.callCobol();		
					
					OUTPUT_WRK overrideOutput =  coarn.get_OUTPUT_WRK();
					/* Process pay plan for each payor */
					for (int currPpIndex = 1; currPpIndex <= overrideOutput.get_PP_DETAIL_CNT().intValue(); currPpIndex++) {
						/*
						 * Reduce the aged debt with remaining scheduled payments
						 * The way of calculation depends on how the arrears 
						 * were calculated
						 * 
						 * note: since we know that msut return cumulative arrears sw is false then we will 
						 * skip the check and will not include HE100-REDUCE-AC-DC-DEBT-CUM
						 */
						PP_COLL_Row ppCollRow = overrideOutput.get_PP_COLL().getArrayElement(currPpIndex);
						/*=============================*/
						/*===HE000-REDUCE-AC-DC-DEBT===*/
						/*=============================*/
						he000ReduceAcDcDebt(accountArrearsResult, ppCollRow);						
					}
					/*======================*/
					/*=END CIPCOARX Section=*/
					/*======================*/
					
					/* If the manipulated debt satisifes the collection process */
					/* cancellation threshold, cancel the collection process    */
					/* HHH000-CHECK-COLL-PROC-ELIG */
					
					/* Find if account has arrears on the Max Day Age (this should    */
					/* be debts older than arrears date). Compare it to the threshold */
					/* (collection class specific debt class threshold)               */
					if (accountArrearsResult.getArrearsDetailsCount().compareTo(BigInteger.ZERO) > 0) {
						/* Find the row which holds the MAX DAY AGE debt */		
						Iterator<ArrearsInfoArrearsCollection> acctArrsIter = accountArrearsResult.getArrearsDetails().iterator();
						while (acctArrsIter.hasNext()) {
							ArrearsInfoArrearsCollection arrsInfoArrsColl = acctArrsIter.next();
							BigDecimal arrearsAmount = arrsInfoArrsColl.getArrearsAmount().getAmount();

							if (arrsInfoArrsColl.getDaysAged().compareTo(maxDayAge) > 0) {

								if (arrearsAmount.compareTo(thresholdToUse) <= 0) {
									wEligibleForCollProcSw = Bool.FALSE;
								}
								else {
									wEligibleForCollProcSw = Bool.TRUE;
								}
								hpOutputArrearsAmount = new Money(arrearsAmount, wCurrency.getId());
								break;
							}
						}						
					}
					else {
						/* No arrears found */
						wEligibleForCollProcSw = Bool.FALSE;
					}										
//					@SuppressWarnings("deprecation")
//					DebtClassPayPlanOverrideArrearsAlgorithmSpot dcPpOverrideArrearsAlgoSpot = overrideArrearsAlgo.getAlgorithmComponent(DebtClassPayPlanOverrideArrearsAlgorithmSpot.class);
////							AlgorithmComponentCache.getAlgorithmComponent(overrideArrearsAlgo.getId(), DebtClassPayPlanOverrideArrearsAlgorithmSpot.class);
//					
//					dcPpOverrideArrearsAlgoSpot.setAccount(hpAccount);
//					dcPpOverrideArrearsAlgoSpot.setArrearsDetails(accountArrearsResult.getArrearsDetails());
//					dcPpOverrideArrearsAlgoSpot.setCurrentScheduledDate(hpPaymentPlanCurrentScheduledDate);
//					dcPpOverrideArrearsAlgoSpot.setCurrentTotalAmount(hpPaymentPlanCurrentTotalAmount);
//					dcPpOverrideArrearsAlgoSpot.setDebtClass(hpDebtClass);
//					dcPpOverrideArrearsAlgoSpot.setFutureScheduledDate(hpPaymentPlanFutureScheduledDate);
//					dcPpOverrideArrearsAlgoSpot.setFutureTotalAmount(hpPaymentPlanFutureTotalAmount);
//					dcPpOverrideArrearsAlgoSpot.setMustReturnCumulativeArrears(Bool.FALSE);
//					dcPpOverrideArrearsAlgoSpot.setPaymentPlan(hpPaymentPlanDTO.getEntity());
//					dcPpOverrideArrearsAlgoSpot.setUseInputPaymentPlan(hpMustUseInputPaymentPlanSw);
//					dcPpOverrideArrearsAlgoSpot.invoke();
				}			
			}
			else {
				/* No arrears found */
				wEligibleForCollProcSw = Bool.FALSE;
			}
			/* If no longer eligible for collection process, cancel the collection process */
			if (wEligibleForCollProcSw.isFalse()
					&& hpCalculateOnlySw.isFalse()) {
				
				collProcID.getEntity().cancel(CollectionStatusReasonLookup.constants.CANCELEDBY_SYSTEM);
				hpOutputDoesActiveCollectionProcessExistsSw = Bool.FALSE;
			}
			else {
				/* If still eligible, indicate that there is still an  */
				/* active collection process for account/debt class    */
				hpOutputDoesActiveCollectionProcessExistsSw = Bool.TRUE;
			}
						
			hpOutputCancellationThresholdAmount = new Money(thresholdToUse, hpAccount.getCurrency().getId());
		}	
	}
	
	private Algorithm getDebtClassAlgorithm(DebtClass debtClass, DebtClassAlgorithmEntityLookup overrideArrears) {
		
		Algorithm returnValue = null;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("  ALG_CD ");
		stringBuilder.append("FROM ");
		stringBuilder.append("  CI_DC_ALG ");
		stringBuilder.append("WHERE  ");
		stringBuilder.append("  DEBT_CL_CD = :debtClass ");
		stringBuilder.append("  AND DC_ALG_ENTITY_FLG = :overrideArrears ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
				"==CmLIPCollectionProcessCancellationAlgComp.getDebtClassAlgorithm==");
		prepState.bindId("debtClass", debtClass.getId());
		prepState.bindLookup("overrideArrears", overrideArrears);
		prepState.setAutoclose(false);
		prepState.execute();
		
		if (notNull(prepState.firstRow())) {
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Algorithm_Id algID = (Algorithm_Id) sqlRow.getId("ALG_CD", Algorithm.class);
			returnValue = algID.getEntity();
		}
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getEligibleCollectionProcess(Account account, DebtClass debtClass) {
				
		/*note: this SQL is from base CIPLACPN*/
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("  CP.COLL_PROC_ID, ");
		stringBuilder.append("  CP.ACCT_ID, ");
		stringBuilder.append("  CP.COLL_STATUS_FLG, ");
		stringBuilder.append("  CP.COLL_STAT_RSN_FLG, ");
		stringBuilder.append("  CP.COLL_CL_CNTL_CD, ");
		stringBuilder.append("  CP.COLL_CAT_PRIO_FLG, ");
		stringBuilder.append("  CP.CRIT_PRIO_FLG, ");
		stringBuilder.append("  CP.COLL_PROC_TMPL_CD, ");
		stringBuilder.append("  CP.CRE_DTTM, ");
		stringBuilder.append("  CP.COLL_ARS_DT, ");
		stringBuilder.append("  CP.ARS_AMT, ");
		stringBuilder.append("  CP.CURRENCY_CD, ");
		stringBuilder.append("  CP.TRIGGER_BP_SW, ");
		stringBuilder.append("  CP.COMMENTS ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("  CI_COLL_PROC CP, ");
		stringBuilder.append("  CI_COLL_CL_CNTL CCC ");
		stringBuilder.append("WHERE ");
		stringBuilder.append("  CP.ACCT_ID = :acctID ");
		stringBuilder.append("  AND CP.COLL_CL_CNTL_CD = CCC.COLL_CL_CNTL_CD ");
		stringBuilder.append("  AND CCC.DEBT_CL_CD = :debtClass ");
		stringBuilder.append("  AND CCC.CIS_DIVISION = :cisDivision ");
		stringBuilder.append("  AND CP.COLL_STATUS_FLG = :activeStatus ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
				"\n==CmLIPCollectionProcessCancellationAlgComp.getEligibleCollectionProcess==\n");
		prepState.bindId("acctID", account.getId());
		prepState.bindId("debtClass", debtClass.getId());
		prepState.bindId("cisDivision", account.getDivisionId());
		prepState.bindLookup("activeStatus", CollectionStatusLookup.constants.ACTIVE);
		prepState.setAutoclose(false);
		prepState.execute();
		Iterator<SQLResultRow> returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private void he000ReduceAcDcDebt(ArrearsInfoResults accountArrearsResult, PP_COLL_Row ppCollRow) {
		
		/* Reduce the passed in aged debt with remaining scheduled */
		/* payments, off-setting the oldest debt first.             */
		
		for (int x = 1; x <= accountArrearsResult.getArrearsDetailsCount().intValue(); x++) {
			
			ArrearsInfoArrearsCollection acctArrears = accountArrearsResult.getArrearsDetails().get(x);
			BigDecimal acctArrearsArrearsAmount = acctArrears.getArrearsAmount().getAmount();
			
			for (int y = 1; y <= ppCollRow.get_PPSP_DETAIL_CNT().intValue()
					|| acctArrearsArrearsAmount.compareTo(BigDecimal.ZERO) <= 0; y++) {
				
				PPSP_COLL_Row ppspCollRow = ppCollRow.get_PPSP_COLL().getArrayElement(y);
				
				if (acctArrearsArrearsAmount.compareTo(ppspCollRow.get_PP_SCHED_AMT()) >= 0) {
					BigDecimal resultingArsAmt = acctArrearsArrearsAmount.subtract(ppspCollRow.get_PP_SCHED_AMT());
					acctArrears.setArrearsAmount(new Money(resultingArsAmt, wCurrency.getId()));
					ppspCollRow.set_PP_SCHED_AMT(BigDecimal.ZERO);
				}
				else {
					BigDecimal resultingppSchedAmt = ppspCollRow.get_PP_SCHED_AMT().subtract(acctArrearsArrearsAmount);
					ppspCollRow.set_PP_SCHED_AMT(resultingppSchedAmt);
					acctArrears.setArrearsAmount(new Money(BigDecimal.ZERO, wCurrency.getId()));
				}
			}
		}		
	}

	// start update - equint - 2025-11-14 - CCB25.4 Upgrade
	@Override
	public Money getUnadjustedArrearsAmount() {
		return hpUnadjustedArrearsAmount;
	}
	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
}
