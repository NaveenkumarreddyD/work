/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB001: ITRON Meter Read Download Batch
 * 
 * This background process will use the information stored on the 
 * Meter Read Staging Download table (CI_MR_STAGING_DWN) to generate
 * a flat file that will be used to interface to ITRON.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-01-26   DHuynh          MGE-CCB001: Initial Version. 
 * 2015-04-27   DHuynh          Defect #3200203: Fix NullPointerException 
 *                              error when no record to process
 * 2015-06-23   DHuynh          Defect #3239081: Modify code to accomplish 
 *                              execution of Succession Read as well. Using
 *                              the same code.  
 * 2015-08-06	JHERNA			Defect #3269752. Updated the format for the
 *                              meter readings. Meter reading fields will 
 *                              now have no decimal points.     
 * 2015-08-11	JHERNA			Defect #3277214. Updated the code to simply
 * 								use hard coded value for the next line. 
 * 								next line value should be "\CRLF" aka "\r\n"     
 * 2015-08-14	JHERNA			Defect #3282313. Updated the code as per 
 * 								request to write the MTS and then MTX records
 * 								immediately after the MTR record.      
 * 2015-08-17	JHERNA			Request to revert back the order. 
 * 								MTR>MTX>MTS
 * 2015-09-09	JHERNA			Defect #3299251. Updated the code so that
 * 								data issue would not cause batch job termination.
 * 2015-09-02	SMiran			Defect 3296586. Succession Reads - Changes 
 * 								to MDL - The Route Type must be S, not A or O    
 * 2015-12-01	DHuynh			SA#56274: update code to 
 * 								-Write out record in route sequence number asc
 * 								-Count each 'CUS' record as 1 customer
 * 								-Change hilo value as 'usage value' not the index
 * 								 on the meter
 * 2015-12-08	JHERNA			SysAid#73195. Peformance Issue. 
 * 2015-12-14	DHuynh			SA#74569: update main query to exclude checking
 *   							the cycle&route to accomplish for sucessionRead  
 * 2016-02-18   MPang			Updated for CCB v2.4 compilation.    
 * SA-211192	DarrylH			06/1/17 Add office area to ERH record. 
 * 								for PR1800 ITRON upgrade project.    
 * SA-220105	DarrylH			07/19/17: Add office area '99' to ERH record
 * 								for succession read process 'CM-MDLSC'  
 * SA-223188	DarrylH			1/8/18: don't calculate hilo since FCS do not use
 * 								this will help performance issue.
 * SA-272431 	DarrylH			Modify SQL Statement to include the single quote "'"
 * 								Surround the where clause    
 * CCB v2.6 Upgrade  SRoman	    12/11/18: Merged the changes from Spire PRD version 
 *  							for the 2.4 to 2.6 Upgrade Activity.         
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.Iterator;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.base.domain.common.geographicType.GeographicType;
import com.splwg.base.domain.common.geographicType.GeographicType_Id;
import com.splwg.ccb.api.lookup.EstimateTypeLookup;
import com.splwg.ccb.api.lookup.ItemStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
import com.splwg.ccb.cobol.mr.CobolCopybookCICMDBRN;
import com.splwg.ccb.cobol.mr.CobolProgramCIPMDBRN;
//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.admin.meterReadCycle.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadCycle.MeterReadCycle_Id;
import com.splwg.ccb.domain.admin.meterReadRouteType.MeterReadRouteType;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.Item;
import com.splwg.ccb.domain.meterread.item.ItemCharacteristic;
import com.splwg.ccb.domain.meterread.item.Item_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meterConfiguration.HighLowCalculationAlgorithmData;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory_Id;*/

import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle_Id;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.entity.Item;
import com.splwg.ccb.domain.meterread.item.entity.ItemCharacteristic;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.data.HighLowCalculationAlgorithmData;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadCustomerDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadCycleHeaderRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadFileHeaderRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadMeterDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadMeterExtraDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadMeterSpecialMessageDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadRadioDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadReadingDetailRecord;
import com.splwg.cm.api.batch.CmITRONMeterReadDownloadRouteHeaderRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;
/**
 * @author 08831
 *
 @BatchJob (modules={},softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ERT_100G, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ERT_40G, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = meterReadRouteType, name = I_AMR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = meterReadRouteType, name = I_OMR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = CM_ITRONCONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = geographicType, name = GEO_LATLONG_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = geographicType, name = GEO_GRID_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOWN_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = I_MTR_TYP_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ERT_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = itemType, name = ERT_ITEM_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)})
 */
public class CmITRONMeterReadDownloadBatch 
	extends CmITRONMeterReadDownloadBatch_Gen {


	// Soft Parameters
	private String parmFilePath;
	@SuppressWarnings("unused")
	private String parmFileName;
	@SuppressWarnings("unused")
	private static final String PROG_NAME_WITH_PATH = "com.splwg.cm.domain.batch.CmITRONMeterReadDownloadBatch.java";
	
	// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
//	@Override
//	public void validateSoftParameters(boolean arg0) {
//
//		// Retrieve Parameter 10: File Path
//		parmFilePath = this.getParameters().getFILE_PATH();
//		// Validate that parameter is a valid file path
//		String parm10Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME_WITH_PATH, BigInteger.TEN);
//		
//		cmOuterValidateFilePath(parmFilePath, parm10Desc);
//		// Retrieve Parameter 20: File Name
//		parmFileName = this.getParameters().getFILE_NAME();
//	}
	private static final String PARM10DESC = "File Path";
	@Override
	public void validateSoftParameters(boolean arg0) {

		// Retrieve Parameter 10: File Path
		parmFilePath = this.getParameters().getFILE_PATH();
		// Validate that parameter is a valid file path
		String parm10Desc = PARM10DESC;		
		cmOuterValidateFilePath(parmFilePath, parm10Desc);
		// Retrieve Parameter 20: File Name
		parmFileName = this.getParameters().getFILE_NAME();
	}
	// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
	// START DELETE - JHERNA - 2015-12-08 - SysAid#73195
//	/**
//	 * Custom method which retrieves the Batch Parameter Description
//	 * @param progName the programe and the package where the program is located
//	 * @param parmSeq the parameter sequence
//	 * @return returnValue the parameter description
//	 */
//	private String cmOutRetrieveBatchParameterDescription(String progName, BigInteger parmSeq) {
//
//		String returnValue = " ";		
//		StringBuilder stringBuilder = new StringBuilder();				
//		stringBuilder.append("SELECT BCPL.DESCR50 ");
//		stringBuilder.append("FROM CI_BATCH_CTRL_P_L BCPL, CI_BATCH_CTRL BC ");
//		stringBuilder.append("WHERE BC.PROGRAM_NAME = :progName ");
//		stringBuilder.append("AND BC.PGM_TYPE_FLG = :javaType ");
//		stringBuilder.append("AND BCPL.BATCH_CD = BC.BATCH_CD ");
//		stringBuilder.append("AND BCPL.LANGUAGE_CD = :language ");
//		stringBuilder.append("AND BCPL.SEQ_NUM = :parmSeq ");
//
//		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
//		prepState.bindStringProperty("progName", BatchControl.properties.programName, progName);
//		prepState.bindLookup("javaType", ProgramTypeLookup.constants.JAVA);
//		prepState.bindId("language", this.getActiveContextLanguage().getId());
//		prepState.bindBigInteger("parmSeq", parmSeq);
//		prepState.execute();
//		if (prepState.list().size() > 0) {
//			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
//			returnValue = (String) sqlRow.get("DESCR50");
//		}
//		prepState.close();
//		return returnValue;
//	}
	// END DELETE - JHERNA - 2015-12-08 - SysAid#73195

	/**
	 * Custom method which validates that the file path is a valid directory
	 * @param filePath
	 * @param parmDesc
	 */
	private void cmOuterValidateFilePath(String filePath, String parmDesc) {

		File fileValidator = new File(filePath.trim());		
		if (isNull(fileValidator)
				|| !fileValidator.isDirectory()) {
			// Batch parameter '%1%2' value (%3%4) is not a valid file path.
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(
					parmDesc.trim(),
					filePath.trim()));
		}
	}
	
	@SuppressWarnings("unchecked")
	public JobWork getJobWork() {

		QueryIterator queryIter = cmMainSelectionCriteria();
		return createJobWorkForQueryIterator(queryIter, this);
	}
	//	*Start Change - DHuynh - 2015-12-01 - Defect#56274
	/**
	 * Custom method which retrieves the records to be processed
	 * @return QueryIterator object
	 */
	private QueryIterator cmMainSelectionCriteria() {

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT MRD.MR_CYC_CD, MRD.SCHED_SEL_DT, MRD.MR_RTE_CD, MRD.SP_MTR_HIST_ID ");
		stringBuilder.append("FROM CI_MR_STAGE_DWN MRD, CI_SP SP, CI_SP_MTR_HIST SPMH ");
		stringBuilder.append("WHERE BATCH_CD = :batchCd ");
		stringBuilder.append("AND BATCH_NBR = :batchNbr ");
		stringBuilder.append("AND SPMH.SP_MTR_HIST_ID = MRD.SP_MTR_HIST_ID ");
		stringBuilder.append("AND SP.SP_ID = SPMH.SP_ID ");
		//*Start Change - DHuynh - 2015-12-14 - Defect#74569
		//stringBuilder.append("AND SP.MR_CYC_CD = MRD.MR_CYC_CD ");
		//stringBuilder.append("AND SP.MR_RTE_CD = MRD.MR_RTE_CD ");
		//*End Change - DHuynh - 2015-12-14 - Defect#74569
		stringBuilder.append("ORDER BY MR_CYC_CD, MR_RTE_CD, SP.MR_CYC_RTE_SEQ, SP_MTR_HIST_ID ");
		
		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("batchCd", this.getBatchControlId());
		prepState.bindBigInteger("batchNbr", this.getBatchNumber());
		prepState.execute();
		return prepState.iterate();
	}
	//	*End Change - DHuynh - 2015-12-01 - Defect#56274
	/**
	 * Base method which creates the Work Unit that will be processed by the batch worker
	 */
	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
//		ThreadWorkUnit twu = new ThreadWorkUnit();
//		String mrCycCdStr = (String) qrw.get("MR_CYC_CD");
//		Date schedSelDate = (Date) qrw.getDate("SCHED_SEL_DT");
//		String mrRteCdStr = (String) qrw.get("MR_RTE_CD");
//		String spMtrHistIdStr = (String) qrw.get("SP_MTR_HIST_ID");
//
//		MeterReadSchedule_Id mrScheduleID = new MeterReadSchedule_Id(new MeterReadCycle_Id(mrCycCdStr), schedSelDate);
//		MeterReadScheduleRoute_Id mrScheduleRouteID = new MeterReadScheduleRoute_Id(mrScheduleID, mrRteCdStr);
//
//		ServicePointMeterHistory_Id spMtrHistID = new ServicePointMeterHistory_Id(spMtrHistIdStr);
//		MeterReadDownload_Id mrStagingDownloadID = new MeterReadDownload_Id(mrScheduleRouteID, spMtrHistID);
//
//		twu.setPrimaryId(mrStagingDownloadID);
//	//*	Start Add - DHuynh - 2015-06-26 - Defect#3239081
//	
//		twu.addSupplementalData("mrCycCdStr", mrCycCdStr);
//		twu.addSupplementalData("schedSelDate", schedSelDate);
//		twu.addSupplementalData("mrRteCdStr", mrRteCdStr);
//		twu.addSupplementalData("spMtrHistIdStr", spMtrHistIdStr);		
//	//* End Add - DHuynh - 2015-06-26 - Defect#3239081	
//		return twu;
		ThreadWorkUnit twu = new ThreadWorkUnit();
		MeterReadCycle_Id meterReadCycleID = (MeterReadCycle_Id) qrw.getId("MR_CYC_CD", MeterReadCycle.class);
		Date schedSelDate = (Date) qrw.getDate("SCHED_SEL_DT");
		String mrRteCdStr = (String) qrw.get("MR_RTE_CD");
		ServicePointMeterHistory_Id spMtrHistID = (ServicePointMeterHistory_Id) qrw.getId("SP_MTR_HIST_ID", ServicePointMeterHistory.class);
		
		twu.setPrimaryId(spMtrHistID);
		twu.addSupplementalData("MR_CYC_CD", meterReadCycleID);
		twu.addSupplementalData("SCHED_SEL_DT", schedSelDate);
		twu.addSupplementalData("MR_RTE_CD", mrRteCdStr);
		
		return twu;
		// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
	}
	
	public Class<CmITRONMeterReadDownloadBatchWorker> getThreadWorkerClass() {
		return CmITRONMeterReadDownloadBatchWorker.class;
	}
	/**
	 * The Inner Class / Batch Worker
	 */
	public static class CmITRONMeterReadDownloadBatchWorker 
		extends CmITRONMeterReadDownloadBatchWorker_Gen {

		// Soft Parameters
		private String parmFileName;
		private String parmFilePath;
		private GeographicType parmGeoType;
		private CharacteristicType parmErtCharType;
		private ItemType parmErtItemTypeCode;
		private String parmErt_100g;
		private String parmErt_40g;
		private MeterReadRouteType parmI_AMR;
		private MeterReadRouteType parmI_OMR;
		private CharacteristicType parmTmprCharType;
		private ServiceTaskType parmServiceTaskType;
		private CharacteristicType parmTownCodeCharType;
		private CharacteristicType parmMeterCharType;
		private GeographicType parmGridGeoType;
		// Constants
		private static final String THREAD_PLACE_HOLDER = "??"; 
		private static final String UNDERSCORE = "_";
		private static final String BACKSLASH = "/";
		private static final String FORWARDSLASH = "\\";
		private static final String RECORD_TYPE_FILEHDR = "FHD";
		private static final String RECORD_TYPE_CYLHDR = "CHD";
		private static final String RECORD_TYPE_ROUTEHDR = "ERH";
		private static final String RECORD_TYPE_ROUTETRLR = "ERT";
		private static final String RECORD_TYPE_CUS = "CUS";
		private static final String RECORD_TYPE_MTR = "MTR";
		private static final String RECORD_TYPE_MTX = "MTX";
		private static final String RECORD_TYPE_MTS = "MTS";
		private static final String RECORD_TYPE_RDG = "RDG";
		private static final String RECORD_TYPE_RFF = "RFF";
		//Start Add - DarrylH - SA211192: 2017-06-01  
		private static final CharacteristicType_Id mgeServingOfficeCharTypeID = new CharacteristicType_Id("OFCLOC");
		private static final CisDivision_Id mgedivision = new CisDivision_Id("MGE");
		//End Add - DarrylH - SA211192: 2017-06-01
		//Start Add - DarrylH - SA-220105: 2017-07-19
		private static final String VALUE_99 = "99";
		//End Add - DarrylH - SA-220105: 2017-07-19
		private static final String INDICATOR_N = "N";
		private static final String INDICATOR_A = "A";
		private static final String INDICATOR_O = "O";
		// 2015-09-02. SMiran. Defect 3296586. Start Add
		private static final String INDICATOR_S = "S";
		// 2015-09-02. SMiran. Defect 3296586. End Add
		private static final String VALUE_0255 = "0255";
		private static final String INDICATOR_Y = "Y";
		private static final String LETTER_L = "L";
		private static final String LETTER_GAS = "GAS ";
		private static final String LETTER_G = "G";
		private static final String TWO_ZERO = "00";
		private static final String RADIO_FREQUENCY = "000956.44375";
		private static final String VALUE_ZERO004 = "0004";
		private static final String VALUE_01 = "01";
		private static final String VALUE_02 = "02";
		private static final String VALUE_06 = "06";
		private static final String LETTER_R = "R";
		private static final String LETTER_K = "K";
		private static final String LETTER_A = "A";
		private static final String LETTER_I = "I";
	
		
		// Work Variables
		private String resultingFilePathName;
		private File file;
		// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
		// Use buffered writer again, for performance gain
		// START CHANGE - JHERNA - 2015-08-11 - 3277214
		private BufferedWriter buffWriter;
		//private FileWriter fileWriter;
		// END CHANGE - JHERNA - 2015-08-11 - 3277214
		// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
		private Premise_Id premId;
		private ServicePoint_Id spId;
		private BigInteger serviceCycleSequence;
		private MeterConfiguration_Id mtrConfigId;
		private Account_Id acctId;
		private String customerName;	
		private String billCode;
		private Meter meter;
		private Register register;
		// Start changes - DarrylH - 2/8/17  - SA-223188
		private String hiLimit = "9999999999";
		private String loLimit = "0000000001";
		// End changes - DarrylH - 2/8/17  - SA-223188
		private String prevRegReading = null;
		private String longitude = null;
		private String latitude = null;
		private COTSInstanceList itronMeterLocationList;
		private COTSInstanceList itronMeterWarnList;
		private COTSInstanceList itronMeterInstructionList;
		private BigInteger totalCycle = BigInteger.ZERO;
		private BigInteger totalRoute = BigInteger.ZERO;
		private BigInteger wTotalErtInRoute = BigInteger.ZERO;
		//*Start Change - DHuynh - 2015-12-01 - Defect#56274
		//private BigInteger wTotalCustInRoute = BigInteger.ZERO;
		private Integer wTotalCustInRoute = 0;
		//*End Change - DHuynh - 2015-12-01 - Defect#56274
		private String scheduleDate = null;
		private Date wScheduleDate = null;
		private String wHoldMeterReadCycle = null;
		private String wHoldRoute = null;
		private String wProcessMeterReadCycle = null;
		private String wProcessRoute = null;
		private Bool isFirstRecord = Bool.TRUE;
		private Bool wWriteRffRecord = Bool.FALSE;
		private Bool isFirstTime = Bool.TRUE;
		private String wHoldCycleheader = null;
		private String wHoldFileheader = null;
		private String wReadMethod = null;
		private String wTamperCode = " ";
		private String wRouteType = null;
		private String wSpSourceStatus = null;	
		private String wErtCharValue = null;
		private String wERTItemBatchNumber = null;	
		private String wGridCode = null;
		private String wTownCode = null;
		private String wAmrSegmentCd = null;			
		private String wHoldCycleForWriteRouteTrailer = null; 
		private String wHoldRouteTypeForWriteRouteTrailer = null;
		private String wHoldRouteForWriteRouteTrailer = null;
		private String wHoldTotalNbrOfMeterInRoute =  null;
		// START DELETE - JHERNA - 2015-12-08 - SysAid#73195
		// This was never used / unnecessary
		//private List<Account_Id> collOfAcctIDs;
		// END DELETE - JHERNA - 2015-12-08 - SysAid#73195
		
		// START ADD - JHERNA - 2015-08-11 - 3277214
		private static final String CARRIAGE_RETURN_LINE_FEED = "\r\n";
		// END ADD - JHERNA - 2015-08-11 - 3277214

		/**
		 * Base method which is invoked once per thread (executed before the main processing)
		 */		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {

			//collOfAcctIDs = new ArrayList<Account_Id>();
			// Retrieve Parameter 10: File Path
			parmFilePath = this.getParameters().getFILE_PATH();
			// Retrieve Parameter 20: File Name
			parmFileName = this.getParameters().getFILE_NAME();
			// Retrieve Parameter 30: Geo Type
			parmGeoType = this.getParameters().getGEO_LATLONG_CD();
			// Retrieve Parameter 40: Ert Type Code
			parmErtCharType = this.getParameters().getERT_CHAR_TYPE_CD();
			// Retrieve Parameter 50: Ert Item Type Code
			parmErtItemTypeCode = this.getParameters().getERT_ITEM_TYPE_CD();
			// Retrieve Parameter 60: Ert 100G
			parmErt_100g = this.getParameters().getERT_100G();
			// Retrieve Parameter 70: Ert 40G
			parmErt_40g = this.getParameters().getERT_40G();
			// Retrieve Parameter 80: Geo Grid Code
			parmGridGeoType = this.getParameters().getGEO_GRID_CD();
			// Retrieve Parameter 90: Town Char Type
			parmTownCodeCharType = this.getParameters().getTOWN_CHAR_TYPE();
			//	Retrieve Parameter 100: Tamper Code
			parmTmprCharType = this.getParameters().getMR_CHAR_TYPE();
			// Retrieve Parameter 110: CM-ITRONCONFIG
			parmServiceTaskType = this.getParameters().getCM_ITRONCONFIG();
			// Retrieve Parameter 120: I_AMR
			parmI_AMR = this.getParameters().getI_AMR();
			// Retrieve Parameter 130: I_AMR
			parmI_OMR = this.getParameters().getI_OMR();
			// Retrieve Parameter 140: Meter Char Type
			parmMeterCharType = this.getParameters().getI_MTR_TYP_CHAR_TYPE();
			
			// Form file path name
			cmFormFilePathName();
			// Open the file
			cmOpenFile(resultingFilePathName);

			// Retrieve the total number of cycle for this run (base on batch number and batch control)
			totalCycle = cmRetrieveCycleCount();

			// Form and write the header record line	
			cmFormFileHeaderRecordLineAndWrite();			
		}
		
		/**
		 * Method to write the header record to a file 
		 */
		private void cmFormFileHeaderRecordLineAndWrite() {
			
			CmITRONMeterReadDownloadFileHeaderRecord fileHeader = new CmITRONMeterReadDownloadFileHeaderRecord();
			fileHeader.setRecordType(RECORD_TYPE_FILEHDR);
			fileHeader.setTableIndicator(INDICATOR_N);
			fileHeader.setOpticalProbeIndicator(INDICATOR_N);				
			fileHeader.setTotalNumberCycle(totalCycle.toString().trim());			
			fileHeader.setRadioIndicator(INDICATOR_Y);			
			fileHeader.setWandIndicator(INDICATOR_N);
			fileHeader.setExtendRouteFormat(INDICATOR_Y);		
			cmWriteToFile(fileHeader.createRecordString());
			// Hold file header for writing out the record as file trailer 
			wHoldFileheader = fileHeader.createRecordString();
		}
		/**
		 * Method to get the count for the total number of cycle in this run. 
		 * @return numOfCycle
		 */
		private BigInteger cmRetrieveCycleCount() {
			
			PreparedStatement countNbrCyle = createPreparedStatement(
					"SELECT COUNT(UNIQUE(MR_CYC_CD)) AS TALLY " +
					"FROM CI_MR_STAGE_DWN MRDWN " +
					"       WHERE MRDWN.BATCH_CD  = :batchCd " +
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//"AND MRDWN.BATCH_NBR = :batchNbr ");
					"AND MRDWN.BATCH_NBR = :batchNbr ", getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			countNbrCyle.bindId("batchCd", this.getBatchControlId());
			countNbrCyle.bindBigInteger("batchNbr", this.getBatchNumber());
			countNbrCyle.execute();
			SQLResultRow result = countNbrCyle.firstRow();
			BigInteger numOfCycle = result.getInteger("TALLY");
			countNbrCyle.close();
			return numOfCycle;
		}
		/**
		 * Custom Method which forms the resulting file path 
		 * 
		 * FILE_PATH + FILE_NAME + _BatchCode + _BatchThreadNumber + _ProcessDateTime
		 *
		 */
		private void cmFormFilePathName() {

			// Filepath = replace all \ with / and make sure that the file path ends with a /
			String filePath = parmFilePath;
			if (!filePath.trim().endsWith(FORWARDSLASH)
					&& !filePath.trim().endsWith(BACKSLASH)) {
				filePath = filePath.trim().concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);

			// Filename = parameter 20_batchCode_batchNumber_batchThreadNumber
			String fileName = " ";

			String batchDetails = this.getBatchControlId().getTrimmedValue();
			batchDetails = batchDetails.trim().concat(UNDERSCORE.concat(this.getBatchNumber().toString()));				
			batchDetails = batchDetails.trim().concat(UNDERSCORE.concat(this.getBatchThreadNumber().toString()));
			batchDetails = batchDetails.trim().concat(UNDERSCORE.concat(this.getProcessDateTime().toString()));

			if (parmFileName.contains(THREAD_PLACE_HOLDER)) {							
				fileName = parmFileName.replace(THREAD_PLACE_HOLDER, batchDetails);			
			}
			else {
				fileName = parmFileName.trim().concat(UNDERSCORE.concat(batchDetails));
			}						
			resultingFilePathName = filePath.trim().concat(fileName.trim());						
		}

		/**
		 * Custom method which opens the file
		 * @param fileName
		 */
		private void cmOpenFile(String fileName) {
			try {
				file = new File(fileName);
				// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
				// use buffered writer again, for performance gain
				// START CHANGE - JHERNA - 2015-08-11 - 3277214
				buffWriter = new BufferedWriter(new FileWriter(file));
				//fileWriter = new FileWriter(file, true);
				// END CHANGE - JHERNA - 2015-08-11 - 3277214
				// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			}
			catch (Exception e) {
				e.printStackTrace();
				// Error encountered opening file (%1%2%3%4)
				addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(fileName.trim()));
			}
		}
		/**
		 * Custom method which writes to the file
		 * @param stringToWrite
		 */
		private void cmWriteToFile(String stringToWrite) {
			
			try {
				// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
				// use buffered writer again, for performance gain. ensure that carriage return line feed is used instead of system new line.
				// START CHANGE - JHERNA - 2015-08-11 - 3277214
				// use hard coded value for new line to use carriage return line feed
				buffWriter.write(stringToWrite);
				//buffWriter.newLine();
				buffWriter.write(CARRIAGE_RETURN_LINE_FEED);
				//fileWriter = new FileWriter(file, true);
				//fileWriter.append(stringToWrite);
				//fileWriter.append(CARRIAGE_RETURN_LINE_FEED);
				//fileWriter.close();
				// END CHANGE - JHERNA - 2015-08-11 - 3277214
				// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			}
			catch (Exception e) {
				e.printStackTrace();
				// Error encountered writing to file (%1%2%3%4)
				addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(resultingFilePathName.trim()));
			}
		}
		/**
		 * Custom method which closes the file
		 *
		 */
		private void cmCloseFile() {
			try {
				// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
				// use buffered writer again, for performance gain.
				// START CHANGE - JHERNA - 2015-08-11 - 3277214
				buffWriter.close();
				//	fileWriter.close();
				// END CHANGE - JHERNA - 2015-08-11 - 3277214
				// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			}
			catch (Exception e) {
				e.printStackTrace();
				// Error encountered closing file (%1%2%3%4)
				addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(resultingFilePathName.trim()));
			}
		}

		/**
		 * Single commit strategy
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {
			// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			// use a different execution strategy to improve performance / no need to cache all records before commit which is a big resource hog.
			//return new SingleTransactionStrategy(this);
			return new CommitEveryUnitStrategy(this);
			// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
		}
		// START ADD - JHERNA - 2015-12-08 - SysAid#73195
		// retrieve directly the itron amr segment via SQL instead of using OOP which would then get the entire row before retrieving the Segment Code.
		private String cmRetrieveItronAMRSegmentCode(String townCode, String gridCode) {
			String amrSegmentCode = " ";
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT CM_ITRON_SEGMENT_CD ");
			stringBuilder.append("FROM CM_AMR_SEGMENT ");
			stringBuilder.append("WHERE CM_ITRON_TOWN_CD = '"+townCode+"' ");
			stringBuilder.append("AND CM_ITRON_GRID_CD = '"+gridCode+"' ");
			
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				amrSegmentCode = (String) sqlRow.getString("CM_ITRON_SEGMENT_CD");
			}
			
			return amrSegmentCode;
		}
		// END ADD - JHERNA - 2015-12-08 - SysAid#73195
		/**
		 * The main processing method
		 */
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {						

			// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			// Changes to attempt to improve performance
			
//			// Loggers for tracing purposes only. These would only show up if the Batch is submitted in Debug Mode.
//			MeterReadDownload_Id mrStagingDownloadID = (MeterReadDownload_Id) unit.getPrimaryId();	
//			
//			//*MeterReadRoute_Id	meterReadRoute_ID = new MeterReadRoute_Id(mrStagingDownloadID.getMeterReadScheduleRoute().fetchIdMeterReadSchedule().fetchIdMeterReadCycle(),
//			//*			mrStagingDownloadID.getMeterReadScheduleRoute().fetchIdMeterReadRoute().trim());
//			
//		    //*Start Add - DHuynh - 2015-06-26 - Defect#3239081
//			String mrCycCdStr = (String) unit.getSupplementallData("mrCycCdStr");
//			Date wSchedSelDate = (Date) unit.getSupplementallData("schedSelDate");
//			String mrRteCdStr = (String) unit.getSupplementallData("mrRteCdStr");
//			String spMtrHistIdStr = (String) unit.getSupplementallData("spMtrHistIdStr");
//										   											
//			if (!isNull(mrStagingDownloadID.getMeterReadScheduleRoute())){
//				MeterReadScheduleRoute mrSchedRte = mrStagingDownloadID.getMeterReadScheduleRoute();
//				MeterReadSchedule mrSched = mrSchedRte.fetchIdMeterReadSchedule();
//				wScheduleDate = mrSched.getScheduledReadDate();
//			}else{
//				wScheduleDate = wSchedSelDate;
//			}			
//						
//			//retrieve route type from table and compare with parameter values to determine if it is an A or O route type 		
//			String wRouteTypeRetrieveFrSql = cmRetrieveRouteType (mrCycCdStr,mrRteCdStr);
//			
//			if (wRouteTypeRetrieveFrSql.toString().trim().equalsIgnoreCase(parmI_AMR.getId().getTrimmedValue())){
//				wRouteType = INDICATOR_A;
//			}
//			else if (wRouteTypeRetrieveFrSql.toString().trim().equalsIgnoreCase(parmI_OMR.getId().getTrimmedValue())) {
//				wRouteType = INDICATOR_O;
//			}
//			//*End Add - DHuynh - 2015-06-26 - Defect#3239081
//			// 2015-09-02. SMiran. Defect 3296586. Start Add
//			else{
//				wRouteType = INDICATOR_S;
//			}
//			// 2015-09-02. SMiran. Defect 3296586. End Add
//			
//			//*Start Comment Out - DHuynh - 2015-06-26 - Defect#3239081
//			/**
//			//retrieve route type from route id and compare from parameter values to determine if it is A or O route type 
//			if (meterReadRoute_ID.getEntity().getMeterReadRouteType().getId().getTrimmedValue().equalsIgnoreCase(parmI_AMR.getId().getTrimmedValue())){
//				wRouteType = INDICATOR_A;
//			}
//			else if (meterReadRoute_ID.getEntity().getMeterReadRouteType().getId().getTrimmedValue().equalsIgnoreCase(parmI_OMR.getId().getTrimmedValue())) {
//				wRouteType = INDICATOR_O;
//			}			
//
//			MeterReadScheduleRoute mrSchedRte = mrStagingDownloadID.getMeterReadScheduleRoute();
//			MeterReadSchedule mrSched = mrSchedRte.fetchIdMeterReadSchedule();			
//			ServicePointMeterHistory_Id spMtrHistId = mrStagingDownloadID.getSpMeterHistoryId();
//			
//			//*wScheduleDate = mrSched.getScheduledReadDate();
//			**/
//			//*End Comment Out - DHuynh - 2015-06-26 - Defect#3239081
//			
//			// Retrieve Service Point ID, Premise ID, Service Cycle Sequence, Meter Configuration ID and Meter
//			
//			//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
//			ServicePointMeterHistory_Id sPMeterHistoryId = new ServicePointMeterHistory_Id(spMtrHistIdStr);
//			cmRetrieveDetailSet1(sPMeterHistoryId);
//			//*End Change - DHuynh - 2015-06-26 - Defect#3239081
//
//			// Retrieve current customer with active service
//			cmRetrieveCurrentCustomer(spId);
//			//*Start Change - DHuynh - 2015-12-01 - Defect#56274
//			//wTotalCustInRoute = wTotalCustInRoute +1;
//			//*End Change - DHuynh - 2015-12-01 - Defect#56274
//			// Retrieve Main Person of account (if applicable)			
//			cmRetrieveMainPerson(acctId);
//
//			// Retrieve the register
//			cmRetrieveRegister(meter);
//
//			// START CHANGE - JHERNA - 2015-09-09 - 3299251
//			// 3299251 - if sp or register is null then set the hi lo limits to zero
//			if (isNull(spId)
//					|| isNull(register)) {				
//				hiLimit = "0";
//				loLimit = "0";				
//			}
//			else {
//				// Retrieve the Hi Limit and Lo Limit
//				cmRetrieveHiLoLimits(spId.getEntity(), register);
//			}
//			// END CHANGE - JHERNA - 2015-09-09 - 3299251
//
//			
//			// Retrieve previous register readings
//			cmRetrievePrevReg(register);
//			//*Start add - DHuynh - 2015-12-01 - Defect#56274
//			BigDecimal loLimitBD = new BigDecimal(loLimit);
//			BigDecimal prevRegReadingBD = new BigDecimal(prevRegReading);
//			loLimit = String.valueOf(cmComputeConsumption( prevRegReadingBD, loLimitBD ,register).intValueExact());
//			
//			BigDecimal hiLimitBD = new BigDecimal(hiLimit);
//			hiLimit = String.valueOf(cmComputeConsumption( prevRegReadingBD, hiLimitBD ,register).intValueExact());
//			//*End add - DHuynh - 2015-12-01 - Defect#56274			
//			
//			// Retrieve Longitude and Latitude
//			cmRetrieveLongitudeLatitude(premId);
//
//			// Retrieve bill code
//			cmRetrieveBillCode(spId);
//			
//			// START CHANGE - JHERNA - 2015-09-09 - 3299251			
//			// 3299251 - proceed only if the premise id is not null
//			if (notNull(premId)) {
//				// Get Grid code value from Premise Geographic Location		
//				wGridCode = cmRetrieveGeoValFromPrem(premId, parmGridGeoType.getId());				
//			}
//			else {
//				wGridCode = " ";
//			}
//			
//			if (notNull(premId)) {
//				// Get town code from town code characteristictype	
//				wTownCode = getPremiseChar(premId.getEntity(), parmTownCodeCharType);				
//			}
//			else {
//				wTownCode = " ";
//			}
//			// END CHANGE - JHERNA - 2015-09-09 - 3299251
//			// Retrieve Amr Segment code from CM_AMR_SEGMENT
//			wAmrSegmentCd = VALUE_0255;
//			// START CHANGE - JHERNA - 2015-09-09 - 3299251
//			// 3299251 - proceed only if town code and grid code are both retrieved successfully
//			if (notBlank(wTownCode)
//					&& notBlank(wGridCode)) {
//				CmAmrSegment_Id amrSegmentId= new CmAmrSegment_Id(wTownCode,wGridCode);		        		
//				if (!isNull(amrSegmentId.getEntity())){	        			    
//					CmAmrSegment amrsegmentEntity = amrSegmentId.getEntity(); 
//					wAmrSegmentCd = amrsegmentEntity.getItronSegmentCode();
//				}				
//			}
//			// END CHANGE - JHERNA - 2015-09-09 - 3299251
//			
//			// Use the Column Delimited Record to form the record line and Write it to the flat file
//			//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
//			cmProcessMRForWritingToFile(mrCycCdStr,wScheduleDate,mrRteCdStr,spMtrHistIdStr);
//			//*End Change - DHuynh - 2015-06-26 - Defect#3239081
			
			ServicePointMeterHistory_Id spMeterHistID = (ServicePointMeterHistory_Id) unit.getPrimaryId();
			wScheduleDate = (Date) unit.getSupplementallData("SCHED_SEL_DT");
			String mrRouteCode = (String) unit.getSupplementallData("MR_RTE_CD");
			MeterReadCycle_Id mrCycleID  = (MeterReadCycle_Id) unit.getSupplementallData("MR_CYC_CD");			
			
			// Retrieve route type from table and compare with parameter values to determine if it is an A or O route type
			String mrRouteTypeStr = cmRetrieveRouteType(mrCycleID.getTrimmedValue(), mrRouteCode.trim());
			
			if (mrRouteTypeStr.trim().compareTo(parmI_AMR.getId().getTrimmedValue()) == 0) {
				wRouteType = INDICATOR_A;
			}
			else if (mrRouteTypeStr.trim().compareTo(parmI_OMR.getId().getTrimmedValue()) == 0) {
				wRouteType = INDICATOR_O;
			}
			else {
				wRouteType = INDICATOR_S;
			}
			
			cmRetrieveDetailSet1(spMeterHistID);
	
			// Retrieve current customer with active service
			cmRetrieveCurrentCustomer(spId);

			// Retrieve Main Person of account (if applicable)			
			cmRetrieveMainPerson(acctId);

			// Retrieve the register
			cmRetrieveRegister(meter);

			// If sp or register is null then set the hi lo limits to zero
			// Start changes - DarrylH - 2/8/17  - SA-223188
			/*if (isNull(spId)
					|| isNull(register)) {				
				hiLimit = "0";
				loLimit = "0";				
			}
			else {
				// Retrieve the Hi Limit and Lo Limit
				cmRetrieveHiLoLimits(spId.getEntity(), register);
			}
			*/
			// End changes - DarrylH - 2/8/17  - SA-223188
			// Retrieve previous register readings
			cmRetrievePrevReg(register);
			// Start changes - DarrylH - 2/8/17  - SA-223188
			//BigDecimal loLimitBD = new BigDecimal(loLimit);
			//BigDecimal prevRegReadingBD = new BigDecimal(prevRegReading);
			//loLimit = String.valueOf(cmComputeConsumption( prevRegReadingBD, loLimitBD ,register).intValueExact());
			
			//BigDecimal hiLimitBD = new BigDecimal(hiLimit);
			//hiLimit = String.valueOf(cmComputeConsumption( prevRegReadingBD, hiLimitBD ,register).intValueExact());			
			// End changes - DarrylH - 2/8/17  - SA-223188
			// Retrieve Longitude and Latitude
			cmRetrieveLongitudeLatitude(premId);

			// Retrieve bill code
			cmRetrieveBillCode(spId);
						
			// Proceed only if the premise id is not null
			if (notNull(premId)) {
				// Get Grid code value from Premise Geographic Location		
				wGridCode = cmRetrieveGeoValFromPrem(premId, parmGridGeoType.getId());				
			}
			else {
				wGridCode = " ";
			}
			
			if (notNull(premId)) {
				// Get town code from town code characteristictype	
				wTownCode = getPremiseChar(premId.getEntity(), parmTownCodeCharType);				
			}
			else {
				wTownCode = " ";
			}

			// Retrieve Amr Segment code from CM_AMR_SEGMENT
			wAmrSegmentCd = VALUE_0255;

			// Proceed only if town code and grid code are both retrieved successfully
			if (notBlank(wTownCode)
					&& notBlank(wGridCode)) {

				wAmrSegmentCd = cmRetrieveItronAMRSegmentCode(wTownCode,wGridCode);			
			}
			
			// Use the Column Delimited Record to form the record line and Write it to the flat file
			cmProcessMRForWritingToFile(mrCycleID.getTrimmedValue(),
					wScheduleDate,
					mrRouteCode.trim(),
					spMeterHistID.getTrimmedValue());						
			
			// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			
			return true;
		}
		/**
		 * Custom method which retrieves premise characteristic value base on charType (in this case it is towncode)
		 *  @param premise: the premise of service point that is processing
		 *  @param charType: characteristic TOWNCD of premise
		 *  @return charVal: characteristic value 
		 */
		private String getPremiseChar(Premise premise, CharacteristicType charType) {

			String charVal = "";
			PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);
			if (notNull(premChar)){       
				if (charType.getCharacteristicType().isPredefinedValue()){
					charVal = premChar.getCharacteristicValue().trim();
				}
				else if (charType.getCharacteristicType().isForeignKeyValue()) {
					charVal = premChar.getCharacteristicValueForeignKey1().trim();
				}
				else {
					charVal = premChar.getAdhocCharacteristicValue().trim();
				}
			}
			return charVal;
		}

		/**
		 * Custom method which retrieves the total number of routes to be processed for the cycle
		 * @param cycle the cycle being processed
		 * @return numOfRouteCount - total number of routes for the cycle being processed
		 */
		private BigInteger cmRetrieveRouteCount(String cycle) {
			
			PreparedStatement countRoute = createPreparedStatement(
					"SELECT COUNT(UNIQUE(MR_RTE_CD)) AS TALLY " +
					"FROM CI_MR_STAGE_DWN MRDWN " +
					"       WHERE MRDWN.BATCH_CD  = :batchCd " +
					"       AND MRDWN.BATCH_NBR = :batchNbr " +
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//"       AND MRDWN.MR_CYC_CD = " + cycle + " ");
					//Start Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					"       AND MRDWN.MR_CYC_CD = '" + cycle + "' ", getClass().getName());
					//End Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			countRoute.bindId("batchCd", this.getBatchControlId());
			countRoute.bindBigInteger("batchNbr", this.getBatchNumber());	  
			countRoute.execute();   
			SQLResultRow result = countRoute.firstRow();
			BigInteger numOfRouteCount = result.getInteger("TALLY");
			countRoute.close();
			return numOfRouteCount;
		}
		//*Start Add - DHuynh - 2015-06-26 - Defect#3239081
		
		/**
		 * Custom method which retrieves Route Type base on cycle and route number
		 * @param cycle, route
		 * @return Route type
		 */
		private String cmRetrieveRouteType(String cycle, String route) {
			
			PreparedStatement countRoute = createPreparedStatement(
					"SELECT MRRTE.MR_RTE_TYPE_CD "		 +
					"FROM CI_MR_RTE MRRTE "							 +
					"       WHERE MRRTE.MR_CYC_CD  = '" + cycle + "'" +
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//"       AND MRRTE.MR_RTE_CD = '" + route + "'");
					"       AND MRRTE.MR_RTE_CD = '" + route + "'", getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
	 
			countRoute.execute();   
			SQLResultRow result = countRoute.firstRow();
			// 2015-09-02. SMiran. Defect 3296586. Start Change
			countRoute.close();
			if (notNull(result)){
				String wRouteTypeTemp = result.getString("MR_RTE_TYPE_CD");
				return wRouteTypeTemp;
			}else{
				return "";
			}
			// 2015-09-02. SMiran. Defect 3296586. End Change
		}
		//*End Add - DHuynh - 2015-06-26 - Defect#3239081
		
		/**
		 * Custom method which retrieves the total number of meter 
		 * being processed per route of a cycle
		 * @param cycle being processed
		 * @param route	being processed
		 * @return numOfMeterCount - Total number of meters to be processed
		 */
		private BigInteger cmRetrieveMeterCount(String cycle, String route) {
			
			PreparedStatement countMeter = createPreparedStatement(
					"SELECT COUNT(*) AS TALLY " +
					"FROM  CI_MR_STAGE_DWN MRDWN " +
					"       WHERE MRDWN.BATCH_CD  = :batchCd " +
					"       AND MRDWN.BATCH_NBR = :batchNbr " +
					//Start Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					"       AND MRDWN.MR_CYC_CD = '" + cycle + "'" + 
					//End Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//"		AND MRDWN.MR_RTE_CD = '" + route + "'" );
					"		AND MRDWN.MR_RTE_CD = '" + route + "'" , getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			countMeter.bindId("batchCd", this.getBatchControlId());
			countMeter.bindBigInteger("batchNbr", this.getBatchNumber());
			countMeter.execute();
			SQLResultRow result = countMeter.firstRow();
			BigInteger numOfMeterCount = result.getInteger("TALLY");
			countMeter.close();
			return numOfMeterCount;
		}
		//Start Add - DarrylH - SA211192: 2017-06-01
		/**
		 * Custom method to get office area base on cycle & route.
		 * @param cycle being processed
		 * @param route	being processed
		 * @return office area (the one which has greatest count)
		 */
		private String cmRetrieveOfficeArea(String cycle, String route) {
			String officeArea = "";
				PreparedStatement getOfficeArea = createPreparedStatement(
					"SELECT COUNT(*) , A.MR_CYC_CD, A.MR_RTE_CD ,B.CHAR_VAL " +
					"FROM CI_SP A, CI_PREM P, CI_PREM_CHAR B  " +
					//Start Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					"       WHERE A.MR_CYC_CD = '" + cycle + "' AND A.PREM_ID = P.PREM_ID " +
					//Start Change - SA-272431: 2018-11-02 DarrylH - include single quote 
					"       AND A.PREM_ID = B.PREM_ID  AND A.MR_RTE_CD = '" + route + "'" +
					"       AND B.CHAR_TYPE_CD = :offcode"+
					"       AND P.CIS_DIVISION = :mgedivision " +
					"       GROUP BY A.MR_CYC_CD, A.MR_RTE_CD ,B.CHAR_VAL "  +
					"		ORDER BY COUNT(*) DESC ", getClass().getName());
			getOfficeArea.bindId("offcode", mgeServingOfficeCharTypeID);
			getOfficeArea.bindId("mgedivision", mgedivision);
			getOfficeArea.execute();   
			SQLResultRow result = getOfficeArea.firstRow();
			if (notNull(result)){
				officeArea = result.getString("CHAR_VAL").trim();
			}
			getOfficeArea.close();
			return officeArea;
		}
		//End Add - DarrylH - SA211192: 2017-06-01
		/**
		 * Custom method which retrieves detail set 1 (Service Point, Premise, Service Cycle Route Sequence, Meter Configuration ID)
		 * @param spmhID the ServicePointMeterHistoryID
		 */
		private void cmRetrieveDetailSet1(ServicePointMeterHistory_Id spmhID) {

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT SP.SP_ID, SP.PREM_ID, SP.MR_CYC_RTE_SEQ, SPMH.MTR_CONFIG_ID ");
			stringBuilder.append("FROM CI_SP SP, CI_SP_MTR_HIST SPMH ");
			stringBuilder.append("WHERE SPMH.SP_MTR_HIST_ID = :spmhID ");
			stringBuilder.append("AND SP.SP_ID = SPMH.SP_ID ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("spmhID", spmhID);
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				String spIdString = (String) sqlRow.get("SP_ID");
				String premIdString = (String) sqlRow.get("PREM_ID");
				serviceCycleSequence = (BigInteger) sqlRow.getInteger("MR_CYC_RTE_SEQ"); 
				String mtrConfigIdString = (String) sqlRow.get("MTR_CONFIG_ID");
				spId = new ServicePoint_Id(spIdString.trim());
				premId = new Premise_Id(premIdString.trim());
				mtrConfigId = new MeterConfiguration_Id(mtrConfigIdString.trim());
				// Retrieve the meter to get the Badge Number, Meter Type and Manufacturer Code
				meter = mtrConfigId.getEntity().getMeter();
			}
			else {
				prepState.close();
				// START CHANGE - JHERNA - 2015-09-09 - 3299251
				// Cannot retrieve service point from Service point meter history Id (%1)
				//addError(CustomMessageRepositoryMGE.ccb001CantRetrieveDetailsFromSpMtrHistId(spmhID.getTrimmedValue()));
				logError(CustomMessageRepositoryMGE.ccb001CantRetrieveDetailsFromSpMtrHistId(spmhID.getTrimmedValue()));
				// END CHANGE - JHERNA - 2015-09-09 - 3299251
			}
			prepState.close();
		}
		/**
		 * Custom method which retrieves the current customer Account
		 * @param spID the Service Point Id
		 */
		private void cmRetrieveCurrentCustomer(ServicePoint_Id spID) {

			StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT SA.ACCT_ID ");
			stringBuilder.append("FROM CI_SA_SP SASP, CI_SA SA ");
			stringBuilder.append("WHERE SASP.SP_ID = :spID ");
			stringBuilder.append("AND SA.SA_ID = SASP.SA_ID ");
			stringBuilder.append("AND SA.SA_STATUS_FLG IN (:pendingStop, :active, :pendingStart, :reactivated) ");
			stringBuilder.append("AND SA.START_DT <= :procDate ");
			stringBuilder.append("ORDER BY SA.START_DT DESC ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("spID", spID);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.bindDate("procDate", this.getProcessDateTime().getDate());
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				String acctIdStr = (String) sqlRow.get("ACCT_ID");
				acctId = new Account_Id(acctIdStr.trim());
			}
			else {
				acctId = null;
			}
			prepState.close();
		}
		/**
		 * Custom method which retrieves the bill code
		 * @param spID the Service Point Id
		 */
		private void cmRetrieveBillCode(ServicePoint_Id spID) {
			// START CHANGE - JHERNA - 2015-09-09 - 3299251
			// 3299251 - proceed only if the spID is not null
			billCode =" ";
			if (notNull(spID)) {				
				StringBuilder stringBuilder = new StringBuilder();						
				stringBuilder.append("select b.trend_cl_cd ");
				stringBuilder.append("from ci_sp a, ci_sp_type b ");
				stringBuilder.append("where a.sp_id =  :spID ");
				stringBuilder.append("and a.sp_type_cd = b.sp_type_cd ");
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				prepState.bindId("spID", spID);
				prepState.execute();
				if (prepState.list().size() > 0) {
					SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
					billCode = (String) sqlRow.get("TREND_CL_CD");
				}
				prepState.close();	
			}			
			// END CHANGE - JHERNA - 2015-09-09 - 3299251
		}
		/**
		 * Custom method which retrieves the Main Person of the Account
		 * @param accountID the account id
		 */
		private void cmRetrieveMainPerson(Account_Id accountID) {
			customerName = " ";
			if (notNull(accountID)) {
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append("SELECT ENTITY_NAME ");
				stringBuilder.append("FROM CI_ACCT_PER APER, CI_PER_NAME PERN ");
				stringBuilder.append("WHERE APER.ACCT_ID = :accountID ");
				stringBuilder.append("AND APER.MAIN_CUST_SW = :mainCustSw ");
				stringBuilder.append("AND PERN.PER_ID = APER.PER_ID ");
				stringBuilder.append("AND PERN.PRIM_NAME_SW = :primNameSw ");
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				prepState.bindId("accountID", accountID);
				prepState.bindBoolean("mainCustSw", Bool.TRUE);
				prepState.bindBoolean("primNameSw", Bool.TRUE);
				prepState.execute();
				if (prepState.list().size() > 0) {
					SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
					customerName = (String) sqlRow.get("ENTITY_NAME");
				}
				else {
					customerName = " ";
				}
				prepState.close();		         
			}
		}

		/**
		 * Custom method which retrieves the Meter's Register 
		 * It is assumed that each meter would only have one register
		 * @param meter 
		 */
		private void cmRetrieveRegister(Meter meter) {
			
			// START CHANGE - JHERNA - 2015-09-09 - 3299251
			// 3299251 - proceed only if meter is not null
			if (notNull(meter)) {
				// Assumption is that each meter will only have one register
				StringBuilder stringBuilder = new StringBuilder();			
				stringBuilder.append("SELECT REG.REG_ID ");
				stringBuilder.append("FROM CI_REG REG ");
				stringBuilder.append("WHERE REG.MTR_ID = :meterID ");
				stringBuilder.append("AND REG.EFF_DTTM <= :effDttm ");
				stringBuilder.append("ORDER BY REG.EFF_DTTM DESC ");
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				prepState.bindId("meterID", meter.getId());
				prepState.bindDateTime("effDttm", this.getProcessDateTime());
				prepState.execute();
				if (prepState.list().size() > 0) {
					SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
					String regString = (String)sqlRow.get("REG_ID");
					register = new Register_Id(regString.trim()).getEntity();
				}
				else {
					prepState.close();
					// Failed to retrieve registers of meter (%1)
					//addError(CustomMessageRepositoryMGE.ccb001CantRetrieveRegisterFromMeter(meter.getId().getTrimmedValue()));
					logError(CustomMessageRepositoryMGE.ccb001CantRetrieveRegisterFromMeter(meter.getId().getTrimmedValue()));
					register = null;
				}
				prepState.close();				
			}			
			// END CHANGE - JHERNA - 2015-09-09 - 3299251
		}
		/**
		 * Custom method which determines if the equipment is an ERT 
		 * @param meter 
		 */
		private void cmCheckMeterForErtEquipment(Meter meter) {
			wErtCharValue = "";
			wERTItemBatchNumber = "";
			wWriteRffRecord = Bool.FALSE;
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT EQP.MTR_ID, ITM.ITEM_ID ");
			stringBuilder.append("FROM CI_MTR_EQ EQP, CI_ITEM ITM, CI_MTR MTR ");
			stringBuilder.append("WHERE (EQP.REMOVAL_DT IS  NULL ");			
			stringBuilder.append("		 OR EQP.REMOVAL_DT > :procDttm) ");			
			stringBuilder.append("AND EQP.ITEM_ID_EQ = ITM.ITEM_ID ");
			stringBuilder.append("AND ITM.ITEM_TYPE_CD = :ert ");
			stringBuilder.append("AND ITM.ITEM_STATUS_FLG = :itemStatus ");			
			stringBuilder.append("AND EQP.MTR_ID = MTR.MTR_ID ");		
			stringBuilder.append("AND (MTR.RETIRE_DT IS NULL ");
			stringBuilder.append("	   OR MTR.RETIRE_DT > :procDttm) ");			
			stringBuilder.append("AND MTR.MTR_ID = :meterID ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("ert", parmErtItemTypeCode.getId());
			prepState.bindLookup("itemStatus", ItemStatusLookup.constants.ACTIVE);
			prepState.bindId("meterID", meter.getId());
			prepState.bindDateTime("procDttm", this.getProcessDateTime());

			prepState.execute();
			if (prepState.list().size() > 0) {
				
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				wTotalErtInRoute = wTotalErtInRoute.add(BigInteger.ONE);
				wReadMethod = LETTER_R;
				Item_Id itemID = (Item_Id) sqlRow.getId("ITEM_ID", Item.class);
				ItemCharacteristic itemChar = itemID.getEntity().getEffectiveCharacteristic(parmErtCharType);
				if(notNull(itemChar)){
					wErtCharValue = itemChar.getCharacteristicValue();	
				}				
				wERTItemBatchNumber = itemID.getEntity().getBadgeNumber();
				wWriteRffRecord = Bool.TRUE;					
			}
			else {
				wReadMethod = LETTER_K;
			}
			prepState.close();			
		}		
		/**
		 * Custom method which retrieves the Hi Limit and Lo Limit by calling the HighLowCalculationAlgorithm
		 * @param sp the service point
		 * @param reg the register
		 */
		private void cmRetrieveHiLoLimits(ServicePoint sp, Register reg) {

			try {
				DateTime wScheduleDateWithTime = new DateTime(wScheduleDate.getYear(), wScheduleDate.getMonth(), wScheduleDate.getDay());	
				
				HighLowCalculationAlgorithmData hiLoData = HighLowCalculationAlgorithmData.Factory.newInstance();
				hiLoData.setReadDateTime(wScheduleDateWithTime);	
				hiLoData.setReadType(ReadTypeLookup.constants.REGULAR);
				hiLoData.setEstimateType(EstimateTypeLookup.constants.HIGH_LOW_ONLY);
				hiLoData.setServicePoint(sp);				
				HighLowCalculationAlgorithmData output = reg.callHighLowCalculationAlgorithms(hiLoData);

				// START CHANGES - JHERNA - 2015-08-06 - 3269752
				//hiLimit = output.getHighLimit().toString().trim();
				//loLimit = output.getLowLimit().toString().trim();
				hiLimit = String.valueOf(output.getHighLimit().intValueExact());
				loLimit = String.valueOf(output.getLowLimit().intValueExact());				
				// END CHANGES - JHERNA - 2015-08-06 - 3269752
				
			}
			catch (ApplicationError e){
				//START CHANGES - JHERNA 
				//e.printStackTrace();				
				//addError(e.getServerMessage());				
				hiLimit = "0";
				loLimit = "0";
				e.printStackTrace();
				logError(e.getServerMessage());
//				logError(CustomMessageRepositoryMGE.ccb001ErrorEncounteredRetrievingHiLo(
//						reg.getId().getTrimmedValue(), sp.getId().getTrimmedValue()));
				//END CHANGES - JHERNA 
			}

			catch (Exception e) {
				//START CHANGES - JHERNA 
				//e.printStackTrace();			
				// Error encountered trying to retrieve the Hi / Lo Limits from Register (%1) of Service Point (%2)
				//addError(CustomMessageRepositoryMGE.ccb001ErrorEncounteredRetrievingHiLo(
				//		reg.getId().getTrimmedValue(), sp.getId().getTrimmedValue()));
				hiLimit = "0";
				loLimit = "0";
				e.printStackTrace();
				logError(CustomMessageRepositoryMGE.ccb001ErrorEncounteredRetrievingHiLo(
						reg.getId().getTrimmedValue(), sp.getId().getTrimmedValue()));
				//END CHANGES - JHERNA 
			}			
		}
		/**
		 * Custom method to retrieve the previous register
		 *     - This is patterned over how CIPMRGRL retrieves the previous register readings/info
		 *     - Assumption is that each meter will only have one register for MGE
		 * @param reg the register
		 */
		private void cmRetrievePrevReg(Register reg) {

			// START CHANGE - JHERNA - 2015-09-09 - 3299251
			// 3299251 - proceed only if the register is not null
			if (notNull(reg)) {
				// First retrieve the latest meter read as of Process Date
				MeterRead latestMeterRead = cmRetrieveLatestMeterRead(mtrConfigId); 
				
				prevRegReading = BigInteger.ZERO.toString().trim();
				
				if (notNull(latestMeterRead)) {
					// Retrieve the Previous Register Reading
					StringBuilder stringBuilder = new StringBuilder();
					stringBuilder.append("SELECT RR.REG_READING, MR.MR_ID ");
					stringBuilder.append("FROM CI_MR MR, CI_REG_READ RR ");
					stringBuilder.append("WHERE MR.MR_ID != :latestMrId ");
					stringBuilder.append("AND MR.MTR_CONFIG_ID = :mtrConfigId ");
					stringBuilder.append("AND MR.USE_ON_BILL_SW = :useOnBillSw ");
					stringBuilder.append("AND MR.READ_DTTM < :latestMrDttm ");
					stringBuilder.append("AND RR.MR_ID = MR.MR_ID ");
					stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
					PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					prepState.bindId("mtrConfigId", mtrConfigId);
					prepState.bindId("latestMrId", latestMeterRead.getId());
					prepState.bindBoolean("useOnBillSw", Bool.TRUE);
					prepState.bindDateTime("latestMrDttm", latestMeterRead.getReadDateTime());
					prepState.execute();
					if (prepState.list().size() > 0) {
						SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
						BigDecimal prevRegReadBD = (BigDecimal) sqlRow.getBigDecimal("REG_READING");

						// START CHANGES - JHERNA - 2015-08-06 - 3269752
						//prevRegReading = prevRegReadBD.toString();
						prevRegReading = String.valueOf(prevRegReadBD.intValueExact());
						// END CHANGES - JHERNA - 2015-08-06 - 3269752

						//cast meterreadid to meteread id type
						cmRetrieveTamperCode(latestMeterRead.getId()); 

					}
					prepState.close();					
				}					
			}
			// END CHANGE - JHERNA - 2015-09-09 - 3299251
		}
		//*Start add - DHuynh - 2015-12-01 - Defect#56274
        /**
         * Custom method which calls the base routine to calculate the consumption given 2 reads and the register's number of digits left
         * and taking into account the dial rollover.
         * @param startReading the starting read
         * @param endReading the ending read
         * @param register the register to retrieve the number of digits left value
         * @return BigDecimal value of the consumption between two reads
         */
         private BigDecimal cmComputeConsumption(BigDecimal startReading, BigDecimal endReading, Register register) {
               
               BigDecimal returnValue = BigDecimal.ZERO;             
               try {
                     /*
                     * Use the base routine CIPMDBRN which calculates the difference (a.k.a. consumption)
                     * between two register reads by taking the dial rollover into account.
                     */               
                     CobolProgramCIPMDBRN cobolRoutine = CobolProgramCIPMDBRN.Factory.newInstance();
                     CobolCopybookCICMDBRN cobolCopybook = cobolRoutine.getCobolCopybookCICMDBRN();
                     // Set the input of the routine
                     cobolCopybook.get_INPUT_WRK().set_START_READING(startReading);
                     cobolCopybook.get_INPUT_WRK().set_END_READING(endReading);
                     cobolCopybook.get_INPUT_WRK().set_NBR_OF_DGTS_LFT(register.getNumberOfDigitsLeft());                  
                     // Execute the routine
                     cobolRoutine.callCobol();
                     // Retrieve the ouput of the routine
                     returnValue = cobolCopybook.get_OUTPUT_WRK().get_DIFFERENCE();
                     
               }
               catch (Exception e) {
                     e.printStackTrace();
                     // Error encountered while invoking base routine %1.
                     logError(CustomMessageRepositoryMGE.commGenericErrorEncounteredInvokingBaseRoutine("CIPMDBRN"));
               }
               return returnValue;
         }
         //*End add - DHuynh - 2015-12-01 - Defect#56274


		/**
		 * Custom method to retrieve the tamper code
		 * @param mrId
		 */
		private void cmRetrieveTamperCode(MeterRead_Id mrId) {
			
			wTamperCode = "";
			StringBuilder stringBuilder = new StringBuilder();

			if (parmTmprCharType.getCharacteristicType().isPredefinedValue()) {
				stringBuilder.append("SELECT MRCHA.CHAR_VAL ");
			} else if (parmTmprCharType.getCharacteristicType().isAdhocValue()
					|| parmTmprCharType.getCharacteristicType().isFileLocationValue()) {
				stringBuilder.append("SELECT MRCHA.ADHOC_CHAR_VAL ");

			} else if (parmTmprCharType.getCharacteristicType().isForeignKeyValue()) {
				stringBuilder.append("SELECT MRCHA.CHAR_VAL_FK1 ");
			}

			stringBuilder.append("FROM CI_MR_CHAR MRCHA ");
			stringBuilder.append("WHERE MRCHA.CHAR_TYPE_CD = :charTypeCode ");
			stringBuilder.append("AND MRCHA.MR_ID = :mrId ");
			stringBuilder.append("ORDER BY MRCHA.SEQ_NUM DESC ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("charTypeCode",parmTmprCharType.getId());

			prepState.bindId("mrId", mrId);

			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();

				if (parmTmprCharType.getCharacteristicType().isPredefinedValue()) {
					wTamperCode = (String) sqlRow.getString("CHAR_VAL");
				} else if (parmTmprCharType.getCharacteristicType().isAdhocValue()
						|| parmTmprCharType.getCharacteristicType().isFileLocationValue()) {
					wTamperCode = (String) sqlRow.getString("ADHOC_CHAR_VAL");

				} else if (parmTmprCharType.getCharacteristicType().isForeignKeyValue()) {
					wTamperCode = (String) sqlRow.getString("CHAR_VAL_FK1");
				}									
			}
			prepState.close();

		}
		/**
		 * Custom method which retrieves the latest meter read.
		 * @param mtrConfigID 
		 * @return mrId Entity
		 */
		private MeterRead cmRetrieveLatestMeterRead(MeterConfiguration_Id mtrConfigID) {
			
			MeterRead returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT MR.MR_ID ");
			stringBuilder.append("FROM CI_MR MR ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :mtrConfigId ");
			stringBuilder.append("AND MR.READ_DTTM <= :procDttm ");
			stringBuilder.append("AND USE_ON_BILL_SW = :useOnBill ");			
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("mtrConfigId", mtrConfigID);
			prepState.bindDateTime("procDttm", this.getProcessDateTime());
			prepState.bindBoolean("useOnBill", Bool.TRUE);
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				String mrIdStr = (String) sqlRow.get("MR_ID");
				MeterRead_Id mrId = new MeterRead_Id(mrIdStr.trim());
				returnValue = mrId.getEntity();
			}
			else {		
				// START CHANGE - JHERNA - 2015-09-09 - 3299251
				//prepState.close();
				// Cannot retrieve latest meter read of meter configuration (%1)
				//addError(CustomMessageRepositoryMGE.ccb001CantRetrieveLatestMeterRead(mtrConfigId.getTrimmedValue()));
				logError(CustomMessageRepositoryMGE.ccb001CantRetrieveLatestMeterRead(mtrConfigId.getTrimmedValue()));
				// END CHANGE - JHERNA - 2015-09-09 - 3299251
			}	
			prepState.close();
			return returnValue;
		}		
		/**
		 * Custom method which retrieves the Longitude and Latitude from the Premise's Geographic Locations
		 * @param premID the premise
		 */
		private void cmRetrieveLongitudeLatitude(Premise_Id premID) {
			
			// START CHANGE - JHERNA - 2015-09-09 - 3299251
			// 3299251 - proceed only if the premise id is not null
			if (notNull(premID)) {
				latitude = null;
				longitude = null;
				String geoVal = cmRetrieveGeoValFromPrem(premID, parmGeoType.getId());
				if (notBlank(geoVal)) {				
					String[] splitGeoVal = geoVal.split(" ", 2);
					if (splitGeoVal.length != 2) {

						// Cannot retrieve Longitude or Latitude from Geographic Type %1 (%2)
						logError(CustomMessageRepositoryMGE.ccb001CantRetrieveLongitudeLatitude(
								parmGeoType.getId().getTrimmedValue(),
								geoVal.trim()));
						return;
					}
					// Retrieve the Latitude (the first component)
					latitude = splitGeoVal[0];				
					// Retrieve the Longitude (the second component)
					longitude = splitGeoVal[1];							
				}
			}
			// END CHANGE - JHERNA - 2015-09-09 - 3299251
		}

		/**
		 * Custom method which retrieves the Longitude/Latiude Geographic value from the premise
		 * @param premID the premise
		 * @param geoTypeID the geo type
		 * @return the Geo Value
		 */
		private String cmRetrieveGeoValFromPrem(Premise_Id premID, GeographicType_Id geoTypeID) {
			
			String returnValue = " ";
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT GEO_VAL  ");
			stringBuilder.append("FROM CI_PREM_GEO ");
			stringBuilder.append("WHERE PREM_ID = :premId ");
			stringBuilder.append("AND GEO_TYPE_CD = :geoTypeCd ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("premId", premID);
			prepState.bindId("geoTypeCd", geoTypeID);
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				returnValue = (String) sqlRow.get("GEO_VAL");				
			}
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method which process Meter Read Download record and forming different record type and write to flat file
		 * @param mrSchedRte the Meter Read Schedule Route
		 * @param mrSched the Meter Read Schedule
		 */
		//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
		private void cmProcessMRForWritingToFile(String mrCycCdStr, Date wSchedSelDate,String mrRteCdStr, String spMtrHistIdStr) {
		//*End Change - DHuynh - 2015-06-26 - Defect#3239081	
			String recordAccountID = " ";			
			String recordMeterLocation = null;
			String wRecordMeterLocation = TWO_ZERO;
			String recordMrInstructionCodeStr = null ;
			String wRecordMrInstructionCodeStr = TWO_ZERO;

			String recordMrWarningStr = null;
			String wRecordMrWarningStr = TWO_ZERO;
			//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
			String mrCycleCode = mrCycCdStr;
			String mrRoute = mrRteCdStr; 
			//*End Change - DHuynh - 2015-06-26 - Defect#3239081
			Premise premise = premId.getEntity();
			ServicePoint servicePoint = spId.getEntity();
			
			//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
			scheduleDate = wSchedSelDate.toString(new DateFormat("MMddyyyy"));
			//Store value to check for what cycle and route is in the processing record
			wProcessMeterReadCycle = mrCycCdStr;
			wProcessRoute = mrRteCdStr;		
			//*End Change - DHuynh - 2015-06-26 - Defect#3239081
			
			//Check to determine what kind of record need to be written 
			if (wProcessMeterReadCycle.equalsIgnoreCase(wHoldMeterReadCycle)) {
				
				if (!wProcessRoute.equalsIgnoreCase(wHoldRoute)) {
					// write Route TRAILER record
					cmFormRouteTrailerRecordLineAndWrite();	
					//Write Route HEADER record
					cmFormRouteHeaderRecordLineAndWrite();
					//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
					wHoldRoute = mrRteCdStr;
					//*End Change - DHuynh - 2015-06-26 - Defect#3239081
					wTotalErtInRoute = BigInteger.ZERO;
				}
			}
			else {
				if (isFirstRecord.isTrue()) {					
					
					totalRoute = cmRetrieveRouteCount(wProcessMeterReadCycle);

					//Write Cycle HEADER record
					cmFormCycleHeaderRecordLineAndWrite();					
					cmFormRouteHeaderRecordLineAndWrite();
					//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
					wHoldMeterReadCycle = mrCycCdStr.toString().trim();					
					wHoldRoute = mrRteCdStr.toString().trim();
					//*End Change - DHuynh - 2015-06-26 - Defect#3239081
					isFirstRecord = Bool.FALSE;
				}
				else {
					//Write Route TRAILER record
					cmFormRouteTrailerRecordLineAndWrite();	
					//Write Cycle TRAILER record
					cmFormCycleTrailerRecordLineAndWrite();
					//Write Cycle HEADER record
					totalRoute = cmRetrieveRouteCount(wProcessMeterReadCycle);
					cmFormCycleHeaderRecordLineAndWrite();

					//write Route HEADER record	
					cmFormRouteHeaderRecordLineAndWrite();				
					//*Start Change - DHuynh - 2015-06-26 - Defect#3239081
					wHoldMeterReadCycle = mrCycCdStr;
					wHoldRoute = mrRteCdStr;
					//*End Change - DHuynh - 2015-06-26 - Defect#3239081
					wTotalErtInRoute = BigInteger.ZERO;
				}								
			}			
			// Check if meter is ERT type 
			cmCheckMeterForErtEquipment(meter);			
			
			// If there is an account add the account to the list
			if (notNull(acctId)) {
				recordAccountID = acctId.getTrimmedValue();	
				// START CHANGES - JHERNA - 2015-12-08 - SysAid#73195
				// removed - collection is not used anyway
				//if (!collOfAcctIDs.contains(acctId)) {
				//	collOfAcctIDs.add(acctId);
				//}
				// END CHANGES - JHERNA - 2015-12-08 - SysAid#73195
			}

			if (notNull(servicePoint.getMeterLocationId())) {
				recordMeterLocation = servicePoint.getMeterLocationId().getTrimmedValue();
			}
			// If the SP has an override premise field info retrieve details from the service point
			if (servicePoint.getOverridePremFieldInfo().isYes()) {
				
				recordMrInstructionCodeStr = servicePoint.getMeterReadInstruction();
				recordMrWarningStr = servicePoint.getMeterReadWarning();
			}
			// Otherwise, retrieve it from the premise
			else {
				if (notNull(premise.getMeterReadWarningId())) {
					
					recordMrWarningStr = premise.getMeterReadWarningId().getTrimmedValue();
				}				
				if (notNull(premise.getMeterReadInstructionId())) {
					
					recordMrInstructionCodeStr = premise.getMeterReadInstructionId().getTrimmedValue();
				}				
			}	

			//process service task type (CM-ITRONCONFIG) one time only
			if (isFirstTime.isTrue()){				
				
				isFirstTime = Bool.FALSE;			
				// Retrieve Itron meter location from CM-ITRONCONFIG
				BusinessObjectInstance placementBoInstance;
				placementBoInstance = BusinessObjectInstance.create(parmServiceTaskType.getBusinessObject());
				placementBoInstance.setXMLString("serviceTaskType",parmServiceTaskType.getId().getTrimmedValue());
				placementBoInstance = BusinessObjectDispatcher.read(placementBoInstance);	

				COTSInstanceNode itronDetailLocation = placementBoInstance.getGroup("itronDetails");
				itronMeterLocationList = itronDetailLocation.getList("meterLocationList");	        

				COTSInstanceNode itronDetailWarn = placementBoInstance.getGroup("itronDetails");
				itronMeterWarnList = itronDetailWarn.getList("mrWarningList");  

				COTSInstanceNode itronDetailInstruction = placementBoInstance.getGroup("itronDetails");
				itronMeterInstructionList = itronDetailInstruction.getList("mrInstructionList");	        
       
			}
			
			//Check if itronMeterLocationList is not empty then create meterLocationIter
			if(!itronMeterLocationList.isEmpty() 
					&& (notNull(recordMeterLocation)) ) {
				
				Iterator<COTSInstanceListNode> meterLocationIter = itronMeterLocationList.iterator();
				//Loop to find the ITRON value
				while(meterLocationIter.hasNext()) {            	
					
					COTSInstanceListNode meterLocationRow = meterLocationIter.next();  
					if (meterLocationRow.getString("mtrLocation").trim().equalsIgnoreCase(
							recordMeterLocation)) {
						
						wRecordMeterLocation = meterLocationRow.getString("itronLocation").trim();
						break;   
					}
				}
			}

			if ((wRecordMeterLocation.equalsIgnoreCase("00")) 
					&& (notBlank(recordMeterLocation))){
				
				logWarning(CustomMessageRepositoryMGE.ccb001ErrorEncounteredMeterLocation(
						servicePoint.getMeterLocationId().getTrimmedValue().toString(),servicePoint.getId().getTrimmedValue()));
			}

			//Check if itronMeterInstructionList is not empty then create meterInstructionIter	        
			if((!itronMeterInstructionList.isEmpty()) 
					&& (notBlank(recordMrInstructionCodeStr))) {
				
				Iterator<COTSInstanceListNode> meterInstructionIter = itronMeterInstructionList.iterator();
				while(meterInstructionIter.hasNext()) {           	
					
					COTSInstanceListNode meterInstructionRow = meterInstructionIter.next();	        		
					if (meterInstructionRow.getString("mrInstruction").trim().equalsIgnoreCase(
							recordMrInstructionCodeStr)) {
						wRecordMrInstructionCodeStr = meterInstructionRow.getString("itronInstruction1").trim();
						break;
					}
				}
			}

			if ((wRecordMrInstructionCodeStr.equalsIgnoreCase("00")) 
					&& (notBlank(recordMrInstructionCodeStr))){
				
				logWarning(CustomMessageRepositoryMGE.ccb001ErrorEncounteredMeterInstruction(
						recordMrInstructionCodeStr,premise.getId().getTrimmedValue()));
			}

			// Check if itronMeterWarnList is not empty then create itronMeterWarnList        
			if((!itronMeterWarnList.isEmpty()) 
					&& (notBlank(recordMrWarningStr))){
				
				Iterator<COTSInstanceListNode> meterWarnIter = itronMeterWarnList.iterator();
				while(meterWarnIter.hasNext()) {          	
					
					COTSInstanceListNode meterWarnRow = meterWarnIter.next();	        		
					if (meterWarnRow.getString("mrWarning").trim().equalsIgnoreCase(
							recordMrWarningStr)) {
						
						wRecordMrWarningStr =meterWarnRow.getString("itronInstruction2").trim();
						break;
					}	          		 
				}
			}

			if ((wRecordMrWarningStr.equalsIgnoreCase("00")) 
					&& (notBlank(recordMrWarningStr))){
				
				logWarning(CustomMessageRepositoryMGE.ccb001ErrorEncounteredMeterWarning(
						recordMrWarningStr,premise.getId().getTrimmedValue()));
			} 

			// Start forming MTR record type
			CmITRONMeterReadDownloadMeterDetailRecord recordLineMtr = new CmITRONMeterReadDownloadMeterDetailRecord();			
			recordLineMtr.setRecordType(RECORD_TYPE_MTR);
			recordLineMtr.setServiceCycle(mrCycleCode);
			recordLineMtr.setRouteType(wRouteType);
			recordLineMtr.setServiceRoute(mrRoute);
			recordLineMtr.setTotalNbrReadExpectForThisMeter("1");
			recordLineMtr.setBillCode(billCode);
					
			wSpSourceStatus = "";
			wSpSourceStatus = servicePoint.getServicePointSourceStatus().trimmedValue();
			if (wSpSourceStatus.equalsIgnoreCase(ServicePointSourceStatusLookup.constants.CONNECTED.trimmedValue())) {
				wSpSourceStatus = LETTER_A;
			}
			else if (wSpSourceStatus.equalsIgnoreCase(ServicePointSourceStatusLookup.constants.DISCONNECTED.trimmedValue())) {
				wSpSourceStatus = LETTER_I;
			}
			recordLineMtr.setSpSourceStatus(wSpSourceStatus);

			recordLineMtr.setMeterBadgeNbr(meter.getBadgeNumber());
			MeterCharacteristic meterChar = meter.getEffectiveCharacteristic(parmMeterCharType);
			if (notNull(meterChar)){				
				if (parmMeterCharType.getCharacteristicType().isPredefinedValue()) {
					recordLineMtr.setMeterType(meterChar.getCharacteristicValue().trim());
				}
				else if (parmMeterCharType.getCharacteristicType().isForeignKeyValue()) {
					recordLineMtr.setMeterType(meterChar.getCharacteristicValueForeignKey1().trim());	
				}
				else {
					recordLineMtr.setMeterType(meterChar.getAdhocCharacteristicValue().trim());
				}						 
			}
			recordLineMtr.setServiceSequence(serviceCycleSequence.toString().trim());
			recordLineMtr.setMeterConfigId(mtrConfigId.getTrimmedValue());
			recordLineMtr.setMeterManufacturer(meter.getModel().fetchIdManufacturer().getId().getTrimmedValue());

			recordLineMtr.setMeterLocationCode(wRecordMeterLocation);

			recordLineMtr.setMeterReadInstruction(wRecordMrInstructionCodeStr);

			recordLineMtr.setMeterWarning(wRecordMrWarningStr);

			Bool wWriteMtxRecord = Bool.FALSE;
			if (notBlank(latitude) 
					&& notBlank(longitude)) {
				
				recordLineMtr.setMeterExtraRecordIndicator(INDICATOR_Y);	
				wWriteMtxRecord = Bool.TRUE;
			}
			else {
				
				recordLineMtr.setMeterExtraRecordIndicator(INDICATOR_N);
				wWriteMtxRecord = Bool.FALSE;
			}

			Bool wWriteMtsRecord = Bool.FALSE;
			if (isBlankOrNull(servicePoint.getMeterLocationDetails())) {
				
				recordLineMtr.setMessageIndicator(INDICATOR_N);
				recordLineMtr.setDisplayIndicator("0");
				wWriteMtsRecord = Bool.FALSE;
			} 
			else {
				
				recordLineMtr.setMessageIndicator(INDICATOR_Y);
				recordLineMtr.setDisplayIndicator("1");
				wWriteMtsRecord = Bool.TRUE;
			}	

			recordLineMtr.setCategory(LETTER_G);

			CmITRONMeterReadDownloadReadingDetailRecord recordLineRdg = new CmITRONMeterReadDownloadReadingDetailRecord();

			//format RDG record type
			recordLineRdg.setRecordType(RECORD_TYPE_RDG);
			recordLineRdg.setServiceCycle(mrCycleCode);
			recordLineRdg.setRouteType(wRouteType);
			recordLineRdg.setServiceRoute(mrRoute);

			recordLineRdg.setTextPrompt(LETTER_GAS);
			recordLineRdg.setPromptCode(INDICATOR_Y);
			recordLineRdg.setReadDirection(LETTER_L);

			recordLineRdg.setNbrOfDialOnMeter(register.getNumberOfDigitsLeft().toString().trim());
			recordLineRdg.setNbrDigitRight(register.getNumberOfDigitsRight().toString().trim());
			recordLineRdg.setReadMethod(wReadMethod);
			// 3269752
			recordLineRdg.setPreviousReading(prevRegReading);
			recordLineRdg.setReadHighLimit(hiLimit);
			recordLineRdg.setReadLowLimit(loLimit);
			recordLineRdg.setRegisterConstant(register.getRegisterConstant().toString().trim());

			if (register.getNumberOfDigitsLeft().intValue() >= 1 
					&& register.getNumberOfDigitsLeft().intValue() <= 5){

				recordLineRdg.setReadTypeCode(VALUE_01);
			}else if (register.getNumberOfDigitsLeft().intValue() == 6) {
				
				if (wErtCharValue.trim().equalsIgnoreCase(parmErt_100g.trim())) {
					
					recordLineRdg.setReadTypeCode(VALUE_02);
				}
				else if(wErtCharValue.trim().equalsIgnoreCase(parmErt_40g.trim())){
					
					recordLineRdg.setReadTypeCode(VALUE_06);
				}
			}					
			else {	
				
				logWarning(CustomMessageRepositoryMGE.ccb001ErrorEncounteredReadType(
						register.getId().getTrimmedValue(), register.getNumberOfDigitsLeft().toString()));								
				recordLineRdg.setReadTypeCode(TWO_ZERO);
			}

			CmITRONMeterReadDownloadCustomerDetailRecord recordLineCus = new CmITRONMeterReadDownloadCustomerDetailRecord();

			//start format CUS record type
			recordLineCus.setRecordType(RECORD_TYPE_CUS);
			recordLineCus.setServiceCycle(mrCycleCode);
			recordLineCus.setRouteType(wRouteType);
			recordLineCus.setServiceRoute(mrRoute);
			//*Start add - DHuynh - 2015-12-01 - Defect#56274
			wTotalCustInRoute = wTotalCustInRoute +1;
			//*End add - DHuynh - 2015-12-01 - Defect#56274
			recordLineCus.setTotalNbrMeterForCustomer("1");

			// Populate the Account Id
			recordLineCus.setAccountId(recordAccountID);

			// Populate the Customer Name
			recordLineCus.setEntityName(customerName);

			// Populate the Address 1
			recordLineCus.setAddress1(premise.getAddress1());

			// Populate the Address 2
			recordLineCus.setAddress2(premise.getAddress2());

			// Populate the Premise Id
			recordLineCus.setPremiseId(premId.getTrimmedValue());

			recordLineCus.setExtendRecord(INDICATOR_N);
			// Populate the Amr Segment Code
			recordLineCus.setSegmentCode(wAmrSegmentCd);

			// Write CUS,MTR,MTX,MTS,RDG,RFF record type to flat file
			cmWriteToFile(recordLineCus.createRecordString());
			cmWriteToFile(recordLineMtr.createRecordString());

			// START CHANGES - JHERNA - 2015-08-14 - 3282313
			/*
			 * Move and re-arrange this section. It is requested that the MTS records should be written immediately after MTR record 
			 * and MTX record after the MTS record. (currently it is MTR>MTX>MTS; request is MTR>MTS>MTX)
			 */
			/*
			 * 2015-08-17 Requested to revert back to the original order MTR>MTX>MTS
			 */
			//check if it need to write Mtx record
			if (wWriteMtxRecord.isTrue()) {
				
				CmITRONMeterReadDownloadMeterExtraDetailRecord recordLineMtx = new CmITRONMeterReadDownloadMeterExtraDetailRecord();
				recordLineMtx.setRecordType(RECORD_TYPE_MTX);
				recordLineMtx.setServiceCycle(mrCycleCode);
				recordLineMtx.setRouteType(wRouteType);
				recordLineMtx.setServiceRoute(mrRoute);				
				recordLineMtx.setBadgeNbr(meter.getBadgeNumber());
				recordLineMtx.setGeoLatitude(latitude);
				recordLineMtx.setGeoLongitude(longitude);
				cmWriteToFile(recordLineMtx.createRecordString());
			}
			//check if it need to write Mts record
			if (wWriteMtsRecord.isTrue()) {
				
				CmITRONMeterReadDownloadMeterSpecialMessageDetailRecord recordLineMts = new CmITRONMeterReadDownloadMeterSpecialMessageDetailRecord();
				recordLineMts.setRecordType(RECORD_TYPE_MTS);
				recordLineMts.setServiceCycle(mrCycleCode);
				recordLineMts.setRouteType(wRouteType);
				recordLineMts.setServiceRoute(mrRoute);				
				recordLineMts.setBadgeNbr(meter.getBadgeNumber());
				recordLineMts.setSpecialTextMessage(servicePoint.getMeterLocationDetails());				
				cmWriteToFile(recordLineMts.createRecordString());
			}
			
			/*
			//check if it need to write Mts record
			if (wWriteMtsRecord.isTrue()) {
				
				CmITRONMeterReadDownloadMeterSpecialMessageDetailRecord recordLineMts = new CmITRONMeterReadDownloadMeterSpecialMessageDetailRecord();
				recordLineMts.setRecordType(RECORD_TYPE_MTS);
				recordLineMts.setServiceCycle(mrCycleCode);
				recordLineMts.setRouteType(wRouteType);
				recordLineMts.setServiceRoute(mrRoute);				
				recordLineMts.setBadgeNbr(meter.getBadgeNumber());
				recordLineMts.setSpecialTextMessage(servicePoint.getMeterLocationDetails());				
				cmWriteToFile(recordLineMts.createRecordString());
			}			
			//check if it need to write Mtx record
			if (wWriteMtxRecord.isTrue()) {
				
				CmITRONMeterReadDownloadMeterExtraDetailRecord recordLineMtx = new CmITRONMeterReadDownloadMeterExtraDetailRecord();
				recordLineMtx.setRecordType(RECORD_TYPE_MTX);
				recordLineMtx.setServiceCycle(mrCycleCode);
				recordLineMtx.setRouteType(wRouteType);
				recordLineMtx.setServiceRoute(mrRoute);				
				recordLineMtx.setBadgeNbr(meter.getBadgeNumber());
				recordLineMtx.setGeoLatitude(latitude);
				recordLineMtx.setGeoLongitude(longitude);
				cmWriteToFile(recordLineMtx.createRecordString());
			}	
			*/
			// END CHANGES - JHERNA - 2015-08-14 - 3282313
			cmWriteToFile(recordLineRdg.createRecordString());

			if (wWriteRffRecord.isTrue()){

				CmITRONMeterReadDownloadRadioDetailRecord recordLineRff = new CmITRONMeterReadDownloadRadioDetailRecord();			
				recordLineRff.setRecordType(RECORD_TYPE_RFF);
				recordLineRff.setServiceCycle(mrCycleCode);
				recordLineRff.setRouteType(wRouteType);
				recordLineRff.setServiceRoute(mrRoute);
				recordLineRff.setBadgeNbrErt(wERTItemBatchNumber);
				recordLineRff.setRadioFrequency(RADIO_FREQUENCY);
				recordLineRff.setRadioTone(VALUE_ZERO004);
				recordLineRff.setTamperCode(wTamperCode);
				recordLineRff.setConcentratorErtIndicator(INDICATOR_N);
				cmWriteToFile(recordLineRff.createRecordString());	
			}
		}

		/**
		 * Custom method which writes the cycle trailer
		 */
		private void cmFormCycleTrailerRecordLineAndWrite() {
			cmWriteToFile(wHoldCycleheader.replaceFirst("CHD", "CTR"));
		}

		/**
		 * Custom method which writes the route trailer
		 */
		private void cmFormRouteTrailerRecordLineAndWrite() {				

			CmITRONMeterReadDownloadRouteHeaderRecord routeTrailer = new CmITRONMeterReadDownloadRouteHeaderRecord();
			routeTrailer.setRecordType(RECORD_TYPE_ROUTETRLR);
			routeTrailer.setMeterCycle(wHoldCycleForWriteRouteTrailer);
			routeTrailer.setRouteType(wHoldRouteTypeForWriteRouteTrailer);				
			routeTrailer.setServiceRoute(wHoldRouteForWriteRouteTrailer);			
			routeTrailer.setSurveyIndicator(INDICATOR_N);
			routeTrailer.setMessageIndicator(INDICATOR_N);					
			routeTrailer.setTotalNbrOfReadExpectInRoute(wHoldTotalNbrOfMeterInRoute);
			routeTrailer.setTotalNbrOfERTRead(wTotalErtInRoute.toString());
			//*Start Change - DHuynh - 2015-12-01 - Defect#56274
			//wTotalCustInRoute = BigInteger.valueOf(collOfAcctIDs.size());
			//*End Change - DHuynh - 2015-12-01 - Defect#56274

			routeTrailer.setTotalNbrOfCustomerInRoute(wTotalCustInRoute.toString());	
			
			routeTrailer.setTotalNbrOfMeterInRoute(wHoldTotalNbrOfMeterInRoute);							
			routeTrailer.setTotalNbrOfGasMeterInRoute(wHoldTotalNbrOfMeterInRoute);																				
			cmWriteToFile(routeTrailer.createRecordString());
			//collOfAcctIDs = new ArrayList<Account_Id>();
			//*Start Add - DHuynh - 2015-12-01 - Defect#56274
			wTotalCustInRoute = 0;
			//*End Add - DHuynh - 2015-12-01 - Defect#56274

		}
		
		/**
		 * Custom method which writes the route header record
		 */
		private void cmFormRouteHeaderRecordLineAndWrite() {
			
			BigInteger totalMeter = cmRetrieveMeterCount(wProcessMeterReadCycle, wProcessRoute );
			//Start Change - DarrylH - SA-220105: 2017-07-19
			//Start Add - DarrylH - SA211192: 2017-06-01
			String mgeServingOfficeCode;			
			if (this.getBatchControlId().getTrimmedValue().equalsIgnoreCase("CM-MDLSC"))	
			 {
				mgeServingOfficeCode = VALUE_99;
			 }
			else{
				mgeServingOfficeCode = cmRetrieveOfficeArea(wProcessMeterReadCycle, wProcessRoute );		
			}			
			//End Add - DarrylH - SA211192: 2017-06-01
			//End Change - DarrylH - SA-220105: 2017-07-19
			CmITRONMeterReadDownloadRouteHeaderRecord routeHeader = new CmITRONMeterReadDownloadRouteHeaderRecord();
			routeHeader.setRecordType(RECORD_TYPE_ROUTEHDR);
			routeHeader.setMeterCycle(wProcessMeterReadCycle);
			routeHeader.setRouteType(wRouteType);
			routeHeader.setServiceRoute(wProcessRoute);
			routeHeader.setSurveyIndicator(INDICATOR_N);
			routeHeader.setMessageIndicator(INDICATOR_N);					
			routeHeader.setTotalNbrOfReadExpectInRoute(totalMeter.toString().trim());
			routeHeader.setTotalNbrOfMeterInRoute(totalMeter.toString().trim());
			routeHeader.setTotalNbrOfGasMeterInRoute(totalMeter.toString().trim());
			//Start Add - DarrylH - SA211192: 2017-06-01
			routeHeader.setOffice(mgeServingOfficeCode.toString().trim());
			//End Add - DarrylH - SA211192: 2017-06-01
			
			cmWriteToFile(routeHeader.createRecordString());

			//move to storage for writing route TRAILER record 
			wHoldCycleForWriteRouteTrailer = wProcessMeterReadCycle;
			wHoldRouteTypeForWriteRouteTrailer = wRouteType;
			wHoldRouteForWriteRouteTrailer = wProcessRoute;
			wHoldTotalNbrOfMeterInRoute = totalMeter.toString().trim();
		}
		
		/**
		 * Custom method which writes the cycle header record
		 */
		private void cmFormCycleHeaderRecordLineAndWrite() {
			
			CmITRONMeterReadDownloadCycleHeaderRecord cycleHeader = new CmITRONMeterReadDownloadCycleHeaderRecord();
			cycleHeader.setRecordType(RECORD_TYPE_CYLHDR);
			cycleHeader.setMeterCycle(wProcessMeterReadCycle.toString().trim());
			cycleHeader.setTotalNbrRouteInCycle(totalRoute.toString().trim());
			cycleHeader.setScheduleWorkDate(scheduleDate);			
			cmWriteToFile(cycleHeader.createRecordString());
			//Hold cycle Header record for later write out as TRAILER record
			wHoldCycleheader = cycleHeader.createRecordString();
		}

		/**
		 * Base method which is called at the end after processing all records for each thread. This is called only once per thread
		 */
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// Start Change - DHuynh - 2015-04-28 - Defect#3200203
			// Write all TRAILER records and close the file only if there is record to process from the table
			if (notNull(wHoldCycleheader)){
				cmFormRouteTrailerRecordLineAndWrite();
				cmFormCycleTrailerRecordLineAndWrite();
				cmFormFileTrailerRecordLineAndWrite();
				cmCloseFile();
			}
			// End Change - DHuynh - 2015-04-28 - Defect#3200203
		}
		/**
		 * Custom method which writes the file trailer record
		 */
		private void cmFormFileTrailerRecordLineAndWrite() {
			cmWriteToFile(wHoldFileheader.replaceFirst("FHD", "FTR"));
		}		
	}
}
