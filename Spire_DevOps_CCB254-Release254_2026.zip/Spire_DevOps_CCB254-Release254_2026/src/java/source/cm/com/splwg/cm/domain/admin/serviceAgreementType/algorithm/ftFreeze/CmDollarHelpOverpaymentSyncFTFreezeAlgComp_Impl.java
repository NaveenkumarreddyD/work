/*
 ***************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Dollar Help Over Payment Sync - FT Freeze Algorithm
 * 
 * This algorithm creates a Sync Adjustment whenever any FT is frozen 
 * against a Dollar Help Over Payment SA, given the following conditions:
 * 
 *     - FT being frozen is not for a Sync Adjustment
 *     - FT current amount != 0 
 *     - FT payoff amount = 0
 *      
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2018-02-02	JHERNA	SysAid#232761. Initial Version.
 * 
 **************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.ftFreeze;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.ftFreeze.SaTypeFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = syncAdjustmentType, required = true, type = entity)})
 */
public class CmDollarHelpOverpaymentSyncFTFreezeAlgComp_Impl 
		extends CmDollarHelpOverpaymentSyncFTFreezeAlgComp_Gen 
		implements SaTypeFtFreezeAlgorithmSpot {


	/*HARD PARAMETERS*/
	private Bool hpWasFinancialProcessAdded;
	private FinancialTransaction hpFT;
	private FinancialTransactionTypeLookup hpFTTypeLookup;
	@SuppressWarnings("unused")
	private FinancialTransaction hpRegularFT;
	
	/*SOFT PARAMETERS*/
	private AdjustmentType parmAdjTypeSync;

	@Override
	public Bool getWasFinancialProcessAdded() {
		return hpWasFinancialProcessAdded;
	}

	@Override
	public void setFinancialTransaction(FinancialTransaction ft) {
		this.hpFT = ft;
	}

	@Override
	public void setFinancialTransactionType(FinancialTransactionTypeLookup ftTypeLookup) {
		this.hpFTTypeLookup = ftTypeLookup;
	}

	@Override
	public void setRegularFinancialTransaction(FinancialTransaction regFT) {
		this.hpRegularFT = regFT;
	}	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		/*Retrieve Algorithm Parameter 10: Sync Adjustment Type*/
		this.parmAdjTypeSync = this.getSyncAdjustmentType();
	}

	@Override
	public void invoke() {
		/*
		 * Skip processing if the FT is for an Adjustment / Adjustment Cancellation and the parent id matches the Sync Adjustment
		 */
		String parentID = hpFT.getParentId().trim();
		if ((hpFTTypeLookup.isAdjustment()
				|| hpFTTypeLookup.isAdjustmentCancellation())
				&& (parentID.compareTo(parmAdjTypeSync.getId().getTrimmedValue()) == 0)) {
			return;
		}
		/* Create Sync Adjustment if current amount != 0 and payoff amount == 0*/
		if (hpFT.getCurrentAmount().compareTo(Money.ZERO) != 0
				&& hpFT.getPayoffAmount().compareTo(Money.ZERO) == 0) {
			/* Create a Sync Adjustment */
						
			ServiceAgreement serviceAgreement = hpFT.getServiceAgreement();
			CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
			adjustmentData.setServiceAgreement(serviceAgreement);
			adjustmentData.setAdjustmentType(parmAdjTypeSync);
			adjustmentData.setAllowZeroAmount(Bool.FALSE);
			adjustmentData.setAdjustmentDate(this.getProcessDateTime().getDate());			
			adjustmentData.setAdjustmentAmount(hpFT.getCurrentAmount().negate());
			createAdjustment(serviceAgreement, adjustmentData);
		}				
	}
	
	private Adjustment_Id createAdjustment(ServiceAgreement sa, CreateFrozenAdjustmentData adjData) {
		
		Adjustment_Id returnValue = null;
		CreateFrozenAdjustmentData result = sa.createFrozenAdjustment(adjData);
		returnValue = result.getAdjustment().getId();		
		return returnValue;
	}
}
