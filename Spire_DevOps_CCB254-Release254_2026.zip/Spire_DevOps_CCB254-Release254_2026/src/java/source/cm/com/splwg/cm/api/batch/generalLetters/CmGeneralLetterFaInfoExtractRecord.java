/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Field Activity Information Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterFaInfoExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String FA_PRINT_KEY = "1150";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    private static final String DEFAULT_TIME_FORMAT_FILLER = ".000000";
    
    public CmGeneralLetterFaInfoExtractRecord() {
        super(20);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(FA_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */    
    public void setFKCharType(String fkCharType) {    	
    	this.rightPadColumn(8, 8, formatString(fkCharType, 8));
    }
          
    public void setCharTypeDescr(String charTypeDescr) {    	
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));
    }  
    
    public void setFaId(String faID) {
    	this.rightPadColumn(10, 10, formatString(faID, 10));    	
    }
    
    public void setFaTypeCd(String faTypeCd) {
    	this.rightPadColumn(11, 8, formatString(faTypeCd, 8));    	
    }
    
    public void setFaTypeDescr(String faTypeDescr) {
    	this.rightPadColumn(12, 60, formatString(faTypeDescr, 60));    	
    }
    
    public void setFaSchedDttm(String faSchedDttm) {
    	this.rightPadColumn(13, 19, formatString(faSchedDttm, 19));   
    	setTimeFormatFiller();
    }
    
    private void setTimeFormatFiller() {
    	this.rightPadColumn(14, 7, DEFAULT_TIME_FORMAT_FILLER);
    }
    
    public void setFaStatus(String faStatus) {
    	this.rightPadColumn(15, 2, formatString(faStatus, 2));    	
    }
    
    public void setFaCanRsnCd(String faCanRsnCd) {
    	this.rightPadColumn(16, 8, formatString(faCanRsnCd, 8));    	
    }
    
    public void setFaCanRsnDescr(String faCanRsnDescr) {
    	this.rightPadColumn(17, 60, formatString(faCanRsnDescr, 60));    	
    }
    
    public void setFaReschedRsnCd(String faReschedRsnCd) {
    	this.rightPadColumn(18, 12, formatString(faReschedRsnCd, 12));    	
    }
    
    public void setFaReschedRsnDescr(String faReschedRsnDescr) {
    	this.rightPadColumn(19, 60, formatString(faReschedRsnDescr, 60));  
    	setFillerEndSpaces();
    }
        
    private void setFillerEndSpaces() {
        this.rightPadColumn(20, 1653, BLANK);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
