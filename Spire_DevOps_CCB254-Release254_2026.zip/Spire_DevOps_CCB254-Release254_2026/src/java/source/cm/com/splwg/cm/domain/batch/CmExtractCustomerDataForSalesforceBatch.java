/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Extract Customer Data for Salesforce Batch Process
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-10-21   RDizon  CCB046. Initial version.  
 * 2021-12-02   NMendo  Defect 4629503. Replace Premise Type field with 
 *                      Customer Type.
 *     
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.ccb.api.lookup.BusinessObjectStatusOptionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StateConditionLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonContactDetail_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.cm.api.batch.CmSalesforceCustomerDataDetailRecord;
import com.splwg.cm.api.batch.CmSalesforceCustomerDataHeaderRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author RDizon
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CUST_CL_CD_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PHONE_TYPE_CD_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CUSTOMER_TYPE, required = true, type = string)})
 */
public class CmExtractCustomerDataForSalesforceBatch extends
        CmExtractCustomerDataForSalesforceBatch_Gen {

    @Override
    public void validateSoftParameters(boolean isNewRun) {
        
        // Validate the File Path
        String parmFilePath = getParameters().getFILE_PATH();
        File folder = new File(parmFilePath);
        if (!folder.isDirectory()) {
            addError(CustomMessageRepositorySpireOne.CCB046_BatchParmInvalidFilePath(
                    "File Path",
                    parmFilePath));
        }
        
        // Validate the CIS Divisions
        String[] cisDivisions = getParameters().getCIS_DIVISION_LIST().split(",");
        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepositorySpireOne.CCB046_BatchParmInvalidCisDivision(
                        "CIS Divisions",
                        cisDivStr));
            }
        }
        
       // Validate the Customer Class Codes
        String[] customerClasses = getParameters().getCUST_CL_CD_LIST().split(",");
        for (int i=0; i < customerClasses.length; i++){
            String customerClassStr = customerClasses[i];
            CustomerClass customerClass = new CustomerClass_Id(customerClassStr.trim()).getEntity();
            if (isNull(customerClass)){
                addError(CustomMessageRepositorySpireOne.CCB046_BatchParmInvalidCustomerClass(
                        "Customer Class Codes",
                        customerClassStr));
            }
        }
        
    }
    
    @Override
    public JobWork getJobWork() {
        
        String cisDivisionsInQuotes = "'" + getParameters().getCIS_DIVISION_LIST().replaceAll(",", "','") + "'";
        String customerClassCodesInQuotes = "'" + getParameters().getCUST_CL_CD_LIST().replaceAll(",", "','") + "'";
        
        StringBuilder queryString = new StringBuilder();
        queryString.append("SELECT ACCT.ACCT_ID ACCT_ID, ");
        queryString.append("    SA.SA_ID SA_ID, ");
        queryString.append("    SP.SP_ID SP_ID ");
        queryString.append("FROM CI_ACCT ACCT, ");
        queryString.append("    CI_SA SA, ");
        queryString.append("    CI_SA_TYPE SAT, ");
        queryString.append("    CI_SA_SP SASP, ");
        queryString.append("    CI_SP SP ");
        queryString.append("WHERE ACCT.CIS_DIVISION IN (" + cisDivisionsInQuotes +") ");
        queryString.append("    AND ACCT.ACCT_ID = SA.ACCT_ID ");
        queryString.append("    AND ACCT.CUST_CL_CD IN (" + customerClassCodesInQuotes +") ");
        queryString.append("    AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop) ");
        queryString.append("    AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        queryString.append("    AND SA.CIS_DIVISION IN (" + cisDivisionsInQuotes +") ");
        queryString.append("    AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        queryString.append("    AND SAT.SVC_TYPE_CD = 'G' ");
        queryString.append("    AND SA.SA_ID = SASP.SA_ID ");
        queryString.append("    AND SASP.SP_ID = SP.SP_ID ");
        queryString.append("    AND SP.PREM_ID = SA.CHAR_PREM_ID ");
        
        PreparedStatement salesforceAccounts = createPreparedStatement(queryString.toString(), getClass().getName());
        salesforceAccounts.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        salesforceAccounts.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        salesforceAccounts.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        
        
        QueryIterator iterator = salesforceAccounts.iterate();
        
        return createJobWorkForQueryIterator(iterator, this);
    }
    
    @Override
    public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {

        String accountIdString = (String) queryResultRow.get("ACCT_ID");
        Account_Id accountId = new Account_Id(accountIdString);
        
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.setPrimaryId(accountId);
        threadWorkUnit.addSupplementalData("SA_ID", queryResultRow.getId("SA_ID", ServiceAgreement.class));   
        threadWorkUnit.addSupplementalData("SP_ID", queryResultRow.getId("SP_ID", ServicePoint.class));
        
        return threadWorkUnit;
    }

    public Class<CmExtractCustomerDataForSalesforceBatchWorker> getThreadWorkerClass() {
        return CmExtractCustomerDataForSalesforceBatchWorker.class;
    }

    public static class CmExtractCustomerDataForSalesforceBatchWorker extends
            CmExtractCustomerDataForSalesforceBatchWorker_Gen {
        
        // Batch Parameters
        private String parmFileName;
        private String parmFilePath;
        private String parmPhoneTypesList;
        // Start Add - NMendo - Defect 4629503 - 2021-12-02
        private String parmCustomerType;
        // End Add - NMendo - Defect 4629503 - 2021-12-02
        
        private CmSalesforceCustomerDataHeaderRecord salesforceHeaderRecord;
        private CmSalesforceCustomerDataDetailRecord salesforceDetailRecord;
        
        private String[] phoneTypes;
        private File extractFile;
        private BufferedWriter bwExtractFile;
        
        private Account account;
        private ServiceAgreement sa;
        private Premise premise;
        private Person mainPerson;
        
        private String mainPersonEntityName;
        private String address1;
        private String phoneNumber;
        private String emailAddress;
        private String badgeNumber;
        
        // Constants
        private static final String COMMA = ",";
        private static final String SPACE = " ";
        private static final String BLANK = "";
        
        private static final String SVC_TASK_TYPE = "CM-PMOC";
        private static final String BO_NAME_CM_PMOC = "CM-PreferredMethodOfContact";
        private static final String XPATH_ELEM_SVC_TASK_ID = "serviceTaskId";
        private static final String XPATH_GROUP_PMOC_DETAILS = "preferredMethodOfContactDetails";
        private static final String XPATH_GROUP_PMOC = "pmoc";
        private static final String XPATH_ELEM_EMAIL_CONTACT_ID = "emailContactId";
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            // Retrieve Batch parameters
            parmFileName = getParameters().getFILE_NAME();
            parmFilePath = getParameters().getFILE_PATH();
            parmPhoneTypesList = getParameters().getPHONE_TYPE_CD_LIST();
            // Start Add - NMendo - Defect 4629503 - 2021-12-02
            parmCustomerType = getParameters().getCUSTOMER_TYPE().trim();
            // End Add - NMendo - Defect 4629503 - 2021-12-02

            salesforceHeaderRecord = new CmSalesforceCustomerDataHeaderRecord();
            salesforceDetailRecord = new CmSalesforceCustomerDataDetailRecord();

            phoneTypes = parmPhoneTypesList.split(COMMA);
            
            String threadNumber = getBatchThreadNumber().toString();
            if (getBatchThreadNumber().compareTo(BigInteger.TEN) < 0){
                threadNumber = "0" + threadNumber;
            }
            
            int periodIndex = parmFileName.lastIndexOf('.');
            //  If filename has file extension
            if(periodIndex > 0){
                String fileNameWithoutFileExtension = parmFileName.substring(0, parmFileName.lastIndexOf('.')).trim();
                String fileExtension = parmFileName.substring(parmFileName.lastIndexOf('.')).trim();
                extractFile = new File(parmFilePath, fileNameWithoutFileExtension.concat(threadNumber).concat(fileExtension));
            //If filename has no file extension
            } else {
                extractFile = new File(parmFilePath, parmFileName + threadNumber + ".txt");
            }
            
            try {
                bwExtractFile = new BufferedWriter(new FileWriter(extractFile));
                bwExtractFile.write(salesforceHeaderRecord.createRecordString());
                bwExtractFile.newLine();
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB046_ErrorFileWriting(e.getMessage()));
                e.printStackTrace();
            }
            
            mainPersonEntityName = BLANK;
            address1 = BLANK;
            phoneNumber = BLANK;
            emailAddress = BLANK;
            badgeNumber = BLANK;
        }

        @Override
        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
            Account_Id accountId = (Account_Id) threadWorkUnit.getPrimaryId();
            ServiceAgreement_Id saId = (ServiceAgreement_Id) threadWorkUnit.getSupplementallData("SA_ID");
            ServicePoint_Id spId = (ServicePoint_Id) threadWorkUnit.getSupplementallData("SP_ID");
            
            account = accountId.getEntity();
            sa = saId.getEntity();  
            premise = sa.fetchPremise();
            
            salesforceDetailRecord.setAccount(accountId.getTrimmedValue());
            
            // Derive First and Last Names
            mainPerson = account.getMainPerson();
            mainPersonEntityName = mainPerson.getPersonPrimaryName();
            String[] names = mainPersonEntityName.split(COMMA);
            
            if (names.length > 1){
                salesforceDetailRecord.setFirstName(names[1]);
                salesforceDetailRecord.setLastName(names[0]);
            }
            else {
                salesforceDetailRecord.setFirstName(names[0]);
                salesforceDetailRecord.setLastName(BLANK);
            }
            
            // Derive Street and Address
            address1 = premise.getAddress1().trim();
            int index = address1.indexOf(SPACE);
            
            salesforceDetailRecord.setStreet(address1.substring(index + 1, address1.length()));
            salesforceDetailRecord.setAddress(address1);
            
            // Set other Premise details
            salesforceDetailRecord.setCity(premise.getCity());
            salesforceDetailRecord.setState(premise.getState().trim());
            salesforceDetailRecord.setPostalCode(premise.getPostal().trim());
            // Start Change - NMendo - Defect 4629503 - 2021-12-02
            //salesforceDetailRecord.setPremiseType(premise.getPremiseType().getId().getTrimmedValue());
            salesforceDetailRecord.setCustomerType(parmCustomerType);
            // End Change - NMendo - Defect 4629503 - 2021-12-02
            salesforceDetailRecord.setPremiseId(premise.getId().getTrimmedValue());

            // Derive Phone Number
            String phoneType = BLANK;
            PhoneType_Id phoneTypeId = null;
            for (int i=0; i < phoneTypes.length; i++){
                phoneType = phoneTypes[i];
                phoneTypeId = new PhoneType_Id(phoneType);
                if (notNull(phoneTypeId.getEntity())){
                    phoneNumber = getPhoneNumber(mainPerson.getId(), phoneTypeId);
                }
                
                if (notBlank(phoneNumber)){
                    break;
                }
            }
            salesforceDetailRecord.setPhoneNumber(phoneNumber);
            
            // Derive PMOC Email Address
            emailAddress = getPmocEmail();
            salesforceDetailRecord.setEmail(emailAddress);
            
            // Derive Badge Number of installed Meter
            badgeNumber = getBadgeNumber(spId);
            salesforceDetailRecord.setBadgeNumber(badgeNumber);

            // Set other details
            salesforceDetailRecord.setBetrw(BLANK);
            salesforceDetailRecord.setBDate(BLANK);
            salesforceDetailRecord.setText(BLANK);
            
            // Write the record to the file
            try {
                bwExtractFile.write(salesforceDetailRecord.createRecordString());
                bwExtractFile.newLine(); 
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB046_ErrorFileWriting(e.getMessage()));
                e.printStackTrace();
            }

            return true;
        }
        
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
            if (bwExtractFile != null){
                try {
                    bwExtractFile.close();
                }  catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB046_ErrorFileClosing(e.getMessage()));
                    e.printStackTrace();
                }
            }
        }

        private String getPmocEmail(){
            String pmocEmailAddress = BLANK;
            
            // Retrieve PMOC Service Task for Person
            ServiceTask pmocServiceTask = getPmocServiceTask();
            if (notNull(pmocServiceTask)){
                // Retrieve Email Contact ID
                BusinessObject_Id boId = new BusinessObject_Id(BO_NAME_CM_PMOC);
                BusinessObjectInstance boInstance = BusinessObjectInstance.create(boId.getEntity());
                boInstance.set(XPATH_ELEM_SVC_TASK_ID, pmocServiceTask.getId().getTrimmedValue());
                boInstance = BusinessObjectDispatcher.read(boInstance); 
                
                COTSInstanceNode boGroupPmocDetails = boInstance.getGroup(XPATH_GROUP_PMOC_DETAILS);
                COTSInstanceNode boGroupPmoc = boGroupPmocDetails.getGroup(XPATH_GROUP_PMOC);
                String emailContactIdStr = boGroupPmoc.getFieldAndMDForPath(XPATH_ELEM_EMAIL_CONTACT_ID).getXMLValue();
               
                if (notBlank(emailContactIdStr)){
                    PersonContactDetail_Id  emailContactId = new PersonContactDetail_Id(emailContactIdStr);
                    pmocEmailAddress = emailContactId.getEntity().getContactDetailValue();
                }
            }

            return pmocEmailAddress;
        }
        
        private ServiceTask getPmocServiceTask() {
            ServiceTask pmocServiceTask = null;
            ServiceTaskType_Id serviceTaskTypeId = new ServiceTaskType_Id(SVC_TASK_TYPE);
            
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT ST.F1_SVC_TASK_ID ");
            stringBuilder.append("FROM F1_SVC_TASK_REL_OBJ STRO, ");
            stringBuilder.append(    "F1_SVC_TASK ST ");
            stringBuilder.append("WHERE STRO.PK_VALUE1 = :personId ");
            stringBuilder.append(    "AND STRO.MAINT_OBJ_CD = 'PERSON' ");
            stringBuilder.append(    "AND STRO.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
            stringBuilder.append(    "AND ST.F1_STASK_TYPE_CD = :serviceTaskType ");
            stringBuilder.append(    "AND NOT EXISTS ( ");
            stringBuilder.append(                    "SELECT BOSTO.BO_OPT_VAL ");
            stringBuilder.append(                    "FROM F1_BUS_OBJ BO, F1_BUS_OBJ_STATUS_OPT BOSTO ");
            stringBuilder.append(                    "WHERE ST.BUS_OBJ_CD = BO.BUS_OBJ_CD ");
            stringBuilder.append(                    "AND BO.LIFE_CYCLE_BO_CD = BOSTO.BUS_OBJ_CD ");
            stringBuilder.append(                    "AND ST.BO_STATUS_CD = BOSTO.BO_STATUS_CD ");
            stringBuilder.append(                    "AND BOSTO.BO_OPT_FLG = :stateCondition ");
            stringBuilder.append(                    "AND BOSTO.BO_OPT_VAL = :inactive) ");

            PreparedStatement getPmocServiceTask = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getPmocServiceTask.bindId("personId", mainPerson.getId());
            getPmocServiceTask.bindId("serviceTaskType", serviceTaskTypeId);
            getPmocServiceTask.bindLookup("stateCondition", BusinessObjectStatusOptionTypeLookup.constants.STATE_CONDITION);
            getPmocServiceTask.bindLookup("inactive", StateConditionLookup.constants.INACTIVE);
            
            getPmocServiceTask.setAutoclose(false);

            SQLResultRow sqlRow = getPmocServiceTask.firstRow();
            if (notNull(sqlRow)) {
                ServiceTask_Id serviceTaskId = (ServiceTask_Id) sqlRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
                pmocServiceTask = serviceTaskId.getEntity();
            }
            
            getPmocServiceTask.close();
            
            return pmocServiceTask;
        }
        
        private String getBadgeNumber(ServicePoint_Id spId) {
            String badgeNumber = BLANK;
            
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT SPMH.MTR_CONFIG_ID MTR_CONFIG_ID ");
            stringBuilder.append("FROM CI_SP_MTR_HIST SPMH ");
            stringBuilder.append("WHERE SPMH.SP_ID = :spId ");
            stringBuilder.append("    AND (SPMH.REMOVAL_DTTM IS NULL ");
            stringBuilder.append("        OR SPMH.REMOVAL_DTTM > :currentDate)");

            PreparedStatement getBadgeNumber = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getBadgeNumber.bindId("spId", spId);
            getBadgeNumber.bindDate("currentDate", getProcessDateTime().getDate());
            
            getBadgeNumber.setAutoclose(false);

            SQLResultRow sqlRow = getBadgeNumber.firstRow();
            if (notNull(sqlRow)) {
                MeterConfiguration_Id meterConfigId = (MeterConfiguration_Id) sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
                badgeNumber = meterConfigId.getEntity().getMeter().getBadgeNumber().trim();
            }
            
            getBadgeNumber.close();
            
            return badgeNumber;
        }
        
        private String getPhoneNumber(Person_Id personId, PhoneType_Id phoneTypeId){
            String phoneNumber = BLANK;
            
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT PP.PHONE PHONE ");
            stringBuilder.append("FROM CI_PER_PHONE PP ");
            stringBuilder.append("WHERE PP.PER_ID = :personId ");
            stringBuilder.append("    AND PHONE_TYPE_CD = :phoneType ");

            PreparedStatement getPhoneNumber = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getPhoneNumber.bindId("personId", personId);
            getPhoneNumber.bindId("phoneType", phoneTypeId);
            getPhoneNumber.setAutoclose(false);

            SQLResultRow sqlRow = getPhoneNumber.firstRow();
            if (notNull(sqlRow)) {
                phoneNumber = sqlRow.getString("PHONE");
                phoneNumber = phoneNumber.replaceAll("[^0-9]", "");
            }
            
            getPhoneNumber.close();
            
            return phoneNumber;
        }
    }
}
