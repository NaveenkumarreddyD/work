/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION:
 * 
 * Pledge Action Batch Process Multi-threaded.
 * Pledge Action batch process was an initial design, with single threaded execution strategy.
 * The original process was rendering a slower output with larger Pledge action files.
 * This design is based on the original single threaded batch process with a few modification to achieve Multi-threading.
 * Instead of reading single record at a time from the file, A staging table has been created where all the valid records are uploaded
 * and then processed in multiple threads.
 * 
 ******************************************************************************* 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason:
 * YYYY-MM-DD  IN        Reason text.
 *
 * 2015-01-27  Rahul     (IM-062090)Created. Initial Version. 
 * 2015-11-11  Ujesh     #57114 -  CCB CMPLEDGE errors (Fixed Re-running Logic)  
 * 2016-02-18  MPang	 Updated for CCB v2.4 compilation.     
 * 2017-03-08  EEsteb    CCB-CC-002.4. Determine Payment Amt Year RoundUpdate on
 *                       existing Process Pledge Action File Batch Process        
 * 2017-07-20  ACasta    Defect 3793715. Modified to handle CWR 12 and CWR 50 
 *                       differently.
 * 2017-09-12  LBallo    Defect 3851641. Added condition in retrieving the
 * 						 lvl50CWRDownpaymentAmount. Checks if the quote source
 * 						 is CWR.
 * 2017-10-04  SFelip    Defect 3843433(Reopen).Updated the query used to 
 *                       retrieve existing active quotes.  
 * 2017-12-13  SFelip    Defect 3948617. Call the CmCreateServiceTask common
 *                       routing when creating Quotes instead of using createDTO.
 * 2018-01-29  JHerna	 SysAid#239434. Do not create CWR Quotes if the SA has a 
 * 						 status of Stopped (a standard quote would be created 
 *                       instead). Also added setAutoclose(false) to PreparedStatement
 *                       lines.
 * 2018-03-23  JHerna	 SysAid#245959. Do not create CWR Quotes if the SA has a
 *                       status of Reactivated (a standard quote would be created
 *                       instead).
 * 2018-07-25  SFelip    CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                       longer needed.                       
 * 2018-08-07  JHERNA	 SysAid#245408. Update Pledge creation to use Business Object
 * 						 so that BO Algorithms will be kicked off and triggered. 
 * 2018-09-20  MPang	 SA-267143. Updated to check if there is PA SA on account
 *                       equal to Parameter then set the selection to STANDARD.                               
 ******************************************************************************* 
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.lookup.TodoPriorityFlagLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControl_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeDrillKeyTypes;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.cm.api.batch.CmProcessPledgeActionFileRecord;
import com.splwg.cm.api.lookup.CmEligibleMajorPledgeFundingTypesLookup;
import com.splwg.cm.api.lookup.CmPaymentArrangementSaTypesLookup;
import com.splwg.cm.api.lookup.CmPledgeRecordStagingFlagLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.CmPledgeActionFileStgUp;
import com.splwg.cm.domain.common.CmPledgeActionFileStgUp_DTO;
import com.splwg.cm.domain.common.CmPledgeActionFileStgUp_Id;
import com.splwg.cm.domain.common.customBusinessComponent.CmCreateServiceTask;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessages;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/*
 * Change - EEsteb - CCB-CC-002.4 - 2017-03-06
 *
 * Added the following Parameters to the annotation below:
 * - QUOTE_SOURCE
 * - SS_PAY_OPT_CHAR_TYPE
 * - SS_PAY_OPT_NEW
 * - SS_PAY_OPT_REINST
 */

/*
 * Change - MPang - SA-267143 - 2018-09-20
 * Added PA_SA_TYPES_FOR_STANDARD_QUOTE
 * 
 */
/**
 * @author rsaran003
 *
@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = false, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = false, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = PLEDGE_BUSINESS_OBJECT, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_CANCELLED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = QUOTE_BUSINESS_OBJECT, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_BO_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = QUOTE_BO_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SA_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_AMOUNT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_CONF_DATE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FUNDING_TYPE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AGENCY_ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AGENCY_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = WEB_TRANS_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_LEVEL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_SOURCE_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SS_PAY_OPT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = SS_PAY_OPT_NEW, required = true, type = string)
 *            , @BatchJobSoftParameter (name = SS_PAY_OPT_REINST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PA_SA_TYPES_FOR_STANDARD_QUOTE, required = true, type = string)
 *            })
 */
public class CmProcessPledgeActionFileMultiThreadBatch extends
CmProcessPledgeActionFileMultiThreadBatch_Gen {

	// BATCH SOFT PARAMETERS
	private String parmFilePath;
	private String parmFileName;

	// CLASS VARIABLES
	private String inputFileCanonicalPath;
	private BufferedReader pledgeActionFile;
	private Bool parseError;
	private String accountIdStr;
	private String serviceAgreementIdStr;
	private String pledgeIdStr;
	private String pledgeAmountStr;
	private String agencyAccountIdStr;
	private String confirmationDateStr;
	private String fundingTypeStr;
	private String webTransactionIdStr;
	private String actionStr;
	private String batchControlId;
	private BigInteger batchControlNumber;
	private ArrayList<String> messageParamList = new ArrayList<String>();
	private BigInteger recordLineNum;

	// CONSTANTS
	private static final String TODO_PRIORITY_HIGH = "HIGH";
	private static final String TODO_PRIORITY_NORMAL = "NORMAL";



	public JobWork getJobWork() {

		
		// Decide we are re-running the batch
		if(getParameters().getBatchRerunNumber().compareTo(BigInteger.ZERO)>0) {
			List<ThreadWorkUnit> workunitList = fetchUnProcessed(getBatchControlId(),getBatchNumber());
			return createJobWorkForThreadWorkUnitList(workunitList);
		}
		
		cmReadFile();
		List<ThreadWorkUnit> workunitList = fetchRecordsToProcess(getBatchControlId(), getBatchNumber());
		List<String> duplicateRecordList = fetchDuplicateRecords(getBatchControlId(), getBatchNumber());

		for (String duplicatePledge : duplicateRecordList){
			messageParamList.clear();
			messageParamList.add(0, duplicatePledge);
			createToDo(CustomMessages.MESSAGE_CATEGORY, CustomMessages.IM062090_DUPLICATE_PLEDGE_RECORD_RECEIVED, messageParamList, TODO_PRIORITY_NORMAL);
		}
		return createJobWorkForThreadWorkUnitList(workunitList);
	}

	/**
	 * Process records in Error for the previous run
	 * @param batchControlId
	 * @param batchRerunNumber
	 * @return
	 */
	private List<ThreadWorkUnit> fetchUnProcessed(BatchControl_Id batchControlId, BigInteger batchRerunNumber) {

		List<ThreadWorkUnit> unitList = new ArrayList<ThreadWorkUnit>();
		
		StringBuilder cmRetrieveRecordStatusStmtStrbuilder = new StringBuilder();
		cmRetrieveRecordStatusStmtStrbuilder.append(" SELECT CM_PLEDGE_ID,ACCT_ID,SA_ID,CM_PLDG_AMT,CM_FNDNG_TYPE,CM_CONF_DATE,CM_AGENCY_ACCT_ID,CM_WEB_TRNSCTN_ID,CM_PLDG_ACTION,PROCESS_DT,CM_PLDG_RCRD_ST_FLG ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" FROM CM_PLDG_ACTN_FILE_STG_UP ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" WHERE BATCH_CD = :batchCode ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" AND BATCH_NBR = :batchNumber ");
		// 2015-11-10 - 57114 - Ujesh -  Start Change
		//cmRetrieveRecordStatusStmtStrbuilder.append(" AND CM_PLDG_RCRD_ST_FLG = :status ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" AND CM_PLDG_RCRD_ST_FLG in(:pending, :error) ");
		// 2015-11-10 - 57114 - Ujesh - End Change
		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement fetchUnProcessedStmt=createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString());
		PreparedStatement fetchUnProcessedStmt=createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString(), getClass().getName());
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		fetchUnProcessedStmt.bindId("batchCode", batchControlId);
		fetchUnProcessedStmt.bindBigInteger("batchNumber", batchRerunNumber);
		// 2015-11-10 - 57114 - Ujesh - Start Change
		//fetchUnProcessedStmt.bindLookup("status", CmPledgeRecordStagingFlagLookup.constants.ERROR);
		fetchUnProcessedStmt.bindLookup("pending", CmPledgeRecordStagingFlagLookup.constants.PENDING);
		fetchUnProcessedStmt.bindLookup("error", CmPledgeRecordStagingFlagLookup.constants.ERROR);
		// 2015-11-10 - 57114 - Ujesh - End Change
		
        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		fetchUnProcessedStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
        
		Iterator<SQLResultRow> fetchUpProcessedIterator = fetchUnProcessedStmt.iterate();
		while(fetchUpProcessedIterator.hasNext())
		{
			SQLResultRow row = fetchUpProcessedIterator.next();
			
			String pledgeIdStr = row.getString("CM_PLEDGE_ID");
			String accountIdStr = row.getString("ACCT_ID");
			String serviceAgreementIdStr = row.getString("SA_ID");
			String actionStr = row.getString("CM_PLDG_ACTION");		
			
			// Updating the Status Back to Pending
			CmPledgeActionFileStgUp_Id pledgerecordId = new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeIdStr), accountIdStr, serviceAgreementIdStr, batchControlId.getTrimmedValue(), batchRerunNumber, actionStr);
			CmPledgeActionFileStgUp pledgerecordEntity = pledgerecordId.getEntity();
			CmPledgeActionFileStgUp_DTO pledgerecordDTO = pledgerecordEntity.getDTO();
			pledgerecordDTO.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.PENDING);
			pledgerecordEntity.setDTO(pledgerecordDTO);
			
			// Adding the unit to Worklist
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new ServiceTask_Id(row.getString("CM_PLEDGE_ID")));
			workUnit.addSupplementalData("ACCT_ID", row.getString("ACCT_ID"));
			workUnit.addSupplementalData("SA_ID", row.getString("SA_ID"));
			workUnit.addSupplementalData("CM_PLDG_AMT", row.getString("CM_PLDG_AMT"));
			workUnit.addSupplementalData("CM_FNDNG_TYPE", row.getString("CM_FNDNG_TYPE"));
			workUnit.addSupplementalData("CM_CONF_DATE", row.getString("CM_CONF_DATE"));
			workUnit.addSupplementalData("CM_AGENCY_ACCT_ID", row.getString("CM_AGENCY_ACCT_ID"));
			workUnit.addSupplementalData("CM_WEB_TRNSCTN_ID", row.getString("CM_WEB_TRNSCTN_ID"));
			workUnit.addSupplementalData("CM_PLDG_ACTION", row.getString("CM_PLDG_ACTION"));
			workUnit.addSupplementalData("PROCESS_DT", row.getDate("PROCESS_DT"));
			unitList.add(workUnit); 
			
		}
		fetchUnProcessedStmt.close();		
		
		return unitList;
	}

	/**
	 * Read input file
	 * @param NULL
	 * @return Void
	 * Raise a TODO if error received while opening the file
	 */
	private void cmReadFile() {

		recordLineNum = BigInteger.ZERO;
		parmFilePath = this.getParameters().getFILE_PATH();
		parmFileName = this.getParameters().getFILE_NAME();
		try
		{
			File file = new File(parmFilePath, parmFileName);
			inputFileCanonicalPath = file.getCanonicalPath();
			pledgeActionFile = new BufferedReader(new FileReader(file));
			String recordLine;
			while(!isBlankOrNull(recordLine = pledgeActionFile.readLine())){
				recordLineNum = recordLineNum.add(BigInteger.ONE);
				cmReadUploadRecords(recordLine);
			}
			pledgeActionFile.close();
		}
		catch(IOException e)
		{	
			messageParamList.clear();
			messageParamList.add(0, inputFileCanonicalPath);
			createToDo(CustomMessagesMDC.MESSAGE_CATEGORY, CustomMessagesMDC.NI0026_3_ERROR_OPENING_FILE, messageParamList, TODO_PRIORITY_HIGH);
			throw new RunAbortedException(CustomMessageRepositoryMDC.ni00263ErrorOpeningFile(inputFileCanonicalPath));
		}
	}


	/**
	 * Retrieves Fields from the input file
	 * @param Record line
	 * @return void
	 * Raise a TODO if an error occurs while parsing the record line
	 */
	private void cmReadUploadRecords(String record) {

		CmProcessPledgeActionFileRecord fileRecord = new CmProcessPledgeActionFileRecord(record);
		accountIdStr = fileRecord.getAccountId();
		serviceAgreementIdStr = fileRecord.getServiceAgreementId();
		pledgeIdStr = fileRecord.getPledgeId();
		pledgeAmountStr = fileRecord.getPledgeAmount();
		agencyAccountIdStr = fileRecord.getAgencyAccountId();
		fundingTypeStr = fileRecord.getFundingType();
		confirmationDateStr = fileRecord.getConfirmationDate();
		webTransactionIdStr = fileRecord.getWebTransactionId();
		actionStr = fileRecord.getAction();
		parseError = fileRecord.getParseError();
		batchControlId = getBatchControlId().getTrimmedValue();
		batchControlNumber = getBatchNumber();

		if (parseError.isTrue()) {

			messageParamList.clear();
			messageParamList.add(0, recordLineNum.toString());
			createToDo(CustomMessagesMDC.MESSAGE_CATEGORY, CustomMessagesMDC.NI0026_3_ERROR_PARSING_FILE, messageParamList, TODO_PRIORITY_NORMAL);
			return;

		}else{

			if(isRecordProcessed(new Account_Id(accountIdStr), new ServiceAgreement_Id(serviceAgreementIdStr), new ServiceTask_Id(pledgeIdStr), new BatchControl_Id(batchControlId), batchControlNumber).equals(Bool.FALSE)){

				CmPledgeActionFileStgUp_Id pledgerecordId = new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeIdStr), accountIdStr, serviceAgreementIdStr, batchControlId, batchControlNumber, actionStr);
				CmPledgeActionFileStgUp_DTO pledgerecordDTO = createDTO(CmPledgeActionFileStgUp.class);
				pledgerecordDTO.setId(pledgerecordId);
				pledgerecordDTO.setCmPledgeAmount(pledgeAmountStr);
				pledgerecordDTO.setCmAgencyAccountId(agencyAccountIdStr);
				pledgerecordDTO.setCmFundingType(fundingTypeStr);
				pledgerecordDTO.setCmConfirmationDate(confirmationDateStr);
				pledgerecordDTO.setCmWebTransactionId(webTransactionIdStr);
				pledgerecordDTO.setProcessDate(getProcessDateTime().getDate());
				pledgerecordDTO.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.PENDING);            
				pledgerecordDTO.newEntity();

			}else{
				String pledgeRecordStatus = cmRetrieveRecordStatus(pledgeIdStr, actionStr);
				if(pledgeRecordStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.ERROR.trimmedValue())){
					CmPledgeActionFileStgUp_Id pledgerecordId = new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeIdStr), accountIdStr, serviceAgreementIdStr, batchControlId, batchControlNumber, actionStr);
					CmPledgeActionFileStgUp pledgerecordEntity = pledgerecordId.getEntity();
					CmPledgeActionFileStgUp_DTO pledgerecordDTO = pledgerecordEntity.getDTO();
					pledgerecordDTO.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.PENDING);
					pledgerecordEntity.setDTO(pledgerecordDTO);
				}
			}
		}
	}
	
	private String cmRetrieveRecordStatus(String pledgeId, String pledgeAction){

		StringBuilder cmRetrieveRecordStatusStmtStrbuilder = new StringBuilder();
		cmRetrieveRecordStatusStmtStrbuilder.append(" SELECT CM_PLDG_RCRD_ST_FLG ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" FROM CM_PLDG_ACTN_FILE_STG_UP ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" WHERE CM_PLEDGE_ID = :pledgeId ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" AND BATCH_CD = :batchCode ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" AND BATCH_NBR = :batchNumber ");
		cmRetrieveRecordStatusStmtStrbuilder.append(" AND CM_PLDG_ACTION = :action ");

		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement cmRetrieveRecordStatusStmt = createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString());
		PreparedStatement cmRetrieveRecordStatusStmt = createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString(), getClass().getName());
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		cmRetrieveRecordStatusStmt.bindBigInteger("pledgeId", new BigInteger(pledgeId));
		cmRetrieveRecordStatusStmt.bindId("batchCode", getBatchControlId());
		cmRetrieveRecordStatusStmt.bindBigInteger("batchNumber", getBatchNumber());
		cmRetrieveRecordStatusStmt.bindStringProperty("action", CmPledgeActionFileStgUp.properties.cmPledgeAction, pledgeAction);
		String recordStatus = (String) cmRetrieveRecordStatusStmt.firstRow().get("CM_PLDG_RCRD_ST_FLG");

        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		cmRetrieveRecordStatusStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
		cmRetrieveRecordStatusStmt.close();

		return recordStatus;

	}
	/**
	 * Checks if the record has been processed before
	 * @param AccountId, SaId, PledgeId, BatchControl, BatchNumber
	 * @return Bool
	 **/

	private Bool isRecordProcessed(Account_Id AccountId, ServiceAgreement_Id SaId, ServiceTask_Id PledgeId, BatchControl_Id BatchControl, BigInteger BatchNumber){

		PreparedStatement isRecordProcessedStmt = createPreparedStatement("SELECT 'X' " +
				"FROM CM_PLDG_ACTN_FILE_STG_UP  " +
				"WHERE ACCT_ID = :accountId " +
				"AND SA_ID = :serviceAgreementId " +
				"AND CM_PLEDGE_ID = :pledgeId " +
				"AND BATCH_CD = :batchCode " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//"AND BATCH_NBR = :batchNumber ");
				"AND BATCH_NBR = :batchNumber ", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

		isRecordProcessedStmt.bindId("accountId", AccountId);
		isRecordProcessedStmt.bindId("serviceAgreementId", SaId);
		isRecordProcessedStmt.bindId("pledgeId", PledgeId);
		isRecordProcessedStmt.bindId("batchCode", BatchControl);
		isRecordProcessedStmt.bindBigInteger("batchNumber", BatchNumber);

		SQLResultRow resultRow = isRecordProcessedStmt.firstRow();

        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		isRecordProcessedStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
		
		isRecordProcessedStmt.close();
		if(isNull(resultRow)){

			return Bool.FALSE;

		}else{

			return Bool.TRUE;
		}
	}

	/**
	 * Fetch records to be processed as work unit
	 * @param batchControl, batchNumber
	 * @return List<ThreadWorkUnit>
	 **/

	public List<ThreadWorkUnit> fetchRecordsToProcess(BatchControl_Id batchControl, BigInteger batchNumber){

		PreparedStatement fetchRecordsToProcessStmt = createPreparedStatement(" SELECT CM_PLEDGE_ID, ACCT_ID, SA_ID, CM_PLDG_AMT, CM_FNDNG_TYPE, CM_CONF_DATE, CM_AGENCY_ACCT_ID, CM_WEB_TRNSCTN_ID, CM_PLDG_ACTION, PROCESS_DT " +
				" FROM CM_PLDG_ACTN_FILE_STG_UP A " +
				" WHERE A.BATCH_CD = :batchCode " +
				" AND A.BATCH_NBR = :batchNumber " +
				" AND A.CM_PLDG_RCRD_ST_FLG = :pledgeRecordStagingFlag " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//" AND  NOT EXISTS (SELECT 'X' FROM CM_PLDG_ACTN_FILE_STG_UP B WHERE B.CM_PLEDGE_ID = A.CM_PLEDGE_ID AND A.BATCH_NBR = B.BATCH_NBR AND A.BATCH_CD = B.BATCH_CD AND B.CM_PLDG_ACTION <> A.CM_PLDG_ACTION ) ");
				" AND  NOT EXISTS (SELECT 'X' FROM CM_PLDG_ACTN_FILE_STG_UP B WHERE B.CM_PLEDGE_ID = A.CM_PLEDGE_ID AND A.BATCH_NBR = B.BATCH_NBR AND A.BATCH_CD = B.BATCH_CD AND B.CM_PLDG_ACTION <> A.CM_PLDG_ACTION ) ", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		
		fetchRecordsToProcessStmt.bindId("batchCode", batchControl);
		fetchRecordsToProcessStmt.bindBigInteger("batchNumber", batchNumber);
		fetchRecordsToProcessStmt.bindLookup("pledgeRecordStagingFlag", CmPledgeRecordStagingFlagLookup.constants.PENDING);
        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		fetchRecordsToProcessStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
		
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> fetchRecordsToProcessIter = fetchRecordsToProcessStmt.iterate();

		while (fetchRecordsToProcessIter.hasNext()) {
			SQLResultRow row = fetchRecordsToProcessIter.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new ServiceTask_Id(row.getString("CM_PLEDGE_ID")));
			workUnit.addSupplementalData("ACCT_ID", row.getString("ACCT_ID"));
			workUnit.addSupplementalData("SA_ID", row.getString("SA_ID"));
			workUnit.addSupplementalData("CM_PLDG_AMT", row.getString("CM_PLDG_AMT"));
			workUnit.addSupplementalData("CM_FNDNG_TYPE", row.getString("CM_FNDNG_TYPE"));
			workUnit.addSupplementalData("CM_CONF_DATE", row.getString("CM_CONF_DATE"));
			workUnit.addSupplementalData("CM_AGENCY_ACCT_ID", row.getString("CM_AGENCY_ACCT_ID"));
			workUnit.addSupplementalData("CM_WEB_TRNSCTN_ID", row.getString("CM_WEB_TRNSCTN_ID"));
			workUnit.addSupplementalData("CM_PLDG_ACTION", row.getString("CM_PLDG_ACTION"));
			workUnit.addSupplementalData("PROCESS_DT", row.getDate("PROCESS_DT"));
			workUnits.add(workUnit);              
		}
		fetchRecordsToProcessIter.close();  
		fetchRecordsToProcessStmt.close();

		return workUnits;
	}

	/**
	 * Fetch Duplicate records list with same Pledgeid and different action
	 * @param batchControl, batchNumber
	 * @return List<String>
	 **/
	public List<String> fetchDuplicateRecords(BatchControl_Id batchControl, BigInteger batchNumber){

		List<String> duplicatePledgeList = new ArrayList<String>();
		PreparedStatement fetchDuplicateRecordsStmt = createPreparedStatement(" SELECT DISTINCT(CM_PLEDGE_ID) PLEDGEID " +
				" FROM CM_PLDG_ACTN_FILE_STG_UP A " +
				" WHERE A.BATCH_CD = :batchCode " +
				" AND A.BATCH_NBR = :batchNumber " +
				" AND A.CM_PLDG_RCRD_ST_FLG = :pledgeRecordStagingFlag " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//" AND EXISTS (SELECT 'X' FROM CM_PLDG_ACTN_FILE_STG_UP B WHERE B.CM_PLEDGE_ID = A.CM_PLEDGE_ID AND A.BATCH_NBR = B.BATCH_NBR AND A.BATCH_CD = B.BATCH_CD AND B.CM_PLDG_ACTION <> A.CM_PLDG_ACTION ) ");
				" AND EXISTS (SELECT 'X' FROM CM_PLDG_ACTN_FILE_STG_UP B WHERE B.CM_PLEDGE_ID = A.CM_PLEDGE_ID AND A.BATCH_NBR = B.BATCH_NBR AND A.BATCH_CD = B.BATCH_CD AND B.CM_PLDG_ACTION <> A.CM_PLDG_ACTION ) ", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		
		fetchDuplicateRecordsStmt.bindId("batchCode", batchControl);
		fetchDuplicateRecordsStmt.bindBigInteger("batchNumber", batchNumber);
		fetchDuplicateRecordsStmt.bindLookup("pledgeRecordStagingFlag", CmPledgeRecordStagingFlagLookup.constants.PENDING);

        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		fetchDuplicateRecordsStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
		
		QueryIterator<SQLResultRow> fetchDuplicateRecordsIter = fetchDuplicateRecordsStmt.iterate();
		while (fetchDuplicateRecordsIter.hasNext()) {

			SQLResultRow row = fetchDuplicateRecordsIter.next();
			duplicatePledgeList.add(row.getString("PLEDGEID"));

		}
		fetchDuplicateRecordsIter.close();  
		fetchDuplicateRecordsStmt.close();

		return duplicatePledgeList;
	}

	/**
	 * Validates soft parameters
	 */
	@Override
	public void validateSoftParameters(boolean isNewRun) {

		// Retrieve Soft Parameters
		String filePath = this.getParameters().getFILE_PATH();
		String fileName = this.getParameters().getFILE_NAME();
		BusinessObject pledgeBo = this.getParameters().getPLEDGE_BUSINESS_OBJECT();
		String pledgeBoActiveStatus = this.getParameters().getPLEDGE_BO_ACTIVE_STATUS();
		String pledgeBoCancelledStatus = this.getParameters().getPLEDGE_BO_CANCELLED_STATUS();
		String pledgeBoExpiredStatus = this.getParameters().getPLEDGE_BO_EXPIRED_STATUS();
		BusinessObject quoteBo = this.getParameters().getQUOTE_BUSINESS_OBJECT();
		String quoteBoActiveStatus = this.getParameters().getQUOTE_BO_ACTIVE_STATUS();
		String quoteBoExpiredStatus = this.getParameters().getQUOTE_BO_EXPIRED_STATUS();
		CharacteristicType accountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
		CharacteristicType saIdCharType = this.getParameters().getSA_ID_CHAR_TYPE();
		CharacteristicType pledgeIdCharType = this.getParameters().getPLEDGE_ID_CHAR_TYPE();
		CharacteristicType pledgeAmountCharType = this.getParameters().getPLEDGE_AMOUNT_CHAR_TYPE();
		CharacteristicType pledgeConfirmationDateCharType = this.getParameters().getPLEDGE_CONF_DATE_CHAR_TYPE();
		CharacteristicType fundingTypeCharType = this.getParameters().getFUNDING_TYPE_CHAR_TYPE();
		CharacteristicType agencyAccountIdCharType = this.getParameters().getAGENCY_ACCT_ID_CHAR_TYPE();
		CharacteristicType agencyCodeCharType = this.getParameters().getAGENCY_CODE_CHAR_TYPE();
		CharacteristicType webTransactionIdCharType = this.getParameters().getWEB_TRANS_ID_CHAR_TYPE();
		CharacteristicType cwrLevelCharType = this.getParameters().getCWR_LEVEL_CHAR_TYPE();
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		String parmQuoteSourceList = getParameters().getQUOTE_SOURCE_LIST(); 
		CharacteristicType ssPayOptCharType = getParameters().getSS_PAY_OPT_CHAR_TYPE();
		String newPayOpt = getParameters().getSS_PAY_OPT_NEW();
		String reinstatePayOpt = getParameters().getSS_PAY_OPT_REINST();
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */

		if(getParameters().getBatchRerunNumber().compareTo(BigInteger.ZERO)==0)
		{
			if(isBlankOrNull(filePath))
				addError(CustomMessageRepositoryMDC.ni00263InvalidFilePath(" "));;
			// Check that filePath is a valid and existing directory.
			if (cmIsValidFilePath(filePath).isFalse()) {
				addError(CustomMessageRepositoryMDC.ni00263InvalidFilePath(filePath));
			}
	
			if(isBlankOrNull(fileName))
				addError(CustomMessageRepositoryMDC.ni00263InvalidFileName(" "));
			// Check that fileName is a valid filename.
			if (cmIsValidFileName(fileName).isFalse()) {
				addError(CustomMessageRepositoryMDC.ni00263InvalidFileName(fileName));
			}

			// Check that fileName exists in the filePath directory.
			if (cmIsFileExisting(filePath, fileName).isFalse()) {
				addError(CustomMessageRepositoryMDC.ni00263FileDoesNotExist(filePath + fileName));
			}
		}		

		// Check that the pledgeBusinessObjectActiveStatus, pledgeBusinessObjectCancelledStatus,
		// and pledgeBusinessObjectExpiredStatus are valid Business Object statuses for pledgeBusinessObject.
		cmValidateBoStatus(pledgeBo, pledgeBoActiveStatus);
		cmValidateBoStatus(pledgeBo, pledgeBoCancelledStatus);
		cmValidateBoStatus(pledgeBo, pledgeBoExpiredStatus);

		// Check that the quoteBusinessObjectActiveStatus and quoteBusinessObjectExpiredStatus are valid
		// Business Object statuses for quoteBusinessObject.
		cmValidateBoStatus(quoteBo, quoteBoActiveStatus);
		cmValidateBoStatus(quoteBo, quoteBoExpiredStatus);

		// Check the following Characteristic Type parameters if it is valid for the Service Task entity.
		// If not, raise error MSG15.
		cmValidateCharacteristicEntity(accountIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(saIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(pledgeIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(pledgeAmountCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(pledgeConfirmationDateCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(fundingTypeCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(agencyAccountIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(agencyCodeCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(webTransactionIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		cmValidateCharacteristicEntity(cwrLevelCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		String[] quoteSourceListArray = parmQuoteSourceList.split(",");
		if(quoteSourceListArray.length == 0){
			addError(CustomMessageRepository.CC_002_4_quoteSourceListInvalid(parmQuoteSourceList));
		}
		
		cmValidateCharacteristicEntity(ssPayOptCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		
		//New Payment Option Characteristic Value
		BatchControlParameter_Id batchParmId = new BatchControlParameter_Id(getBatchControlId(), BigInteger.valueOf(260));
		validateCharTypePredefinedValue(batchParmId.getEntity().fetchLanguageDescription(), ssPayOptCharType, newPayOpt);
		
		//Reinstatement Payment Option Characteristic Value
		batchParmId = new BatchControlParameter_Id(getBatchControlId(), BigInteger.valueOf(270));
		validateCharTypePredefinedValue(batchParmId.getEntity().fetchLanguageDescription(), ssPayOptCharType, reinstatePayOpt);
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
	}
	
	/*
     * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
     */
	private void validateCharTypePredefinedValue(String parmDesc, CharacteristicType charType, String charValue){
		if (charType.getCharacteristicType().isPredefinedValue()) {
		    CharacteristicValue_Id charValId = new CharacteristicValue_Id(charType, charValue);

		    if (isNull(charValId.getEntity())) {
		        addError(CustomMessageRepository.CC_002_4_charValueInvalidForCharType(parmDesc, charValue
		        		, charType.getId().getTrimmedValue()));
		    }
		}
	}
	/*
     * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
     */

	/**
	 * Validates File Path
	 * @param path File Path
	 * @return True if valid, else False
	 */
	private Bool cmIsValidFilePath(String path) {

		File filePath = new File(path);

		if (filePath.isDirectory()) {

			return Bool.TRUE;

		}

		return Bool.FALSE;

	}

	/**
	 * Validates File Name
	 * @param fileName File Name
	 * @return True if valid, else False
	 */
	public Bool cmIsValidFileName(String fileName)
	{	

		File file = new File(fileName);

		try {

			file.getCanonicalPath();
			return Bool.TRUE;

		}

		catch (IOException e) {

			return Bool.FALSE;

		}
	}

	/**
	 * Checks is file is existing
	 * @param path File Path
	 * @param fileName File Name
	 * @return True if existing, else False
	 */
	public Bool cmIsFileExisting(String path, String fileName)
	{	

		File file = new File(path + fileName);
		if (file.exists()) {

			return Bool.TRUE;

		}

		return Bool.FALSE;

	}

	/**
	 * Validates Business Object Status
	 * @param bo Business Object
	 * @param boStatus Business Object Status
	 */
	private void cmValidateBoStatus(BusinessObject bo, String boStatus) {

		BusinessObjectStatus_Id boStatusId = new BusinessObjectStatus_Id(bo.fetchLifecycleBusinessObject(), boStatus);

		if (isNull(boStatusId.getEntity())) {

			addError(CustomMessageRepositoryMDC.ni00263InvalidStatusForBo(boStatus.trim(), bo.getId().getTrimmedValue()));

		}
	}


	/**
	 * Validates Characteristic Entity
	 * @param charType Characteristic Type
	 * @param charEntityLookup Characteristic Entity Lookup
	 */
	private void cmValidateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType,
				charEntityLookup);

		if (isNull(charEntityId.getEntity())) {

			addError(CustomMessageRepositoryMDC.ni00263InvalidCharTypeForEntity(charType.getId().getTrimmedValue(),
					charEntityLookup.getLookupValue().fetchLanguageDescription().trim()));

		}
	}
	/**
	 * This method creates To Do Entry
	 * @param accountStr - Account Id
	 */
	private void createToDo(int messageCategory, int messageNumber, ArrayList<String> messageParameterList, String priority) {

		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		ToDoType toDoType = getParameters().getTO_DO_TYPE();
		entryDto.setToDoTypeId(toDoType.getId());
		entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);

		if(priority.equals(TODO_PRIORITY_HIGH)){

			entryDto.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_1_0);

		}else{

			entryDto.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_3_0);

		}


		entryDto.setToDoRoleId(getDefaultToDoRole().getId());
		entryDto.setCreationDateTime(getProcessDateTime());
		MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(messageCategory));
		Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(messageNumber));
		entryDto.setMessageId(msgId);

		ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
		ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

		for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {

			ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
			ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
			BigInteger seq = sortKeyType.fetchIdSequence();
			sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){

				sortKeyDto.setKeyValue(getBatchControlId().getTrimmedValue());

			}
			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(2))==0){

				sortKeyDto.setKeyValue(getBatchNumber().toString());

			}
			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(3))==0){

				sortKeyDto.setKeyValue(getBatchRerunNumber().toString());

			}
			sortKeyList.add(sortKeyDto);
		}

		ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
		ToDoTypeDrillKeyTypes drillKeyTypes = toDoType.getDrillKeyTypes();

		for(Iterator<ToDoDrillKeyType> iter = drillKeyTypes.iterator(); iter.hasNext();){

			ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) iter.next();
			ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
			BigInteger seq = drillKeyType.fetchIdSequence();
			drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){

				drillKeyDto.setKeyValue(getBatchControlId().getTrimmedValue());

			}
			if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(2))==0){

				drillKeyDto.setKeyValue(getBatchNumber().toString());

			}
			if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(3))==0){

				drillKeyDto.setKeyValue(getBatchRerunNumber().toString());

			}
			drillKeyList.add(drillKeyDto);
		}

		ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();
		toDoEntryData.setDrillKeys(drillKeyList);
		toDoEntryData.setEntryDto(entryDto);
		toDoEntryData.setSortKeys(sortKeyList);
		toDoEntryData.setMessageParams(messageParameterList);
		ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		toDoEntryData.setToDoCharacteristics(charList);
		ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		toDoProcessor.addToDo(toDoEntryData);
	}

	/**
	 * This method fetches the Default Role to create a TODO
	 * @return Role 
	 */ 
	private Role getDefaultToDoRole(){

		Role defaultRole = null;
		StringBuilder defaultRoleQueryString = new StringBuilder();
		defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");

		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString()); 
		PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString(), getClass().getName()); 
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		defaultRolePrepStmt.bindId("toDoType", getParameters().getTO_DO_TYPE().getId()); 
		defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
		defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
		
        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
		defaultRolePrepStmt.setAutoclose(false);
        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
		
		defaultRolePrepStmt.close();
		return defaultRole;

	}

	/**
	 * Gets Thread Worker Class 
	 */    

	public Class<CmProcessPledgeActionFileMultiThreadBatchWorker> getThreadWorkerClass() {
		return CmProcessPledgeActionFileMultiThreadBatchWorker.class;
	}


	public static class CmProcessPledgeActionFileMultiThreadBatchWorker extends
	CmProcessPledgeActionFileMultiThreadBatchWorker_Gen {

		// BATCH SOFT PARAMETERS
		private ServiceTaskType parmPledgeServiceTaskType;
		private BusinessObject parmPledgeBo;
		private String parmPledgeBoActiveStatus;
		private String parmPledgeBoCancelledStatus;
		private String parmPledgeBoExpiredStatus;
		private ServiceTaskType parmQuoteServiceTaskType;
		private BusinessObject parmQuoteBo;
		private String parmQuoteBoActiveStatus;
		private String parmQuoteBoExpiredStatus;
		/*
		 *  START CHANGES - JHERNA - 2018-08-07 - SysAid#245408
		 *  Remove unused variables
		 */
		//private CharacteristicType parmAccountIdCharType;
		private CharacteristicType parmSaIdCharType;
		private CharacteristicType parmPledgeIdCharType;
		//private CharacteristicType parmPledgeAmountCharType;
		//private CharacteristicType parmPledgeConfirmationDateCharType;
		//private CharacteristicType parmFundingTypeCharType;
		//private CharacteristicType parmAgencyAccountIdCharType;
		/*
		 * END CHANGES - JHERNA - 2018-08-07 - SysAid#245408
		 * remove unused variables
		 */
		private CharacteristicType parmAgencyCodeCharType;
		private CharacteristicType parmWebTransactionIdCharType;
		private CharacteristicType parmCwrLevelCharType;
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		private String parmQuoteSourceListString;
		private String parmNewPayOptCharVal;
		private String parmReinstatePayOptCharVal;
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */

		// Input variables
		private ServiceTaskType serviceTaskType;
		private BusinessObject businessObject;
		private String status;
		private DateTime creationDateTime;
		private DateTime statusDateTime;
		private DateTime effectiveDateTime;
		private String selection;
		private String source;

		// Constants
		private static final String QUOTE_SRC_AGENCY = "Agency";
		private static final String SELECTION_CWR = "CWR";
		private static final String SERVICE_AGREEMENT = "Service Agreement";
		private static final String ACCOUNT = "Account";
		private static final String ACTION_NEW = "NEW";
		private static final String ACTION_CANCEL = "CANCEL";
		private static final String ACTION_EXPIRE = "EXPIRE";
		private static final String SERVICE_TASK_TYPE = "Service Task Type";
		private static final String BUSINESS_OBJECT = "Business Object";
		private static final String STATUS = "Status";
		/*
		 * Start Add - MPang - SA-267143 - 2018-09-20
		 */
		private static final String PA_SA_TYPE_FOR_STANDARD_QUOTE = "PA SA Type For Standard Quote";
		/*
		 * End Add - MPang - SA-267143 - 2018-09-20
		 */
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private static final String PREMISE = "Premise";
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		private static final String SERVICE_TASK = "Service Task";
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private static final String DATE_FORMAT = "yyyy-MM-dd";
		//private static final String CWR_SEASON_DATE_FORMAT = "MM/dd/yyyy";
		//private static final String CWR_SEASON_END = "CWR Season End";
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		private static final String STANDARD = "Standard";
		private static final String CCB = "CCB";
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private static final String NO = "No";
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		private static final String PERCENT_12 = "12";
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private static final String PERCENT_50 = "50";
		//private static final String PERCENT_80 = "80";
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		private static final String TODO_PRIORITY_HIGH = "HIGH";
		private static final String TODO_PRIORITY_NORMAL = "NORMAL";
		private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
		private static DateFormat yyyyMmDd = new DateFormat(DATE_FORMAT_YYYY_MM_DD);
		private static final String STATUS_ERROR = "ERROR";
		private static final String STATUS_COMPLETE = "COMPLETE";
		// Defect 3851641 - 2017-09-12 - Start Add
		private static final String CWR_QUOTE_SRC = "CSS-CWR";
		// Defect 3851641 - 2017-09-12 - End Add
		/*
		 * Start Add - MPang - SA-267143 - 2018-09-20
		 */
		private static final String COMMA_DELIMITER = ",";
		private static final String SINGLE_QUOTE = "'";
		/*
		 * End Add - MPang - SA-267143 - 2018-09-20
		 */
		
		// Other variables
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private CharacteristicType serviceAgreementCharType;
		//private CharacteristicType cisDivisionCharType;
		//private CharacteristicType debtClassCharType;
		//private CharacteristicType expirationDateCharType;
		//private CharacteristicType cwrLevelCharType;
		//private CharacteristicType totalSaArrearsCharType;
		//private CharacteristicType totalDiversionCharType;
		//private CharacteristicType monthlyBudgetCharType;
		//private CharacteristicType standardTurnOnOrAvoidSeveranceAmountCharType;
		//private CharacteristicType cwrDownPaymentCharType;
		//private CharacteristicType cwrMonthlyPaymentArrangementCharType;
		//private CharacteristicType bpap050MonthlyBudgetCharType;
		//private CharacteristicType bpap5199MonthlyBudgetCharType;
		//private CharacteristicType bpap100125MonthlyBudgetCharType;
		//private CharacteristicType bpap126185MonthlyBudgetCharType;
		//private CharacteristicType arp050DownPaymentCharType;
		//private CharacteristicType arp5199DownPaymentCharType;
		//private CharacteristicType arp100125DownPaymentCharType;
		//private CharacteristicType arp126185DownPaymentCharType;    
		//private CharacteristicType monthlyArp050PaymentArrangement12MonthCharType;
		//private CharacteristicType monthlyArp5199PaymentArrangement12MonthCharType;
		//private CharacteristicType monthlyArp100125PaymentArrangement12MonthCharType;
		//private CharacteristicType monthlyArp126185PaymentArrangement12MonthCharType;
		//private CharacteristicType monthlyArp050PaymentArrangement24MonthCharType;
		//private CharacteristicType monthlyArp5199PaymentArrangement24MonthCharType;
		//private CharacteristicType monthlyArp100125PaymentArrangement24MonthCharType;
		//private CharacteristicType monthlyArp126185PaymentArrangement24MonthCharType;
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		private CharacteristicType selectionCharType;
		private CharacteristicType quoteSourceCharType;
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private CharacteristicType customDownPaymentCharType;
		//private CharacteristicType averageBillAmountCharType;
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		private CharacteristicType selfServicePayOptCharType;
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		/*
		 * Start Add - MPang - SA-267143 - 2018-09-20
		 */
		private String paSaTypesForStandardQuote;
		/*
		 * End Add - MPang - SA-267143 - 2018-09-20
		 */

		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//private BigDecimal bpap050CreditValue;
		//private BigDecimal bpap5199CreditValue;
		//private BigDecimal bpap100125CreditValue;
		//private BigDecimal bpap126185CreditValue;
		//
		//private BigDecimal arp050DownPaymentValue;
		//private BigDecimal arp5199DownPaymentValue;
		//private BigDecimal arp100125DownPaymentValue;
		//private BigDecimal arp126185DownPaymentValue;
		//
		//private FeatureConfiguration diversionSaTypesFeatConfig; 
		//private CharacteristicType recalculatedCharType;
		//private CharacteristicType cwrPremiseCharType;
		//private String recalculatedCharValue;
		//private CharacteristicType brokenCharType;
		//private String brokenCharValue;
		//private CharacteristicType cwrCharType;
		//private String cwrCharValue;
		//private AdjustmentType transferAdjustmentType;
		//private String cwrSeasonEnd;
		//private String charPremiseIdString;
		//private int roundUpUnit;
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */

		// Class Variables
		private FeatureConfiguration paymentArrangementSaTypesFeatConfig;
		private Account_Id accountId;
		private Account account;
		private Account_Id otherPledgeAccountId;
		private Account otherPledgeAccount;
		private ServiceTask_Id pledgeId;
		private ServiceTask_Id otherPledgePledgeId;
		private ServiceAgreement_Id serviceAgreementId;
		private ServiceAgreement serviceAgreement;
		private ServiceAgreement_Id otherPledgeServiceAgreementId;
		private ServiceAgreement otherPledgeServiceAgreement;
		private Money pledgeAmount;
		private Money otherPledgePledgeAmount;
		private String fundingType;
		private String otherPledgeFundingType;
		private Date confirmationDate;
		private Date otherPledgeConfirmationDate;
		private Account_Id agencyAccountId;
		private Account_Id otherPledgeAgencyAccountId;
		private Account agencyAccount;
		private Account otherPledgeAgencyAccount;
		private List<String> majorFundingTypesList = new ArrayList<String>();
		private BigInteger webTransactionId;
		private BigInteger otherPledgeWebTransactionId;
		private String pledgeAction;
		private String otherPledgePledgeAction;
		private String pledgeStatus;
		private String otherPledgePledgeStatus;
		private String agencyCode;
		private String otherpledgeAgencyCode;
		private BigInteger numOfToDoEntriesPosted;
		ArrayList <String> messageParameterList = new ArrayList<String> ();
		private Bool skipRecord;
		private Bool skipOtherRecord;
		private String systemErrorStr;
		private int messageCategory;
		private int messageNumber;
		private String priority;
		private ServerMessage serverMessage;
		private FrameworkSession session;
		private String savepointId;
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		private String[] quoteSourceListArray;
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */

		/**
		 * Creates execution strategy
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {

			return new CommitEveryUnitStrategy(this);

		}

		/**
		 * Initializes Thread Work
		 */
		@Override
		public void initializeThreadWork(
				boolean arg0)
						throws ThreadAbortedException, RunAbortedException {

			numOfToDoEntriesPosted = BigInteger.ZERO;
			cmRetrieveBatchParameters();
			retrieveAndValidateInputParameters();
			retrieveAndValidateOtherParameters();

		}



		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			skipRecord = Bool.FALSE;
			skipOtherRecord = Bool.FALSE;
			otherPledgePledgeId = null;
			systemErrorStr = null;

			// Validate the record fields
			cmValidatePledgeFields(unit);

			// Retrieve the Major Funding Types from the Eligible Major Pledge Funding Type Feature Configuration
			cmRetrieveMajorFundingTypes();

			// Retrieve the Payment Arrangement SA Type feature configuration 
			paymentArrangementSaTypesFeatConfig = 
					cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_PAYMENT_ARRANGEMENT_SA_TYPES);
			// If action is NEW
			if(skipRecord.isFalse()){

				SQLResultRow existingPledgeResultRow = cmAnotherActionExistForAccount();

				if (pledgeAction.equals(ACTION_NEW)) {

					if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){

						if(cmCreateNewPledge(pledgeId, confirmationDate, serviceAgreement, account, pledgeAmount, fundingType, agencyAccount, webTransactionId, agencyCode)){
							
							setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_COMPLETE);

							return true;
						}else{

							if(!isNull(systemErrorStr)){
								messageParameterList.clear();
								messageParameterList.add(0, pledgeId.getTrimmedValue());
								messageParameterList.add(1, systemErrorStr);
								createToDo(CustomMessages.MESSAGE_CATEGORY, CustomMessages.IM062090_PLEDGE_NOT_PROCESSED, messageParameterList, TODO_PRIORITY_NORMAL);
								logError(CustomMessageRepository.IM062090_pledgeNotProcessed(pledgeId.getTrimmedValue(), systemErrorStr));
								numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);
							}
							setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

							return false;
						}

					}
					if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.COMPLETE.trimmedValue())){
						return true;
						
					}
					if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.ERROR.trimmedValue())){
						return false;
					}

				}

				// If action is CANCEL or EXPIRE
				if (pledgeAction.equals(ACTION_CANCEL) || pledgeAction.equals(ACTION_EXPIRE)) {

					if(!isNull(existingPledgeResultRow)){

						cmValidateExistingPledgeFields(existingPledgeResultRow);
						
						if(otherPledgePledgeAction.trim().equals(ACTION_NEW)  && (otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue()))){

							if(skipOtherRecord.isFalse()){

								if(cmCreateNewPledge(otherPledgePledgeId, otherPledgeConfirmationDate, otherPledgeServiceAgreement, otherPledgeAccount, otherPledgePledgeAmount,otherPledgeFundingType, otherPledgeAgencyAccount, otherPledgeWebTransactionId, otherpledgeAgencyCode)){

									setRecordStatus(otherPledgePledgeId, otherPledgeAccountId, otherPledgeServiceAgreementId, otherPledgePledgeAction, STATUS_COMPLETE);

									if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){

										if (cmCancelExpirePledge(pledgeId, confirmationDate, webTransactionId, accountId, serviceAgreementId, pledgeAction)){

											setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_COMPLETE);

											return true;
										}

										setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

										return false;

									}
								}else{

									setRecordStatus(otherPledgePledgeId, otherPledgeAccountId, otherPledgeServiceAgreementId, otherPledgePledgeAction, STATUS_ERROR);

									setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

									if(!isNull(systemErrorStr)){

										messageParameterList.clear();
										messageParameterList.add(0, otherPledgePledgeId.getTrimmedValue());
										messageParameterList.add(1, pledgeId.getTrimmedValue());
										messageParameterList.add(2, otherPledgeAccountId.getTrimmedValue());
										messageParameterList.add(3, systemErrorStr);
										createToDo(CustomMessages.MESSAGE_CATEGORY, CustomMessages.IM062090_PLEDGE_CANCEL_NOT_PROCESSED, messageParameterList, TODO_PRIORITY_HIGH);
										logError(CustomMessageRepository.IM062090_pledgeCancelNotProcessed(otherPledgePledgeId.getTrimmedValue(), pledgeId.getTrimmedValue(), accountId.getTrimmedValue(), systemErrorStr));
										numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);
									}

									return false;
								}
							}

							logError(serverMessage);
							createToDo(messageCategory, messageNumber, messageParameterList, priority);
							numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);
							setRecordStatus(otherPledgePledgeId, otherPledgeAccountId, otherPledgeServiceAgreementId, otherPledgePledgeAction, STATUS_ERROR);

							setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);
							
							return false;
						}else{

							if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){

								if (cmCancelExpirePledge(pledgeId, confirmationDate, webTransactionId, accountId, serviceAgreementId, pledgeAction)){

									setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_COMPLETE);

									return true;
								}

								setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

								return false;
							}
						}
					}else{

						if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){

							if (cmCancelExpirePledge(pledgeId, confirmationDate, webTransactionId, accountId, serviceAgreementId, pledgeAction)){

								setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_COMPLETE);

								return true;
							}

							setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

							return false;
						}
					}
				}

			}

			logError(serverMessage);
			createToDo(messageCategory, messageNumber, messageParameterList, priority);
			numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);
			setRecordStatus(pledgeId, accountId, serviceAgreementId, pledgeAction, STATUS_ERROR);

			return false;
		}

		private void setRecordStatus(ServiceTask_Id pledgeId, Account_Id accountId, ServiceAgreement_Id serviceAgreementId, String pledgeAction, String status){
			CmPledgeActionFileStgUp_Id cmPledgeActionid = 
					new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeId.getTrimmedValue()), 
							accountId.getTrimmedValue(), serviceAgreementId.getTrimmedValue(), getBatchControlId().getTrimmedValue(), getBatchNumber(), pledgeAction); 
			CmPledgeActionFileStgUp cmPledgeActionEntity = cmPledgeActionid.getEntity();
			CmPledgeActionFileStgUp_DTO cmPledgeActionDto = cmPledgeActionEntity.getDTO();
			if(status.equalsIgnoreCase(STATUS_ERROR)){
			cmPledgeActionDto.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.ERROR);
			}else if(status.equalsIgnoreCase(STATUS_COMPLETE)){
				cmPledgeActionDto.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.COMPLETE);
			}
			cmPledgeActionEntity.setDTO(cmPledgeActionDto);
		}
		private String cmRetrieveRecordStatus(){

			StringBuilder cmRetrieveRecordStatusStmtStrbuilder = new StringBuilder();
			cmRetrieveRecordStatusStmtStrbuilder.append(" SELECT CM_PLDG_RCRD_ST_FLG ");
			cmRetrieveRecordStatusStmtStrbuilder.append(" FROM CM_PLDG_ACTN_FILE_STG_UP ");
			cmRetrieveRecordStatusStmtStrbuilder.append(" WHERE CM_PLEDGE_ID = :pledgeId ");
			cmRetrieveRecordStatusStmtStrbuilder.append(" AND BATCH_CD = :batchCode ");
			cmRetrieveRecordStatusStmtStrbuilder.append(" AND BATCH_NBR = :batchNumber ");
			cmRetrieveRecordStatusStmtStrbuilder.append(" AND CM_PLDG_ACTION = :action ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement cmRetrieveRecordStatusStmt = createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString());
			PreparedStatement cmRetrieveRecordStatusStmt = createPreparedStatement(cmRetrieveRecordStatusStmtStrbuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			cmRetrieveRecordStatusStmt.bindBigInteger("pledgeId", new BigInteger(pledgeId.getTrimmedValue()));
			cmRetrieveRecordStatusStmt.bindId("batchCode", getBatchControlId());
			cmRetrieveRecordStatusStmt.bindBigInteger("batchNumber", getBatchNumber());
			cmRetrieveRecordStatusStmt.bindStringProperty("action", CmPledgeActionFileStgUp.properties.cmPledgeAction, pledgeAction);
			String recordStatus = (String) cmRetrieveRecordStatusStmt.firstRow().get("CM_PLDG_RCRD_ST_FLG");

	        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
			cmRetrieveRecordStatusStmt.setAutoclose(false);
	        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
			
			cmRetrieveRecordStatusStmt.close();

			return recordStatus;

		}

		@SuppressWarnings("unused")
		private boolean cmCreateNewPledge(ServiceTask_Id pledgeId ,Date confirmationDate, ServiceAgreement serviceAgreement, Account account , Money pledgeAmount, String fundingType, Account agencyAccount, BigInteger webTransactionId, String agencyCode){
			boolean newPledgeCreated = false;
			ServiceTask serviceTask = null;
			Query<ServiceTask_Id> serviceTaskQuery = cmRetrieveServiceTaskUsingPledgeId(pledgeId);
			if (!serviceTaskQuery.list().isEmpty()) {

				logError(CustomMessageRepositoryMDC.ni00263PledgeRecordAlreadyExists(pledgeId.getTrimmedValue()));
				messageParameterList.clear();
				messageParameterList.add(0,pledgeId.getTrimmedValue());
				createToDo(CustomMessagesMDC.MESSAGE_CATEGORY, CustomMessagesMDC.NI0026_3_PLEDGE_RECORD_ALREADY_EXISTS, messageParameterList, TODO_PRIORITY_NORMAL);

				numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);

			}
			else {
				try {
					savepointId = "oneCreateSavePoint";
			        session = (FrameworkSession) SessionHolder.getSession();
			        session.setSavepoint(savepointId);
			        
			        // START CHANGES - JHERNA - 2018-08-07 - SysAid#245408
			        /*
					ServiceTask_DTO newServiceTaskDTO = new ServiceTask_DTO();

					// Set Service Task Type
					newServiceTaskDTO.setServiceTaskTypeId(parmPledgeServiceTaskType.getId());
					// Set Business Object
					newServiceTaskDTO.setBusinessObjectId(parmPledgeBo.getId());
					// Set Creation Date Time
					newServiceTaskDTO.setCreationDateTime(this.getProcessDateTime());
					// Set Confirmation Date Time
					Time time = new Time(1, 1, 1);
					DateTime confirmationDateTime = new DateTime(confirmationDate, time);
					// Set Effective Date Time
					newServiceTaskDTO.setEffectiveDateTime(confirmationDateTime);
					// Set Business Object Status
					newServiceTaskDTO.setStatus(parmPledgeBoActiveStatus.trim());
					// Set Status Update Date Time
					newServiceTaskDTO.setStatusDateTime(this.getProcessDateTime());
					serviceTask = newServiceTaskDTO.newEntity();

					// Add a new Service Agreement ID characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmSaIdCharType, serviceAgreement.getId().getTrimmedValue(),
							BigInteger.valueOf(10));

					// Add a new Account ID characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmAccountIdCharType, account.getId().getTrimmedValue(),
							BigInteger.valueOf(10));

					// Add a new Pledge ID characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmPledgeIdCharType, pledgeId.getTrimmedValue(),
							BigInteger.valueOf(10));

					// Add a new Pledge Amount characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmPledgeAmountCharType, pledgeAmount.getAmount().toString(),
							BigInteger.valueOf(10));

					// Add a new Pledge Confirmation Date characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmPledgeConfirmationDateCharType, confirmationDate.toString(),
							BigInteger.valueOf(10));

					// Add a new Funding Type characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmFundingTypeCharType, fundingType.trim(),
							BigInteger.valueOf(10));

					// Add a new Agency Account ID characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmAgencyAccountIdCharType, agencyAccount.getId().getTrimmedValue(),
							BigInteger.valueOf(10));

					// Add a new Agency Code characteristic
					agencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, agencyAccount);
					cmAddServiceTaskCharacteristic(serviceTask, parmAgencyCodeCharType, agencyCode, BigInteger.valueOf(10));

					// Add a new Website Transaction ID characteristic
					cmAddServiceTaskCharacteristic(serviceTask, parmWebTransactionIdCharType, webTransactionId.toString().trim(),
							BigInteger.valueOf(10));
					*/
			        Time time = new Time(1, 1, 1);
					DateTime confirmationDateTime = new DateTime(confirmationDate, time);
					agencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, agencyAccount);
										
			        BusinessObjectInstance boInstance =  BusinessObjectInstance.create(parmPledgeBo);

			        // Main fields for Pledge Service Task
			        boInstance.set("serviceTaskType", parmPledgeServiceTaskType.getId().getTrimmedValue());
					boInstance.set("businessObject", parmPledgeBo.getId().getTrimmedValue());
					boInstance.set("creationDateTime", this.getProcessDateTime());					
					boInstance.set("effectiveDateTime", confirmationDateTime);
					boInstance.set("status", parmPledgeBoActiveStatus.trim());
					boInstance.set("statusDateTime", this.getProcessDateTime());					

					// Child fields for Pledge Service Task Characteristic
					boInstance.set("account", account.getId().getTrimmedValue());
					boInstance.set("serviceAgreement", serviceAgreement.getId().getTrimmedValue());
					boInstance.set("pledgeID", pledgeId.getTrimmedValue());
					boInstance.set("pledgeAmount", pledgeAmount.getAmount().toString().trim());
					boInstance.set("fundingType", fundingType.trim());
					boInstance.set("pledgeAgency", agencyCode.trim());
					boInstance.set("transID", webTransactionId.toString().trim());
					boInstance.set("pledgeDate", confirmationDate.toString().trim());
					boInstance.set("pledgeAgencyAccount", agencyAccount.getId().getTrimmedValue());
					
					BusinessObjectInstance newPledgeBOInstance = BusinessObjectDispatcher.add(boInstance);
					String pledgeSvcTaskIdStr = newPledgeBOInstance.getString("serviceTaskId");
					ServiceTask_Id pledgeSvcTaskID = new ServiceTask_Id(pledgeSvcTaskIdStr);
					// END CHANGES - JHERNA - 2018-08-07 - SysAid#245408
					
					/*
		             * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
		             */
					if (pledgeAction.equals(ACTION_NEW)) {
					    /*
				         * Defect 3843433(Reopen) - 2017-10-04 - Start Change
				         */
						//Query<ServiceTask_Id> retrieveSaQuoteQuery = retrieveServiceAgreementStandardQuote();
						//ServiceTask_Id quoteServiceTaskId = retrieveSaQuoteQuery.firstRow();
					    ServiceTask_Id quoteServiceTaskId = retrieveServiceAgreementStandardQuote();
						/*
                         * Defect 3843433(Reopen) - 2017-10-04 - End Change
                         */
						if(notNull(quoteServiceTaskId)){
						
							ServiceTask quoteServiceTask = quoteServiceTaskId.getEntity();
							
							//Retrieve Self Service Payment Option Characteristic
							String filter = new String();
							filter = filter.concat("WHERE this.id.characteristicType = :charType");
							ListFilter<ServiceTaskCharacteristic> stCharListFilter = quoteServiceTask
									.getCharacteristics().createFilter(filter, getClass().getName());
							stCharListFilter.bindEntity("charType", selfServicePayOptCharType);
							ServiceTaskCharacteristic selfServicePayOptChar = stCharListFilter.firstRow();
							
							//Retrieve Quote Source Characteristic
							filter = new String();
							filter = filter.concat("WHERE this.id.characteristicType = :charType");
							stCharListFilter = quoteServiceTask
									.getCharacteristics().createFilter(filter, getClass().getName());
							stCharListFilter.bindEntity("charType", quoteSourceCharType);
							ServiceTaskCharacteristic quoteSourceChar = stCharListFilter.firstRow();
							
							if(notNull(selfServicePayOptChar)){
								//Call the CM-QuotePortalCWRQuoteInfo Business Service
								Bool performPayOptSelProc = Bool.FALSE;
								/*
		                         * Defect 3843433(Reopen) - 2017-10-04 - Start Change
		                         */
								//BusinessServiceInstance qpCwrQuoteInfoBsInstance = BusinessServiceInstance.create("CM-QuotePortalCWRQuoteInfo");
								//qpCwrQuoteInfoBsInstance.set("sa", serviceAgreement);
								//qpCwrQuoteInfoBsInstance.set("person"
								//		, retrieveAccountMainPerson(serviceAgreement.getAccount()).getId().getTrimmedValue());
								//qpCwrQuoteInfoBsInstance.set("cisDivision"
								//		, serviceAgreement.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
								//qpCwrQuoteInfoBsInstance.set("debtClass"
								//		, serviceAgreement.getServiceAgreementType().getDebtClass().getId().getTrimmedValue());
								//qpCwrQuoteInfoBsInstance = BusinessServiceDispatcher.execute(qpCwrQuoteInfoBsInstance);
								
								// Call the Quote Info Business Service.
								BusinessServiceInstance qpCwrQuoteInfoBsInstance = BusinessServiceInstance.create("CM-CWRGPAQuoteInfo");
								qpCwrQuoteInfoBsInstance.set("sa", serviceAgreement.getId().getTrimmedValue());
								qpCwrQuoteInfoBsInstance.set("quote", quoteServiceTask.getId().getTrimmedValue());
								qpCwrQuoteInfoBsInstance = BusinessServiceDispatcher.execute(qpCwrQuoteInfoBsInstance);
								/*
                                 * Defect 3843433(Reopen) - 2017-10-04 - End Change
                                 */
								
								String ssPayOptVal = new String();
								if(selfServicePayOptChar.fetchIdCharacteristicType().getCharacteristicType().isPredefinedValue()){
									ssPayOptVal = selfServicePayOptChar.getCharacteristicValue().trim();
								}else if(selfServicePayOptChar.fetchIdCharacteristicType().getCharacteristicType().isForeignKeyValue()){
									ssPayOptVal = selfServicePayOptChar.getCharacteristicValueForeignKey1().trim();
								} else{
									ssPayOptVal = selfServicePayOptChar.getAdhocCharacteristicValue().trim();
								}

								if(ssPayOptVal.equals(parmNewPayOptCharVal)){
								    // Defect 3793715 - 2017-07-20 - Start Change
									//if (pledgeAmount.compareTo(qpCwrQuoteInfoBsInstance.getMoney("downPayment")) >= 0){
								    Money downPayment = qpCwrQuoteInfoBsInstance.getMoney("downPayment");
								    // Defect 3851641 - 2017-09-12 - Start Add
								    if(CWR_QUOTE_SRC.compareTo(qpCwrQuoteInfoBsInstance.getString("quoteSource")) == 0) {
								    // Defect 3851641 - 2017-09-12 - End Add
								    	String cwrLevel = qpCwrQuoteInfoBsInstance.getString("cwrLevel");
								    	// Defect 3851641 - 2017-09-12 - Start Delete
								    	//Money lvl50CWRDownpaymentAmount = 
								    	//		qpCwrQuoteInfoBsInstance.getGroup("optional").
								    	//		getMoney("lvl50CWRDownpaymentAmount");
								    	// Defect 3851641 - 2017-09-12 - End Delete
								    	if (cwrLevel.trim().compareToIgnoreCase(PERCENT_12.trim()) == 0){
								    		// Defect 3851641 - 2017-09-12 - Start Add
								    		Money lvl50CWRDownpaymentAmount = 
									    			qpCwrQuoteInfoBsInstance.getGroup("optional").
									    			getMoney("lvl50CWRDownpaymentAmount");
								    		// Defect 3851641 - 2017-09-12 - End Add
								    		if (lvl50CWRDownpaymentAmount.isLessThan(downPayment)){
								    			downPayment = lvl50CWRDownpaymentAmount;
								    		}
								    	}
								    	if (pledgeAmount.compareTo(downPayment) >= 0){
								    		// Defect 3793715 - 2017-07-20 - End Change
								    		performPayOptSelProc = Bool.TRUE;
								    	}
							    	// Defect 3851641 - 2017-09-12 - Start Add
								    }
								    // Defect 3851641 - 2017-09-12 - End Add
								    
								}
								else if(ssPayOptVal.equals(parmReinstatePayOptCharVal)){
									if (pledgeAmount.compareTo(qpCwrQuoteInfoBsInstance.getMoney("reinstatementAmount")) >= 0){
										performPayOptSelProc = Bool.TRUE;
									}
								}

								if(performPayOptSelProc.isTrue()){
									
									//Retrieve Quote Source Char Value
									String quoteSource = new String();
									if(quoteSourceChar.fetchIdCharacteristicType().getCharacteristicType().isPredefinedValue()){
										quoteSource = quoteSourceChar.getCharacteristicValue();
									}else if(quoteSourceChar.fetchIdCharacteristicType().getCharacteristicType().isForeignKeyValue()){
										quoteSource = quoteSourceChar.getCharacteristicValueForeignKey1();
									}else{
										quoteSource = quoteSourceChar.getAdhocCharacteristicValue();
									}
									
									BusinessServiceInstance procPayArrBsInstance = BusinessServiceInstance.create("CM-ProcPayArr");
									procPayArrBsInstance.set("selfServicePayOptionCharVal", ssPayOptVal);
									procPayArrBsInstance.set("quoteSrc", quoteSource);
									procPayArrBsInstance.set("quoteSA", serviceAgreement.getId().getTrimmedValue());
									BusinessServiceDispatcher.execute(procPayArrBsInstance);
								}
							}
						}
					}
					/*
		             * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
		             */
					
					// If fundingType is in majorFundingTypesList
					if (majorFundingTypesList.contains(fundingType.trim())) {
						// Retrieve all active Quote Service Tasks 
						Query<QueryResultRow> activeQuoteTaskQuery = cmRetrieveActiveQuoteServiceTask(serviceAgreement);
						QueryIterator<QueryResultRow> activeQuoteTaskQueryItr = activeQuoteTaskQuery.iterate();
						ServiceTask_Id quoteServiceTaskId;
						ServiceTask quoteServiceTask = null;
						ServiceTask_DTO quoteServiceTaskDTO;

						while (activeQuoteTaskQueryItr.hasNext()) {
							quoteServiceTaskId = (ServiceTask_Id) activeQuoteTaskQueryItr.next();
							quoteServiceTask = quoteServiceTaskId.getEntity();
							quoteServiceTaskDTO = quoteServiceTask.getDTO();

							quoteServiceTaskDTO.setStatus(parmQuoteBoExpiredStatus.trim());
							quoteServiceTaskDTO.setStatusDateTime(this.getProcessDateTime());
							quoteServiceTask.setDTO(quoteServiceTaskDTO);
						}

						activeQuoteTaskQueryItr.close();
						/*
                         * Defect 3948617 - 2017-12-13 - Start Change
                         */
						//ServiceTask_DTO serviceTaskDto = createDTO(ServiceTask.class);
						//serviceTaskDto.setServiceTaskTypeId(serviceTaskType.getId());
						//serviceTaskDto.setBusinessObjectId(businessObject.getId());
						//serviceTaskDto.setStatus(status);
						//serviceTaskDto.setCreationDateTime(creationDateTime);
						//serviceTaskDto.setStatusDateTime(statusDateTime);
						//
						//if (isNull(effectiveDateTime)) {
						//	serviceTaskDto.setEffectiveDateTime(effectiveDateTime);
						//}
						//
						//ServiceTask newQuoteServiceTask = serviceTaskDto.newEntity();
						//
						//// Create Service Task Characteristics
						//createServiceTaskCharacteristics(newQuoteServiceTask);
						
						/* START ADD - JHERNA - 2018-01-29 - SysAid#239434 */
						/* START CHANGE - JHERNA - 2018-03-23 - SysAid#245959 */
						//if (serviceAgreement.getStatus().isStopped()) {
						ServiceAgreementStatusLookup saStatus = serviceAgreement.getStatus();
						if (saStatus.isStopped()
								|| saStatus.isReactivated()) {
						/* END CHANGE - JHERNA - 2018-03-23 - SysAid#245959 */
							selection = STANDARD;
						}
						else {
							selection = SELECTION_CWR;
						}
						/* END ADD - JHERNA - 2018-01-29 - SysAid#239434 */

						/*
						 * Start Add - MPang - SA-267143 - 2018-09-20
						 */
						List<ServiceAgreement_Id> paSaOnAccount = retrievePaSAType(account);
						if(paSaOnAccount.size() > 0) {
							selection = STANDARD;
						}
						/*
						 * End Add - MPang - SA-267143 - 2018-09-20
						 */
						
						CmCreateServiceTask createServiceTask = CmCreateServiceTask.Factory.newInstance();
                        createServiceTask.setServiceTaskType(serviceTaskType);
                        createServiceTask.setBusinessObject(businessObject);
                        createServiceTask.setStatus(status);
                        createServiceTask.setCreationDateTime(creationDateTime);
                        createServiceTask.setStatusDateTime(statusDateTime);
                          
                        if (isNull(effectiveDateTime)) {
                            createServiceTask.setEffectiveDateTime(effectiveDateTime);
                        }
                        createServiceTask.setServiceAgreement(serviceAgreement);
                        createServiceTask.setSelection(selection);
                        createServiceTask.setSource(source);
                        ServiceTask newQuoteServiceTask = createServiceTask.createServiceTask();
						/*
                         * Defect 3948617 - 2017-12-13 - End Change
                         */

						Query<QueryResultRow> activePaymentArrangmentSasQuery = cmRetrieveActivePaymentArrangementSas(account);

						if (notNull(activePaymentArrangmentSasQuery.firstRow())) {
							ServiceAgreement_Id activePaymentArrangementSaId = (ServiceAgreement_Id) activePaymentArrangmentSasQuery.firstRow();
							ServiceAgreement activePaymentArrangementSa = activePaymentArrangementSaId.getEntity();

							if (notNull(activePaymentArrangementSa)) {
								Query<QueryResultRow> cwrLevelOfPreviousQuoteQuery = cmRetrieveCwrLevelOfPreviousQuote();
								QueryResultRow row = (QueryResultRow) cwrLevelOfPreviousQuoteQuery.firstRow();
								String cwrLevel = "";

								if (parmCwrLevelCharType.getCharacteristicType().isAdhocValue()
										|| parmCwrLevelCharType.getCharacteristicType().isFileLocationValue()) {
									cwrLevel = row.getString("serviceTaskAdhocCharValue");
								}
								else if (parmCwrLevelCharType.getCharacteristicType().isForeignKeyValue()) {
									cwrLevel = row.getString("serviceTaskForeignKeyCharValue");
								}
								else if (parmCwrLevelCharType.getCharacteristicType().isPredefinedValue())
								{
									cwrLevel = row.getString("serviceTaskPreDefinedCharValue");
								}
								cmUpdateServiceTaskCharacteristic(newQuoteServiceTask, parmCwrLevelCharType, cwrLevel);
							}
						}
					}
					
					newPledgeCreated = true;
				} catch (ApplicationError e) {
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//session.flush();
					session.flush(session.toString().trim());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					session.rollbackToSavepoint(savepointId);
					systemErrorStr = e.getServerMessage().getMessageText();
					newPledgeCreated = false;
				}

			}
			return newPledgeCreated;
		}
		
		/*
         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		/*
         * Defect 3843433(Reopen) - 2017-10-04 - Start Change
         */
		//private Query<ServiceTask_Id> retrieveServiceAgreementStandardQuote(){
		private ServiceTask_Id retrieveServiceAgreementStandardQuote(){
		    
		    ServiceTask_Id quoteServiceTaskId = null;
		/*
         * Defect 3843433(Reopen) - 2017-10-04 - End Change
         */
			String quoteSourceBind = new String();
            for(int i=0; i < quoteSourceListArray.length; i++){
            	quoteSourceBind = quoteSourceBind.concat(":quoteSource").concat(String.valueOf(i)).concat(",");
            }
            
            /*
             * Defect 3843433(Reopen) - 2017-10-04 - Start Delete
             */
			//StringBuilder sb = new StringBuilder("from ServiceTask st, ServiceTaskCharacteristic stc");
			//sb.append(" where stc.characteristicValueForeignKey1 = :saId");
			//sb.append(" and stc.id.characteristicType = :saCharType");
			//sb.append(" and stc.id.serviceTask = st.id");
			//sb.append(" and st.serviceTaskType = :quoteSvcTaskType");
			//sb.append(" and st.status = :quoteStatus");
			//sb.append(" and st.creationDateTime <= :procDttm");
			//sb.append(" and exists (select stc2.id.serviceTask from ServiceTaskCharacteristic stc2");
			//                sb.append(" where stc2.id.serviceTask = stc.id.serviceTask");
			//                sb.append(" and stc2.id.characteristicType = :selTypeCharType");
			//                sb.append(" and stc2.adhocCharacteristicValue = :selType)");
			//sb.append(" and exists (select stc3.id.serviceTask from ServiceTaskCharacteristic stc3");
            //                sb.append(" where stc3.id.serviceTask = stc.id.serviceTask");
        	//                sb.append(" and stc3.id.characteristicType = :quoteSrcCharType");
        	//                sb.append(" and stc3.adhocCharacteristicValue in (");
        	//                sb.append(quoteSourceBind.substring(0, quoteSourceBind.length() - 1));
        	//                sb.append("))");
        	//
        	//Query<ServiceTask_Id> svcTaskQuery = createQuery(sb.toString(), getClass().getName());
        	//svcTaskQuery.bindId("saId", serviceAgreement.getId());
        	//svcTaskQuery.bindEntity("saCharType", parmSaIdCharType);
        	//svcTaskQuery.bindEntity("quoteSvcTaskType", parmQuoteServiceTaskType);
        	//svcTaskQuery.bindStringProperty("quoteStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
        	//svcTaskQuery.bindDateTime("procDttm", getProcessDateTime());
        	//svcTaskQuery.bindEntity("selTypeCharType", selectionCharType);
        	//svcTaskQuery.bindStringProperty("selType", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, STANDARD);
        	//svcTaskQuery.bindEntity("quoteSrcCharType", quoteSourceCharType);
        	//for(int i=0; i < quoteSourceListArray.length; i++){
        	//	svcTaskQuery.bindStringProperty("quoteSource".concat(String.valueOf(i))
        	//			, ServiceTaskCharacteristic.properties.adhocCharacteristicValue, quoteSourceListArray[i].trim());
        	//}
        	//svcTaskQuery.addResult("serviceTaskId", "st.id");
            //
            //return svcTaskQuery;
        	/*
             * Defect 3843433(Reopen) - 2017-10-04 - End Delete
             */
        	/*
             * Defect 3843433(Reopen) - 2017-10-04 - Start Add
             */
        	StringBuilder sb = new StringBuilder();
            
            sb.append("SELECT ST.F1_SVC_TASK_ID ");
            sb.append("FROM F1_SVC_TASK ST, F1_SVC_TASK_CHAR STC1, F1_SVC_TASK_CHAR STC2, F1_SVC_TASK_CHAR STC3 ");
            sb.append("WHERE ST.F1_STASK_TYPE_CD  =:quoteSvcTaskType ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //sb.append("AND TRIM(ST.BO_STATUS_CD) =:quoteStatus ");
            sb.append("AND ST.BO_STATUS_CD =:quoteStatus ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
            sb.append("AND TRUNC(ST.CRE_DTTM) =:processDate ");
            sb.append("AND STC1.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
            sb.append("AND STC1.CHAR_TYPE_CD = :saCharType ");
            sb.append("AND STC1.SRCH_CHAR_VAL = :saId ");
            sb.append("AND STC2.F1_SVC_TASK_ID = STC1.F1_SVC_TASK_ID ");
            sb.append("AND STC2.CHAR_TYPE_CD =:quoteSrcCharType ");
            sb.append("AND STC2.SRCH_CHAR_VAL IN (");
            sb.append(quoteSourceBind.substring(0, quoteSourceBind.length() - 1));
            sb.append(") ");
            sb.append("AND STC3.F1_SVC_TASK_ID =STC1.F1_SVC_TASK_ID ");
            sb.append("AND STC3.CHAR_TYPE_CD =:selTypeCharType ");
            sb.append("AND STC3.SRCH_CHAR_VAL =:selType ");
            sb.append("ORDER BY ST.CRE_DTTM DESC ");
            
            PreparedStatement svcTaskQuery = createPreparedStatement(sb.toString(), getClass().getName());
            
            svcTaskQuery.bindEntity("quoteSvcTaskType", parmQuoteServiceTaskType);
            svcTaskQuery.bindStringProperty("quoteStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
            svcTaskQuery.bindDate("processDate", getProcessDateTime().getDate());
            svcTaskQuery.bindEntity("saCharType", parmSaIdCharType);
            svcTaskQuery.bindId("saId", serviceAgreement.getId());
            svcTaskQuery.bindEntity("quoteSrcCharType", quoteSourceCharType);
            svcTaskQuery.bindEntity("selTypeCharType", selectionCharType);
            svcTaskQuery.bindStringProperty("selType", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, STANDARD.toUpperCase());
            for(int i=0; i < quoteSourceListArray.length; i++){
                svcTaskQuery.bindStringProperty("quoteSource".concat(String.valueOf(i))
                        , ServiceTaskCharacteristic.properties.searchCharacteristicValue, quoteSourceListArray[i].toUpperCase().trim());
            }
            
            SQLResultRow serviceTaskRow = svcTaskQuery.firstRow();
            
            if(notNull(serviceTaskRow)) {
                quoteServiceTaskId = (ServiceTask_Id) serviceTaskRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
            }
            
	        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
            svcTaskQuery.setAutoclose(false);
	        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
			
            svcTaskQuery.close();
            
            return quoteServiceTaskId;
        	/*
             * Defect 3843433(Reopen) - 2017-10-04 - End Add
             */
		}
		/*
         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
         */
		
		/*
		 * Start Add - MPang - SA-267143 - 2018-09-20
		 */
		/**
		 * This method retrieves the PA SA Type defined in Parameter 280 from the account.
		 * @param account
		 * @return list
		 */
		private List<ServiceAgreement_Id> retrievePaSAType(Account account) {
			String saTypes = createServiceAgreementTypesString(paSaTypesForStandardQuote);
			
			String queryString = "FROM ServiceAgreement sa " 
								 + "WHERE sa.account = :accountId "
								 + "AND sa.status in (:pendingStart, :active) "
								 + "AND sa.serviceAgreementType.id.saType IN (" + saTypes + ") ";
					
			Query<ServiceAgreement_Id> query = createQuery(queryString, getClass().getName());
			query.bindId("accountId", account.getId());
			query.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			query.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			
			query.addResult("serviceAgreement", "sa.id");
			
			return query.list();
		}

		
	    /**
	     * This method builds the Service Agreement Types String for Query.
	     * @param saTypesStr
	     * @return String
	     */
	    private String createServiceAgreementTypesString(String saTypesStr) {
	        StringTokenizer strTokenizer = new StringTokenizer(saTypesStr, COMMA_DELIMITER);
	        StringBuilder strBuilder = new StringBuilder();

	        while (strTokenizer.hasMoreElements()) {
	            strBuilder.append(SINGLE_QUOTE);
	            strBuilder.append(strTokenizer.nextToken().trim());
	            strBuilder.append(SINGLE_QUOTE);

	            if (strTokenizer.hasMoreTokens()) {
	                strBuilder.append(COMMA_DELIMITER);
	            }
	        }

	        return strBuilder.toString();
	    }
		/*
		 * End Add - MPang - SA-267143 - 2018-09-20
		 */

		private boolean cmCancelExpirePledge(ServiceTask_Id pledgeId, Date confirmationDate, BigInteger webTransactionId, Account_Id accountId, ServiceAgreement_Id serviceAgreementId, String pledgeAction){
			boolean isPledgeCancelled = false;
			ServiceTask serviceTask = null;
			Query<ServiceTask_Id> serviceTaskQuery = cmRetrieveServiceTaskUsingPledgeId(pledgeId);

			if (serviceTaskQuery.list().isEmpty()) {

				logError(CustomMessageRepositoryMDC.ni00263NoRecordsFoundForPledge(pledgeId.getTrimmedValue()));
				messageParameterList.clear();
				messageParameterList.add(0,pledgeId.getTrimmedValue());
				createToDo(CustomMessagesMDC.MESSAGE_CATEGORY, CustomMessagesMDC.NI0026_3_NO_RECORDS_WERE_FOUND_FOR_PLEDGE, messageParameterList, TODO_PRIORITY_NORMAL);
				CmPledgeActionFileStgUp_Id cmPledgeActionid = 
						new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeId.getTrimmedValue()), 
								accountId.getTrimmedValue(), serviceAgreementId.getTrimmedValue(), getBatchControlId().getTrimmedValue(), getBatchNumber(), pledgeAction); 
				CmPledgeActionFileStgUp cmPledgeActionEntity = cmPledgeActionid.getEntity();
				CmPledgeActionFileStgUp_DTO cmPledgeActionDto = cmPledgeActionEntity.getDTO();
				cmPledgeActionDto.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.ERROR);
				cmPledgeActionEntity.setDTO(cmPledgeActionDto);
				numOfToDoEntriesPosted = numOfToDoEntriesPosted.add(BigInteger.ONE);
				

			}
			else {

				// Update the Service Task retrieved
				ServiceTask_Id serviceTaskId = (ServiceTask_Id) serviceTaskQuery.firstRow();
				serviceTask = serviceTaskId.getEntity();
				ServiceTask_DTO serviceTaskDTO = serviceTaskId.getEntity().getDTO();

				if (pledgeAction.equals(ACTION_CANCEL)) {

					serviceTaskDTO.setStatus(parmPledgeBoCancelledStatus.trim());

				}
				else if (pledgeAction.equals(ACTION_EXPIRE)) {

					serviceTaskDTO.setStatus(parmPledgeBoExpiredStatus.trim());

				}
				// Set Confirmation Date Time
				Time time = new Time(0, 0, 0);
				DateTime confirmationDateTime = new DateTime(confirmationDate, time);
				// Set Effective Date Time
				serviceTaskDTO.setEffectiveDateTime(confirmationDateTime);
				// Set Status Update Date Time
				serviceTaskDTO.setStatusDateTime(this.getProcessDateTime());
				serviceTask.setDTO(serviceTaskDTO);

				// Get the maximum sequence number of the of the Service Task's Website Transaction ID characteristics
				Query<BigInteger> maxSeqNbrQuery = cmRetrieveMaximumSequenceNumber(serviceTask);
				BigInteger seqNbr = maxSeqNbrQuery.firstRow();
				seqNbr = seqNbr.add(BigInteger.TEN);

				// Add a new Website Transaction ID characteristic
				cmAddServiceTaskCharacteristic(serviceTask, parmWebTransactionIdCharType, webTransactionId.toString().trim(), seqNbr);

				CmPledgeActionFileStgUp_Id cmPledgeActionid = 
						new CmPledgeActionFileStgUp_Id(new BigInteger(pledgeId.getTrimmedValue()), 
								accountId.getTrimmedValue(), serviceAgreementId.getTrimmedValue(), getBatchControlId().getTrimmedValue(), getBatchNumber(), pledgeAction); 
				CmPledgeActionFileStgUp cmPledgeActionEntity = cmPledgeActionid.getEntity();
				CmPledgeActionFileStgUp_DTO cmPledgeActionDto = cmPledgeActionEntity.getDTO();
				cmPledgeActionDto.setCmPledgeRecordStatusFlag(CmPledgeRecordStagingFlagLookup.constants.COMPLETE);
				cmPledgeActionEntity.setDTO(cmPledgeActionDto);
				isPledgeCancelled = true;
				
			}

			return isPledgeCancelled;
		}

		private SQLResultRow cmAnotherActionExistForAccount(){

			StringBuilder cmAnotherActionExistForAccountStringBuilder = new StringBuilder();
			cmAnotherActionExistForAccountStringBuilder.append(" SELECT CM_PLEDGE_ID, ACCT_ID, SA_ID, CM_PLDG_AMT, CM_FNDNG_TYPE, CM_CONF_DATE, CM_AGENCY_ACCT_ID, CM_WEB_TRNSCTN_ID, CM_PLDG_ACTION, PROCESS_DT, CM_PLDG_RCRD_ST_FLG ");
			cmAnotherActionExistForAccountStringBuilder.append(" FROM CM_PLDG_ACTN_FILE_STG_UP ");
			cmAnotherActionExistForAccountStringBuilder.append(" WHERE BATCH_CD =:batchCode ");
			cmAnotherActionExistForAccountStringBuilder.append(" AND BATCH_NBR =:batchNumber ");
			cmAnotherActionExistForAccountStringBuilder.append(" AND ACCT_ID =:accountId ");
			cmAnotherActionExistForAccountStringBuilder.append(" AND TRIM(CM_PLEDGE_ID) <> TRIM(:pledgeId) ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement cmAnotherActionExistForAccountStmt = createPreparedStatement(cmAnotherActionExistForAccountStringBuilder.toString());
			PreparedStatement cmAnotherActionExistForAccountStmt = createPreparedStatement(cmAnotherActionExistForAccountStringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			cmAnotherActionExistForAccountStmt.bindId("batchCode", getBatchControlId());
			cmAnotherActionExistForAccountStmt.bindBigInteger("batchNumber", getBatchNumber());
			cmAnotherActionExistForAccountStmt.bindId("accountId", accountId);
			cmAnotherActionExistForAccountStmt.bindId("pledgeId", pledgeId);
	        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
			cmAnotherActionExistForAccountStmt.setAutoclose(false);
	        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
			cmAnotherActionExistForAccountStmt.close();

			if(cmAnotherActionExistForAccountStmt.list().isEmpty()){

				return null;

			}else{

				return cmAnotherActionExistForAccountStmt.firstRow();

			}
		}

		/**
		 * Finalized thread work
		 */
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

			logInfo(CustomMessageRepository.nm0038NoOfToDoEntriesCreated(numOfToDoEntriesPosted.toString()));

		}

		/**
		 * Retrieves Batch Parameters
		 */
		private void cmRetrieveBatchParameters() {

			parmPledgeServiceTaskType = this.getParameters().getPLEDGE_SERVICE_TASK_TYPE();
			parmPledgeBo = this.getParameters().getPLEDGE_BUSINESS_OBJECT();
			parmPledgeBoActiveStatus = this.getParameters().getPLEDGE_BO_ACTIVE_STATUS();
			parmPledgeBoCancelledStatus = this.getParameters().getPLEDGE_BO_CANCELLED_STATUS();
			parmPledgeBoExpiredStatus = this.getParameters().getPLEDGE_BO_EXPIRED_STATUS();
			parmQuoteServiceTaskType = this.getParameters().getQUOTE_SERVICE_TASK_TYPE();
			parmQuoteBo = this.getParameters().getQUOTE_BUSINESS_OBJECT();
			parmQuoteBoActiveStatus = this.getParameters().getQUOTE_BO_ACTIVE_STATUS();
			parmQuoteBoExpiredStatus = this.getParameters().getQUOTE_BO_EXPIRED_STATUS();
			/*
			 *  START CHANGES - JHERNA - 2018-08-07 - SysAid#245408
			 *  Remove unused variables
			 */
			//parmAccountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
			parmSaIdCharType = this.getParameters().getSA_ID_CHAR_TYPE();
			parmPledgeIdCharType = this.getParameters().getPLEDGE_ID_CHAR_TYPE();
			//parmPledgeAmountCharType = this.getParameters().getPLEDGE_AMOUNT_CHAR_TYPE();
			//parmPledgeConfirmationDateCharType = this.getParameters().getPLEDGE_CONF_DATE_CHAR_TYPE();
			//parmFundingTypeCharType = this.getParameters().getFUNDING_TYPE_CHAR_TYPE();
			//parmAgencyAccountIdCharType = this.getParameters().getAGENCY_ACCT_ID_CHAR_TYPE();
			/*
			 *  END CHANGES - JHERNA - 2018-08-07 - SysAid#245408
			 *  Remove unused variables
			 */
			parmAgencyCodeCharType = this.getParameters().getAGENCY_CODE_CHAR_TYPE();
			parmWebTransactionIdCharType = this.getParameters().getWEB_TRANS_ID_CHAR_TYPE();
			parmCwrLevelCharType = this.getParameters().getCWR_LEVEL_CHAR_TYPE();
			/*
	         * Start Add - EEsteb - CCB-CC-002.4 - 2017-03-06
	         */
			parmQuoteSourceListString = getParameters().getQUOTE_SOURCE_LIST();
			quoteSourceListArray = parmQuoteSourceListString.split(",");
			parmNewPayOptCharVal = getParameters().getSS_PAY_OPT_NEW();
			parmReinstatePayOptCharVal = getParameters().getSS_PAY_OPT_REINST();
			selfServicePayOptCharType = getParameters().getSS_PAY_OPT_CHAR_TYPE();
			/*
	         * End Add - EEsteb - CCB-CC-002.4 - 2017-03-06
	         */
			
			/*
			 * Start Add - MPang - SA-267143 - 2018-09-20
			 */
			paSaTypesForStandardQuote = getParameters().getPA_SA_TYPES_FOR_STANDARD_QUOTE();
			/*
			 * End Add - MPang - SA-267143 - 2018-09-20
			 */
		}

		/**
		 * This method will validate input parameters
		 *
		 */
		private void retrieveAndValidateInputParameters() {

			serviceTaskType = parmQuoteServiceTaskType;
			businessObject = parmQuoteBo;
			status = parmQuoteBoActiveStatus;
			creationDateTime = getProcessDateTime();
			statusDateTime = getProcessDateTime();
			effectiveDateTime = getProcessDateTime();
			selection = SELECTION_CWR;
			source = QUOTE_SRC_AGENCY;

			// Service Task Type input is required
			if (isNull(serviceTaskType)) {
				addError(CustomMessageRepositoryMDC.np0055InputMissing(SERVICE_TASK_TYPE));
			}

			// Business Object input is required
			if (isNull(businessObject)) {
				addError(CustomMessageRepositoryMDC.np0055InputMissing(BUSINESS_OBJECT));
			}

			// Status input is required
			if (isBlankOrNull(status)) {
				addError(CustomMessageRepositoryMDC.np0055InputMissing(STATUS));
			}

			// Status input must be valid for Business Object input
			BusinessObjectStatus_Id boStatusId = new BusinessObjectStatus_Id(businessObject.fetchLifecycleBusinessObject(), status);
			if (isNull(boStatusId.getEntity())) {
				addError(CustomMessageRepositoryMDC.np0055InvalidBusinessObjectStatus(status, businessObject.getId().getTrimmedValue()));
			}

			// Set creation date/time to porcess date/time if not provided
			if (isNull(creationDateTime)) {
				this.creationDateTime = this.getProcessDateTime();
			}

			// Set status date/time to porcess date/time if not provided
			if (isNull(statusDateTime)) {
				this.statusDateTime = this.getProcessDateTime();
			}

			// Set selection to Standard if not provided
			if (isBlankOrNull(selection)) {
				this.selection = STANDARD;
			}

			// Set source to CCB if not provided
			if (isBlankOrNull(source)) {
				this.source = CCB;
			}
		}

		/**
		 * This method will validate other parameters
		 *
		 */
		private void retrieveAndValidateOtherParameters() {
		  // Service Task Characteristic Types Feature Configuration
		  FeatureConfiguration svcTaskCharTypeFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_SERVICE_TASK_CHARACTERISTIC_TYPES);

		  /*
           * Defect 3948617 - 2017-12-13 - Start Add
           */
		  LookupValue optionType;
		  String optionValue;
		  /*
           * Defect 3948617 - 2017-12-13 - End Add
           */
		  
		  /*
		   * Defect 3948617 - 2017-12-13 - Start Delete
		   */
		  //// Service Agreement Characteristic Type
		  //LookupValue optionType = CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue();
		  //String optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //serviceAgreementCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);       
		  //
		  //// CIS Division Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.CIS_DIVISION_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //cisDivisionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    
		  //
		  //// Debt Class Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.DEBT_CLASS_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //debtClassCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// Expiration Date Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.EXPIRATION_DATE_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //expirationDateCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// CWR Level Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_LEVEL_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //cwrLevelCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// Total SA Arrears Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.TOTAL_SA_ARREARS_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //totalSaArrearsCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// Total Diversion Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.TOTAL_DIVERSION_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //totalDiversionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// Monthly Budget Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// Standard Turn-On or Avoid Severance Amount Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.STANDARD_TURN_ON_OR_AVOID_SEVERANCE_AMOUNT_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //standardTurnOnOrAvoidSeveranceAmountCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// CWR Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //cwrDownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// CWR Monthly Payment Arrangement Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_MONTHLY_PAYMENT_ARRANGEMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //cwrMonthlyPaymentArrangementCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// BPAP 0-50 Monthly Budget Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_0_5_0_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //bpap050MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// BPAP 51-99 Monthly Budget Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_5_1_9_9_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //bpap5199MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// BPAP 100-125 Monthly Budget Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_1_0_0_1_2_5_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //bpap100125MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    
		  //
		  //// BPAP 126-185 Monthly Budget Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_1_2_6_1_8_5_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //bpap126185MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    
		  //
		  //// ARP 0-50 Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_0_5_0_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //arp050DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// ARP 51-99 Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_5_1_9_9_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //arp5199DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// ARP 100-125 Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_1_0_0_1_2_5_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //arp100125DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// ARP 126-185 Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_1_2_6_1_8_5_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //arp126185DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   
		  //
		  //// Monthly ARP 0-50 Payment Arrangement - 12 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_0_5_0_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp050PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// Monthly ARP 51-99 Payment Arrangement - 12 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_5_1_9_9_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp5199PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    
		  //
		  //// Monthly ARP 100-125 Payment Arrangement - 12 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_0_0_1_2_5_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp100125PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// Monthly ARP 126-185 Payment Arrangement - 12 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_2_6_1_8_5_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp126185PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// Monthly ARP 0-50 Payment Arrangement - 24 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_0_5_0_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp050PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  //
		  //// Monthly ARP 51-99 Payment Arrangement - 24 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_5_1_9_9_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp5199PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    
		  //
		  //// Monthly ARP 100-125 Payment Arrangement - 24 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_0_0_1_2_5_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp100125PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// Monthly ARP 126-185 Payment Arrangement - 24 Month Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_2_6_1_8_5_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //monthlyArp126185PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  /*
		   * Defect 3948617 - 2017-12-13 - End Delete
		   */
		  // Selection Characteristic Type
		  optionType = CmServiceTaskCharacteristicTypesLookup.constants.SELECTION_CHARACTERISTIC_TYPE.getLookupValue();
		  optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  selectionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  
		  // Quote Source Characteristic Type
		  optionType = CmServiceTaskCharacteristicTypesLookup.constants.QUOTE_SOURCE_CHARACTERISTIC_TYPE.getLookupValue();
		  optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  quoteSourceCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 
		  
		  /*
		   * Defect 3948617 - 2017-12-13 - Start Delete
		   */
		  //// Custom Down Payment Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.CUSTOM_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //customDownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  
		  //
		  //// BPAP Credit Values Feature Configuration
		  //FeatureConfiguration bpapCreditValuesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_BPAP_CREDIT_VALUES);   
		  //
		  //// BPAP 0-50 Credit Value
		  //optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_5_0_CREDIT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
		  //bpap050CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);
		  //
		  //// BPAP 51-99 Credit Value
		  //optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_9_9_CREDIT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
		  //bpap5199CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);
		  //
		  //// BPAP 100-125 Credit Value
		  //optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_1_2_5_CREDIT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
		  //bpap100125CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);
		  //
		  //// BPAP 126-185 Credit Value
		  //optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_1_8_5_CREDIT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
		  //bpap126185CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);
		  //
		  //// ARP Down Payment Feature Configuration
		  //FeatureConfiguration arpDownPaymentFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_ARP_DOWN_PAYMENT);
		  //
		  //// ARP 0-50 Down Payment Value
		  //optionType = CmArpDownPaymentLookup.constants.ARP_0_5_0_DOWN_PAYMENT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
		  //arp050DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);
		  //
		  //// ARP 51-99 Down Payment Value
		  //optionType = CmArpDownPaymentLookup.constants.ARP_5_1_9_9_DOWN_PAYMENT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
		  //arp5199DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);
		  //
		  //// ARP 100-125 Down Payment Value
		  //optionType = CmArpDownPaymentLookup.constants.ARP_1_0_0_1_2_5_DOWN_PAYMENT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
		  //arp100125DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);
		  //
		  //// ARP 126-185 Down Payment Value
		  //optionType = CmArpDownPaymentLookup.constants.ARP_1_2_6_1_8_5_DOWN_PAYMENT_VALUE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
		  //arp126185DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);
		  //
		  //// Diversion SA Types Feature Configuration
		  //diversionSaTypesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_DIVERSION_SA_TYPES);
		  //
		  //// Payment Arrangement SA Types Feature Configuration
		  //paymentArrangementSaTypesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_PAYMENT_ARRANGEMENT_SA_TYPES); 
		  //
		  //// Quote Portal Parameters Feature Configuration
		  //FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 
		  //
		  //// Recalculated Characteristic Type
		  //optionType = CmQuotePortalParametersLookup.constants.RECALCULATED_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //recalculatedCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);
		  //
		  //// Recalculated Characteristic Value
		  //optionType = CmQuotePortalParametersLookup.constants.RECALCULATED_CHARACTERISTIC_VALUE.getLookupValue();
		  //recalculatedCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //
		  //// Broken Payment Arrangement Characteristic Type
		  //optionType = CmQuotePortalParametersLookup.constants.BROKEN_PAYMENT_ARRANGEMENT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //brokenCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);
		  //
		  //// Broken Payment Arrangement Characteristic Value
		  //optionType = CmQuotePortalParametersLookup.constants.BROKEN_PAYMENT_ARRANGEMENT_CHARACTERISTIC_VALUE.getLookupValue();
		  //brokenCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //
		  //// CWR Characteristic Type
		  //optionType = CmQuotePortalParametersLookup.constants.CWR_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //cwrCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);
		  //
		  //// CWR Characteristic Value
		  //optionType = CmQuotePortalParametersLookup.constants.CWR_CHARACTERISTIC_VALUE.getLookupValue();
		  //cwrCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //
		  //// Transfer Adjustment Type
		  //optionType = CmQuotePortalParametersLookup.constants.TRANSFER_ADJUSTMENT_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //transferAdjustmentType = validateAdjustmentType(quotePortalParmsFeatConfig, optionType, optionValue);
		  //
		  //// CWR Premise Characteristic Type
		  //optionType = CmQuotePortalParametersLookup.constants.CWR_PREMISE_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //cwrPremiseCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);        
		  //
		  //// Average Bill Amount Characteristic Type
		  //optionType = CmServiceTaskCharacteristicTypesLookup.constants.AVERAGE_BILL_AMOUNT_CHARACTERISTIC_TYPE.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
		  //averageBillAmountCharType = validatePremiseCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);
		  //
		  //// Round Up Unit
		  //optionType = CmQuotePortalParametersLookup.constants.ROUND_UP_UNIT.getLookupValue();
		  //optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		  //roundUpUnit = validateIntegerValue(quotePortalParmsFeatConfig, optionType, optionValue);
		  /*
		   * Defect 3948617 - 2017-12-13 - End Delete
		   */
		  /*
		   * Start Add - MPang - SA-267143 - 2018-09-20
		   */
		  validatePaSaTypesForStandardQuote(paSaTypesForStandardQuote);
		  /*
		   * End Add - MPang - SA-267143 - 2018-09-20
		   */

		}
		/*
		 * Start Add - MPang - SA-267143 - 2018-09-20
		 */
	    /**
	     * This method validates the PA SA Types For Standard Quote
	     * @param paSaTypesForStandardQuote
	     */
	    private void validatePaSaTypesForStandardQuote(String paSaTypesForStandardQuote) {
	    	StringTokenizer strTokenizer = new StringTokenizer(paSaTypesForStandardQuote, ",");
	    	int saTypeCount = strTokenizer.countTokens();
	    	if(saTypeCount < 1) {
	    		addError(CustomMessageRepository.SA267143_parameterIsMissing(PA_SA_TYPE_FOR_STANDARD_QUOTE));
	    	}
	    	for(int i = 0; i < saTypeCount; i++) {
	    		String saType = strTokenizer.nextToken().trim();
	    		StringBuilder stringBuilder = new StringBuilder();
	    		stringBuilder.append("SELECT 'X' ");
	    		stringBuilder.append("FROM CI_SA_TYPE ");
	    		stringBuilder.append("WHERE SA_TYPE_CD = :saType ");

	    		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==ValidateCwrPaSaTypes==");
	    		prepState.bindString("saType", saType, "SA_TYPE_CD");
	    		prepState.execute();
	    		if (prepState.list().size() == 0) {
	    			prepState.close();
	    			// SA Type is invalid
	    			addError(CustomMessageRepository.SA267143_parameterIsInvalid(PA_SA_TYPE_FOR_STANDARD_QUOTE, saType.trim()));

	    		}
	    	}
	    	
	    }
		/*
		 * End Add - MPang - SA-267143 - 2018-09-20
		 */
		
		/**
		 * This method will retrieve feature configuration option value
		 * @param featureConfiguration FeatureConfiguration
		 * @param optionType String
		 * @return optionValue String
		 */
		private String retrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {

		    String optionValue = null;

		    StringBuilder stringBuilder = new StringBuilder();
		    stringBuilder.append(" FROM FeatureConfigurationOption fco ");
		    stringBuilder.append(" WHERE fco.id.workforceManagementSystem = :workforceManagementSystem ");
		    stringBuilder.append(" AND fco.id.optionType = :optionType ");

		    //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		    //Query<String> query = createQuery(stringBuilder.toString());
		    Query<String> query = createQuery(stringBuilder.toString(), getClass().getName());
		    //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		    query.bindEntity("workforceManagementSystem", featureConfiguration);
		    query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, lookupValue.fetchIdFieldValue().trim());   
		    query.addResult("value", "fco.value");

		    if (query.list().isEmpty()) {
		        addError(CustomMessageRepositoryMDC.np0055NoOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
		    }
		    else if (query.list().size() > 1) {
		        addError(CustomMessageRepositoryMDC.np0055MultipleOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
		    }
		    else {

		        optionValue = query.firstRow();

		    }

		    return optionValue;
		}


		/**
		 * This method will validate Service Task Characteristic Type
		 * @param featConfig FeatureConfiguration
		 * @param optionType LookupValue
		 * @param charTypeStr String
		 * @return charType CharacteristicType
		 */
		private CharacteristicType validateServiceTaskCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {

		  CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
		  CharacteristicType charType = charTypeId.getEntity();

		  if (isNull(charType)) {
		      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
		              optionType.fetchLanguageDescription(), charTypeStr));
		  }

		  CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		  if (isNull(charEntityId.getEntity())) {
		      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
		              optionType.fetchLanguageDescription(), charTypeStr, SERVICE_TASK));
		  }

		  return charType;
		}
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		//
		///**
		// * This method will validate Service Agreement Characteristic Type
		// * @param featConfig FeatureConfiguration
		// * @param optionType LookupValue
		// * @param charTypeStr String
		// * @return charType CharacteristicType
		// */
		//private CharacteristicType validateServiceAgreementCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
		//  CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
		//  CharacteristicType charType = charTypeId.getEntity();
		//
		//  if (isNull(charType)) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), charTypeStr));
		//  }
		//
		//  CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
		//  if (isNull(charEntityId.getEntity())) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), charTypeStr, SERVICE_AGREEMENT));
		//  }
		//
		//  return charType;
		//}
		//
		//private CharacteristicType validatePremiseCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
		//  CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
		//  CharacteristicType charType = charTypeId.getEntity();
		//
		//  if (isNull(charType)) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), charTypeStr));
		//  }
		//
		//  CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.PREMISE);
		//  if (isNull(charEntityId.getEntity())) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), charTypeStr, PREMISE));
		//  }
		//
		//  return charType;
		//}
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		
		/**
		 * This method will retrieve feature configuration
		 * @param lookup ExternalSystemTypeLookup
		 * @return featureConfiguration FeatureConfiguration
		 */
		private FeatureConfiguration retrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
		  FeatureConfiguration featureConfiguration = null;
		
		  StringBuilder stringBuilder = new StringBuilder();
		  stringBuilder.append(" FROM FeatureConfiguration fc ");
		  stringBuilder.append(" WHERE fc.featureType = :featureType ");
		
		  //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		  //Query<QueryResultRow> query = createQuery(stringBuilder.toString());
		  Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
		  //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		  query.bindLookup("featureType", featureType);
		
		  if (query.list().isEmpty()) {
		      addError(CustomMessageRepositoryMDC.np0055NoFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
		  }
		  else if (query.list().size() > 1) {
		      addError(CustomMessageRepositoryMDC.np0055MultipleFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
		  }
		  else {
		      featureConfiguration = (FeatureConfiguration) query.firstRow();
		  }
		
		  return featureConfiguration;
		}
		
		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		///**
		// * This method will validate Adjustment Type
		// * @param featConfig FeatureConfiguration
		// * @param optionType LookupValue
		// * @param adjTypeStr String
		// * @return adj AdjustmentType
		// */
		//private AdjustmentType validateAdjustmentType(FeatureConfiguration featConfig, LookupValue optionType, String adjTypeStr) {
		//  AdjustmentType_Id adjId = new AdjustmentType_Id(adjTypeStr);
		//  AdjustmentType adj = adjId.getEntity();
		//
		//  if (isNull(adj)) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidAdjustmentType(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), adjTypeStr));
		//  }
		//
		//  return adj;
		//}
		//
		///**
		// * This method will validate BigDecimal input
		// * @param featConfig FeatureConfiguration
		// * @param optionType LookupValue
		// * @param str String
		// * @return decimal BigDecimal
		// */
		//private BigDecimal validateBigDecimalValue(FeatureConfiguration featConfig, LookupValue optionType, String str) {   
		//  BigDecimal decimal = BigDecimal.ZERO;
		//  try {
		//      decimal = BigDecimal.valueOf(Double.parseDouble(str));
		//  }
		//  catch (NumberFormatException nfe) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidNumber(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), str));
		//  }
		//
		//  return decimal;
		//}
		//
		///**
		// * This method will validate BigInteger input
		// * @param featConfig FeatureConfiguration
		// * @param optionType LookupValue
		// * @param str String
		// * @return integer BigInteger
		// */
		//private int validateIntegerValue(FeatureConfiguration featConfig, LookupValue optionType, String str) {   
		//  int integer = 0;
		//  try {
		//      integer = Integer.parseInt(str);
		//  }
		//  catch (NumberFormatException nfe) {
		//      addError(CustomMessageRepositoryMDC.np0055InvalidNumber(featConfig.getId().getTrimmedValue(), 
		//              optionType.fetchLanguageDescription(), str));
		//  }
		//
		//  return integer;
		//}
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */

		/**
		 * Validates record to be processed
		 */
		

		private void cmValidatePledgeFields(ThreadWorkUnit unit) {

			pledgeId = (ServiceTask_Id) unit.getPrimaryId();
			fundingType = (String) unit.getSupplementallData("CM_FNDNG_TYPE");
			webTransactionId = new BigInteger((String) unit.getSupplementallData("CM_WEB_TRNSCTN_ID"));
			accountId = new Account_Id((String) unit.getSupplementallData("ACCT_ID"));
			account = accountId.getEntity();
			serviceAgreementId = new ServiceAgreement_Id((String) unit.getSupplementallData("SA_ID"));
			serviceAgreement = serviceAgreementId.getEntity();
			agencyAccountId = new Account_Id((String) unit.getSupplementallData("CM_AGENCY_ACCT_ID"));
			agencyAccount = agencyAccountId.getEntity();
			pledgeAction = (String) unit.getSupplementallData("CM_PLDG_ACTION");
			pledgeStatus = cmRetrieveRecordStatus();

			if (isNull(account)) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId((String) unit.getSupplementallData("ACCT_ID"), ACCOUNT, pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) unit.getSupplementallData("ACCT_ID"));
					messageParameterList.add(1, ACCOUNT);
					messageParameterList.add(2, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID; 
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}

			// Check that the SA ID retrieved is a valid Service Agreement ID. If not, log error MSG4 and set 
			// skipRecord to true. Exit method.

			if (isNull(serviceAgreement)) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId((String) unit.getSupplementallData("SA_ID"), SERVICE_AGREEMENT, pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) unit.getSupplementallData("SA_ID"));
					messageParameterList.add(1, SERVICE_AGREEMENT);
					messageParameterList.add(2, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}

			// Account Bill Cycle is required
			if (isNull(serviceAgreement.getAccount().fetchBillCycle())) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					String accountStr = serviceAgreement.getAccount().getId().getTrimmedValue();
					serverMessage = CustomMessageRepositoryMDC.np0055BillCycleMissing(accountStr);
					messageParameterList.clear();
					messageParameterList.add(0, accountStr);
					messageCategory = CustomMessagesMDC.MESSAGE_CATEGORY;
					messageNumber = CustomMessagesMDC.NP0055_BILL_CYCLE_MISSING;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;

			}


			// Check that the Pledge Amount retrieved is a valid amount. If not, log error MSG5 and set skipRecord to true.
			// Exit method.
			try {
				pledgeAmount = new Money((String) unit.getSupplementallData("CM_PLDG_AMT"), serviceAgreement.getCurrencyId());
			}
			catch (NumberFormatException e) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidAmount((String) unit.getSupplementallData("CM_PLDG_AMT"), pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) unit.getSupplementallData("CM_PLDG_AMT"));
					messageParameterList.add(1, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_AMOUNT;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}

			// Check that the Agency Account ID retrieved is a valid Account ID. If not, log error MSG4 and set skipRecord
			// to true. Exit method.

			if (isNull(agencyAccount)) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId((String) unit.getSupplementallData("CM_AGENCY_ACCT_ID"), ACCOUNT, pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) unit.getSupplementallData("CM_AGENCY_ACCT_ID"));
					messageParameterList.add(1, ACCOUNT);
					messageParameterList.add(2, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}

			// Check that the Agency Account Id has an Agency Code Characteristic Type, if not, log error MSG
			// and set skipRecord to true. Exit method
			agencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, agencyAccount);
			AccountCharacteristic acctChar = agencyAccount.getEffectiveCharacteristic(parmAgencyCodeCharType);

			if (isNull(acctChar)) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepositoryMDC.ni00263AgencyAccountHasNoAgencyCodeCharType(agencyAccountId.getTrimmedValue(),
							parmAgencyCodeCharType.fetchLanguageDescription().trim(), parmAgencyCodeCharType.getId().getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, agencyAccountId.getTrimmedValue());
					messageParameterList.add(1, parmAgencyCodeCharType.fetchLanguageDescription().trim());
					messageParameterList.add(2, parmAgencyCodeCharType.getId().getTrimmedValue());
					messageCategory = CustomMessagesMDC.MESSAGE_CATEGORY;
					messageNumber = CustomMessagesMDC.NI0026_3_AGENCY_ACCT_HAS_NO_AGENCY_CHAR_TYPE;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}

			try {
				confirmationDate = Date.fromString((String) unit.getSupplementallData("CM_CONF_DATE"), yyyyMmDd) ;
			} catch (DateFormatParseException e) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidDate((String) unit.getSupplementallData("CM_CONF_DATE"), pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) unit.getSupplementallData("CM_CONF_DATE"));
					messageParameterList.add(1, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_DATE;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;

			}

			// Check that Action is equal to "NEW", or "CANCEL", or "EXPIRE".
			// If not, log error MSG7 and set skipRecord to true. Exit method .

			if (!pledgeAction.equals(ACTION_NEW) && !pledgeAction.equals(ACTION_CANCEL) && !pledgeAction.equals(ACTION_EXPIRE)) {
				if(pledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidAction(pledgeAction, pledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, pledgeAction);
					messageParameterList.add(1, pledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ACTION;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipRecord = Bool.TRUE;
				return;
			}
		}

		private void cmValidateExistingPledgeFields(SQLResultRow row) {

			otherPledgePledgeId = (ServiceTask_Id) row.getId("CM_PLEDGE_ID", ServiceTask.class);
			otherPledgePledgeStatus = row.getString("CM_PLDG_RCRD_ST_FLG");
			otherPledgeFundingType = row.getString("CM_FNDNG_TYPE");
			otherPledgeWebTransactionId = new BigInteger(row.getString("CM_WEB_TRNSCTN_ID"));
			otherPledgeAccountId = (Account_Id) row.getId("ACCT_ID", Account.class);
			otherPledgeAccount = otherPledgeAccountId.getEntity();
			otherPledgeServiceAgreementId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
			otherPledgeServiceAgreement = otherPledgeServiceAgreementId.getEntity();
			otherPledgeAgencyAccountId = (Account_Id) row.getId("CM_AGENCY_ACCT_ID", Account.class);
			otherPledgeAgencyAccount = otherPledgeAgencyAccountId.getEntity();
			otherPledgePledgeAction = row.getString("CM_PLDG_ACTION");
			if (isNull(otherPledgeAccount)) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId(row.getString("ACCT_ID"), ACCOUNT, otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, row.getString("ACCT_ID"));
					messageParameterList.add(1, ACCOUNT);
					messageParameterList.add(2, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}

			// Check that the SA ID retrieved is a valid Service Agreement ID. If not, log error MSG4 and set 
			// skipRecord to true. Exit method.


			if (isNull(otherPledgeServiceAgreement)) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId(row.getString("SA_ID"), SERVICE_AGREEMENT, otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, row.getString("SA_ID"));
					messageParameterList.add(1, SERVICE_AGREEMENT);
					messageParameterList.add(2, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}

			// Account Bill Cycle is required
			if (isNull(otherPledgeServiceAgreement.getAccount().fetchBillCycle())) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					String otherAccountStr = otherPledgeServiceAgreement.getAccount().getId().getTrimmedValue();
					serverMessage = CustomMessageRepositoryMDC.np0055BillCycleMissing(otherAccountStr);
					messageParameterList.clear();
					messageParameterList.add(0, otherAccountStr);
					messageCategory = CustomMessagesMDC.MESSAGE_CATEGORY;
					messageNumber = CustomMessagesMDC.NP0055_BILL_CYCLE_MISSING;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;

			}


			// Check that the Pledge Amount retrieved is a valid amount. If not, log error MSG5 and set skipRecord to true.
			// Exit method.
			try {
				otherPledgePledgeAmount = new Money(row.getString("CM_PLDG_AMT"), otherPledgeServiceAgreement.getCurrencyId());
			}
			catch (NumberFormatException e) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidAmount(row.getString("CM_PLDG_AMT"), otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, (String) row.getString("CM_PLDG_AMT"));
					messageParameterList.add(1, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_AMOUNT;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}

			// Check that the Agency Account ID retrieved is a valid Account ID. If not, log error MSG4 and set skipRecord
			// to true. Exit method.

			if (isNull(otherPledgeAgencyAccount)) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidId(row.getString("CM_AGENCY_ACCT_ID"), ACCOUNT, otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, row.getString("CM_AGENCY_ACCT_ID"));
					messageParameterList.add(1, ACCOUNT);
					messageParameterList.add(2, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ID;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}

			// Check that the Agency Account Id has an Agency Code Characteristic Type, if not, log error MSG
			// and set skipRecord to true. Exit method
			otherpledgeAgencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, otherPledgeAgencyAccount);
			AccountCharacteristic acctChar = otherPledgeAgencyAccount.getEffectiveCharacteristic(parmAgencyCodeCharType);

			if (isNull(acctChar)) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepositoryMDC.ni00263AgencyAccountHasNoAgencyCodeCharType(otherPledgeAgencyAccountId.getTrimmedValue(),
							parmAgencyCodeCharType.fetchLanguageDescription().trim(), parmAgencyCodeCharType.getId().getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, otherPledgeAgencyAccountId.getTrimmedValue());
					messageParameterList.add(1, parmAgencyCodeCharType.fetchLanguageDescription().trim());
					messageParameterList.add(2, parmAgencyCodeCharType.getId().getTrimmedValue());
					messageCategory = CustomMessagesMDC.MESSAGE_CATEGORY;
					messageNumber = CustomMessagesMDC.NI0026_3_AGENCY_ACCT_HAS_NO_AGENCY_CHAR_TYPE;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}

			try {
				otherPledgeConfirmationDate = Date.fromString( row.getString("CM_CONF_DATE"), yyyyMmDd) ;
			} catch (DateFormatParseException e) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidDate(row.getString("CM_CONF_DATE"), otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, row.getString("CM_CONF_DATE"));
					messageParameterList.add(1, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_DATE;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;

			}

			// Check that Action is equal to "NEW", or "CANCEL", or "EXPIRE".
			// If not, log error MSG7 and set skipRecord to true. Exit method .

			if (!otherPledgePledgeAction.equals(ACTION_NEW) && !otherPledgePledgeAction.equals(ACTION_CANCEL) && !otherPledgePledgeAction.equals(ACTION_EXPIRE)) {
				if(otherPledgePledgeStatus.trim().equals(CmPledgeRecordStagingFlagLookup.constants.PENDING.trimmedValue())){
					serverMessage = CustomMessageRepository.IM062090_InvalidAction(otherPledgePledgeAction, otherPledgePledgeId.getTrimmedValue());
					messageParameterList.clear();
					messageParameterList.add(0, otherPledgePledgeAction);
					messageParameterList.add(1, otherPledgePledgeId.getTrimmedValue());
					messageCategory = CustomMessages.MESSAGE_CATEGORY;
					messageNumber = CustomMessages.IM062090_INVALID_ACTION;
					priority = TODO_PRIORITY_NORMAL;

				}
				skipOtherRecord = Bool.TRUE;
				return;
			}
		}

		/**
		 * This method creates To Do Entry
		 * @param accountStr - Account Id
		 */
		private void createToDo(int messageCategory, int messageNumber, ArrayList<String> messageParameterList, String priority) {

			ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
			ToDoType toDoType = getParameters().getTO_DO_TYPE();
			entryDto.setToDoTypeId(toDoType.getId());
			entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);

			if(priority.equals(TODO_PRIORITY_HIGH)){
				entryDto.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_1_0);
			}else{
				entryDto.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_3_0);
			}


			entryDto.setToDoRoleId(getDefaultToDoRole().getId());
			entryDto.setCreationDateTime(getProcessDateTime());
			MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(messageCategory));
			Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(messageNumber));
			entryDto.setMessageId(msgId);

			ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
			ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

			for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
				ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
				ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
				BigInteger seq = sortKeyType.fetchIdSequence();
				sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

				if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
					sortKeyDto.setKeyValue(getBatchControlId().getTrimmedValue());
				}
				if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(2))==0){
					sortKeyDto.setKeyValue(getBatchNumber().toString());
				}
				if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(3))==0){
					sortKeyDto.setKeyValue(getBatchRerunNumber().toString());
				}
				sortKeyList.add(sortKeyDto);
			}

			ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
			ToDoTypeDrillKeyTypes drillKeyTypes = toDoType.getDrillKeyTypes();

			for(Iterator<ToDoDrillKeyType> iter = drillKeyTypes.iterator(); iter.hasNext();){
				ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) iter.next();
				ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
				BigInteger seq = drillKeyType.fetchIdSequence();
				drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, seq));

				if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
					drillKeyDto.setKeyValue(getBatchControlId().getTrimmedValue());
				}
				if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(2))==0){
					drillKeyDto.setKeyValue(getBatchNumber().toString());
				}
				if(drillKeyType.getId().getSequence().compareTo(BigInteger.valueOf(3))==0){
					drillKeyDto.setKeyValue(getBatchRerunNumber().toString());
				}
				drillKeyList.add(drillKeyDto);
			}

			ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

			toDoEntryData.setDrillKeys(drillKeyList);
			toDoEntryData.setEntryDto(entryDto);
			toDoEntryData.setSortKeys(sortKeyList);
			toDoEntryData.setMessageParams(messageParameterList);
			ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
			toDoEntryData.setToDoCharacteristics(charList);

			ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
			toDoProcessor.addToDo(toDoEntryData);
		}

		/**
		 * @return Role 
		 * This method fetches the Default Role to create a TODO
		 * 
		 */ 
		private Role getDefaultToDoRole(){
			Role defaultRole = null;
			StringBuilder defaultRoleQueryString = new StringBuilder();
			defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString()); 
			PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString(), getClass().getName()); 
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			defaultRolePrepStmt.bindId("toDoType", getParameters().getTO_DO_TYPE().getId()); 
			defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
			defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
	        // START ADD - JHERNA - 2018-03-16 - SyAid#239434
			defaultRolePrepStmt.setAutoclose(false);
	        // END ADD - JHERNA - 2018-03-16 - SyAid#239434
			defaultRolePrepStmt.close();
			return defaultRole;
		}

		/**
		 * Retrieves Agency Code
		 * @param charType Agency Code Characteristic Type
		 * @param account Account
		 * @return Agency Code
		 */
		private String cmRetrieveAgencyCode(CharacteristicType charType, Account account) {
			String agencyCode = "";
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			AccountCharacteristic acctChar = account.getEffectiveCharacteristic(charType);

			if (notNull(acctChar)) {
				if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
					agencyCode = acctChar.getAdhocCharacteristicValue().trim();
				}
				else if (charTypeLookup.isForeignKeyValue()) {
					agencyCode = acctChar.getCharacteristicValueForeignKey1().trim();
				}
				else if (charTypeLookup.isPredefinedValue()) {
					agencyCode = acctChar.getCharacteristicValue().trim();
				}
			}
			return agencyCode.trim();
		}

		/**
		 * Retrieves Active Service Task using Pledge ID query
		 * @return query
		 */
		private Query<ServiceTask_Id> cmRetrieveServiceTaskUsingPledgeId( ServiceTask_Id pledgeId) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
			stringBuilder.append(" WHERE SVCTASKCHAR.id.characteristicType = :pledgeIdCharacteristicType ");
			stringBuilder.append("  AND (SVCTASKCHAR.adhocCharacteristicValue = :pledgeIdAdhoc ");
			stringBuilder.append("      OR SVCTASKCHAR.characteristicValueForeignKey1 = :pledgeIdFK1 ");
			stringBuilder.append("      OR SVCTASKCHAR.characteristicValue = :pledgeIdCharVal) ");
			stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<ServiceTask_Id> query = createQuery(stringBuilder.toString());
			Query<ServiceTask_Id> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			query.bindEntity("pledgeIdCharacteristicType", parmPledgeIdCharType);
			query.bindStringProperty("pledgeIdFK1", ServiceTaskCharacteristic.properties.characteristicValueForeignKey1, pledgeId.getTrimmedValue());
			query.bindStringProperty("pledgeIdAdhoc", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, pledgeId.getTrimmedValue());
			query.bindStringProperty("pledgeIdCharVal", ServiceTaskCharacteristic.properties.characteristicValue, pledgeId.getTrimmedValue());
			query.addResult("serviceTask", "SVCTASK.id");

			return query;
		}



		/**
		 * Adds Service Task Characteristic
		 * @param serviceTask Service Task
		 * @param charType Characteristic Type
		 * @param charValue Characteristic Value
		 * @param seqNbr Sequence Number
		 */
		private void cmAddServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType,
				String charValue, BigInteger seqNbr) {

			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

			ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = createDTO(ServiceTaskCharacteristic.class);
			if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
				serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
			} 
			else if (charTypeLookup.isPredefinedValue()) {
				serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
			}

			serviceTask.getCharacteristics().add(serviceTaskCharacteristicDto, charType.getId(), seqNbr);
		}

		/**
		 * Retrieves Major Funding Types
		 */
		private void cmRetrieveMajorFundingTypes() {
			// Retrieve the Eligible Major Pledge Funding Type feature configuration
			FeatureConfiguration eligibleMajorPledgeFundingTypeFeatConfig = 
					cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_ELIGIBLE_MAJOR_PLEDGE_FUNDING_TYPES);

			// Retrieve the Funding Types from the Feature Configuration
			LookupValue lookupValue = CmEligibleMajorPledgeFundingTypesLookup.constants.CM_ELIGIBLE_MAJOR_PLEDGE_FUNDING_TYPE.getLookupValue();
			Query<String> query = cmRetrieveFeatureConfigurationOptionValue(eligibleMajorPledgeFundingTypeFeatConfig, lookupValue);

			QueryIterator<String> queryItr = query.iterate();
			String fundingTypeOptVal;
			majorFundingTypesList = new ArrayList<String>();

			while (queryItr.hasNext()) {
				fundingTypeOptVal = queryItr.next();
				majorFundingTypesList.add(fundingTypeOptVal);
			}
			queryItr.close();
		}

		/**
		 * Retrieves Feature Configuration
		 * @param featureType External System Feature Type
		 * @return Feature Configuration
		 */
		private FeatureConfiguration cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
			FeatureConfiguration featureConfiguration = null;

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM FeatureConfiguration FEATCONFIG ");
			stringBuilder.append(" WHERE FEATCONFIG.featureType = :extSysTypeFlag ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
			Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			query.bindLookup("extSysTypeFlag", featureType);

			if (query.list().isEmpty()) {
				addError(CustomMessageRepositoryMDC.ni00263NoFeatConfigRetrieved(featureType.getLookupValue().
						fetchLanguageDescription()));
			}
			else {
				featureConfiguration = (FeatureConfiguration) query.firstRow();
			}

			return featureConfiguration;
		}

		/**
		 * Retrieves Feature Configuration Option Value
		 * @param featureConfiguration Feature Configuration
		 * @param lookupValue
		 * @return Feature Configuration Option value query
		 */
		private Query<String> cmRetrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM FeatureConfigurationOption FEATCONFIGOPTION ");
			stringBuilder.append(" WHERE FEATCONFIGOPTION.id.workforceManagementSystem = :featureConfiguration ");
			stringBuilder.append(" 	AND FEATCONFIGOPTION.id.optionType = :optionType ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<String> query = createQuery(stringBuilder.toString());
			Query<String> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			query.bindEntity("featureConfiguration", featureConfiguration);
			query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,
					lookupValue.fetchIdFieldValue().trim());	
			query.addResult("value", "FEATCONFIGOPTION.value");

			if (query.list().isEmpty()) {
				addError(CustomMessageRepositoryMDC.ni00263ni00263NoFeatConfigOptionValueRetrieved(featureConfiguration.getId().getTrimmedValue(),
						lookupValue.fetchLanguageDescription()));
			}
			return query;

		}

		/**
		 * Retrieves Active Quote Service Task query
		 * @return query
		 */
		private Query<QueryResultRow> cmRetrieveActiveQuoteServiceTask( ServiceAgreement serviceAgreement) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
			stringBuilder.append(" WHERE SVCTASK.serviceTaskType = :serviceTaskType ");
			stringBuilder.append(" 	AND SVCTASK.businessObject = :businessObject ");
			stringBuilder.append(" 	AND SVCTASK.status = :activeBusinessObjectStatus ");
			stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");
			stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :saIdCharacteristicType ");
			stringBuilder.append(" 	AND (SVCTASKCHAR.adhocCharacteristicValue = :saId ");
			stringBuilder.append("  	OR SVCTASKCHAR.characteristicValueForeignKey1 = :saId ");
			stringBuilder.append("  	OR SVCTASKCHAR.characteristicValue = :saId) ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
			Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			query.bindEntity("serviceTaskType", parmQuoteServiceTaskType);
			query.bindEntity("businessObject", parmQuoteBo);
			query.bindStringProperty("activeBusinessObjectStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
			query.bindEntity("saIdCharacteristicType", parmSaIdCharType);
			query.bindId("saId", serviceAgreement.getId());

			query.addResult("serviceTask", "SVCTASK.id");

			return query;
		}

		/**
		 * Retrieves Active Payment Arrangement SAs query
		 * @return query
		 */
		private Query<QueryResultRow> cmRetrieveActivePaymentArrangementSas( Account account) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM ServiceAgreement SA, ");
			stringBuilder.append("	FeatureConfigurationOption CISDIVOPTION, ");
			stringBuilder.append("  FeatureConfigurationOption SATYPEOPTION ");
			stringBuilder.append(" WHERE SA.account = :account");
			stringBuilder.append(" 	AND SA.status = :activeStatus");
			stringBuilder.append(" 	AND CISDIVOPTION.id.workforceManagementSystem = :featureConfiguration");
			stringBuilder.append(" 	AND CISDIVOPTION.id.optionType = :cisDivisionOptType");
			stringBuilder.append(" 	AND SATYPEOPTION.id.workforceManagementSystem = :featureConfiguration");
			stringBuilder.append(" 	AND SATYPEOPTION.id.optionType = :saTypeOptType");
			stringBuilder.append(" 	AND TRIM(SA.serviceAgreementType.id.division) = TRIM(CISDIVOPTION.value)");
			stringBuilder.append(" 	AND TRIM(SA.serviceAgreementType.id.saType) = TRIM(SATYPEOPTION.value)");
			stringBuilder.append(" 	AND CISDIVOPTION.id.sequence = SATYPEOPTION.id.sequence ");

			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
			Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

			query.bindEntity("account", account);
			query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
			query.bindEntity("featureConfiguration", paymentArrangementSaTypesFeatConfig);
			query.bindStringProperty("cisDivisionOptType", FeatureConfigurationOption.properties.optionType,
					CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.trimmedValue());
			query.bindStringProperty("saTypeOptType", FeatureConfigurationOption.properties.optionType,
					CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.trimmedValue());

			query.addResult("saId", "SA.id");

			return query;
		}

		/*
         * Defect 3948617 - 2017-12-13 - Start Delete
         */
		///**
		// * This method will create Service Task Characteristics
		// * @param serviceTask ServiceTask
		// */
		//private void createServiceTaskCharacteristics(ServiceTask serviceTask) {    
		//	// Service Agreement Characteristic
		//	addServiceTaskCharacteristic(serviceTask, serviceAgreementCharType, serviceAgreement.getId().getTrimmedValue());
		//
		//	// CIS Division Characteristic
		//	addServiceTaskCharacteristic(serviceTask, cisDivisionCharType, serviceAgreement.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
		//
		//	// Debt Class Characteristic
		//	addServiceTaskCharacteristic(serviceTask, debtClassCharType, serviceAgreement.getServiceAgreementType().getDebtClass().getId().getTrimmedValue());
		//
		//	// Expiration Date Characteristic
		//	Date nextBillDate = retrieveNextBillingWindow();
		//	Date expirationDate = null;
		//
		//	DateFormat cwrSeasonDateFormat = new DateFormat(CWR_SEASON_DATE_FORMAT);
		//
		//
		//	if (isNull(nextBillDate)) {
		//		FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 
		//		// CWR Season End
		//		LookupValue optionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_END.getLookupValue();
		//		cwrSeasonEnd = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
		//
		//		int systemYear = this.getProcessDateTime().getYear();
		//
		//		String cwrSeasonEndStr = cwrSeasonEnd + "/" + systemYear;
		//		Date cwrSeasonEndDate = null;
		//		try {
		//			cwrSeasonEndDate = Date.fromString(cwrSeasonEndStr, cwrSeasonDateFormat);
		//			if (this.getProcessDateTime().getDate().isAfter(cwrSeasonEndDate)) {
		//				cwrSeasonEndDate = cwrSeasonEndDate.addYears(1);
		//			}
		//		}
		//		catch (Exception e) {
		//			addError(CustomMessageRepositoryMDC.np0055InputInvalid(CWR_SEASON_END));
		//		}
		//
		//		expirationDate = cwrSeasonEndDate;
		//
		//	} else {
		//		expirationDate = nextBillDate;
		//	}
		//
		//	if(notNull(expirationDate)) {
		//		addServiceTaskCharacteristic(serviceTask, expirationDateCharType, expirationDate.toString(new DateFormat(DATE_FORMAT)));
		//	}
		//
		//	// CWR Level Characteristic
		//	String cwrLevel = retrieveCwrLevel();
		//	addServiceTaskCharacteristic(serviceTask, cwrLevelCharType, cwrLevel);
		//
		//	// Total SA Arrears Characteristic
		//	BigDecimal totalSaArrears = serviceAgreement.getPayoffBalance(creationDateTime.getDate(), creationDateTime.getDate(), Bool.FALSE).getAmount();
		//
		//	addServiceTaskCharacteristic(serviceTask, totalSaArrearsCharType, totalSaArrears.toString());
		//
		//	// Total Diversion Characteristic
		//	BigDecimal totalDiversion = retrieveTotalDiversion().getAmount();
		//	addServiceTaskCharacteristic(serviceTask, totalDiversionCharType, totalDiversion.toString());
		//
		//	// Monthly Budget Characteristic
		//	BigDecimal monthlyBudget = retrieveMonthlyBudget();
		//	addServiceTaskCharacteristic(serviceTask, monthlyBudgetCharType, monthlyBudget.toString());
		//
		//	// Standard Turn-On or Avoid Severance Amount Characteristic
		//	BigDecimal standardAmount = retrieveStandardAmount().add(totalDiversion);
		//	addServiceTaskCharacteristic(serviceTask, standardTurnOnOrAvoidSeveranceAmountCharType, standardAmount.toString());
		//
		//	// CWR Down Payment Characteristic
		//	BigDecimal cwrDownPayment = retrieveCwrDownPayment(cwrLevel, totalSaArrears, monthlyBudget, totalDiversion).setScale(2, BigDecimal.ROUND_HALF_UP);
		//	addServiceTaskCharacteristic(serviceTask, cwrDownPaymentCharType, cwrDownPayment.toString());
		//
		//	// CWR Monthly Payment Arrangement Characteristic
		//	BigDecimal cwrMonthlyPaymentArrangement = (totalSaArrears.subtract(cwrDownPayment.subtract(totalDiversion))).divide(BigDecimal.valueOf(12)).setScale(2, BigDecimal.ROUND_HALF_UP);
		//	addServiceTaskCharacteristic(serviceTask, cwrMonthlyPaymentArrangementCharType, cwrMonthlyPaymentArrangement.toString());
		//
		//	// BPAP 0-50 Monthly Budget Characteristic
		//	BigDecimal bpap050MonthlyBudget = monthlyBudget.subtract(bpap050CreditValue);
		//	addServiceTaskCharacteristic(serviceTask, bpap050MonthlyBudgetCharType, bpap050MonthlyBudget.toString());
		//
		//	// BPAP 51-99 Monthly Budget Characteristic
		//	BigDecimal bpap5199MonthlyBudget = monthlyBudget.subtract(bpap5199CreditValue);
		//	addServiceTaskCharacteristic(serviceTask, bpap5199MonthlyBudgetCharType, bpap5199MonthlyBudget.toString());
		//
		//	// BPAP 100-125 Monthly Budget Characteristic
		//	BigDecimal bpap100125MonthlyBudget = monthlyBudget.subtract(bpap100125CreditValue);
		//	addServiceTaskCharacteristic(serviceTask, bpap100125MonthlyBudgetCharType, bpap100125MonthlyBudget.toString());
		//
		//	// BPAP 126-185 Monthly Budget Characteristic
		//	BigDecimal bpap126185MonthlyBudget = monthlyBudget.subtract(bpap126185CreditValue);
		//	addServiceTaskCharacteristic(serviceTask, bpap126185MonthlyBudgetCharType, bpap126185MonthlyBudget.toString());
		//
		//	// ARP 0-50 Down Payment Characteristic
		//	addServiceTaskCharacteristic(serviceTask, arp050DownPaymentCharType, arp050DownPaymentValue.toString());
		//
		//	// ARP 51-99 Down Payment Characteristic
		//	addServiceTaskCharacteristic(serviceTask, arp5199DownPaymentCharType, arp5199DownPaymentValue.toString());
		//
		//	// ARP 100-125 Down Payment Characteristic
		//	addServiceTaskCharacteristic(serviceTask, arp100125DownPaymentCharType, arp100125DownPaymentValue.toString());
		//
		//	// ARP 126-185 Down Payment Characteristic
		//	addServiceTaskCharacteristic(serviceTask, arp126185DownPaymentCharType, arp126185DownPaymentValue.toString());
		//
		//	// Monthly ARP 0-50 Payment Arrangement - 12 Month Characteristic
		//	BigDecimal monthlyArp050PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp050DownPaymentValue, BigDecimal.valueOf(24));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp050PaymentArrangement12MonthCharType, monthlyArp050PaymentArrangement12Month.toString());
		//
		//	// Monthly ARP 51-99 Payment Arrangement - 12 Month Characteristic
		//	BigDecimal monthlyArp5199PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp5199DownPaymentValue, BigDecimal.valueOf(24));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp5199PaymentArrangement12MonthCharType, monthlyArp5199PaymentArrangement12Month.toString());
		//
		//	// Monthly ARP 100-125 Payment Arrangement - 12 Month Characteristic
		//	BigDecimal monthlyArp100125PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp100125DownPaymentValue, BigDecimal.valueOf(24));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp100125PaymentArrangement12MonthCharType, monthlyArp100125PaymentArrangement12Month.toString());
		//
		//	// Monthly ARP 126-185 Payment Arrangement - 12 Month Characteristic
		//	BigDecimal monthlyArp126185PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp126185DownPaymentValue, BigDecimal.valueOf(24));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp126185PaymentArrangement12MonthCharType, monthlyArp126185PaymentArrangement12Month.toString());
		//
		//	// Monthly ARP 0-50 Payment Arrangement - 24 Month Characteristic
		//	BigDecimal monthlyArp050PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp050DownPaymentValue, BigDecimal.valueOf(48));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp050PaymentArrangement24MonthCharType, monthlyArp050PaymentArrangement24Month.toString());
		//
		//	// Monthly ARP 51-99 Payment Arrangement - 24 Month Characteristic
		//	BigDecimal monthlyArp5199PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp5199DownPaymentValue, BigDecimal.valueOf(48));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp5199PaymentArrangement24MonthCharType, monthlyArp5199PaymentArrangement24Month.toString());
		//
		//	// Monthly ARP 100-125 Payment Arrangement - 24 Month Characteristic
		//	BigDecimal monthlyArp100125PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp100125DownPaymentValue, BigDecimal.valueOf(48));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp100125PaymentArrangement24MonthCharType, monthlyArp100125PaymentArrangement24Month.toString());
		//
		//	// Monthly ARP 126-185 Payment Arrangement - 24 Month Characteristic
		//	BigDecimal monthlyArp126185PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
		//			arp126185DownPaymentValue, BigDecimal.valueOf(48));
		//	addServiceTaskCharacteristic(serviceTask, monthlyArp126185PaymentArrangement24MonthCharType, monthlyArp126185PaymentArrangement24Month.toString());
		//
		//	// Selection Characteristic
		//	addServiceTaskCharacteristic(serviceTask, selectionCharType, selection);
		//
		//	// Quote Source Characteristic
		//	addServiceTaskCharacteristic(serviceTask, quoteSourceCharType, source);
		//
		//	// Custom Down Payment Characteristic
		//	addServiceTaskCharacteristic(serviceTask, customDownPaymentCharType, NO);
		//}
		//
		///**
		// * This method will add Service Task Characteristic
		// * @param serviceTask ServiceTask
		// * @param charType CharacteristicType
		// * @param charValue String
		// */
		//private void addServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType, String charValue) {
		//	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
		//
		//	ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = createDTO(ServiceTaskCharacteristic.class);
		//	if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
		//		serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
		//	} 
		//	else if (charTypeLookup.isPredefinedValue()) {
		//		serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
		//	}
		//	else if (charTypeLookup.isForeignKeyValue()) {
		//		serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
		//	}
		//
		//	serviceTask.getCharacteristics().add(serviceTaskCharacteristicDto, charType.getId(), BigInteger.TEN);
		//}
		//
		//
		///**
		// * This method will retrieve the next billing window
		// * @return windowStartDate Date
		// */
		//private Date retrieveNextBillingWindow() {
		//	Date windowStartDate = null;
		//
		//	PreparedStatement checkIfAccountDoesNotHaveBillableSAs = createPreparedStatement(
		//			" SELECT ACCT_ID " +
		//					" FROM CI_ACCT ACCT " +
		//					" WHERE ACCT_ID = :acctId " +
		//					" AND NOT EXISTS (SELECT 'X' " +
		//					"                 FROM CI_SA SA " +
		//					"                     ,CI_SA_TYPE SAT " +
		//					"                 WHERE SA.CIS_DIVISION = SAT.CIS_DIVISION " +
		//					"                   AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD " +
		//					"                   AND SAT.ALLOW_BILLING_SW = 'Y' " +
		//					"                   AND SA.ACCT_ID = ACCT.ACCT_ID " +
		//					"                   AND (SA.SA_STATUS_FLG IN (:pendingStart,:active,:pendingStop) " +
		//					"                        OR  " +
		//					"                       (SA.SA_STATUS_FLG = :stopped " +
		//					"                        AND NOT EXISTS (SELECT 'X' " +
		//					"                                        FROM CI_BSEG " +
		//					"                                        WHERE SA_ID = SA.SA_ID " +
		//					"                                          AND BSEG_STAT_FLG = :frozen " +
		//			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//			//"                                          AND CLOSING_BSEG_SW = 'Y')))) ");
		//			"                                          AND CLOSING_BSEG_SW = 'Y')))) ", getClass().getName());
		//			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//
		//	checkIfAccountDoesNotHaveBillableSAs.bindEntity("acctId", serviceAgreement.getAccount());
		//	checkIfAccountDoesNotHaveBillableSAs.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		//	checkIfAccountDoesNotHaveBillableSAs.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		//	checkIfAccountDoesNotHaveBillableSAs.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		//	checkIfAccountDoesNotHaveBillableSAs.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		//	checkIfAccountDoesNotHaveBillableSAs.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		//
		//	if (!checkIfAccountDoesNotHaveBillableSAs.list().isEmpty()) {
		//
		//		// Account Does Not have a Billable SA so next Billing Window is null
		//		windowStartDate = null;
		//		return windowStartDate;
		//
		//	}
		//
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM BillCycleSchedule bcs ");
		//	stringBuilder.append(" WHERE bcs.id.billCycle = :billCycle ");
		//	stringBuilder.append(" AND bcs.id.windowStartDate > :windowStartDate ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Date> query = createQuery(stringBuilder.toString());
		//	Query<Date> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	query.bindEntity("billCycle", serviceAgreement.getAccount().fetchBillCycle());
		//
		//	Date latestCompletedBillDate = retrieveLatestCompletedBill();
		//	if (this.getProcessDateTime().getDate().isAfter(latestCompletedBillDate)) {
		//		latestCompletedBillDate = this.getProcessDateTime().getDate();
		//	}
		//	query.bindDate("windowStartDate", latestCompletedBillDate);
		//
		//	query.addResult("windowStartDate", "bcs.id.windowStartDate");
		//	query.orderBy("windowStartDate", Query.ASCENDING);
		//
		//	if (!query.list().isEmpty()) {
		//		windowStartDate = query.firstRow();
		//	}
		//
		//	return windowStartDate;
		//}
		//
		///**
		// * This method will retrieve CWR Level
		// * @return cwrLevel String
		// */
		//private String retrieveCwrLevel() {
		//	String cwrLevel = "";
		//
		//	// Select all CWR Payment Arrangement SAs
		//
		//	Query<QueryResultRow> cwrPaymentArrangementSaQuery = retrieveCwrPaymentArrangementSa();
		//	if(cwrPaymentArrangementSaQuery.list().isEmpty()) {
		//		cwrLevel = PERCENT_12;
		//	}
		//	else {
		//		QueryResultRow cwrResult = (QueryResultRow) cwrPaymentArrangementSaQuery.firstRow();
		//		ServiceAgreement cwrPaymentArrangementSa = (ServiceAgreement) cwrResult.get("sa");
		//		// Determine if most recent CWR Payment Arrangement SA was broken
		//		if (isCwrPaymentArrangementSaBroken(cwrPaymentArrangementSa).isFalse()) {
		//			cwrLevel = PERCENT_12;
		//		}
		//		else {
		//			// Select all broken CWR Payment Arrangement SAs with CWR Char = 50
		//			Query<QueryResultRow> brokenCwrPaymentArrangementSaQuery = retrieveBrokenCwrPaymentArrangementSa();
		//			if (brokenCwrPaymentArrangementSaQuery.list().isEmpty()) {
		//				cwrLevel = PERCENT_50;
		//			}
		//			else {
		//				QueryResultRow brokenResult = (QueryResultRow) brokenCwrPaymentArrangementSaQuery.firstRow();
		//				Date startDate = (Date) brokenResult.get("startDate");
		//				// Determine if start date of most recent broken CWR Payment Arrangement SA with CWR Char = 50 is greater or equal to 2 years from system date
		//				if (startDate.isSameOrBefore(this.getProcessDateTime().getDate().addYears(-2))) {
		//					// Determine if count of broken CWR Payment Arrangement SAs with CWR Char = 50 is greater than or equal to 3
		//					if (brokenCwrPaymentArrangementSaQuery.list().size() >= 3) {
		//						cwrLevel = PERCENT_80;
		//					}
		//					else {
		//						cwrLevel = PERCENT_50;
		//					}
		//				}
		//				else {
		//					cwrLevel = PERCENT_80;
		//				}
		//			}
		//		}
		//	}
		//
		//	return cwrLevel;
		//}
		//
		//
		///**
		// * This method will retrieve total diversion
		// * @return totalDiversion Money
		// */
		//private Money retrieveTotalDiversion() {        
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreement sa, AccountPerson ap, FinancialTransaction ft ");
		//	stringBuilder.append(" WHERE fco1.id.workforceManagementSystem = :workforceManagementSystem ");
		//	stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
		//	stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
		//	stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
		//	stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
		//	stringBuilder.append(" AND TRIM (fco1.value) = TRIM (sa.serviceAgreementType.id.division) ");
		//	stringBuilder.append(" AND TRIM (fco2.value) = TRIM (sa.serviceAgreementType.id.saType) ");
		//	stringBuilder.append(" AND sa.account = ap.id.account ");
		//	stringBuilder.append(" AND ap.id.person = :person ");
		//	stringBuilder.append(" AND ap.isFinanciallyResponsible = :isFinanciallyResponsible ");
		//	stringBuilder.append(" AND ft.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
		//	stringBuilder.append(" AND ft.shouldShowOnBill = :shouldShowOnBill ");
		//	stringBuilder.append(" AND ft.isFrozen = :isFrozen ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Money> query = createQuery(stringBuilder.toString());
		//	Query<Money> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//
		//	query.bindEntity("workforceManagementSystem", diversionSaTypesFeatConfig);
		//	query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmDiversionSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
		//	query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmDiversionSaTypesLookup.constants.DIVERSION_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());
		//
		//	query.bindEntity("person", retrieveAccountMainPerson(serviceAgreement.getAccount()));
		//	query.bindBoolean("isRedundant", Bool.FALSE);
		//	query.bindBoolean("isFinanciallyResponsible", Bool.TRUE);
		//	query.bindBoolean("shouldShowOnBill", Bool.TRUE);
		//	query.bindBoolean("isFrozen", Bool.TRUE);
		//
		//	query.addResult("currentAmount", "SUM(ft.currentAmount)");
		//
		//	return query.firstRow();
		//}
		//
		//
		///**
		// * This method will retrieve Monthly Budget Amount
		// * @return budgetAmount BigDecimal
		// */
		//private BigDecimal retrieveMonthlyBudget()  {
		//	BigDecimal budgetAmount = BigDecimal.ZERO;
		//
		//	Account account = serviceAgreement.getAccount();
		//
		//	ServiceAgreementStatusLookup saStatusLookup = serviceAgreement.getStatus();
		//	if (saStatusLookup.isPendingStart() || saStatusLookup.isActive() || saStatusLookup.isPendingStop()){
		//		BudgetPlan budgetPlan = account.fetchBudgetPlan();
		//		if (isNull(budgetPlan)) {
		//			CustomerClassControl_Id controlId = new CustomerClassControl_Id(serviceAgreement.getAccount().getCustomerClass(), 
		//					serviceAgreement.getServiceAgreementType().fetchIdDivision());
		//			budgetPlan = controlId.getEntity().fetchDefaultBudgetPlan();
		//		}
		//
		//		if (notNull(budgetPlan)) {
		//			try {
		//				budgetAmount = serviceAgreement.recommendBudgetAmount(creationDateTime.getDate(), budgetPlan).getAmount();
		//			}
		//			catch(Exception e) {
		//			}
		//			if (serviceAgreement.recommendBudgetAmount(creationDateTime.getDate(), budgetPlan).isEqualTo(Money.ZERO)){
		//				budgetAmount = retrieveRecurringChargeAmount();
		//			}
		//		}
		//		else {
		//			budgetAmount = retrieveRecurringChargeAmount();
		//		}
		//	}
		//	else {
		//		budgetAmount = retrieveRecurringChargeAmount();
		//	}
		//
		//	return budgetAmount;
		//}
		//
		///**
		// * This method will retrieve standard amount
		// * @return BigDecimal
		// */
		//private BigDecimal retrieveStandardAmount() {
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM FinancialTransaction ft, Bill b ");
		//	stringBuilder.append(" WHERE ft.serviceAgreement = :serviceAgreement ");
		//	stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
		//	stringBuilder.append(" AND ft.isFrozen = :isFrozen ");
		//	stringBuilder.append(" AND ft.billId = b.id ");
		//	stringBuilder.append(" AND b.dueDate >= :dueDate ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Money> query = createQuery(stringBuilder.toString());
		//	Query<Money> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	query.bindEntity("serviceAgreement", serviceAgreement);
		//	query.bindBoolean("isRedundant", Bool.FALSE);
		//	query.bindBoolean("isFrozen", Bool.TRUE);
		//	query.bindDate("dueDate", this.getProcessDateTime().getDate());
		//
		//	query.addResult("currentAmount", "SUM(ft.currentAmount)");
		//
		//	Money currentAmount = query.firstRow();
		//
		//	return serviceAgreement.getCurrentBalance().getAmount().subtract(currentAmount.getAmount());
		//
		//}
		//
		///**
		// * This method will retrieve CWR Down Payment
		// * @param cwrLevel String
		// * @param totalSaArrears BigDecimal
		// * @param monthlyBudget BigDecimal
		// * @param totalDiversion BigDecimal
		// * @return cwrDownPayment BigDecimal
		// */ 
		//private BigDecimal retrieveCwrDownPayment(String cwrLevel, BigDecimal totalSaArrears, BigDecimal monthlyBudget, BigDecimal totalDiversion) {
		//	BigDecimal cwrDownPayment = BigDecimal.ZERO;
		//
		//	if (cwrLevel.equalsIgnoreCase(PERCENT_12)) {
		//		cwrDownPayment = BigDecimal.valueOf(Double.parseDouble("12")).multiply(monthlyBudget)
		//				.add(totalSaArrears).multiply(BigDecimal.valueOf(Double.parseDouble("0.12"))).add(totalDiversion);
		//	}
		//	else if (cwrLevel.equalsIgnoreCase(PERCENT_50)) {
		//		BigDecimal temp1 = totalDiversion.add(BigDecimal.valueOf(Double.parseDouble("500")));
		//		BigDecimal temp2 = (BigDecimal.valueOf(Double.parseDouble("0.50")).multiply(totalSaArrears)).add(totalDiversion);
		//
		//		if(temp1.compareTo(temp2) > 0) {
		//			cwrDownPayment = temp2;
		//		}
		//		else {
		//			cwrDownPayment = temp1;
		//		}
		//	}
		//	else if (cwrLevel.equalsIgnoreCase(PERCENT_80)) {
		//		cwrDownPayment = (BigDecimal.valueOf(Double.parseDouble("0.80")).multiply(totalSaArrears)).add(totalDiversion);
		//	}
		//
		//	return cwrDownPayment;
		//
		//}
		//
		///**
		// * This method will compute for the monthly payment arrangement
		// * @param totalSaArrears BigDecimal
		// * @param totalDiversion BigDecimal
		// * @param downPayment BigDecimal
		// * @param months BigDecimal
		// * @return monthlyPaymentArrangement BigDecimal
		// */
		//private BigDecimal computeMonthlyPaymentArrangement(BigDecimal totalSaArrears, BigDecimal totalDiversion, BigDecimal downPayment, BigDecimal months) {
		//	BigDecimal monthlyPaymentArrangement = (totalSaArrears.add(totalDiversion).add(retrievePaymentArrangemtSaPayoffBalance().getAmount()).subtract(downPayment)).divide(months);
		//
		//	return monthlyPaymentArrangement;
		//}
		//
		//
		///**
		// * This method will retrieve latest completed bill
		// * @return
		// */
		//private Date retrieveLatestCompletedBill() {
		//	Date billDate = null;
		//
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM Bill bill ");
		//	stringBuilder.append(" WHERE bill.account = :account ");
		//	stringBuilder.append(" AND bill.billStatus = :billStatus ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Date> query = createQuery(stringBuilder.toString());
		//	Query<Date> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	query.bindEntity("account", serviceAgreement.getAccount());
		//	query.bindLookup("billStatus", BillStatusLookup.constants.COMPLETE);
		//	query.addResult("billDate", "bill.billDate");
		//	query.orderBy("billDate", Query.DESCENDING);
		//
		//	billDate = query.firstRow();
		//
		//	if (isNull(billDate)) {
		//		billDate = this.getProcessDateTime().getDate();
		//	}
		//
		//	return billDate;
		//}
		//
		///**
		// * This method will retrieve CWR Payment Arrangement SA
		// * @return query Query
		// */
		//private Query<QueryResultRow> retrieveCwrPaymentArrangementSa() {
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM ServiceAgreement sa, FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreementCharacteristic sac1 ");
		//	stringBuilder.append(" WHERE sa.status IN (:pendingStop, :stopped, :closed) ");
		//	stringBuilder.append(" AND fco1.id.workforceManagementSystem = :workforceManagementSystem ");
		//	stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
		//	stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
		//	stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
		//	stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
		//	stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.division) = TRIM (fco1.value) ");
		//	stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.saType) = TRIM (fco2.value) ");
		//	stringBuilder.append(" AND NOT EXISTS (SELECT sac.id.characteristicType ");
		//	stringBuilder.append("                 FROM ServiceAgreementCharacteristic sac ");
		//	stringBuilder.append("                 WHERE sac.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append("                 AND sac.id.characteristicType = :characteristicType ");
		//	stringBuilder.append("                 AND (sac.characteristicValue = :characteristicValue ");
		//	stringBuilder.append("                      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
		//	stringBuilder.append("                      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1))");
		//	stringBuilder.append(" AND sac1.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND sac1.id.characteristicType = :cwrPremiseCharacteristicType ");
		//	stringBuilder.append(" AND (sac1.characteristicValue = :premiseIdCharVal ");
		//	stringBuilder.append("      OR sac1.adhocCharacteristicValue = :premiseIdAdhocCharval ");
		//	stringBuilder.append("      OR sac1.characteristicValueForeignKey1 = :premiseIdCharValFK1)");
		//	stringBuilder.append(" AND sac1.id.effectiveDate = (SELECT MAX(sac2.id.effectiveDate) ");
		//	stringBuilder.append("                                 FROM ServiceAgreementCharacteristic sac2 ");
		//	stringBuilder.append("                                WHERE sac2.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append("                                  AND sac2.id.characteristicType = sac1.id.characteristicType ");
		//	stringBuilder.append("                                  AND sac2.id.effectiveDate <= :effectiveDate) ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
		//	Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//
		//	query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		//	query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		//	query.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
		//	query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
		//	query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
		//	query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());
		//	query.bindEntity("characteristicType", recalculatedCharType);
		//	query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, recalculatedCharValue);
		//	query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, recalculatedCharValue);
		//	query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, recalculatedCharValue);
		//	query.bindEntity("cwrPremiseCharacteristicType", cwrPremiseCharType);
		//	if (notNull(serviceAgreement.getPremiseId())){
		//		charPremiseIdString = serviceAgreement.getPremiseId().getTrimmedValue();
		//	}
		//
		//	query.bindStringProperty("premiseIdCharVal", ServiceAgreementCharacteristic.properties.characteristicValue, charPremiseIdString);
		//	query.bindStringProperty("premiseIdAdhocCharval", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, charPremiseIdString);
		//	query.bindStringProperty("premiseIdCharValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, charPremiseIdString);
		//	query.bindDate("effectiveDate", this.getProcessDateTime().getDate());
		//
		//	query.addResult("startDate", "sa.startDate");
		//	query.addResult("sa", "sa");
		//
		//	query.orderBy("startDate", Query.DESCENDING);
		//
		//	return query;
		//}
		//
		//
		///**
		// * This method will determine if CWR Payment Arrangement SA is broken
		// * @param sa ServiceAgreement
		// * @return isBroken Bool
		// */
		//private Bool isCwrPaymentArrangementSaBroken(ServiceAgreement sa) {
		//	Bool isBroken = Bool.FALSE;
		//
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM ServiceAgreementCharacteristic sac ");
		//	stringBuilder.append(" WHERE sac.id.serviceAgreement = :serviceAgreement ");
		//	stringBuilder.append(" AND sac.id.characteristicType = :characteristicType ");
		//	stringBuilder.append(" AND (sac.characteristicValue = :characteristicValue ");
		//	stringBuilder.append("      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
		//	stringBuilder.append("      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1)");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Date> query = createQuery(stringBuilder.toString());
		//	Query<Date> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//
		//	query.bindEntity("serviceAgreement", sa);
		//	query.bindEntity("characteristicType", brokenCharType);
		//	query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, brokenCharValue);
		//	query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, brokenCharValue);
		//	query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, brokenCharValue);
		//
		//	query.addResult("effectiveDate", "sac.id.effectiveDate");
		//	query.orderBy("effectiveDate", Query.DESCENDING);
		//
		//	if (!query.list().isEmpty()) {
		//		isBroken = Bool.TRUE;
		//	}
		//
		//	return isBroken;
		//}
		//
		///**
		// * This method will retrieve broken CWR Payment Arrangement SA
		// * @return query Query
		// */
		//private Query<QueryResultRow> retrieveBrokenCwrPaymentArrangementSa() {
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM ServiceAgreement sa, FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreementCharacteristic sac1, ServiceAgreementCharacteristic sac2, ServiceAgreementCharacteristic sac3 ");
		//	stringBuilder.append(" WHERE sa.status IN (:pendingStop, :stopped, :closed) ");
		//	stringBuilder.append(" AND fco1.id.workforceManagementSystem = :workforceManagementSystem ");
		//	stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
		//	stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
		//	stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
		//	stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
		//	stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.division) = TRIM (fco1.value) ");
		//	stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.saType) = TRIM (fco2.value) ");
		//	stringBuilder.append(" AND NOT EXISTS (SELECT sac.id.characteristicType ");
		//	stringBuilder.append("                 FROM ServiceAgreementCharacteristic sac ");
		//	stringBuilder.append("                 WHERE sac.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append("                 AND sac.id.characteristicType = :characteristicType ");
		//	stringBuilder.append("                 AND (sac.characteristicValue = :characteristicValue ");
		//	stringBuilder.append("                      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
		//	stringBuilder.append("                      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1))");
		//	stringBuilder.append(" AND sac1.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND sac1.id.characteristicType = :brokenCharacteristicType ");
		//	stringBuilder.append(" AND (sac1.characteristicValue = :brokenCharacteristicValue ");
		//	stringBuilder.append("      OR sac1.adhocCharacteristicValue = :brokenAdhocCharacteristicValue ");
		//	stringBuilder.append("      OR sac1.characteristicValueForeignKey1 = :brokenCharacteristicValueForeignKey1)");
		//	stringBuilder.append(" AND sac2.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND sac2.id.characteristicType = :cwrCharacteristicType ");
		//	stringBuilder.append(" AND (sac2.characteristicValue = :cwrCharacteristicValue ");
		//	stringBuilder.append("      OR sac2.adhocCharacteristicValue = :cwrAdhocCharacteristicValue ");
		//	stringBuilder.append("      OR sac2.characteristicValueForeignKey1 = :cwrCharacteristicValueForeignKey1)");
		//	stringBuilder.append(" AND sac3.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND sac3.id.characteristicType = :cwrPremiseCharacteristicType ");
		//	stringBuilder.append(" AND (sac3.characteristicValue = :premiseIdCharVal ");
		//	stringBuilder.append("      OR sac3.adhocCharacteristicValue = :premiseIdAdhocCharval ");
		//	stringBuilder.append("      OR sac3.characteristicValueForeignKey1 = :premiseIdCharValFK1)");
		//	stringBuilder.append(" AND sac3.id.effectiveDate = (SELECT MAX(sac4.id.effectiveDate) ");
		//	stringBuilder.append("                                 FROM ServiceAgreementCharacteristic sac4 ");
		//	stringBuilder.append("                                WHERE sac4.id.serviceAgreement.id = sa.id ");
		//	stringBuilder.append("                                  AND sac4.id.characteristicType = sac3.id.characteristicType ");
		//	stringBuilder.append("                                  AND sac4.id.effectiveDate <= :effectiveDate) ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
		//	Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//
		//	query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		//	query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		//	query.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
		//
		//	query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
		//	query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
		//	query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());
		//
		//	query.bindEntity("characteristicType", recalculatedCharType);
		//	query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, recalculatedCharValue);
		//	query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, recalculatedCharValue);
		//	query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, recalculatedCharValue);
		//
		//	query.bindEntity("brokenCharacteristicType", brokenCharType);
		//	query.bindStringProperty("brokenCharacteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, brokenCharValue);
		//	query.bindStringProperty("brokenAdhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, brokenCharValue);
		//	query.bindStringProperty("brokenCharacteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, brokenCharValue);
		//
		//	query.bindEntity("cwrCharacteristicType", cwrCharType);
		//	query.bindStringProperty("cwrCharacteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, cwrCharValue);
		//	query.bindStringProperty("cwrAdhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, cwrCharValue);
		//	query.bindStringProperty("cwrCharacteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, cwrCharValue);
		//	query.bindEntity("cwrPremiseCharacteristicType", cwrPremiseCharType);
		//
		//	if (notNull(serviceAgreement.getPremiseId())){
		//		charPremiseIdString = serviceAgreement.getPremiseId().getTrimmedValue();
		//	}
		//
		//	query.bindStringProperty("premiseIdCharVal", ServiceAgreementCharacteristic.properties.characteristicValue, charPremiseIdString);
		//	query.bindStringProperty("premiseIdAdhocCharval", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, charPremiseIdString);
		//	query.bindStringProperty("premiseIdCharValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, charPremiseIdString);
		//	query.bindDate("effectiveDate", this.getProcessDateTime().getDate());
		//
		//
		//	query.addResult("startDate", "sa.startDate");
		//	query.addResult("sa", "sa");
		//
		//	query.orderBy("startDate", Query.DESCENDING);
		//
		//	return query;
		//}
		//
		///**
		// * This method will retrieve account main person
		// * @param account Account
		// * @return Person
		// */
		//private Person retrieveAccountMainPerson(Account account) {
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM AccountPerson ap ");
		//	stringBuilder.append(" WHERE ap.id.account = :account ");
		//	stringBuilder.append(" AND ap.isMainCustomer = :isMainCustomer ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
		//	Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	query.bindEntity("account", account);
		//	query.bindBoolean("isMainCustomer", Bool.TRUE);
		//	query.addResult("person", "ap.id.person");
		//
		//	return (Person) query.firstRow();   
		//}
		//
		//
		//private BigDecimal retrieveRecurringChargeAmount()  {
		//
		//	BigDecimal recurChargeAmount = BigDecimal.ZERO;
		//
		//	Bool saTypeBudgetEligible = serviceAgreement.getServiceAgreementType().getIsEligibleForBudget();
		//	if (saTypeBudgetEligible.isTrue()) {
		//		//Retrieve Recurring Charge
		//		ListFilter<ServiceAgreementRecurringCharge> recurringChargesFilter = null;
		//		ServiceAgreementRecurringCharge recurringCharge = null;
		//
		//		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//		//recurringChargesFilter = serviceAgreement.getRecurringCharges().createFilter("WHERE this.id.effectiveDate <= :processDate ORDER BY this.id.effectiveDate DESC ");
		//		recurringChargesFilter = serviceAgreement.getRecurringCharges().
		//				createFilter("WHERE this.id.effectiveDate <= :processDate ORDER BY this.id.effectiveDate DESC ", getClass().getName());
		//		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//		recurringChargesFilter.bindDate("processDate", this.getProcessDateTime().getDate());
		//
		//		if(recurringChargesFilter.listSize() > 0) {
		//			recurringCharge = recurringChargesFilter.firstRow();
		//			recurChargeAmount = recurringCharge.getRecurringChargeAmount().getAmount();
		//		}
		//		else {
		//			recurChargeAmount = retrievePremiseAverageCharacteristic();
		//		}
		//	}
		//	else {
		//		recurChargeAmount = retrievePremiseAverageCharacteristic();
		//	}
		//
		//	return roundUp(recurChargeAmount);
		//}
		//
		///**
		// * This method will retrieve the sum of payoff balance of any Payment Arrangement SAs associated with the Service Agreement
		// * @return Money
		// */
		//private Money retrievePaymentArrangemtSaPayoffBalance() {
		//	StringBuilder stringBuilder = new StringBuilder();
		//	stringBuilder.append(" FROM FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreement sa, Adjustment a, FinancialTransaction ft ");
		//	stringBuilder.append(" WHERE fco1.id.workforceManagementSystem = :workforceManagementSystem ");
		//	stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
		//	stringBuilder.append(" AND fco2.id.workforceManagementSystem = fco1.id.workforceManagementSystem ");
		//	stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
		//	stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
		//	stringBuilder.append(" AND TRIM (fco1.value) = TRIM (sa.serviceAgreementType.id.division) ");
		//	stringBuilder.append(" AND TRIM (fco2.value) = TRIM (sa.serviceAgreementType.id.saType) ");
		//	stringBuilder.append(" AND sa.id = a.serviceAgreement.id ");
		//	stringBuilder.append(" AND a.adjustmentType = :adjustmentType ");
		//	stringBuilder.append(" AND a.transferAdjustmentId IN (SELECT adj.id ");
		//	stringBuilder.append("                               FROM Adjustment adj ");
		//	stringBuilder.append("                               WHERE adj.adjustmentType = a.adjustmentType ");
		//	stringBuilder.append("                               AND adj.adjustmentStatus = :frozen ");
		//	stringBuilder.append("                               AND adj.serviceAgreement = :serviceAgreement) ");
		//	stringBuilder.append(" AND ft.serviceAgreement.id = sa.id ");
		//	stringBuilder.append(" AND ft.shouldShowOnBill = :shouldShowOnBill ");
		//	stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
		//	stringBuilder.append(" AND ft.isFrozen = :isFrozen ");
		//
		//	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	//Query<Money> query = createQuery(stringBuilder.toString());
		//	Query<Money> query = createQuery(stringBuilder.toString(), getClass().getName());
		//	//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//	
		//	query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
		//	query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
		//	query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
		//			CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());
		//
		//	query.bindEntity("adjustmentType", transferAdjustmentType);
		//	query.bindEntity("serviceAgreement", serviceAgreement);
		//	query.bindBoolean("shouldShowOnBill", Bool.TRUE);
		//	query.bindBoolean("isRedundant", Bool.FALSE);
		//	query.bindBoolean("isFrozen", Bool.TRUE);
		//	query.bindLookup("frozen", AdjustmentStatusLookup.constants.FROZEN);
		//
		//	query.addResult("currentAmount", "SUM(ft.payoffAmount)");
		//
		//	return query.firstRow();
		//
		//}
		//
		//
		//private BigDecimal retrievePremiseAverageCharacteristic()  {
		//
		//	BigDecimal premCharAmount = BigDecimal.ZERO;
		//
		//	Premise_Id saCharPremId = serviceAgreement.getPremiseId();
		//	Premise premise = null;
		//	CharacteristicType charType = averageBillAmountCharType;
		//	String charVal = "";
		//
		//	if (notNull(saCharPremId)){
		//		premise = saCharPremId.getEntity();
		//	}
		//
		//	if (notNull(premise)){
		//		PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);
		//
		//		if (notNull(premChar)){                     
		//			if (charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
		//				charVal = premChar.getAdhocCharacteristicValue().trim();
		//			}
		//			if (charType.getCharacteristicType().isForeignKeyValue()) {
		//				charVal = premChar.getCharacteristicValueForeignKey1().trim();           
		//			}
		//			if (charType.getCharacteristicType().isPredefinedValue()) {
		//				charVal = premChar.getCharacteristicValue().trim(); 
		//			}
		//
		//			try {
		//				BigDecimal monthlyBudgetAmount = BigDecimal.valueOf(Double.parseDouble(charVal));
		//				premCharAmount = monthlyBudgetAmount;
		//			}
		//			catch (Exception e) {
		//			}
		//		}
		//	}
		//
		//	return premCharAmount;
		//}
		//
		//
		//private BigDecimal roundUp(BigDecimal amount) {
		//
		//	BigDecimal roundUpValue = BigDecimal.valueOf(roundUpUnit);
		//	int roundInt = amount.divide(roundUpValue).intValue();
		//
		//	int roundAmount = roundInt * roundUpUnit;
		//
		//	if (amount.compareTo(BigDecimal.valueOf(roundAmount)) != 0) {
		//		roundAmount = roundUpUnit + roundAmount;
		//	}
		//
		//	return BigDecimal.valueOf(roundAmount);
		//}  
		/*
         * Defect 3948617 - 2017-12-13 - End Delete
         */
		/**
		 * Retrieves CWR Level of Previous Quote query
		 * @return query
		 */
		private Query<QueryResultRow> cmRetrieveCwrLevelOfPreviousQuote() {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
			stringBuilder.append(" WHERE SVCTASK.serviceTaskType = :serviceTaskType ");
			stringBuilder.append(" 	AND SVCTASK.businessObject = :businessObject ");
			stringBuilder.append(" 	AND SVCTASK.status = :activeBusinessObjectStatus ");
			stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");
			stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :cwrLevelCharacteristicType ");
		
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<QueryResultRow> query = createQuery(stringBuilder.toString());
			Query<QueryResultRow> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			
			query.bindEntity("serviceTaskType", parmQuoteServiceTaskType);
			query.bindEntity("businessObject", parmQuoteBo);
			query.bindStringProperty("activeBusinessObjectStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
			query.bindEntity("cwrLevelCharacteristicType", parmCwrLevelCharType);
		
			query.addResult("serviceTaskAdhocCharValue", "SVCTASKCHAR.adhocCharacteristicValue");
			query.addResult("serviceTaskForeignKeyCharValue", "SVCTASKCHAR.characteristicValueForeignKey1");
			query.addResult("serviceTaskPreDefinedCharValue", "SVCTASKCHAR.characteristicValue");
			query.addResult("creationDateTime", "SVCTASK.creationDateTime");
			query.orderBy("creationDateTime", Query.DESCENDING);
		
			return query;
		}
		
		/**
		 * Adds Service Task Characteristic
		 * @param serviceTask Service Task
		 * @param charType Characteristic Type
		 * @param charValue Characteristic Value
		 */
		private void cmUpdateServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType,
				String charValue) {
		
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//ListFilter<ServiceTaskCharacteristic> filter = serviceTask.getCharacteristics().createFilter("WHERE this.id.characteristicType = :characteristicType");
			ListFilter<ServiceTaskCharacteristic> filter = serviceTask.getCharacteristics().
					createFilter("WHERE this.id.characteristicType = :characteristicType", getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			filter.bindEntity("characteristicType", charType);
		
			ServiceTaskCharacteristic serviceTaskChar = (ServiceTaskCharacteristic) filter.firstRow();
			ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = serviceTaskChar.getDTO();
		
			if (notNull(serviceTaskChar)) {
		
				if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
					serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
				} 
				else if (charTypeLookup.isPredefinedValue()) {
					serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
				}
				else if (charTypeLookup.isForeignKeyValue()) {
					serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
				}
				serviceTaskChar.setDTO(serviceTaskCharacteristicDto);
			}
		}
		
		
		/**
		 * RetrievesMaximum Sequence Number query
		 * @return query
		 */
		private Query<BigInteger> cmRetrieveMaximumSequenceNumber(ServiceTask serviceTask) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append(" FROM ServiceTaskCharacteristic SVCTASKCHAR ");
			stringBuilder.append(" WHERE SVCTASKCHAR.id.serviceTask.id = :serviceTaskId ");
			stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :webTransactionIdCharacteristicType ");
		
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//Query<BigInteger> query = createQuery(stringBuilder.toString());
			Query<BigInteger> query = createQuery(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			
			query.bindId("serviceTaskId", serviceTask.getId());
			query.bindEntity("webTransactionIdCharacteristicType", parmWebTransactionIdCharType);
		
			query.addResult("sequenceNumber", "MAX(SVCTASKCHAR.id.sequence)");
		
			return query;
		}
	}

}
