/**************************************************************************
* Program Name: CmUpdateDepositAlgComp_Impl
* Program Title: CmUpdateDepositAlgComp_Impl
* Author: Alfonso Castano
* Creation Date: 2017-10-11
* Purpose: This algorithm will check if a deposit exists for the same
* account, same premise as the newly created SA. If so, it will update the
* requested deposit amount or stop the deposit.
*  
* Functional Spec: CCB-CC-002A
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-002A       Alfonso Castano  2017-10-11    Initial Version            
 *  Defect 38920066   Alfonso Castano  2017-10-20	 Updated to adjust deposit current balance
 *  												 to $0 and make sure requested deposit amount
 *  												 is positive.                                
 *  Defect 4146452    El Quinto        2018-11-08    Use the correct method for getting SA ID when
 *                                                   creating prepared statement
 *  Defect 4157313 	  Kiran			   2018-11-12	 remove date condition because SA can have future date 
 *                                                   CCB v2.6 Upgrade 12/14/2018
 * Defect 4253862/    EQuint           2019-05-22    set prepared statement auto close
 * ID56 (Reopen)   	 
 ************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saCreation;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.api.lookup.StopReasonLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author ACasta
 *
@AlgorithmComponent ()
 */
public class CmUpdateDepositAlgComp_Impl extends CmUpdateDepositAlgComp_Gen
        implements SaTypeSaCreationAlgorithmSpot {

    // Hard Parameter
    private ServiceAgreement serviceAgreement;
    
    // Work variables
    private Premise premCharPremise;
    private Account account;
    private ServiceAgreement gasSa;
    private List<ServiceAgreement> serviceAgreements;
    
    /*
     * Defect 3892066 - 2017-10-20 - Start Add
     */
    // Constants
    private static final String QUOTE_PORTAL_FEAT_CONFIG = "CM-QPPARM";
    /*
     * Defect 3892066 - 2017-10-20 - End Add
     */
    
    @Override
    public void invoke() {
        account = serviceAgreement.getAccount();
        
        // Retrieve recent Active Gas SA
        gasSa = retGasSA(account.getId());
        if (isNull(gasSa)){
        	return;
        }
        
        premCharPremise = gasSa.fetchPremise();
        if (isNull(premCharPremise)){
            return;
        }
        
        // Determine if there is an active or pending start deposit SA
        serviceAgreements = retrieveDepositSA(account.getId(), premCharPremise.getId());
        ListIterator<ServiceAgreement> iter = serviceAgreements.listIterator();
        while (iter.hasNext()){
            ServiceAgreement sa = iter.next();
            /*
             * Defect 3892066 - 2017-10-20 - Start Change
             */
            //if (sa.getStatus().isPendingStart()){
            //	if (sa.getPayoffBalance().getAmount().compareTo(BigDecimal.ZERO) == 0) {
            //		sa.cancel(Bool.FALSE);
            //	}
            //}
            //else if (sa.getStatus().isActive()){
            //	if (sa.getPayoffBalance().getAmount().compareTo(BigDecimal.ZERO) == 0){
            //    	sa.initiateStop(getProcessDateTime().getDate(), premCharPremise.getId(), getActiveContextUser().getId().getTrimmedValue(), 
            //                StopReasonLookup.constants.SYSTEM_GENERATED, Bool.TRUE, Bool.FALSE);
            //    } else {
            //    	ServiceAgreement_DTO saDTO = sa.getDTO();
            //        saDTO.setTotalAmountToBill(sa.getPayoffBalance());
            //        sa.setDTO(saDTO);
            //        saveChanges();
            //    }
            //}
            
            //else if (sa.getStatus().isPendingStop()){
		    //    ServiceAgreement_DTO saDTO = sa.getDTO();
		    //    saDTO.setTotalAmountToBill(sa.getPayoffBalance());
		    //    sa.setDTO(saDTO);
		    //    saveChanges();
        	//}
            Money payoffBalance;
            BigDecimal posVal;
            if (sa.getStatus().isPendingStop()){
            	ServiceAgreement_DTO saDTO = sa.getDTO();
            	posVal = sa.getPayoffBalance().getAmount().abs();
            	payoffBalance = new Money(posVal, sa.getCurrencyId());
                saDTO.setTotalAmountToBill(payoffBalance);
                sa.setDTO(saDTO);
                saveChanges();
            }
            
            if (sa.getPayoffBalance().getAmount().compareTo(BigDecimal.ZERO) == 0){
            	if (sa.getStatus().isPendingStart()){
            		sa.cancel(Bool.FALSE);
            	} else if (sa.getStatus().isActive()){
            		sa.initiateStop(getProcessDateTime().getDate(), premCharPremise.getId(), getActiveContextUser().getId().getTrimmedValue(), 
                            StopReasonLookup.constants.SYSTEM_GENERATED, Bool.TRUE, Bool.FALSE);
            		if (!sa.getCurrentBalance().isZero()){
            			createAdjustment(sa);
            		}
            	}
            } else {
            	if (sa.getStatus().isActive()){
	            	ServiceAgreement_DTO saDTO = sa.getDTO();
	            	posVal = sa.getPayoffBalance().getAmount().abs();
	            	payoffBalance = new Money(posVal, sa.getCurrencyId());
	                saDTO.setTotalAmountToBill(payoffBalance);
	                sa.setDTO(saDTO);
	                saveChanges();
            		if (!sa.getCurrentBalance().isZero()){
            			createAdjustment(sa);
            		}
            	}
            }
        	/*
             * Defect 3892066 - 2017-10-20 - End Change
             */            	
        }
    }

    /*
     * Defect 3892066 - 2017-10-20 - Start Add
     */
    /**
     * This method will create adjustment for the Deposit SA
     */
    private void createAdjustment(ServiceAgreement depositSA){
    	CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
    	
    	adjustmentData.setServiceAgreement(depositSA);
    	Money adjAmt = depositSA.getCurrentBalance().negate();
    	adjustmentData.setAdjustmentAmount(adjAmt);
    	adjustmentData.setAdjustmentType(retrieveAdjustmentType());
    	adjustmentData.setAllowZeroAmount(Bool.FALSE);
    	
    	CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
    	createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
    }
    
    private AdjustmentType retrieveAdjustmentType(){
    	AdjustmentType adjType;
    	
    	FeatureConfiguration featConfig = new FeatureConfiguration_Id(QUOTE_PORTAL_FEAT_CONFIG).getEntity();
    	CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
    	featConfigRetriever.setParmWFMName(featConfig);
    	
    	LookupValue optionType = CmQuotePortalParametersLookup.constants.ZERO_CURRENT_AMOUNT_ADJUSTMENT_TYPE.getLookupValue();
    	featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
    	adjType = new AdjustmentType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
    	
    	if (isNull(adjType)){
    		addError(CustomMessageRepository.CC_002_2_invalidAdjType(adjType.getId().getTrimmedValue()));
    	}
    	return adjType;
    }
    /*
     * Defect 3892066 - 2017-10-20 - End Add
     */
    
    /**
     * This method will retrieve the return active gas SA for the PA SA Account. 
     * @param accountId
     * @return sa
     */
    private ServiceAgreement retGasSA(Account_Id accountId){
    	ServiceAgreement_Id returnSA = null;
    	
    	StringBuilder strQuery = new StringBuilder();
    	strQuery.append("SELECT SA.SA_ID ");
    	strQuery.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
    	strQuery.append("WHERE SA.ACCT_ID = :acctId ");
//    	strQuery.append("AND SA.START_DT <= :processDate "); // // Defect	4157313  comment out 
    	strQuery.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
    	strQuery.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
    	strQuery.append("AND SAT.SVC_TYPE_CD = 'G' ");
    	// Defect	4157313 - Start Change
    	//strQuery.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active) ");
    	strQuery.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active , :stopped) ");
    	// Defect	4157313 - End Change
    	strQuery.append("ORDER BY SA.START_DT DESC ");
    	
    	PreparedStatement prepQuery = createPreparedStatement(strQuery.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        prepQuery.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
    	
    	prepQuery.bindId("acctId", accountId);
    	// Defect 4157313 - Start Delete
    	//prepQuery.bindDate("processDate", getProcessDateTime().getDate());
    	// Defect 4157313 - End Delete
    	prepQuery.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
    	prepQuery.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
    	//09-13-2018 temp change add stopped SA status - Start Add
    	prepQuery.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
    	// 09-13-2018 temp change add stopped SA status - End Add
    	prepQuery.execute();
    	
    	SQLResultRow row = prepQuery.firstRow();
    	
    	if (notNull(row)){
    		// Start Change - Defect 4146452 - 2018-11-08
    		// returnSA = row.getEntity("SA_ID", ServiceAgreement.class).getId();
    		returnSA = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
    		// End Change - Defect 4146452 - 2018-11-08
    	}
    	prepQuery.close();
    	
    	// Start Change - Defect 4146452 - 2018-11-08
    	// return returnSA.getEntity();
    	return (notNull(returnSA)) ? returnSA.getEntity() : null;
    	// End Change - Defect 4146452 - 2018-11-08
    }

    /**
     * This method will retrieve active or pending start deposit SA
     * @param accountId
     * @param premiseId
     */
    private List<ServiceAgreement> retrieveDepositSA(Account_Id accountId, Premise_Id premiseId){
        ArrayList<ServiceAgreement> returnSAs = new ArrayList<ServiceAgreement>();
        StringBuilder queryStr = new StringBuilder();
        queryStr.append("SELECT SA.SA_ID");
        queryStr.append(" FROM CI_SA SA, CI_SA_TYPE SAT");
        queryStr.append(" WHERE ACCT_ID = :acctId");
        queryStr.append(" AND SA.CHAR_PREM_ID = :premiseId");
        // Defect 4157313 - Start Change
        //queryStr.append(" AND SA.SA_STATUS_FLG IN (:activeStatus,:pendingStartStatus,:pendingStopStatus)");
        queryStr.append(" AND SA.SA_STATUS_FLG IN (:activeStatus,:pendingStartStatus)");
        // Defect 4157313 - End Change
        queryStr.append(" AND SAT.CIS_DIVISION = SA.CIS_DIVISION");
        queryStr.append(" AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD");
        queryStr.append(" AND SAT.SPECIAL_ROLE_FLG = :cashDepositFlag");
        
        PreparedStatement getSAs = createPreparedStatement(queryStr.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getSAs.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getSAs.bindId("acctId", accountId);
        getSAs.bindId("premiseId", premiseId);
        getSAs.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        getSAs.bindLookup("pendingStartStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        // Defect 4157313 - Start Delete
        //getSAs.bindLookup("pendingStopStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        // Defect 4157313 - End Delete
        getSAs.bindLookup("cashDepositFlag", SpecialRoleLookup.constants.CASH_DEPOSIT);
        getSAs.execute();
        
        List<SQLResultRow> resultList = getSAs.list();
        for (SQLResultRow result: resultList){
            ServiceAgreement_Id saId = (ServiceAgreement_Id) result.getId("SA_ID", ServiceAgreement.class);
            returnSAs.add(saId.getEntity());
        }
        getSAs.close();
        
        return returnSAs;
    }
    
    @Override
    public void setServiceAgreement(ServiceAgreement arg0) {
        this.serviceAgreement = arg0;
    }

}
