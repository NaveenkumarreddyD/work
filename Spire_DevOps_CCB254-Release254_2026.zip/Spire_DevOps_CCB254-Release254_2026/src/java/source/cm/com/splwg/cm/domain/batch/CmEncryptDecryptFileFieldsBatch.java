/******************************************************************************************
 * Program Name: CmEncryptDecryptFileFieldsBatch
 * Program Title: CmEncryptDecryptFileFieldsBatch
 * Author: Ravi
 * Creation Date: 2020-09-18
 * Purpose: 
 * This batch will encrypt and Decrypt the fields of a extract 
 * file using the record layout configured in the 
 * Master Configuration :Cm-DecryptFileLayoutMastConfig.
 * 
 ******************************************************************************************
/*--------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: -------------------------
 * -------------------------------------------------------------------------
 *  Modification ID:   CCTicket:	    Author:        Date:          Description:
.* ---------------------------------------------------------------------------------------
 *  CCB017				46343   	    Ravi   		  2020-09-18     Initial Version         
 *  CCB017             	46343   	    Ravi   		  2020-10-30     Added logic to capture 
 *  																 Prefix for delimited files                           
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.cm.api.lookup.CmFileFormatFlagLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.Cryptography;

/**
 * @author TMG02518
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (entityName = batchControl, name = BATCH_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = INPUT_FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = INPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_PATH, required = false, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_NAME, required = false, type = string)
 *            , @BatchJobSoftParameter (name = ENCRYPT_DECRYPT, required = false, type = boolean)})
 */
public class CmEncryptDecryptFileFieldsBatch extends
CmEncryptDecryptFileFieldsBatch_Gen {

	public void validateSoftParameters(boolean isNewRun){
		String strInputFilePath = getParameters().getINPUT_FILE_PATH();
		String strOutputFilePath = getParameters().getOUTPUT_FILE_PATH();
		String strInputFileName = getParameters().getINPUT_FILE_NAME();
		String strOutputFileName = getParameters().getOUTPUT_FILE_NAME();

		// Validate if the file path is valid
		File inputFolder = new File(strInputFilePath);
		if(!(inputFolder.exists() && inputFolder.isDirectory())) {
			addError(CustomMessageRepositorySpireOne.ccb017InvalidFilePath(strInputFilePath));
		}

		// Validate if input File name is Valid
		File inputFile = new File(inputFolder, strInputFileName);
		if(!(inputFile.exists() && inputFile.isFile())){
			addError(CustomMessageRepositorySpireOne.ccb017InvalidFileName(strInputFilePath,strInputFileName));
		}

		//Either Output Path or Output File Name Must Be Provided
		if(isBlankOrNull(strOutputFilePath) && isBlankOrNull(strOutputFileName)){
			addError(CustomMessageRepositorySpireOne.ccb017EitherOutputPathOrOutputFileIsRequired());
		}

		// Validate if the output file path is valid
		if(!isBlankOrNull(strOutputFilePath)){
			File outputFolder = new File(strOutputFilePath);
			if(!(outputFolder.exists() && outputFolder.isDirectory())) {
				addError(CustomMessageRepositorySpireOne.ccb017InvalidFilePath(strOutputFilePath));
			}
		}else{
			strOutputFilePath = strInputFilePath;
		}

		if(isBlankOrNull(strOutputFileName)){
			strOutputFileName = strInputFileName;
		}

		if((strOutputFilePath.equalsIgnoreCase(strInputFilePath)) && (strOutputFileName.equalsIgnoreCase(strInputFileName))){
			addError(CustomMessageRepositorySpireOne.ccb017OutputFileAndInputFileCannotBeSame());
		}

		BigInteger maxErrors = getParameters().getSoftMaxErrors();
		if(notNull(maxErrors))
		{
			if(maxErrors.intValue()<0)
			{
				addError(CustomMessageRepositorySpireOne.ccb017MaxErrorInv());
			}
		}	
	}

	public JobWork getJobWork() {
		List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
		threadWorkUnitList.add(new ThreadWorkUnit());
		return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
	}

	public Class<CmEncryptDecryptFileFieldsBatchWorker> getThreadWorkerClass() {
		return CmEncryptDecryptFileFieldsBatchWorker.class;
	}

	public static class CmEncryptDecryptFileFieldsBatchWorker extends
	CmEncryptDecryptFileFieldsBatchWorker_Gen {

		private boolean isSuccessful = true;
		private Bool isEncrypt = Bool.TRUE;

		private String parmInputFilePath = "";
		private String parmOutputFilePath = "";
		private String parmInputFileName = "";
		private String parmOutputFileName = "";
		private BufferedReader bufferedReader = null;
		private BufferedWriter bufferedWriter = null;

		//Node variables
		private COTSInstanceNode batchControlInfoNode = null;
		private COTSInstanceNode fileInfoNode = null;
		private Boolean isBatchDetailsConfigured = false;

		//Working Variables
		private CmFileFormatFlagLookup fileFormatLkp = null;
		private Bool hasHeader = Bool.FALSE;
		private String delimeterValue = "";
		private int numberofRecordsProcessed = 0;

		private ArrayList<COTSInstanceNode> fixedLengthDetNodesList = new ArrayList<>(); 
		private ArrayList<String> delimitedPrefixesList = new ArrayList<>();
		private ArrayList<Integer> fixedLengthStartNodeList = new ArrayList<>();
		private ArrayList<Integer> delimitedPositionsList = new ArrayList<>(); 
		private ArrayList<String> xpathNodeList = new ArrayList<>();
		private ArrayList<String> fieldDescriptionList = new ArrayList<>();

		private ArrayList<Integer> fieldSuccessCountList = new ArrayList<>(); 
		private ArrayList<Integer> fieldsMissedCountList = new ArrayList<>();

		private ArrayList<String> outputList = new ArrayList<>();
		private List<String> subStringsList = new ArrayList<>();
		private Bool isCorrupt = Bool.FALSE;

		//Constants
		private static final String ENC_DEC_MAST_CONFIG="CM-IoFileEncryptionMasterConf";
		private static final String MASTER_CONFIG_GROUP_NAME="details";
		private static final String RECORD_DETAILS_GROUP_NAME="batchControlList";
		private static final String BATCHES_LIST_NAME="batchControl";
		private static final String WILD_CARD="*";

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {
			if(notNull(getParameters().getENCRYPT_DECRYPT())){
				isEncrypt = getParameters().getENCRYPT_DECRYPT();
			}
			parmInputFilePath = getParameters().getINPUT_FILE_PATH();
			parmInputFileName = getParameters().getINPUT_FILE_NAME();
			parmOutputFilePath = getParameters().getOUTPUT_FILE_PATH();
			if(isBlankOrNull(parmOutputFilePath)){
				parmOutputFilePath = parmInputFilePath;
			}
			parmOutputFileName = getParameters().getOUTPUT_FILE_NAME();
			if(isBlankOrNull(parmOutputFileName)){
				parmOutputFileName = parmInputFileName;
			}

		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			//If the File needs to be Encrypted
			if(isEncrypt.isTrue()){
				encryptFile();
			}else{
				//If the File Needs to be decrypted
				decryptFile();
			}

			//Set the number of records Processed
			WorkUnitResult result = new WorkUnitResult(isSuccessful);
			result.setUnitsProcessed(numberofRecordsProcessed);

			return result;
		}

		private void encryptFile(){
			//Get the Master Configuration Values
			getMasterConfigurationDetails();

			// If the File Name provided in the batch and the Master configuration does not match, do not proceed
			if(notNull(fileFormatLkp)){
				if(fileFormatLkp.isCmXmlDocument()){
					//If the File is a XMl file 
					readXMLFile();
				}else if(fileFormatLkp.isCmDelimitedValues()){
					//Read and Encrypt the delimited File
					readDelimitiedRecord();
				}else if (fileFormatLkp.isCmFixedLength()){
					//Read and Encrypt the Fixed Length File
					readFixedLength();
				}
			}

		}

		private void readFixedLength(){
			openFileForRead();
			int i=0;

			ArrayList<Integer> fixedLengthSortedStartNodeList = new ArrayList<>();
			fixedLengthSortedStartNodeList.addAll(fixedLengthStartNodeList);
			Collections.sort(fixedLengthSortedStartNodeList);

			for (int index=0; index<fixedLengthSortedStartNodeList.size() ;index++){
				fieldsMissedCountList.add(0);
				fieldSuccessCountList.add(0);
			}

			try{
				while(bufferedReader.ready()) {
					String record = bufferedReader.readLine();
					String temp = record;
					if(!(i==0 && hasHeader.isTrue())){
						int j = 0;
						int startingPos;
						int endingPos;
						String linePrefix;
						String stringToBeEncrypted = "";
						String preString = "";
						String postString = "";
						//Traverse the list in the reverse order
						for (j = fixedLengthSortedStartNodeList.size()-1; j > -1 ; j--){
							int actualIndex = fixedLengthStartNodeList.indexOf(fixedLengthSortedStartNodeList.get(j));
							COTSInstanceNode fixedLengthNode = fixedLengthDetNodesList.get(actualIndex);
							linePrefix = fixedLengthNode.getXMLString("linePrefixForFixedLength");
							if(isBlankOrNull(linePrefix) ||
									(!isBlankOrNull(linePrefix) && record.substring(0, linePrefix.length()).equalsIgnoreCase(linePrefix))){
								startingPos = fixedLengthNode.getNumber("startCharacterForFixedLength").intValue()-1;
								endingPos = fixedLengthNode.getNumber("endCharacterForFixedLength").intValue()-1;	
								if(record.length() >= endingPos){
									stringToBeEncrypted = temp.substring(startingPos, endingPos);
									preString = temp.substring(0,startingPos);
									postString=temp.substring(endingPos);
									if(stringToBeEncrypted.length() > 0){
										stringToBeEncrypted = Cryptography.encryptAndWrap(stringToBeEncrypted);
									}
									temp = preString.concat(stringToBeEncrypted).concat(postString);
									int tempCount = fieldSuccessCountList.get(actualIndex)+1;
									fieldSuccessCountList.set(actualIndex, tempCount);
								}else{
									int tempCount = fieldsMissedCountList.get(actualIndex)+1;
									fieldsMissedCountList.set(actualIndex, tempCount);
								}
							}
						}
					}
					if(!temp.equalsIgnoreCase(record)){
						numberofRecordsProcessed =numberofRecordsProcessed+1;
					}
					outputList.add(temp);
					i=i+1;
				}
				writeIntoFile();
				for(int index = 0; index<fieldDescriptionList.size(); index++){
					if(fieldsMissedCountList.get(index) !=0 && fieldSuccessCountList.get(index) == 0){
						addWarning(CustomMessageRepositorySpireOne.ccb017NoMatchingFieldsException(parmInputFileName, fieldDescriptionList.get(index)));
					}
				}
			}catch (IOException e){
				e.printStackTrace();
				addError(CustomMessageRepositorySpireOne.ccb017ErrorDuringDecryption(e.getMessage()));
			}
		}

		private void readDelimitiedRecord(){
			openFileForRead();
			int i=0;

			for (int index=0; index<delimitedPositionsList.size() ;index++){
				fieldsMissedCountList.add(0);
				fieldSuccessCountList.add(0);
			}

			try{
				while(bufferedReader.ready()) {
					String record = bufferedReader.readLine();
					String temp = "";
					if(i==0 && hasHeader.isTrue()){
						outputList.add(record);
					}else{
						int j = 0;
						String stringToBeEncrypted = "";
						String[] subStrings = record.split(delimeterValue);

						//Cleaning the subStrings to ensure the correct record is picked
						subStringsList = new ArrayList<>();
						int counter = 0;
						isCorrupt=Bool.FALSE;
						stringSearch(counter, subStrings);

						if(isCorrupt.isFalse()){
							//Traverse the list in the reverse order
							if(!subStringsList.isEmpty()){
								for (j = delimitedPositionsList.size()-1; j > -1 ; j--){
									int fieldPosition = delimitedPositionsList.get(j)-1;
									String prefix = delimitedPrefixesList.get(j);
									//2020-10-30 - Ravi - Start Changes - Logic to check Prefix for delimited records
									if(isBlankOrNull(prefix) || (!isBlankOrNull(prefix) && prefix.equalsIgnoreCase(subStringsList.get(0)))){
										if(!subStringsList.isEmpty() && subStringsList.size() > fieldPosition){
											stringToBeEncrypted = subStringsList.get(fieldPosition);
											stringToBeEncrypted = Cryptography.encryptAndWrap(stringToBeEncrypted);
											subStringsList.set(fieldPosition,stringToBeEncrypted);
											int tempCount = fieldSuccessCountList.get(j)+1;
											fieldSuccessCountList.set(j, tempCount);
										}else{
											int tempCount = fieldsMissedCountList.get(j)+1;
											fieldsMissedCountList.set(j, tempCount);
										}
									}
									//2020-10-30 - Ravi - End Changes - Logic to check Prefix for delimited records
								}
							}else{
								for (j = delimitedPositionsList.size()-1; j > -1 ; j--){
									int tempCount = fieldsMissedCountList.get(j)+1;
									fieldsMissedCountList.set(j, tempCount);
								}
							}

							if(!subStringsList.isEmpty()){
								temp=subStringsList.get(0);
								for(j=1;j<subStringsList.size();j++){
									temp=temp.concat(delimeterValue).concat(subStringsList.get(j));
								}
							}
							if(!temp.equalsIgnoreCase(record)){
								numberofRecordsProcessed = numberofRecordsProcessed+1;
							}
							outputList.add(temp);
						}else{
							outputList.add(record);
							int lineNumber = i+1;
							logError(CustomMessageRepositorySpireOne.ccb017ErrorDuringDecryption("Line Number:"+lineNumber+"is Corrupt, Please correct it Manually"));
						}
					}
					i=i+1;
				}
			}catch (IOException e){
				e.printStackTrace();
				addError(CustomMessageRepositorySpireOne.ccb017ErrorDuringDecryption(e.getMessage()));
			}
			writeIntoFile();
			for(int index = 0; index<fieldDescriptionList.size(); index++){
				if(fieldsMissedCountList.get(index) !=0 && fieldSuccessCountList.get(index) == 0){
					addWarning(CustomMessageRepositorySpireOne.ccb017NoMatchingFieldsException(parmInputFileName, fieldDescriptionList.get(index)));
				}
			}
		}

		private void stringSearch(int counter, String[] subStrings){
			if(counter < subStrings.length){
				String string = subStrings[counter];
				if((string.startsWith("\"") && string.endsWith("\"")) || (!string.startsWith("\"") && !string.endsWith("\""))){
					subStringsList.add(string);	
					counter++;
					stringSearch(counter, subStrings);
				}else{
					if(string.startsWith("\"")){
						for(int i=counter+1;i<subStrings.length;i++){
							string=string.concat(delimeterValue).concat(subStrings[i]);
							counter=i+1;
							isCorrupt=Bool.TRUE;
							if(subStrings[i].startsWith("\"")){
								isCorrupt=Bool.TRUE;
								return;
							}

							if(string.endsWith("\"")){
								subStringsList.add(string);
								isCorrupt=Bool.FALSE;
								break;
							}
						}
					} else{
						if(string.endsWith("\"")){
							isCorrupt=Bool.TRUE;
							return;
						}
					}
					stringSearch(counter, subStrings);
				}
			}

		}


		/**
		 * Read the XML file and then rewrite the file after encrypting all fields
		 */
		private void readXMLFile(){
			File fileForRead = new File(parmInputFilePath, parmInputFileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); 
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, ""); 
			DocumentBuilder dBuilder;
			try {
				dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fileForRead);
				doc.getDocumentElement().normalize();

				int i=0;
				for(String path : xpathNodeList){
					evaluateXPath(doc, path,i);
					i=i+1;
				}

				//write the updated document to file or console
				doc.getDocumentElement().normalize();
				TransformerFactory transformerFactory = TransformerFactory.newInstance();

				//Not Supported -will result in Illegal Argument Exception
				//transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
				//transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				File outputFile = new File(parmOutputFilePath,parmOutputFileName); 
				StreamResult result = new StreamResult(outputFile);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.transform(source, result);
			} catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
				addError(CustomMessageRepositorySpireOne.ccb017ErrorDuringDecryption(e1.getMessage()));
			}
		}

		private void evaluateXPath(Document document, String xpathExpression, int j) 
		{
			// Create XPathFactory object
			XPathFactory xpathFactory = XPathFactory.newInstance();

			// Create XPath object
			XPath xpath = xpathFactory.newXPath();
			Boolean isPathFound = false;

			try
			{
				// Create XPathExpression object
				XPathExpression expr = xpath.compile(xpathExpression);

				// Evaluate expression result on XML document
				NodeList nodes = (NodeList) expr.evaluate(document, XPathConstants.NODESET);

				for (int i = 0; i < nodes.getLength(); i++) {
					Node node = nodes.item(i).getFirstChild();
					if(notNull(node)){
						node.setNodeValue(Cryptography.encryptAndWrap(node.getNodeValue()));
					}
					numberofRecordsProcessed = numberofRecordsProcessed+1;
					isPathFound = true;
				}

			} catch (XPathExpressionException e) {
				addError(CustomMessageRepositorySpireOne.ccb017FileReadError(parmInputFileName, e.getMessage()));
			}

			// if the configured path is not found, terminate the process
			if(!isPathFound){
				addWarning(CustomMessageRepositorySpireOne.ccb017NoMatchingXPathFieldsException(parmInputFileName, fieldDescriptionList.get(j),xpathExpression));
			}
		}

		/**
		 * 
		 * This method will decrypt the sensitive data present in the file and write the new file
		 */
		private void decryptFile(){
			openFileForRead();

			try{
				while(bufferedReader.ready()) {
					String record = bufferedReader.readLine();
					String temp = record;
					while(temp.contains("ENCKS(")){
						int startIndex = temp.indexOf("ENCKS(");
						int endIndex =  temp.indexOf(")",startIndex);
						String encryptedSubstring = temp.substring(startIndex, endIndex+1);
						String decryptedSubstring = Cryptography.decryptIfNeeded(encryptedSubstring);
						temp=temp.replace(encryptedSubstring, decryptedSubstring);
						numberofRecordsProcessed = numberofRecordsProcessed+1;
					}
					outputList.add(temp);
				}
			}catch (IOException e){
				addError(CustomMessageRepositorySpireOne.ccb017ErrorDuringDecryption(e.getMessage()));
			}
			writeIntoFile();
		}

		private void getMasterConfigurationDetails(){

			String inputBatchControl = getParameters().getBATCH_CD().getId().getTrimmedValue();
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(ENC_DEC_MAST_CONFIG);
			boInstance.setXMLString("bo", ENC_DEC_MAST_CONFIG);
			boInstance = BusinessObjectDispatcher.read(boInstance);

			//Get Group details
			COTSInstanceNode recordDetailsGroupNode = boInstance.getGroup(MASTER_CONFIG_GROUP_NAME).getGroup(RECORD_DETAILS_GROUP_NAME);
			COTSInstanceList batchesListNode = recordDetailsGroupNode.getList(BATCHES_LIST_NAME);

			if(notNull(batchesListNode)){
				for(COTSInstanceNode node : batchesListNode){

					String batchControlName = node.getXMLString("batchCd").trim();

					if(batchControlName.equalsIgnoreCase(inputBatchControl)){
						batchControlInfoNode = node;
						isBatchDetailsConfigured = true;
						break;
					}
				}
				if(isBatchDetailsConfigured){
					COTSInstanceList fileDetailsListNode = batchControlInfoNode.getGroup("fileList").getList("file");
					isBatchDetailsConfigured = false;
					if(notNull(fileDetailsListNode)){
						for(COTSInstanceNode fileDetailNode : fileDetailsListNode){
							String fileName = fileDetailNode.getXMLString("fileName").trim();

							if(fileName.contains(WILD_CARD)){
								if(strmatch(parmInputFileName,fileName,parmInputFileName.length(),fileName.length())){
									fileInfoNode = fileDetailNode;
									isBatchDetailsConfigured = true;
									break;
								}
							}

							if(fileName.equalsIgnoreCase(parmInputFileName)){
								fileInfoNode = fileDetailNode;
								isBatchDetailsConfigured = true;
								break;
							}
						}
						getFileDetails();
					}
				}
			}
		}

		private  boolean strmatch(String str, String pattern, 
				int n, int m) 
		{ 
			// empty pattern can only match with 
			// empty string 
			if (m == 0) 
				return (n == 0); 

			// lookup table for storing results of 
			// subproblems 
			boolean[][] lookup = new boolean[n + 1][m + 1]; 

			// initailze lookup table to false 
			for(int i = 0; i < n + 1; i++) 
				Arrays.fill(lookup[i], false); 


			// empty pattern can match with empty string 
			lookup[0][0] = true; 

			// Only '*' can match with empty string 
			for (int j = 1; j <= m; j++) 
				if (pattern.charAt(j - 1) == '*') 
					lookup[0][j] = lookup[0][j - 1]; 

			// fill the table in bottom-up fashion 
			for (int i = 1; i <= n; i++) 
			{ 
				for (int j = 1; j <= m; j++) 
				{ 
					// Two cases if we see a '*' 
					// a) We ignore '*'' character and move 
					// to next character in the pattern, 
					//	 i.e., '*' indicates an empty sequence. 
					// b) '*' character matches with ith 
					//	 character in input 
					if (pattern.charAt(j - 1) == '*') 
						lookup[i][j] = lookup[i][j - 1] || 
						lookup[i - 1][j]; 
					else if (str.charAt(i - 1) == pattern.charAt(j - 1)) 
						lookup[i][j] = lookup[i - 1][j - 1]; 

					// If characters don't match 
					else lookup[i][j] = false; 
				} 
			} 

			return lookup[n][m]; 
		} 

		private void getFileDetails(){
			if(isBatchDetailsConfigured){
				fileFormatLkp = (CmFileFormatFlagLookup) fileInfoNode.getLookup("fileType");
				hasHeader = fileInfoNode.getBoolean("hasHeader");
				COTSInstanceList fieldDetailsListNode= fileInfoNode.getGroup("fieldList").getList("field");
				if(fileFormatLkp.isCmDelimitedValues()){
					delimeterValue = fileInfoNode.getXMLString("delimiter");
					for(COTSInstanceNode fieldDetailNode : fieldDetailsListNode){
						//2020-10-30 - Ravi - Start Changes - Logic to check Prefix for delimited records
						delimitedPositionsList.add(fieldDetailNode.getNumber("fieldSequenceForDelimitedFiles").intValue());
						delimitedPrefixesList.add(fieldDetailNode.getString("linePrefixForFixedLength"));
						fieldDescriptionList.add(fieldDetailNode.getString("description"));
						//2020-10-30 - Ravi - End Changes - Logic to check Prefix for delimited records
					}
				}else if(fileFormatLkp.isCmFixedLength()){
					for(COTSInstanceNode fieldDetailNode : fieldDetailsListNode){
						fixedLengthStartNodeList.add(fieldDetailNode.getNumber("startCharacterForFixedLength").intValue());
						fixedLengthDetNodesList.add(fieldDetailNode);
						fieldDescriptionList.add(fieldDetailNode.getString("description"));
					}
				}else if(fileFormatLkp.isCmXmlDocument()){
					for(COTSInstanceNode fieldDetailNode : fieldDetailsListNode){
						xpathNodeList.add(fieldDetailNode.getXMLString("xPath"));
						fieldDescriptionList.add(fieldDetailNode.getString("description"));
					}
				}
			}
		}

		/**
		 * Custom method used to Open files in preparation for Read.
		 */
		public void openFileForRead() {

			// Local variables
			File fileForRead = new File(parmInputFilePath, parmInputFileName);

			try {
				// Open file
				bufferedReader = new BufferedReader(new FileReader(fileForRead));
			} catch (IOException e) {
				addError(CustomMessageRepositorySpireOne.ccb017FileOpenError(parmInputFileName));
			}

		}

		/**
		 * Custom method used to Open files in preparation for Write.
		 */
		public void openFileForWrite() {

			// Local variables
			File fileForWrite = new File(parmOutputFilePath, parmOutputFileName);

			try {
				// Open file
				bufferedWriter = new BufferedWriter(new FileWriter(fileForWrite));
			} catch (IOException e) {
				addError(CustomMessageRepositorySpireOne.ccb017FileOpenError(parmOutputFileName));
			}

		}	

		/**
		 * Custom method used to close the file.
		 */
		private void closeFile() {

			closeFileForRead();
			closeFileForWrite();
		}

		private void closeFileForRead() {

			try {
				bufferedReader.close();
			} catch (IOException e) {
				addError(CustomMessageRepositorySpireOne.ccb017FileClosingError(parmInputFileName));
			}
		}

		private void closeFileForWrite() {

			try {
				bufferedWriter.close();
			} catch (IOException e) {
				addError(CustomMessageRepositorySpireOne.ccb017FileClosingError(parmOutputFileName));
			}
		}

		/**
		 * Method to write record into a file.
		 * @param outputFileWriter a BufferedWriter object.
		 * @param recordString a string.
		 */
		private void writeIntoFile() {

			openFileForWrite();

			try {
				for(int i=0; i<outputList.size(); i++){
					bufferedWriter.write(outputList.get(i));
					if(i != outputList.size()-1){
						bufferedWriter.newLine();
					}
				}
			} catch (IOException iOException) {
				// Error in file : %1. (Writing into file)
				addError(CustomMessageRepositorySpireOne.ccb017ErrorInFile(iOException.getMessage()));
			}

			closeFile();
		}

	}

}
