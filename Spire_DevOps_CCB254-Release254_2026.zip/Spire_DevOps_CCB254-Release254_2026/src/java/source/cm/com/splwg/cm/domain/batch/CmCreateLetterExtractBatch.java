/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCLXTX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-02-10   EQuint      RI0016. Initial Version. 
 * 2016-06-01   MPang       Defect 3444302. Added connection close.
 * 2016-09-22   SFelip      Defect 3512884. Updated how the letter count is 
 *                          being retrieved in the finalizeThreadWork
 *                          method.  
 * 2016-09-27   SFelip      Defect 3512842. Updated to fix handling of 
 *                          warnings returned by the extract algorithm.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2019-01-31   SRoman      Defect 4156578. Added override annotation on 
 *                          createWorkUnit method.   
 * 2019-05-28   JHERNA      SysAid#216236. Origin conversion tool/verang 
 *                          framework flaw.          
 * 2021-04-14   RDizon      CCB034. Added Separate CIS Divisions batch parameter. 
 * 2021-07-14   EQuint      SA-373868. Fix String index out of bounds error
 * 2021-09-16   RDizon      CCB034.Issue4. For every file produced, write their
 *                          own 0010 record with the correct record count.
 * 2021-09-29   RDizon      Defect 4599345. Modify logic in checking the
 *                          CIS Divisions.
 * 2021-11-08   RDizon      Defect 4602708. Stamp the Customer Contact
 *                          with the print date/time.
 * 2021-11-09   RDizon      Defect 4611170. Skip printing of letter if its
 *                          Collection Process is already inactive or if its
 *                          Collection Amount is already a credit amount.
 * 2022-06-22   DLampa      CCB047.5. Updated for MO Severance Process Alignment.  
 * 2022-11-16   JVitug      E-06267. Updated the error handling of the batch   
 * 2023-03-02   DLampa      E-06267.Issue1. Create a to do entry for missing 
 *                          addresses.  
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * *************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate_Id;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcessServiceAgreements;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.common.StringUtilities;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpclxtx;

// Start Change - DLampa - E-06267.Issue1. - 03-23-2023
///**
// * @author Administrator
// *
//@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
// * softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
// *            , @BatchJobSoftParameter (name = FIELD_DELIM_SW,type = boolean)
// *            , @BatchJobSoftParameter (name = CNTL_REC_SW, type = boolean)
// *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
// *            , @BatchJobSoftParameter (name = CIS_DIVISIONS, type = string)
// *            , @BatchJobSoftParameter (name = EXTRACT_96HR_CC_SW, type = string)})
// */
/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
 * softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FIELD_DELIM_SW,type = boolean)
 *            , @BatchJobSoftParameter (name = CNTL_REC_SW, type = boolean)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (name = CIS_DIVISIONS, type = string)
 *            , @BatchJobSoftParameter (name = EXTRACT_96HR_CC_SW, type = string)
 *            , @BatchJobSoftParameter (name = TD_TYPE_CD, type = entity, required = true, entityName = toDoType)})
 */
// End Change - DLampa - E-06267.Issue1. - 03-02-2023
public class CmCreateLetterExtractBatch extends CmCreateLetterExtractBatch_Gen {

    // CONSTANTS
    private static final String CONNECTION_ONLINE = "O";
    private static final String CONNECTION_BATCH = "B";

    private static final String SWITCH_YES = "Y";
    private static final String SWITCH_NO = "N";

    private static final String LETTER_EXT = "LTR"; 
    private static final String PERIOD = ".";
    private static final String PRINT_KEY = "0010";
    private static final String BLANK = "";  

    public JobWork getJobWork() {
        Query<QueryResultRow> query = createQuery(" FROM CustomerContact cc " +
                " WHERE cc.batchControlId = :batchCd " +
                " AND cc.batchNumber = :batchNumber " +
                " AND cc.shouldPrintLetter = :shouldPrintLetter "
                , "getJobWork");

        query.bindId("batchCd", getBatchControlId());
        query.bindBigInteger("batchNumber", getBatchNumber());
        query.bindBoolean("shouldPrintLetter", Bool.TRUE);

        query.addResult("ccId", "cc.id");
        query.addResult("letterTmplt", "cc.letterTemplateId");

        query.orderBy("letterTmplt", Query.ASCENDING);

        return createJobWorkForQueryIterator(query.iterate(), this);

    }

    /*
     * This method will create the Thread Work Unit per result row
     */
    //Start Add - 2019-01-31 - SRoman -  Defect 4156578.
    @Override
    //End Add - 2019-01-31 - SRoman -  Defect 4156578.
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
        CustomerContact_Id ccId = (CustomerContact_Id) resultRow.getId("ccId", CustomerContact.class);
        LetterTemplate_Id ltrTemplageId = (LetterTemplate_Id) resultRow.getId("letterTmplt", LetterTemplate.class);

        ThreadWorkUnit unit = new ThreadWorkUnit();
        unit.setPrimaryId(ccId);
        unit.addSupplementalData("letterTmpltId", ltrTemplageId);
        return unit;
    }

    public Class<CmCreateLetterExtractBatchWorker> getThreadWorkerClass() {
        return CmCreateLetterExtractBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean flag) {

        if (getParameters().getFIELD_DELIM_SW().isTrue()) {
            addError(CustomMessageRepository.RI0016_delimNotAllowedOnLetterPrint());
        }
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        if (notNull(this.getParameters().getCIS_DIVISIONS())){
            String[] parmCisDivisions = this.getParameters().getCIS_DIVISIONS().split(",");
            
            for (int i=0; i < parmCisDivisions.length; i++){
                String cisDivStr = parmCisDivisions[i];
                CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
                if (isNull(cisDivision)){
                    addError(CustomMessageRepository.CCB034_BatchParameterContainsInvalidCisDivision(
                            "Separate CIS Divisions",
                            cisDivStr));
                }
            }
        }
        // End Add - CCB034 - RDizon - 04-14-2021
                
    }

    public static class CmCreateLetterExtractBatchWorker extends
    CmCreateLetterExtractBatchWorker_Gen {
        
        // soft parameters
        private String filePath;
        private Bool fieldDelimiterSw;
        private Bool controlRecordSwitch;
        @SuppressWarnings("unused")
        private BigInteger maxErrors;
        // Start Add - CCB034 - RDizon - 04-14-2021
        private String parmCisDivisions;
        // End Add - CCB034 - RDizon - 04-14-2021
        // Start Add - CCB047.5 - DLampa - 06-22-2022
        private Bool extract96hrCcSw = Bool.FALSE;
        // End Add - CCB047.5 - DLampa - 06-22-2022   
        // Start Add - DLampa - E-06267.Issue1. - 03-02-2023
        private ToDoType toDoType;
        // End Add - DLampa - E-06267.Issue1. - 03-02-2023

        // work variable
        private Cmpclxtx cmpclxtx;
        
        // start delete - equint - 2025-11-14 - CCB25.4 Upgrade
        // //Start Add - MPang - Defect 3444302 - 2016-06-01
        // private Connection connection;
        // //End Add - MPang - Defect 3444302 - 2016-06-01
        // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        private Bool wSeparateCisDivisionSw = Bool.FALSE;
        // End Add - CCB034 - RDizon - 04-14-2021

        private CustomerContact_Id ccId;
        private LetterTemplate_Id letterTemplateId;
        
        // Start Add - Defect 4599345 - RDizon - 09-29-2021
        private Account account;
        // End Add - Defect 4599345 - RDizon - 09-29-2021
        
        // Start Add - CCB047.5 - DLampa - 06-22-2022
        private String cwrSeasonBeginDate;
        private String cwrSeasonEndDate;        
        // End Add - CCB047.5 - DLampa - 06-22-2022

        // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
        // private Map<LetterTemplate_Id, BigInteger> letterTemplateCountMap = new HashMap<LetterTemplate_Id, BigInteger>();
        // private Map<LetterTemplate_Id, String> letterTemplateFileMap = new HashMap<LetterTemplate_Id, String>();
        private Map<String,  BigInteger> extractFileMap = new HashMap<String,  BigInteger>();
        // End Change - CCB034.Issue4 - RDizon - 09-16-2021
        
        // Start Add - SFelip - Defect 3512842 - 2016-09-27
        List<ServerMessage> warnings = new ArrayList<ServerMessage>();
        FrameworkSession session;
        // End Add - SFelip - Defect 3512842 - 2016-09-27
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        private static final String AL_GC_CIS_DIVISION = "AL_GC";
        // End Add - CCB034 - RDizon - 04-14-2021
        
        // Start Add - Defect 4599345 - RDizon - 09-29-2021
        private static final String ACCOUNT = "ACCOUNT";
        // End Add - Defect 4599345 - RDizon - 09-29-2021        
        
        // Start Add - CCB047.5 - DLampa - 06-22-2022
        private static final String CC_TYPE_96HR = "96HR";
        private static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
        // End Add - CCB047.5 - DLampa - 06-22-2022  
    
        @Override
        public void initializeThreadWork(boolean flag)
                throws ThreadAbortedException, RunAbortedException {
            filePath = getParameters().getFILE_PATH();

            if (isBlankOrNull(filePath)) {
                filePath = new File("").getAbsolutePath();
            }

            fieldDelimiterSw = getParameters().getFIELD_DELIM_SW();
            controlRecordSwitch = getParameters().getCNTL_REC_SW();
            maxErrors = getParameters().getMAX_ERRORS();
            
            // Start Add - CCB034 - RDizon - 04-14-2021
            parmCisDivisions = this.getParameters().getCIS_DIVISIONS();
            // End Add - CCB034 - RDizon - 04-14-2021
            
            // Start Add - CCB047.5 - DLampa - 06-22-2022
            if (!isBlankOrNull(this.getParameters().getEXTRACT_96HR_CC_SW())) {
                if (this.getParameters().getEXTRACT_96HR_CC_SW().equalsIgnoreCase(SWITCH_YES)) {
                    extract96hrCcSw = Bool.TRUE;
                }
            }
            
            // Quote Portal Parameters Feature Configuration
            FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 
          
            // Season Begin
            LookupValue seasonStartOptionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_BEGIN.getLookupValue();
            String seasonStartOptionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, seasonStartOptionType);
            cwrSeasonBeginDate = seasonStartOptionValue.trim();
            
            // Season End
            LookupValue seasonEndOptionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_END.getLookupValue();
            String seasonEndOptionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, seasonEndOptionType);
            cwrSeasonEndDate = seasonEndOptionValue.trim();            
            // End Add - CCB047.5 - DLampa - 06-22-2022
            
            // Start Add - DLampa - E-06267.Issue1. - 03-02-2023
            toDoType = this.getParameters().getTD_TYPE_CD();
            // End Add - DLampa - E-06267.Issue1. - 03-02-2023

            
            try {
            	// initialize program
            	initializeCobolProgram();
            }
            catch(Exception err) {
            	addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
            } 
            
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        @Override
        protected boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            ccId = (CustomerContact_Id) unit.getPrimaryId();
            letterTemplateId = (LetterTemplate_Id) unit.getSupplementallData("letterTmpltId");
           
            // Start Add - CCB047.5 - DLampa - 06-22-2022
            // Do not extract the 96HR Customer Contact if the business date does not fall within the CWR season
            // and the extract 96HR CC switch is N 
            if (ccId.getEntity().getCustomerContactType().fetchIdContactType().trim().equalsIgnoreCase(CC_TYPE_96HR)
                    && checkIfCwrSeason().isFalse()
                    && extract96hrCcSw.isFalse()) {
                return true;
            }
            // End Add - CCB047.5 - DLampa - 06-22-2022            
            
            // Start Add - Defect 4611170 - RDizon - 11-09-2021
            // Check if Customer Contact is tied to a Collection Process
            CollectionProcess collectionProcess = getCustomerContactCollectionProcess();

            if (notNull(collectionProcess)){
                // Skip Customer Contact if Collection Process is already inactive
                if (collectionProcess.getCollectionProcessStatus().isInactive()){
                    return true;
                }

                // Skip Customer Contact if Collection Process already has a credit collection amount
                Money collectionAmount = calculateAmountOwed(collectionProcess);
                if (collectionAmount.getAmount().intValue() < 0){
                    return true;
                }
            }
            // End Add - Defect 4611170 - RDizon - 11-09-2021
            
            // start add - equint - 2025-11-14 - CCB25.4 Upgrade
 			try {
 				session = (FrameworkSession) SessionHolder.getSession();
				session.doWork(new ConnectionWork() {
		  			
		  			@Override
		  			public void execute(Connection connection) throws SQLException {
		  				try {  
							// assign new connection as it closes per work unit
		  					cmpclxtx.getSession().getDbSession().setUpdateConnection(connection);
		  				}
		  				catch(Exception e) {
							throw new SQLException(e.getCause());
						}
					}
				});
 			}
			catch(Exception e) {
				createToDo(e);
            	logInfo(CustomMessageRepository.JACOB_toDoEntryCreated(ccId.getTrimmedValue()));
				return false;
			}
 			// end add - equint - 2025-11-14 - CCB25.4 Upgrade
            
            cmpclxtx.setZstatProgramStatus(" ");
            cmpclxtx.setZmsgnMessageNbr(BigDecimal.ZERO);
            cmpclxtx.setZmsgnMessageCatNbr(BigDecimal.ZERO);
            
            // Start Add - CCB034 - RDizon - 04-14-2021
            if (notNull(parmCisDivisions)){
                String cisDivisionsInQuotes = "'" + parmCisDivisions.replaceAll(",", "','") + "'";
                
                // Start Change - Defect 4599345 - RDizon - 09-29-2021
                account = ccId.getEntity().fetchAccount();
                if (notNull(account)){
                    // Call query with specified Account ID
                    wSeparateCisDivisionSw = checkMainPersonCisDivisionWithAccount(ccId.getEntity().fetchPerson(),
                                                                                account,
                                                                                cisDivisionsInQuotes);
                }
                else {
                    CharacteristicType_Id charTypeId = new CharacteristicType_Id(ACCOUNT);
                    CustomerContactCharacteristic accountIdChar =  ccId.getEntity().getEffectiveCharacteristic(charTypeId.getEntity());

                    if (notNull(accountIdChar)){
                        // Call query with specified Account ID
                        wSeparateCisDivisionSw = checkMainPersonCisDivisionWithAccount(ccId.getEntity().fetchPerson(),
                                new Account_Id(accountIdChar.getCharacteristicValueForeignKey1().trim()).getEntity(),
                                cisDivisionsInQuotes);
                    }
                    else {
                        wSeparateCisDivisionSw = checkMainPersonCisDivision(ccId.getEntity().fetchPerson(), cisDivisionsInQuotes);
                    }
                }
                
                //wSeparateCisDivisionSw = checkMainPersonCisDivision(ccId.getEntity().fetchPerson(), cisDivisionsInQuotes);
                // End Change - Defect 4599345 - RDizon - 09-29-2021
            }
            // End Add - CCB034 - RDizon - 04-14-2021

            // Build the complete file path/name
            String fullFileName = createPathName();

            // set unit parameter
            cmpclxtx.setInputWrkCcId(ccId.getTrimmedValue());
            cmpclxtx.setLtrTmplCd(letterTemplateId.getTrimmedValue());
            // set soft parameters
            cmpclxtx.setInputWrkExtractFileName(fullFileName);
            String fieldDelimSw = (fieldDelimiterSw.isTrue()) ? SWITCH_YES : SWITCH_NO;
            cmpclxtx.setFieldDelimSw(fieldDelimSw);
            String controlRecordSw = (controlRecordSwitch.isTrue()) ? SWITCH_YES : SWITCH_NO;
            cmpclxtx.setDelim_1stHeaderSw(controlRecordSw);
            
            // Start add - SA-373868 - EQuint - 2021-07-14
            CustomerContact cc = ccId.getEntity();
            cmpclxtx.setBatchCd(cc.getBatchControlId().getTrimmedValue());
            cmpclxtx.setBatchNbr(java.math.BigDecimal.valueOf(cc.getBatchNumber().doubleValue()));
            cmpclxtx.setInputWrkExtractAlgCd(letterTemplateId.getEntity().getExtractAlgorithmId().getTrimmedValue());
            // End add - SA-373868 - EQuint - 2021-07-14
            
            // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
            // cmpclxtx.setCcExtractedCnt(BigDecimal.valueOf(letterTemplateCountMap.get(letterTemplateId).doubleValue()));
            cmpclxtx.setCcExtractedCnt(BigDecimal.valueOf(extractFileMap.get(fullFileName).doubleValue()));
            // End Change - CCB034.Issue4 - RDizon - 09-16-2021

            //Start Add JVitug - E-06267 - 2022-11-16
            try {
            //End Add JVitug - E-06267 - 2022-11-16
                callCobol();
            //Start Add JVitug - E-06267 - 2022-11-16
            } catch (Exception e) {
            	// Start Change - DLampa - E-06267.Issue1. - 03-02-2023
                //logError(CustomMessageRepository.JACOB_exceptionDuringLetterProcessing(ccId.getTrimmedValue(), e.getLocalizedMessage()));
                createToDo(e);
            	logInfo(CustomMessageRepository.JACOB_toDoEntryCreated(ccId.getTrimmedValue()));
                // End Change - DLampa - E-06267.Issue1. - 03-02-2023
                
                return false;
            }
          //End Add JVitug - E-06267 - 2022-11-16

            // Start Add - Defect 4602708 - RDizon  11-08-2021
            stampCustomerContactWithPrintDttm(cc, this.getProcessDateTime());
            // End Add - Defect 4602708 - RDizon  11-08-2021

            return true;
        }

        // Start Add - Defect 4602708 - RDizon  11-08-2021
        private void stampCustomerContactWithPrintDttm(CustomerContact cc, DateTime printDttm) {

            startChanges();
            CustomerContact_DTO ccDto = cc.getDTO();
            ccDto.setLetterPrintDateTime(printDttm);
            cc.setDTO(ccDto);            
            saveChanges();
        }
        // End Add - Defect 4602708 - RDizon  11-08-2021

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
        RunAbortedException {
            if (controlRecordSwitch.isTrue()) {
                
                // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
                // Iterator<LetterTemplate_Id> iterator = letterTemplateFileMap.keySet().iterator();
                Iterator<String> iterator = extractFileMap.keySet().iterator();
                // End Change - CCB034.Issue4 - RDizon - 09-16-2021
                while(iterator.hasNext()) {
                    // Start Change - SFelip - Defect 3512884 - 2016-09-22
                    // BigInteger count = letterTemplateCountMap.get(letterTemplateId);
                    // String filename = letterTemplateFileMap.get(iterator.next());
                    // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
                    // LetterTemplate_Id currentLetterTemplate = iterator.next();
                    // BigInteger count = letterTemplateCountMap.get(currentLetterTemplate);
                    // String filename = letterTemplateFileMap.get(currentLetterTemplate);
                    String currentFilename = iterator.next();
                    BigInteger count = extractFileMap.get(currentFilename);
                    // End Change - CCB034.Issue4 - RDizon - 09-16-2021
                    // End Change - SFelip - Defect 3512884 - 2016-09-22
                    
                    // Write the heading Record
                    String printerKey = StringUtilities.padRight(PRINT_KEY,4);
                    String sortKey = StringUtilities.padRight(BLANK, 26);
                    String mailingKey = StringUtilities.padRight(BLANK, 15);

                    String printDetails = StringUtilities.padRight(getBatchControlId().getTrimmedValue(), 8);
                    printDetails += StringUtilities.leftPadWithZeros(getBatchNumber().toString(), 10);
                    printDetails += StringUtilities.leftPadWithZeros(getBatchRerunNumber().toString(), 10);
                    printDetails += StringUtilities.leftPadWithZeros(count.toString(), 10);
                    printDetails += StringUtilities.padRight(getProcessDateTime().toString() + ".000000", 26);
                    printDetails += StringUtilities.leftPadWithZeros(getLowIdForThread(CustomerContact_Id.FIELD_SIZE), 10);
                    printDetails += StringUtilities.leftPadWithZeros(getHighIdForThread(CustomerContact_Id.FIELD_SIZE), 10);
                    printDetails += StringUtilities.leftPadWithZeros(getBatchThreadNumber().toString(), 10);
                    printDetails += StringUtilities.leftPadWithZeros(getParameters().getThreadCount().toString(), 10);

                    String headerRecord = StringUtilities.padRight(printerKey + sortKey + mailingKey + printDetails, 2012);

                    try {
                        // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
                        // BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File(filename),true));
                        BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File(currentFilename),true));
                        // End Change - CCB034.Issue4 - RDizon - 09-16-2021
                        bufferedWriter.write(headerRecord);
                        bufferedWriter.close();

                    } catch (IOException e) {
                        addError(CustomMessageRepository.JACOB_FileWriteError(e.getMessage()));
                    }
                }
            }
            
            // Start Add - SFelip - Defect 3512842 - 2016-09-27
            // Log all the warnings that were previously stored from the callCobol method.
            for(ServerMessage warning : warnings) {
                logWarning(warning);
            }
            // End Add - SFelip - Defect 3512842 - 2016-09-27
         // start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//            //Start Add - MPang - Defect 3444302 - 2016-06-01
//            try {
//                connection.close();
//            }
//            catch(SQLException se) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//            }
//            //End Add - MPang - Defect 3444302 - 2016-06-01
         // end delete- equint - 2025-11-14 - CCB25.4 Upgrade
        }

        /*
         * Initialize cobol program
         */
        @SuppressWarnings("deprecation")
        private void initializeCobolProgram() throws Exception {
            
            // Start Change - SFelip - Defect 3512842 - 2016-09-27
            //FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
            session = (FrameworkSession) SessionHolder.getSession();
            // End Change - SFelip - Defect 3512842 - 2016-09-27
            RequestContext context = session.getRequestContext();
            
            // start update - equint - 2025-11-14 - CCB25.4 Upgrade
      		session.doWork(new ConnectionWork() {
      			
      			@Override
      			public void execute(Connection connection) throws SQLException {
      				try {  
      		            String username = connection.getMetaData().getUserName();
      		            String url = connection.getMetaData().getURL();

      		            CobolSession.setLogSessionStartEnd(false);
      		            cmpclxtx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpclxtx.class);

      		            cmpclxtx.getSession().getDbSession().setUpdateConnection(connection);
      		            cmpclxtx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

      		            // set ZSTAT parameters
      		            cmpclxtx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
      		            cmpclxtx.setProcessDttmProcessDttmSep("-");
      		            cmpclxtx.setProcessDttmProcessTm(getProcessDateTime().getTime().toString() + ".000000");
      		            cmpclxtx.setLicenseInfoLkExpiryDt(Date.MAX.toString());
      		            if (session.isOnlineConnection()) { 
      		                cmpclxtx.setZstatConnectionFlg(CONNECTION_ONLINE);
      		            }
      		            else {
      		                cmpclxtx.setZstatConnectionFlg(CONNECTION_BATCH);
      		            }

      		            cmpclxtx.setZstatUserId(context.getUserId()); 
      		            cmpclxtx.setZstatLanguageCd(context.getLanguageCode());

      		            if (context.ignoreWarnings()) {
      		                cmpclxtx.setZstatIgnoreWarningSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpclxtx.setZstatIgnoreWarningSw(SWITCH_NO);
      		            }

      		            if (session.getBatchInstanceId() != null) {
      		                cmpclxtx.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
      		                cmpclxtx.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));

      		            } else {
      		                cmpclxtx.setZstatSchedulerId(new BigDecimal(0));
      		                cmpclxtx.setZstatSchedulerId(new BigDecimal(0));
      		            }

      		            cmpclxtx.setZstatAppSvcId(context.getSecurityServiceIdContext());

      		            DatabaseHelper dbHelper = session.getDatabaseHelper();
      		            cmpclxtx.setDbInfoDbMode(dbHelper.getCobolDBMode());
      		            // CCB v2.6 Upgrade - 2018-05-31 - Start Change
      		            //cmpclxtx.setSplValuesSplHighValue(cmpclxtx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
      		            //cmpclxtx.setSplValuesSplLowValue(cmpclxtx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
      		            
      		            cmpclxtx.setSplValuesSplHighValue(cmpclxtx.getSession().getSettings().getString(
      		                    new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
      		            cmpclxtx.setSplValuesSplLowValue(cmpclxtx.getSession().getSettings().getString(
      		                    new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
      		            // CCB v2.6 Upgrade - 2018-05-31 - End Change

      		            cmpclxtx.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
      		            cmpclxtx.setLicenseInfoLkExpiryDt(Date.MAX.toString());
      		            cmpclxtx.setZstatProgramStatus(" ");
      		            
      		            // Start add - SA-373868 - EQuint - 2021-07-14
      		            cmpclxtx.setZstatMessageAreaCallSeq(";");
      		            cmpclxtx.setZstatMessageAreaProgramName("CMPCXCLX");
      		            // End add - SA-373868 - EQuint - 2021-07-14

      		            if (context.getRandomGeneratorSeedSet().isTrue()) {
      		                cmpclxtx.setRandomNumberInfoRandomGenSeedSw(SWITCH_YES);
      		                cmpclxtx.setRandomNumberInfoRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
      		                cmpclxtx.setRandomNumberInfoRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
      		                cmpclxtx.setRandomNumberInfoRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
      		                cmpclxtx.setRandomNumberInfoRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
      		            }
      		            else {
      		                cmpclxtx.setRandomNumberInfoRandomGenSeedSw(SWITCH_NO);
      		            }

      		            if (context.traceStandardOut()) { 
      		                cmpclxtx.setZstatTrcStdoutSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpclxtx.setZstatTrcStdoutSw(SWITCH_NO);
      		            }

      		            if (context.traceProgramStart()) { 
      		                cmpclxtx.setZstatTrcProgStartSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpclxtx.setZstatTrcProgStartSw(SWITCH_NO);
      		            }

      		            if (context.traceProgramExit()) { 
      		                cmpclxtx.setZstatTrcProgExitSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpclxtx.setZstatTrcProgExitSw(SWITCH_NO);
      		            }

      		            if (context.traceSQL()) { 
      		                cmpclxtx.setZstatTrcExecSqlSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpclxtx.setZstatTrcExecSqlSw(SWITCH_NO);
      		            } 
      				}
      				catch(Exception e) {
    					throw new SQLException(e.getCause());
    				}
    				
    			}
    		});

//            SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//            //Start Change - MPang - Defect 3444302 - 2016-06-01
//            //Connection connection = implementor.getConnectionProvider().getConnection();
//            connection = implementor.getConnectionProvider().getConnection();
//            //End Change - MPang - Defect 3444302 - 2016-06-01
//
//            String username = connection.getMetaData().getUserName();
//            String url = connection.getMetaData().getURL();
//
//            CobolSession.setLogSessionStartEnd(false);
//            cmpclxtx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpclxtx.class);
//
//            cmpclxtx.getSession().getDbSession().setUpdateConnection(connection);
//            cmpclxtx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//            // set ZSTAT parameters
//            cmpclxtx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//            cmpclxtx.setProcessDttmProcessDttmSep("-");
//            cmpclxtx.setProcessDttmProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//            cmpclxtx.setLicenseInfoLkExpiryDt(Date.MAX.toString());
//            if (session.isOnlineConnection()) { 
//                cmpclxtx.setZstatConnectionFlg(CONNECTION_ONLINE);
//            }
//            else {
//                cmpclxtx.setZstatConnectionFlg(CONNECTION_BATCH);
//            }
//
//            cmpclxtx.setZstatUserId(context.getUserId()); 
//            cmpclxtx.setZstatLanguageCd(context.getLanguageCode());
//
//            if (context.ignoreWarnings()) {
//                cmpclxtx.setZstatIgnoreWarningSw(SWITCH_YES);
//            }
//            else {
//                cmpclxtx.setZstatIgnoreWarningSw(SWITCH_NO);
//            }
//
//            if (session.getBatchInstanceId() != null) {
//                cmpclxtx.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//                cmpclxtx.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//            } else {
//                cmpclxtx.setZstatSchedulerId(new BigDecimal(0));
//                cmpclxtx.setZstatSchedulerId(new BigDecimal(0));
//            }
//
//            cmpclxtx.setZstatAppSvcId(context.getSecurityServiceIdContext());
//
//            DatabaseHelper dbHelper = session.getDatabaseHelper();
//            cmpclxtx.setDbInfoDbMode(dbHelper.getCobolDBMode());
//            // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//            //cmpclxtx.setSplValuesSplHighValue(cmpclxtx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//            //cmpclxtx.setSplValuesSplLowValue(cmpclxtx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//            
//            cmpclxtx.setSplValuesSplHighValue(cmpclxtx.getSession().getSettings().getString(
//                    new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmpclxtx.setSplValuesSplLowValue(cmpclxtx.getSession().getSettings().getString(
//                    new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//            // CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//            cmpclxtx.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//            cmpclxtx.setLicenseInfoLkExpiryDt(Date.MAX.toString());
//            cmpclxtx.setZstatProgramStatus(" ");
//            
//            // Start add - SA-373868 - EQuint - 2021-07-14
//            cmpclxtx.setZstatMessageAreaCallSeq(";");
//            cmpclxtx.setZstatMessageAreaProgramName("CMPCXCLX");
//            // End add - SA-373868 - EQuint - 2021-07-14
//
//            if (context.getRandomGeneratorSeedSet().isTrue()) {
//                cmpclxtx.setRandomNumberInfoRandomGenSeedSw(SWITCH_YES);
//                cmpclxtx.setRandomNumberInfoRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//                cmpclxtx.setRandomNumberInfoRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//                cmpclxtx.setRandomNumberInfoRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//                cmpclxtx.setRandomNumberInfoRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//            }
//            else {
//                cmpclxtx.setRandomNumberInfoRandomGenSeedSw(SWITCH_NO);
//            }
//
//            if (context.traceStandardOut()) { 
//                cmpclxtx.setZstatTrcStdoutSw(SWITCH_YES);
//            }
//            else {
//                cmpclxtx.setZstatTrcStdoutSw(SWITCH_NO);
//            }
//
//            if (context.traceProgramStart()) { 
//                cmpclxtx.setZstatTrcProgStartSw(SWITCH_YES);
//            }
//            else {
//                cmpclxtx.setZstatTrcProgStartSw(SWITCH_NO);
//            }
//
//            if (context.traceProgramExit()) { 
//                cmpclxtx.setZstatTrcProgExitSw(SWITCH_YES);
//            }
//            else {
//                cmpclxtx.setZstatTrcProgExitSw(SWITCH_NO);
//            }
//
//            if (context.traceSQL()) { 
//                cmpclxtx.setZstatTrcExecSqlSw(SWITCH_YES);
//            }
//            else {
//                cmpclxtx.setZstatTrcExecSqlSw(SWITCH_NO);
//            } 
      		
      	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
        }

        private void callCobol() {
            try {
                cmpclxtx.cobolMain();
            }catch(Exception _ex) {
                Throwable ex=_ex;

                while(ex.getCause()!=null) ex=ex.getCause();
                if(ex instanceof Stop) {
                    // if message number and category are not 0, meaning a server message is passed from the jacob code
                    if (cmpclxtx.getZmsgnMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
                            && cmpclxtx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
                        // pass the parameter to the server message
                        MessageParameters messageparameters = new MessageParameters();
                        for (int i = 1; i <= 9; i++) {
                            try { 
                                String parmValue = cmpclxtx.getParmCollMessageParm(i);
                                if (notBlank(parmValue)) {
                                    messageparameters.addRawString(parmValue.trim());
                                }
                            }
                            catch(IndexOutOfBounds e) {
                                break;
                            }

                        }
                        MessageCategory_Id categoryId = new MessageCategory_Id(cmpclxtx.getZmsgnMessageCatNbr().toBigInteger());
                        ServerMessage serverMessage = 
                                ServerMessageFactory.Factory.newInstance().createMessage(
                                        categoryId, cmpclxtx.getZmsgnMessageNbr().intValue(), messageparameters);

                        // check the message severity so we'll know what type of message to raise

                        // info
                        if (cmpclxtx.getZmsgnMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
                            logInfo(serverMessage);
                        }
                        // warning
                        else if (cmpclxtx.getZmsgnMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
                            logWarning(serverMessage);
                        }
                        // error
                        else {
                            logError(serverMessage);
                        }
                    }

                    // START DELETE - JHERNA - 2018-05-28 - SysAid#216236
                    // Move time-stamp of customer contact to the letter extract algorithm  
                    /*
                    // update letter print dttm
                    CustomerContact cc =ccId.getEntity();
                    CustomerContact_DTO dto = cc.getDTO();
                    dto.setLetterPrintDateTime(getProcessDateTime());
                    cc.setDTO(dto);
                    */
                    // END DELETE - JHERNA - 2018-05-28 - SysAid#216236
                    
                    // Start Add - SFelip - Defect 3512842 - 2016-09-27
                    // Retrieve all the warnings from the session.
                    List<ServerMessage> sessionWarnings = session.getWarnings();
                    Bool duplicateFound = Bool.FALSE;
                    String currentMessage = "";
                    
                    if(notNull(sessionWarnings) && !sessionWarnings.isEmpty()) {
                        for(ServerMessage warning : sessionWarnings) {
                            
                            duplicateFound = Bool.FALSE;
                            currentMessage = warning.getMessageText();
                            
                            if(notNull(warnings) && !warnings.isEmpty()) {
                                for(ServerMessage storedWarning : warnings) {
                                    
                                    String storedMessage = storedWarning.getMessageText();
                                    
                                    if(notNull(storedMessage)) {
                                        if(storedWarning.getMessageText().equals(currentMessage)) {
                                            duplicateFound = Bool.TRUE;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            // Add only distinct warnings to the warnings list. This will later be used in finalizedThreadWork.
                            if(duplicateFound.isFalse()) {
                                warnings.add(warning);
                            }
                        }
                    
                        // Clear all warnings from the session.
                        session.clearWarnings();
                    }
                    // End Add - SFelip - Defect 3512842 - 2016-09-27
                }
                else  {
                    //Start Add - MPang - Defect 3444302 - 2016-06-01
                    ex.printStackTrace();
                    //End Add - MPang - Defect 3444302 - 2016-06-01
                    // Start Change - SA-373868 - EQuint - 2021-07-14
                    // addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
                    String errMsg = ex.getMessage();
                    if (ex instanceof ApplicationError) {
                        ApplicationError appErr = (ApplicationError) ex;
                        errMsg = appErr.getServerMessage().getMessageText();
                    }
                    
                    addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(),errMsg));
                    // End Change - SA-373868 - EQuint - 2021-07-14
                }
            }
        }

        private String createPathName(){
            // Start Change - CCB034 - RDizon - 04-14-2021
            // generate filename
            // String fileName = getBatchControlId().getTrimmedValue() + String.format("%010d", getBatchNumber())
            //        + String.format("%010d", getBatchThreadNumber()) + letterTemplateId.getTrimmedValue() + PERIOD + LETTER_EXT;
            
            String fileName = getBatchControlId().getTrimmedValue() + String.format("%010d", getBatchNumber())
                            + String.format("%010d", getBatchThreadNumber()) + letterTemplateId.getTrimmedValue();
            if (wSeparateCisDivisionSw.isTrue()){
                 fileName = fileName + AL_GC_CIS_DIVISION + PERIOD + LETTER_EXT;
            }
            else {
                 fileName = fileName + PERIOD + LETTER_EXT;
            }
            // End Change - CCB034 - RDizon - 04-14-2021
            
            // replace spaces with underscore
            fileName = fileName.replaceAll("\\s+", "_");
            
            // check if file exist
            String fullPath = filePath + fileName;
            File file = new File(fullPath);
            if(!file.exists() || file.isDirectory()) { 
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    addError(CustomMessageRepository.JACOB_FileOpenError(e.getMessage()));
                }

                // close file
                FileOutputStream oFile;
                try {
                    oFile = new FileOutputStream(file, false);
                    oFile.close();
                } catch (FileNotFoundException e) {
                    addError(CustomMessageRepository.JACOB_FileOpenError(e.getMessage()));
                } catch (IOException e) {
                    addError(CustomMessageRepository.JACOB_FileCloseError(e.getMessage()));
                } 
            }
            
            // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
            // keep letter template filename
            // letterTemplateFileMap.put(letterTemplateId, fullPath);
            // // keep letter template count
            // BigInteger currentCount = letterTemplateCountMap.get(letterTemplateId);
            // if (isNull(currentCount)) {
            //     letterTemplateCountMap.put(letterTemplateId, BigInteger.ONE);
            // }
            // else {
            //     letterTemplateCountMap.put(letterTemplateId, currentCount.add(BigInteger.ONE));
            // }
            BigInteger currentCount = extractFileMap.get(fullPath);
            if (isNull(currentCount)) {
                extractFileMap.put(fullPath, BigInteger.ONE);
            }
            else {
                extractFileMap.put(fullPath, currentCount.add(BigInteger.ONE));
            }
            // End Change - CCB034.Issue4 - RDizon - 09-16-2021
            
            return fullPath;
        }
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        private Bool checkMainPersonCisDivision(Person person, String cisDivisions) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM AccountPerson AP, ");
            stringBuilder.append("    Account ACCT ");
            stringBuilder.append("WHERE AP.id.person = :person ");
            stringBuilder.append(    "AND AP.isMainCustomer = :isMainCustomer ");
            stringBuilder.append(    "AND AP.id.account = ACCT.id ");
            stringBuilder.append(    "AND ACCT.divisionId IN (" + cisDivisions + ")");
            
            Query query = createQuery(stringBuilder.toString(), "=getMainPersonAccount=");
            query.bindEntity("person", person);
            query.bindBoolean("isMainCustomer", Bool.TRUE);
            query.addResult("account", "ACCT.id");
            
            if (notNull(query.firstRow())){
                return Bool.TRUE;
            }
            else {
                return Bool.FALSE;   
            }
        }
        // End Add - CCB034 - RDizon - 04-14-2021
        
        
        // Start Add - Defect 4599345 - RDizon - 09-29-2021
        private Bool checkMainPersonCisDivisionWithAccount(Person person, Account account, String cisDivisions) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM AccountPerson AP, ");
            stringBuilder.append("    Account ACCT ");
            stringBuilder.append("WHERE AP.id.person = :person ");
            stringBuilder.append(    "AND AP.isMainCustomer = :isMainCustomer ");
            stringBuilder.append(    "AND AP.id.account = ACCT.id ");
            stringBuilder.append(    "AND ACCT.id = :account ");
            stringBuilder.append(    "AND ACCT.divisionId IN (" + cisDivisions + ")");

            Query query = createQuery(stringBuilder.toString(), "=getMainPersonAccount=");
            query.bindEntity("person", person);
            query.bindEntity("account", account);
            query.bindBoolean("isMainCustomer", Bool.TRUE);
            query.addResult("cisDivision", "ACCT.divisionId");
            
            if (notNull(query.firstRow())){
                return Bool.TRUE;
            }
            else {
                return Bool.FALSE;   
            }
        }
        // End Add - Defect 4599345 - RDizon - 09-29-2021
        
        // Start Add - Defect 4611170 - RDizon - 11-09-2021
        private CollectionProcess getCustomerContactCollectionProcess(){
            CollectionProcess collectionProcess = null;
            StringBuilder stringBuildert = new StringBuilder();
            PreparedStatement getCustomerContactCollectionProcess;
            
            stringBuildert.append("SELECT CE.COLL_PROC_ID ");
            stringBuildert.append("FROM CI_COLL_EVT_CC CE ");
            stringBuildert.append("WHERE CE.CC_ID = :ccId ");
            
            getCustomerContactCollectionProcess = createPreparedStatement(stringBuildert.toString(), getClass().getName());
            getCustomerContactCollectionProcess.bindId("ccId", ccId);
            
            SQLResultRow sqlRow = getCustomerContactCollectionProcess.firstRow();
            if (notNull(sqlRow)) {
                CollectionProcess_Id collProcId = (CollectionProcess_Id) sqlRow.getId("COLL_PROC_ID", CollectionProcess.class);
                collectionProcess = collProcId.getEntity();
            }
            
            getCustomerContactCollectionProcess.close();
            
            return collectionProcess;
        }
        
        private Money calculateAmountOwed(CollectionProcess collectionProcess) {
            Money amountOwed = Money.ZERO;
            Money tempAmountOwed = Money.ZERO;

            CollectionProcessServiceAgreements collProcSAs = collectionProcess.getServiceAgreements();
            Iterator<CollectionProcessServiceAgreement> collProcSAsItr;
            for (collProcSAsItr = collProcSAs.iterator(); collProcSAsItr.hasNext();) {
                CollectionProcessServiceAgreement collProcSa = collProcSAsItr.next();

                tempAmountOwed = collProcSa.fetchIdServiceAgreement().getCurrentBalance(Date.MAX, collectionProcess.getCollectionArrearsDate(), Bool.TRUE);
                amountOwed = amountOwed.add(tempAmountOwed);
            }

            return amountOwed;
        }
        // End Add - Defect 4611170 - RDizon - 11-09-2021
        
        // Start Add - CCB047.5 - DLampa - 06-22-2022        
        /**
         * This method will retrieve feature configuration
         * @param lookup ExternalSystemTypeLookup
         * @return featureConfiguration FeatureConfiguration
         */
        private FeatureConfiguration retrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
            FeatureConfiguration featureConfiguration = null;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfiguration fc ");
            stringBuilder.append(" WHERE fc.featureType = :featureType ");

            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            query.bindLookup("featureType", featureType);
            
            List<SQLResultRow> results = query.list();

            if (results.isEmpty()) {
                addError(CustomMessageRepository.CCB047_5_noFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
            }
            else if (results.size() > 1) {
                addError(CustomMessageRepository.CCB047_5_multipleFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
            }
            else {
                featureConfiguration = (FeatureConfiguration) query.firstRow();
            }

            return featureConfiguration;
        }
        
        /**
         * This method will retrieve feature configuration option value
         * @param featureConfiguration FeatureConfiguration
         * @param optionType String
         * @return optionValue String
         */
        private String retrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {
            String optionValue = "";

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfigurationOption fco ");
            stringBuilder.append(" WHERE fco.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco.id.optionType = :optionType ");

            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            
            query.bindEntity("workforceManagementSystem", featureConfiguration);
            query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, lookupValue.fetchIdFieldValue().trim());   
            query.addResult("value", "fco.value");

            List<SQLResultRow> results = query.list();
            
            if (results.isEmpty()) {
                addError(CustomMessageRepository.CCB047_5_noOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
            }
            else if (results.size() > 1) {
                addError(CustomMessageRepository.CCB047_5_multipleOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
            }
            else {
                optionValue = (String) query.firstRow();
            }

            return optionValue.trim();
        }  
        
        /**
         * This method will check if the business date is within the CWR season
         * @param serviceAgreement ServiceAgreement
         * @return bool isHeatingSeason
         */
        private Bool checkIfCwrSeason(){
            Bool isInsideOfthePeriod = Bool.FALSE;
            DateFormat dateFormat = new DateFormat(DATE_FORMAT_MMDDYYYY);
            
            int systemYear = this.getSystemDateTime().getYear();
            
            Date currentDate = this.getProcessDateTime().getDate();

            systemYear = this.getProcessDateTime().getYear();
            String cwrSeasonEndStr = cwrSeasonEndDate + "/" + systemYear;
            Date cwrSeasonEndDate = null;
            try {
                cwrSeasonEndDate = Date.fromString(cwrSeasonEndStr, dateFormat);
                if (currentDate.isAfter(cwrSeasonEndDate)) {
                    cwrSeasonEndDate = cwrSeasonEndDate.addYears(1);
                }
            }
            catch (Exception e) {}
            
            String cwrSeasonBeginStr = cwrSeasonBeginDate + "/" + cwrSeasonEndDate.getYear();
            Date cwrSeasonBeginDate = null;
            try {
                cwrSeasonBeginDate = Date.fromString(cwrSeasonBeginStr, dateFormat);
                if (cwrSeasonEndDate.isBefore(cwrSeasonBeginDate)) {
                    cwrSeasonBeginDate = cwrSeasonBeginDate.addYears(-1);
                }
            }
            catch (Exception e) {}
            if (currentDate.isAfter(cwrSeasonBeginDate) && currentDate.isBefore(cwrSeasonEndDate)) {
                isInsideOfthePeriod = Bool.TRUE;
            }
            
            return isInsideOfthePeriod;
        }  
        // End Add - CCB047.5 - DLampa - 06-22-2022        
        
        // Start Add - DLampa - E-06267.Issue1. - 03-02-2023
        /**
         * Create To Do Entry 
         */
        private void createToDo(Exception e) {
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            toDoEntryDTO.setMessageId(CustomMessageRepository.JACOB_exceptionDuringLetterProcessing(ccId.getTrimmedValue(), e.getLocalizedMessage()).getMessageId());
            
            toDoCreator.addMessageParameter(ccId.getTrimmedValue());
            toDoCreator.addMessageParameter(e.getLocalizedMessage());           
            
            toDoCreator.setToDoDTO(toDoEntryDTO);
                        
            // Use the Customer Contact ID as the Drill Key            
            List<ToDoDrillKeyType> drillKeyTypes = getDrillKeyTypes(toDoType.getId());
            for (ToDoDrillKeyType drillKeyType : drillKeyTypes) {
                toDoCreator.addDrillKeyValue(drillKeyType, ccId.getTrimmedValue());
            }                                    
            
            toDoCreator.create();
            
            // Update the Customer Contact's Batch Number so that it is processed in the succeeding run
            CustomerContact cc = ccId.getEntity();
            CustomerContact_DTO ccDto = cc.getDTO();
            ccDto.setBatchNumber(cc.getBatchNumber().add(BigInteger.ONE));
            cc.setDTO(ccDto);
            
        } 
        
        private List<ToDoDrillKeyType> getDrillKeyTypes(ToDoType_Id tdTypeID) {
            
            List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
            
            StringBuilder stringBuilder = new StringBuilder();                  
            stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
            stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
            stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
            
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=CmCreateLetterExtractBatch.getDrillKeyTypes=");
            prepState.bindId("tdTypeID", tdTypeID);
            prepState.setAutoclose(false);
            prepState.execute();
            
            if (prepState.list().size() > 0) {
                
                Iterator<SQLResultRow> iter = prepState.list().iterator();
                
                while (iter.hasNext()) {
                
                    SQLResultRow sqlRow = (SQLResultRow) iter.next();
                    BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                    ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
                    returnValue.add(tdDrillKeyTypeID.getEntity());
                }                               
            }           
            prepState.close();
            return returnValue;         
        }          
        // End Add - DLampa - E-06267.Issue1. - 03-02-2023        
    }

}
