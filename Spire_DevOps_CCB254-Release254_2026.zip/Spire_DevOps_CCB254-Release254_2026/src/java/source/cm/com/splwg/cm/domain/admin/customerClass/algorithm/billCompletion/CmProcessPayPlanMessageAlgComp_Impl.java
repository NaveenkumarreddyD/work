/**************************************************************************
* Program Name: CmProcessPayPlanMessageAlgComp_Impl
* Program Title: CmProcessPayPlanMessageAlgComp_Impl
* Author: Sharmayne Felipe
* Creation Date: 2017-03-02
* Purpose: This algorithm will check if an active pay plan exists and add 
*          a bill message for the customer. Since the pay plan scheduled 
*          payment is set 90 days out and the system will only mark the 
*          pay plan as kept on are after the scheduled payment date, we 
*          want to check if a pledge payment has been received since the 
*          pay plan start date and mark the pay plan as kept as well.
*  
* Functional Spec: CCB-CC-002
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-002.3      Sharmayne Felipe 2017-03-02    Initial Version
 *  Defect 4253862    El Quinto        2019-05-22    set prepared statement auto close 
 *  ID56 (Reopen)
 ************************************************************************************************/
package com.splwg.cm.domain.admin.customerClass.algorithm.billCompletion;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.currency.Currency;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.PaymentPlanStatusLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.TenderStatusLookup;
import com.splwg.ccb.api.lookup.ThirdPartyGuarantorLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.billCompletion.CustomerClassBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlan;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlan_DTO;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author SFelipe
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageType, required = true, type = entity)})
 */
public class CmProcessPayPlanMessageAlgComp_Impl extends
        CmProcessPayPlanMessageAlgComp_Gen implements
        CustomerClassBillCompletionAlgorithmSpot {
       
    // Constants
    private static final String COMMA = ",";
    private static final String PLEDGE_PAYMENT_FEAT_CONFIG = "CM-PLEDGEPAY";
    private static final String PLEDGE_TENDER_SRC_FEAT_OPT = "PLTS";
    
    // Hard parameters
    private Date accountingDate;
    private BillData billData;
    private Date billDate;
    private Currency currency;
    private Bool allowBillReopen;
        
    // Soft parameter
    private BillMessageType billMessageType;
    
    // Work variables
    private Account account;
    private Bill bill;
    private List<TenderSource_Id> tenderSourceIdList;
    private PaymentPlan payPlan;
    private Date payPlanStartDate;
    private Account payorAccount;
    private Money payPlanScheduledAmount = Money.ZERO;
    private Money pledgeAmount = Money.ZERO;
    
    @Override
    public Bool getAllowBillReopen() {
        return allowBillReopen;
    }

    @Override
    public BillData getBillData() {
        return billData;
    }

    @Override
    public void setAccountingDate(Date accountingDate) {
        this.accountingDate = accountingDate;
    }

    @Override
    public void setBillData(BillData billData) {
        this.billData = billData;
    }

    @Override
    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }

    @Override
    public void setCurrency(Currency currency) {
        this.currency = currency;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        // Retrieve the list of Pledge Tender Sources from the Pledge Payment Reconciliation Feature Configuration.
        FeatureConfiguration featureConfiguration = 
                new FeatureConfiguration_Id(PLEDGE_PAYMENT_FEAT_CONFIG).getEntity();
        
        CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        featConfigRetriever.setParmWFMName(featureConfiguration);
        featConfigRetriever.setParmOptType(PLEDGE_TENDER_SRC_FEAT_OPT);
        
       String tenderSourceList = featConfigRetriever.getMaxSequenceOptionValue();
        
        if(isBlankOrNull(tenderSourceList)){
            addError(CustomMessageRepository.CC_002_3_tenderSourceMissing(featureConfiguration.getId().getTrimmedValue()));
        }
        
        // Validate the list of Tender Sources.
        String[] tenderSources = tenderSourceList.split(COMMA);
        TenderSource_Id tenderSourceId = null;
        tenderSourceIdList = new ArrayList<TenderSource_Id>();
        
        for(String tenderSourceString : tenderSources){
            tenderSourceId =  new  TenderSource_Id(tenderSourceString);
            
            if(isNull(tenderSourceId.getEntity())){
                addError(CustomMessageRepository.CC_002_3_invalidTenderSource(
                        tenderSourceString, featureConfiguration.getId().getTrimmedValue()));
            }
            tenderSourceIdList.add(tenderSourceId);              
        }
        
        // Retrieve the Bill Message Type soft parameter.
        billMessageType = getBillMessageType();
    }

    @Override
    public void invoke() {
        
        // Set the allow bill to reopen switch to true.
        allowBillReopen = Bool.TRUE;
        
        // Retrieve the Account from the Bill Data hard parameter.
        account = billData.getBillDTO().fetchAccount();
        
        //  Retrieve the Bill from the Bill Data hard parameter.
        bill = billData.getBillDTO().getId().getEntity();
        
        // Check if an active third party payor pay plan exists for the account.
        getActiveThirdPartyPayor();
        
        // If no active third party payor pay plan exists, exit the algorithm.
        if(isNull(payPlan)) {
            return;
        }
        
        // Check if a pledge payment has already been received that satisfies the pay plan 
        // scheduled payment amount.
        checkIfPaymentReceived();
        
        if(pledgeAmount.isGreaterThan(Money.ZERO) && pledgeAmount.isGreaterThanOrEqual(payPlanScheduledAmount)) {
            // Update the status of the Pay Plan to "kept".
            PaymentPlan_DTO payPlanDto = payPlan.getDTO();
            payPlanDto.setPaymentPlanStatus(PaymentPlanStatusLookup.constants.KEPT);
            payPlan.setDTO(payPlanDto);
        } else {
            // Add a bill message to the bill using the bill message type parameter.
            BillMessage_Id billMessageId = new BillMessage_Id(billMessageType, bill);
            BillMessage billMessage = billMessageId.getEntity();
            
            if (isNull(billMessage)){
                bill.getMessages().add(new BillMessage_DTO(), billMessageType.getId());
            }
        }        
    }

    private void getActiveThirdPartyPayor() {
        
        StringBuilder getActivePayor = new StringBuilder();
        
        getActivePayor.append("SELECT A.PP_ID, A.START_DT, A.PAYOR_ACCT_ID, NVL(SUM(B.PP_SCHED_AMT), 0) SCHED_AMT ");
        getActivePayor.append("FROM CI_PP A, CI_PP_SCHED_PAY B ");
        getActivePayor.append("WHERE A.ACCT_ID =:accountId ");
        getActivePayor.append("AND A.PP_STAT_FLG =:activeStatus ");
        getActivePayor.append("AND A.THRD_PTY_SW =:isThirdParty ");
        getActivePayor.append("AND B.PP_ID = A.PP_ID ");
        getActivePayor.append("GROUP BY A.PP_ID, A.START_DT, A.PAYOR_ACCT_ID ");
        
        PreparedStatement getActivePayorQuery = createPreparedStatement(getActivePayor.toString(), 
                getClass().getName());
        
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getActivePayorQuery.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        
        getActivePayorQuery.bindLookup("activeStatus", PaymentPlanStatusLookup.constants.ACTIVE);
        getActivePayorQuery.bindId("accountId", account.getId());
        getActivePayorQuery.bindLookup("isThirdParty", ThirdPartyGuarantorLookup.constants.THIRD_PARTY_GUARANTOR);
        getActivePayorQuery.execute();
        
        SQLResultRow result = getActivePayorQuery.firstRow();
        
        if(notNull(result)) {
            payPlan = result.getEntity("PP_ID", PaymentPlan.class);
            payPlanStartDate = result.getDate("START_DT");
            payorAccount = result.getEntity("PAYOR_ACCT_ID", Account.class);
            payPlanScheduledAmount = result.getMoney("SCHED_AMT");
        }
        
        getActivePayorQuery.close();
    }
    
    private void checkIfPaymentReceived() {
        
        String pledgeTenderSources = " ";
        
        Iterator<TenderSource_Id> iter = tenderSourceIdList.iterator();
        
        while (iter.hasNext()) {
            TenderSource_Id tenderSourceID = iter.next();
            pledgeTenderSources = pledgeTenderSources.concat("'");
            pledgeTenderSources = pledgeTenderSources.concat(tenderSourceID.getTrimmedValue());
            pledgeTenderSources = pledgeTenderSources.concat("',");
        }
        
        // Remove the extra comma at the end of the string
        pledgeTenderSources = pledgeTenderSources.substring(0, (pledgeTenderSources.length() - 1));
        
        StringBuilder getPayment = new StringBuilder();
        getPayment.append("SELECT NVL(SUM(D.PAY_AMT), 0) PAY_AMT ");
        getPayment.append("FROM CI_PAY_TNDR A, CI_TNDR_CTL B, CI_PAY_EVENT C, CI_PAY D ");
        getPayment.append("WHERE D.ACCT_ID =:account ");
        getPayment.append("AND D.PAY_STATUS_FLG =:frozenStatus ");
        getPayment.append("AND C.PAY_EVENT_ID = D.PAY_EVENT_ID ");
        getPayment.append("AND C.PAY_DT >=:payPlanCreateDate ");
        getPayment.append("AND A.PAY_EVENT_ID = C.PAY_EVENT_ID ");
        getPayment.append("AND A.TNDR_STATUS_FLG =:validStatus ");
        getPayment.append("AND A.TNDR_CTL_ID = B.TNDR_CTL_ID ");
        getPayment.append("AND B.TNDR_SOURCE_CD IN (" + pledgeTenderSources.trim() + ") ");
        
        PreparedStatement getPaymentQuery = createPreparedStatement(getPayment.toString(), 
                getClass().getName());
        
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getPaymentQuery.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        
        getPaymentQuery.bindLookup("validStatus", TenderStatusLookup.constants.VALID);
        getPaymentQuery.bindDate("payPlanCreateDate", payPlanStartDate);
        getPaymentQuery.bindLookup("frozenStatus", PaymentStatusLookup.constants.FROZEN);
        getPaymentQuery.bindEntity("account", payorAccount);
        
        getPaymentQuery.execute();
        
        SQLResultRow result = getPaymentQuery.firstRow();
        
        pledgeAmount = result.getMoney("PAY_AMT");
        
        getPaymentQuery.close();
    }
}
