/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm will calculate and apply a late payment charge for 
 * MGE customers based solely on their previous month's unpaid dues. 
 * Finals bills will be excluded from late payment charges. 
 * 
 * 
 ********************************************************************** 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason: 
 * 2015-02-19  DHUYNH    MGE-CCB012. Initial Version.
 * 2016-01-26  MPang	 Updated for CCB v2.4 compilation.                
 ************************************************************************ 
 */

package com.splwg.cm.domain.admin.serviceAgreementType;
import java.util.List;
import com.splwg.base.api.datatypes.TimeInterval;
import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.billFactor.BillFactor;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeLpcCalculationAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.data.BillFactorValueData;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoData;
import com.splwg.ccb.domain.admin.common.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.lpcCalculation.SaTypeLpcCalculationAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author DHUYNH
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = lpcAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billFactor, name = billFactor, required = true, type = entity)})
 */
public class CmMGELatePaymentChargeCalculationAlgComp_Impl 
		extends CmMGELatePaymentChargeCalculationAlgComp_Gen 
		implements SaTypeLpcCalculationAlgorithmSpot {
	
	// Soft Parameter Variables
	private AdjustmentType adjustmentType;
	private BillFactor billFactor;

	// Hard Parameter variables
	private Bill bill;
	private Date billDate;
	private ServiceAgreement serviceAgreement;

	// Work varibales
	private static final TimeInterval ONE_DAY = new TimeInterval(TimeInterval.MS_IN_DAY);
	private Money latePaymentAmount;

	public AdjustmentType getAdjustmentType() {
		return this.adjustmentType;
	}

	public Money getLatePaymentAmount() {
		return latePaymentAmount;
	}

	public void setBill(Bill bill) {
		this.bill = bill;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		this.serviceAgreement = serviceAgreement;
	}

	public void invoke() {

		latePaymentAmount = Money.ZERO;
		
		// Get the Bill Segment's Closing Switch
		cmGetBillSegmentClosingSwitch();
		
		if (notNull(cmGetBillSegmentClosingSwitch().firstRow())) {
			latePaymentAmount = Money.ZERO;
			return;
		} else {
			Money amountToChargeLate = Money.ZERO;
			
			// Get the Bill Factor Value
			BigDecimal billFactorValue = cmGetBillFactorValue();
			
			// Subtract oneday from billdate
			Date billDateMinusOne = billDate.subtract(ONE_DAY);
			
			// Retrieve Cal amount base on the bill date
			Money latestBillSegCalAmount = cmGetCalAmount();
			
			// Retrieve saBlance one day before bill date
			Money saBalanceADayBeforeBillDate = serviceAgreement
					.getCurrentBalance(billDate.subtract(ONE_DAY), billDate
							.subtract(ONE_DAY), Bool.TRUE);
			
			// Retrieve total frozen payment since the last bill date
			Money frozenPaymentSinceLatestBillDate = cmGetPayAmount(billDateMinusOne);

			if (saBalanceADayBeforeBillDate.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				
				Money remainderAmountDue = frozenPaymentSinceLatestBillDate.subtract(saBalanceADayBeforeBillDate);
				
				if (remainderAmountDue.getAmount().compareTo(BigDecimal.ZERO) > 0) {
					amountToChargeLate = latestBillSegCalAmount.subtract(remainderAmountDue);
				} else {
					amountToChargeLate = latestBillSegCalAmount;
				}
				
			} else {
				amountToChargeLate = latestBillSegCalAmount.subtract(frozenPaymentSinceLatestBillDate);
			}
			
			// Check to calculate late fee only if the amount to be calculating
			// for late fee greater than zero
			if (amountToChargeLate.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
				latePaymentAmount = Money.ZERO;
			} else {
				// Calculate late fee
				BigDecimal amount = amountToChargeLate.getAmount().multiply(
						billFactorValue.divide(BigDecimal.valueOf(100)))
						.setScale(2, BigDecimal.ROUND_HALF_UP);
				latePaymentAmount = new Money(amount, serviceAgreement
						.getCurrencyId());
			}
		}
	}
	
	   /**
	    * This method to retrieve the latest bill segment calculate amount base on the bill date
	    * @return wLatestBillSegCalAmount
	    */		   
		private Money cmGetCalAmount() {
			Money wLatestBillSegCalAmount = Money.ZERO;	
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT SUM(C.CALC_AMT) CALAMT ");
			stringBuilder.append("FROM CI_BSEG B, CI_BSEG_CALC C ");
			stringBuilder.append("WHERE B.SA_ID  = :SaId ");
			stringBuilder.append("AND B.BSEG_ID = C.BSEG_ID ");			
			stringBuilder.append("AND B.BILL_ID = :BillId ");	
			//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindEntity("SaId", serviceAgreement);
			prepState.bindEntity("BillId", bill);
			
			List<SQLResultRow> resultList = prepState.list();

	        if(resultList.isEmpty()){
	        	wLatestBillSegCalAmount = Money.ZERO;
	        }else{
	        	wLatestBillSegCalAmount = resultList.get(0).getMoney("CALAMT");
	        }
	        if(isNull(wLatestBillSegCalAmount)){
	        	wLatestBillSegCalAmount = Money.ZERO;
	        }

			prepState.close();
	        return wLatestBillSegCalAmount;
		}
		
		/**
		 * This method to retrieve the SA balance a day before Bill Date
		 * @param wBillDateMinusOne
		 * @return wTotalPaymentADayBeforeBillDate
		 */
		private Money cmGetPayAmount(Date wBillDateMinusOne) {
			
			Money wTotalPaymentADayBeforeBillDate = Money.ZERO;
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT SUM(PAY_AMT) AS PYMNT ");
			stringBuilder.append("FROM CI_PAY_EVENT A, CI_PAY B, CI_PAY_SEG C ");
			stringBuilder.append("WHERE C.SA_ID = :SaId ");
			stringBuilder.append("AND B.PAY_ID = C.PAY_ID ");			
			stringBuilder.append("AND A.PAY_EVENT_ID = B.PAY_EVENT_ID ");
			stringBuilder.append("AND A.PAY_DT >=  :xdate ");
			stringBuilder.append("AND B.PAY_STATUS_FLG = :frozen ");	
			//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindEntity("SaId", serviceAgreement);
			prepState.bindDate("xdate", wBillDateMinusOne);
			prepState.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);			

			List<SQLResultRow> resultList = prepState.list();

	        if(resultList.isEmpty()){
	        	wTotalPaymentADayBeforeBillDate = Money.ZERO;
	        }else{
	        	wTotalPaymentADayBeforeBillDate = resultList.get(0).getMoney("PYMNT");
	        }
	        if(isNull(wTotalPaymentADayBeforeBillDate)){
	        	wTotalPaymentADayBeforeBillDate = Money.ZERO;
	        }
            prepState.close();
            return wTotalPaymentADayBeforeBillDate;	
		}
		
	/**
	 * This method will retrieve algorithm parameters
	 * @param isValid boolean
	 */
	@Override	
	protected void extraSoftParameterValidations(boolean isValid) {
		adjustmentType = this.getLpcAdjustmentType();
		billFactor = this.getBillFactor();
	}	
	
	/**
	 * This method will retrieve bill segment closing switch
	 * @return query
	 */	
	private Query cmGetBillSegmentClosingSwitch() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(" FROM Bill b, BillSegment bs ");
		stringBuilder.append(" WHERE b.id = :billId ");
		stringBuilder.append(" AND b.id = bs.billId ");
		stringBuilder.append(" AND bs.serviceAgreement = :serviceAgreement ");
		stringBuilder.append(" AND bs.billSegmentStatus = :billSegmentStatus ");
		stringBuilder.append(" AND bs.isClosingBillSegment = :billSegCloseSw ");
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//Query query = createQuery(stringBuilder.toString());
		Query query = createQuery(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		query.addResult("isClosingBillSegment", "bs.isClosingBillSegment");		
		query.bindId("billId", bill.getId());
		query.bindEntity("serviceAgreement", serviceAgreement);
		query.bindLookup("billSegmentStatus", BillSegmentStatusLookup.constants.FROZEN);
		query.bindBoolean("billSegCloseSw",Bool.TRUE);		
		return query;
	}
	
	/**
	 * This method will retrieve bill factor value
	 * @return billFactorValue
	 */	
	private BigDecimal cmGetBillFactorValue() {	
		
		// Retrieve the Bill Factor Value.
		BillFactorValueInfoRetrieverData billFactorValueRetrieverData = BillFactorValueInfoRetrieverData.Factory.newInstance();
		billFactorValueRetrieverData.setBillFactor(billFactor);
		billFactorValueRetrieverData.setServiceAgreement(serviceAgreement);
		billFactorValueRetrieverData.setBillFactorPeriodStartDate(billDate);
		billFactorValueRetrieverData.setBillFactorPeriodEndDate(billDate);
		billFactorValueRetrieverData.setCharSourcePremise(serviceAgreement.fetchPremise());
		billFactorValueRetrieverData.setNoProrationAccountingDate(billDate);
		billFactorValueRetrieverData.setNoProrationStartDate(billDate);
		billFactorValueRetrieverData.setNoProrationEndDate(billDate);
		billFactorValueRetrieverData.setToFillTheGap(Bool.FALSE);				
		BillFactorValueInfoRetriever billFactorValueInfoRetriever = BillFactorValueInfoRetriever.Factory.newInstance();
		billFactorValueInfoRetriever.retrieveBillFactorValueInfo(billFactorValueRetrieverData);		
		BillFactorValueInfoData billFactorVal = billFactorValueRetrieverData.getBillFactorValueInfoData();	
		
		// Retrieve the Bill Factor Value Data List.
		
		List<BillFactorValueData> billFactorValueDataList = billFactorVal.getBillFactorValueDataList();				
		if (billFactorValueDataList.isEmpty()) {
			addError(CustomMessageRepositoryMGE.ccb012_NoBillFactorValueRetrieved(billFactor.getId().getTrimmedValue(), billDate.toString()));
		}		
		return billFactorValueDataList.get(0).getBfValue();
	}
}
