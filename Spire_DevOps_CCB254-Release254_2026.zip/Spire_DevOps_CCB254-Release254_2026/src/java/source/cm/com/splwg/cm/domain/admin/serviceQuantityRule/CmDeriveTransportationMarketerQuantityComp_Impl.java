/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB011: Transportation Billing
 * 
 * This algorithm will be used to accumulate a quantity for a marketer. 
 * For example, this algorithm may be used to accumulated customer's 
 * nominated therms, actual usage or imbalance therms.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-03-04   JHERNA          MGE-CCB011: Initial Version.
 * 2015-06-17	JHERNA			3237365: catch error when no SQ Collection.  
 * 2016-01-26   MPang			Updated for CCB v2.4 compilation.  
 * 2017-03-23	JHERNA			SysAid#93194.
 * 2019-01-15   MPang           Defect 4133027. Changed the bindId to
 *                              bindStringProperty and updated the 
 *                              concatenation of error.
 * 2019-05-22   EQuint	        Defect 4253862 - ID56 - set prepared statement auto close
 **************************************************************************
 */
package com.splwg.cm.domain.admin.serviceQuantityRule;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceQuantityLookup;

//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.ServiceAgreementRelationshipType;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.ServiceAgreementRelationshipType_Id;
import com.splwg.ccb.domain.admin.serviceProvider.ServiceProvider_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceQuantityRule.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentItemData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.common.characteristic.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.rate.ApplyRateData;
import com.splwg.cm.domain.common.customBusinessComponent.CmTransportationBillingRoutine;*/

import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.entity.ServiceAgreementRelationshipType;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.entity.ServiceAgreementRelationshipType_Id;
import com.splwg.ccb.domain.admin.serviceProvider.entity.ServiceProvider_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.data.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import  com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
import com.splwg.cm.domain.common.customBusinessComponent.CmTransportationBillingRoutine;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
 @BusinessComponent (customizationCallable = true)
 */
public class CmDeriveTransportationMarketerQuantityComp_Impl 
		extends GenericBusinessComponent 
		implements CmDeriveTransportationMarketerQuantityComp, ServiceQuantityRuleComponent {

	// Hard Parameters
	private ApplyRateData hpApplyRateDate;
	private List<BillSegmentItemData> hpCollOfBsegItemData;
	private List<BillSegmentReadData> hpCollOfBsegReadData;
	private List<BillSegmentServiceQuantityData> hpCollOfBsegSQData;
	private List<CharacteristicData> hpCollOfCharacteristicData;	
	private ServiceQuantityIdentifier_Id hpSqiID;
	private ServiceQuantityLookup hpSQLookup;
	private Bool hpShouldCreateBillingError;
	private TimeOfUse_Id hpTouID;
	private UnitOfMeasure_Id hpUomID;
	
	// Soft Parameters
	private String parm1;
	private String parm2;
	private String parm3;
	private String parm4;
	private String parm5;
	private String parm6;
	private String parm7;
	private String parm8;
	private String parm9;
	private String parm10;
	private ServiceAgreementRelationshipType parmSARelationshipType;
	private CharacteristicType parmCharTypeMarketerPool;
	private UnitOfMeasure parmSourceUOM;
	private TimeOfUse parmSourceTOU;
	private ServiceQuantityIdentifier parmSourceSQI;
	
	// Constants
	private static final String ALG_DESC = "Derive Transportation Marketer Quantity";
	private static final String PARM10_DESC = "SA Relationship Type";
	private static final String PARM20_DESC = "Characteristic Type for Customer Pool";
	private static final String PARM30_DESC = "Source UOM";
	private static final String PARM40_DESC = "Source TOU";
	private static final String PARM50_DESC = "Source SQI";
	//================//
	// Getter methods //
	//================//
	/**
	 * Method which returns the apply rate date
	 */
	public ApplyRateData getApplyRateData() {
		return hpApplyRateDate;
	}
	/**
	 * Method which returns the collection of bill segment item data
	 */
	public List<BillSegmentItemData> getBillSegmentItemData() {
		return hpCollOfBsegItemData;
	}
	/**
	 * Method which returns the collection of bill segment read data
	 */
	public List<BillSegmentReadData> getBillSegmentReadData() {
		return hpCollOfBsegReadData;
	}
	/**
	 * Method which returns the collection of bill segment service quantity data
	 */
	public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
		return hpCollOfBsegSQData;
	}
	/**
	 * Method which returns the collection of characteristic data
	 */
	public List<CharacteristicData> getCharacteristicData() {
		return hpCollOfCharacteristicData;
	}
	/**
	 * Method which returns the sq rule parameter 1
	 */
	public String getSQRuleParameter1() {
		return parm1;
	}
	/**
	 * Method which returns the sq rule parameter 10
	 */
	public String getSQRuleParameter10() {
		return parm10;
	}
	/**
	 * Method which returns the sq rule parameter 2
	 */
	public String getSQRuleParameter2() {
		return parm2;
	}
	/**
	 * Method which returns the sq rule parameter 3
	 */
	public String getSQRuleParameter3() {
		return parm3;
	}
	/**
	 * Method which returns the sq rule parameter 4
	 */
	public String getSQRuleParameter4() {
		return parm4;
	}
	/**
	 * Method which returns the sq rule parameter 5
	 */
	public String getSQRuleParameter5() {
		return parm5;
	}
	/**
	 * Method which returns the sq rule parameter 6
	 */
	public String getSQRuleParameter6() {
		return parm6;
	}
	/**
	 * Method which returns the sq rule parameter 7
	 */
	public String getSQRuleParameter7() {
		return parm7;
	}
	/**
	 * Method which returns the sq rule parameter 8
	 */
	public String getSQRuleParameter8() {
		return parm8;
	}
	/**
	 * Method which returns the sq rule parameter 9
	 */
	public String getSQRuleParameter9() {
		return parm9;
	}
	/**
	 * Method which returns the sq rule's SQI 
	 */
	public ServiceQuantityIdentifier_Id getServiceQuantityIdentifierId() {
		return hpSqiID;
	}
	/**
	 * Method which returns the sq rule's SQ Lookup
	 */
	public ServiceQuantityLookup getServiceQuantityLookup() {
		return hpSQLookup;
	}
	/**
	 * Method which returns the sq rule's should create billing error flag
	 */
	public Bool getShouldCreateBillingError() {
		return hpShouldCreateBillingError;
	}
	/**
	 * Method which returns the sq rule's TOU
	 */
	public TimeOfUse_Id getTimeOfUseId() {
		return hpTouID;
	}
	/**
	 * Method which returns the sq rule's UOM
	 */
	public UnitOfMeasure_Id getUnitOfMeasureId() {
		return hpUomID;
	}
	
	//================//
	// Setter methods //
	//================//
	/**
	 * Method which sets the apply rate data
	 */
	public void setApplyRateData(ApplyRateData applyRateData) {
		hpApplyRateDate = applyRateData;
	}
	/**
	 * Method which sets the collection of bill segment item data
	 */
	public void setBillSegmentItemData(List<BillSegmentItemData> listBillSegmentItemData) {
		hpCollOfBsegItemData = listBillSegmentItemData;
	}
	/**
	 * Method which sets the collection of bill segment read data
	 */
	public void setBillSegmentReadData(List<BillSegmentReadData> listBillSegmentReadData) {
		hpCollOfBsegReadData = listBillSegmentReadData;
	}
	/**
	 * Method which sets the collection of bill segment service quantity data
	 */
	public void setBillSegmentServiceQuantityData(
			List<BillSegmentServiceQuantityData> listBillSegmentServiceQuantityData) {
		hpCollOfBsegSQData = listBillSegmentServiceQuantityData;
	}
	/**
	 * Method which sets the collection of characteristic data
	 */
	public void setCharacteristicData(List<CharacteristicData> listCharacteristicData) {
		hpCollOfCharacteristicData = listCharacteristicData;
	}
	/**
	 * Method which sets the sq rule's parameter 1
	 */
	public void setSQRuleParameter1(String sqrParm1) {
		parm1 = sqrParm1;
	}
	/**
	 * Method which sets the sq rule's parameter 10
	 */
	public void setSQRuleParameter10(String sqrParm10) {
		parm10 = sqrParm10;
	}
	/**
	 * Method which sets the sq rule's parameter 2
	 */
	public void setSQRuleParameter2(String sqrParm2) {
		parm2 = sqrParm2;
	}
	/**
	 * Method which sets the sq rule's parameter 3
	 */
	public void setSQRuleParameter3(String sqrParm3) {
		parm3 = sqrParm3;
	}
	/**
	 * Method which sets the sq rule's parameter 4
	 */
	public void setSQRuleParameter4(String sqrParm4) {
		parm4 = sqrParm4;
	}
	/**
	 * Method which sets the sq rule's parameter 5
	 */
	public void setSQRuleParameter5(String sqrParm5) {
		parm5 = sqrParm5;
	}
	/**
	 * Method which sets the sq rule's parameter 6
	 */
	public void setSQRuleParameter6(String sqrParm6) {
		parm6 = sqrParm6;
	}
	/**
	 * Method which sets the sq rule's parameter 7
	 */
	public void setSQRuleParameter7(String sqrParm7) {
		parm7 = sqrParm7;
	}
	/**
	 * Method which sets the sq rule's parameter 8
	 */
	public void setSQRuleParameter8(String sqrParm8) {
		parm8 = sqrParm8;
	}
	/**
	 * Method which sets the sq rule's parameter 9
	 */
	public void setSQRuleParameter9(String sqrParm9) {
		parm9 = sqrParm9;
	}
	/**
	 * Method which sets the sq rule's SQI
	 */
	public void setServiceQuantityIdentifierId(ServiceQuantityIdentifier_Id sqiID) {
		hpSqiID = sqiID;
	}
	/**
	 * Method which sets the sq rule's SQ Lookup
	 */
	public void setServiceQuantityLookup(ServiceQuantityLookup sqLookup) {
		hpSQLookup = sqLookup;
	}
	/**
	 * Method which sets the sq rule's should create billing error flag
	 */
	public void setShouldCreateBillingError(Bool shouldCreateBillingError) {
		hpShouldCreateBillingError = shouldCreateBillingError;
	}
	/**
	 * Method which sets the sq rule's TOU
	 */
	public void setTimeOfUseId(TimeOfUse_Id touID) {
		hpTouID = touID;
	}
	/**
	 * Method which sets the sq rule's UOM
	 */
	public void setUnitOfMeasureId(UnitOfMeasure_Id uomID) {
		hpUomID = uomID;
	}
	/**
	 * Custom method which retrieves and validates the input soft parameters
	 */
	private void cmRetrieveAndValidateParameters() {
		
		// Retrieve and Validate Parameter 10: SA Relationship Type
		if (isBlankOrNull(parm1)) {
		    // Algorithm %1's parameter '%2%3' is missing. This is a required parameter.
			addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterMissing(ALG_DESC, PARM10_DESC));
		}
		ServiceAgreementRelationshipType_Id saRelTypeID = new ServiceAgreementRelationshipType_Id(parm1.trim());
		if (isNull(saRelTypeID.getEntity())) {
			// SQ Rule %2%3's parameter '%4%5' has an invalid value (%1).
			addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterIsInvalid(ALG_DESC, PARM10_DESC, parm1));
		}
		parmSARelationshipType = saRelTypeID.getEntity();
		// Retrieve and Validate  Parameter 20: Characteristic Type for Customer Pool
		if (isBlankOrNull(parm2)) {
		    // SQ Rule %1%2's parameter '%3%4' is missing. This is a required parameter.
			addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterMissing(ALG_DESC, PARM20_DESC));
		}
		CharacteristicType_Id charTypeID = new CharacteristicType_Id(parm2.trim());
		if (isNull(charTypeID.getEntity())) {
			// SQ Rule %2%3's parameter '%4%5' has an invalid value (%1).			
			addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterIsInvalid(ALG_DESC, PARM20_DESC, parm2));
		}	
		parmCharTypeMarketerPool = charTypeID.getEntity();
		// SQ Rule %1 must provide at least one source parameter. Either the Source UOM, TOU or SQI. 
		if (isBlankOrNull(parm3)
				&& isBlankOrNull(parm4)
				&& isBlankOrNull(parm5)) {
			// SQ Rule %1 must provide at least one source parameter. Either the Source UOM, TOU or SQI.
			addError(CustomMessageRepositoryMGE.ccb011SQRuleMustHaveAtLeastOneParameterSourcePopulated(ALG_DESC));
		}
		// Retrieve and Validate Parameter 30: Source UOM
		if (notBlank(parm3)) {
			UnitOfMeasure_Id uomID = new UnitOfMeasure_Id(parm3.trim());
			if (isNull(uomID.getEntity())) {
				// SQ Rule %2%3's parameter '%4%5' has an invalid value (%1).			
				addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterIsInvalid(ALG_DESC, PARM30_DESC, parm3));
			}	
			parmSourceUOM = uomID.getEntity();
		}
		// Retrieve and Validate Parameter 40: Source TOU
		if (notBlank(parm4)) {
			TimeOfUse_Id touID = new TimeOfUse_Id(parm4.trim());
			if (isNull(touID.getEntity())) {
				// SQ Rule %2%3's parameter '%4%5' has an invalid value (%1).				
				addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterIsInvalid(ALG_DESC, PARM40_DESC, parm4));
			}	
			parmSourceTOU = touID.getEntity();
		}
		// Retrieve and Validate Parameter 50: Source SQI
		if (notBlank(parm5)) {
			ServiceQuantityIdentifier_Id sqiID = new ServiceQuantityIdentifier_Id(parm5.trim());
			if (isNull(sqiID.getEntity())) {
				// SQ Rule %2%3's parameter '%4%5' has an invalid value (%1).		
				addError(CustomMessageRepositoryMGE.ccb011SQRuleParameterIsInvalid(ALG_DESC, PARM50_DESC, parm5));
			}
			parmSourceSQI = sqiID.getEntity();
		}
	}
	
	/**
	 * Main method
	 */
	public void invoke() {
		// Retrieve and Validate Algorithm Parameters
		cmRetrieveAndValidateParameters();
		
		// Retrieve Service Agreement
		ServiceAgreement serviceAgreement = hpApplyRateDate.getServiceAgreement();
		
		// Initialize Total Init SQ and Total Bill SQ
		BigDecimal totalInitSQ = BigDecimal.ZERO;
		BigDecimal totalBillSQ = BigDecimal.ZERO;
		CmTransportationBillingRoutine transportationBillingRoutine = CmTransportationBillingRoutine.Factory.newInstance();
		
		// Retrieve Service Provider
		ServiceProvider_Id serviceProviderID = transportationBillingRoutine.getMarketerServiceProvider(serviceAgreement.getId(),
				parmCharTypeMarketerPool.getId());
		if (isNull(serviceProviderID)) {
			// Cannot retrieve transportation marketer Service Provider for Service Agreement (%1).
			addError(CustomMessageRepositoryMGE.ccb011CannotRetrieveServiceProviderOfSA(serviceAgreement.getId().getTrimmedValue()));
		}
		
		// Retrieve Customer Pool
		String customerPool = transportationBillingRoutine.getCustomerPool(serviceAgreement.getId(), parmCharTypeMarketerPool.getId());
		if (isBlankOrNull(customerPool)) {
			// Cannot retrieve transportation marketer customer pool characteristic value for SA (%1)
			addError(CustomMessageRepositoryMGE.ccb011CannotRetrieveCustomerPoolCharSA(serviceAgreement.getId().getTrimmedValue()));
		}
		
		// START CHANGE - JHERNA - 2017-03-23 - SysAid#93194
		/*Moved this here from below so the variables can be used for the routine*/
		Date startPeriodDate = hpApplyRateDate.getBillSegmentPeriodStart();
		Date endPeriodDate = hpApplyRateDate.getBillSegmentPeriodEnd();
		
		/*Added start period date and end period date to the routine method's arguments*/
		// Get collection of End Customers for the Service Provider's Customer Pool
		List<ServiceAgreement_Id> collOfEndCustomers = transportationBillingRoutine.retrieveServiceProviderEndCustomersPerPool(serviceProviderID, 
				parmSARelationshipType.getId(),
				parmCharTypeMarketerPool.getId(),
				customerPool,
		//		this.getProcessDateTime().getDate());
				this.getProcessDateTime().getDate(),
				startPeriodDate,
				endPeriodDate
				);
			
		/*Move these above so the variables can be used for the routine*/
		/*
		// Retrieve the Frozen Bill Segment of the SAs in the collection which overlaps the current bill period
		Date startPeriodDate = hpApplyRateDate.getBillSegmentPeriodStart();
		Date endPeriodDate = hpApplyRateDate.getBillSegmentPeriodEnd();
		*/
		// END CHANGE - JHERNA - 2017-03-23 - SysAid#93194
		Iterator<ServiceAgreement_Id> iter = collOfEndCustomers.iterator();
		while (iter.hasNext()) {
		
			ServiceAgreement_Id saIDInColl = (ServiceAgreement_Id) iter.next();
			
			Iterator<BillSegment_Id> iterBsegID = cmRetrieveBillSegments(saIDInColl, startPeriodDate, endPeriodDate);
			// Retrieve total SQs from the bill segments
			while (iterBsegID.hasNext()) {
				
				BillSegment_Id bsegID = (BillSegment_Id) iterBsegID.next();

				UnitOfMeasure_Id sourceUOMID = UnitOfMeasure_Id.NULL;
				TimeOfUse_Id sourceTOUID = TimeOfUse_Id.NULL;
				ServiceQuantityIdentifier_Id sourceSQIID = ServiceQuantityIdentifier_Id.NULL;
				
				if (notNull(parmSourceUOM)) {
					sourceUOMID = parmSourceUOM.getId();
				}
				if (notNull(parmSourceTOU)) {
					sourceTOUID = parmSourceTOU.getId();
				}
				if (notNull(parmSourceSQI)) {
					sourceSQIID = parmSourceSQI.getId();
				}
				
				StringBuilder getBsegTotalSQs = new StringBuilder();			
				getBsegTotalSQs.append("SELECT SUM(INIT_SQ) TOT_INITSQ, SUM(BILL_SQ) TOT_BILLSQ ");
				getBsegTotalSQs.append("FROM CI_BSEG_SQ "); 
				getBsegTotalSQs.append("WHERE BSEG_ID = :bsegID ");
				getBsegTotalSQs.append("AND UOM_CD = :sourceUomCd ");
				getBsegTotalSQs.append("AND TOU_CD = :sourceTouCd ");
				getBsegTotalSQs.append("AND SQI_CD = :sourceSqiCd ");
				
				//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
				//PreparedStatement prepState = createPreparedStatement(getBsegTotalSQs.toString());
				PreparedStatement prepState = createPreparedStatement(getBsegTotalSQs.toString(), getClass().getName());
				//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
                // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
                prepState.setAutoclose(false);
                // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
				prepState.bindId("bsegID", bsegID);
				// Start Change - MPang - 2019-01-15 - Defect 4133027
				//prepState.bindId("sourceUomCd", sourceUOMID);
				//prepState.bindId("sourceTouCd", sourceTOUID);
				//prepState.bindId("sourceSqiCd", sourceSQIID);
				prepState.bindStringProperty("sourceUomCd", BillSegmentServiceQuantity.properties.unitOfMeasure, notNull(sourceUOMID) ? sourceUOMID.getIdValue() : " ");
				prepState.bindStringProperty("sourceTouCd", BillSegmentServiceQuantity.properties.timeOfUse, notNull(sourceTOUID) ? sourceTOUID.getIdValue() : " ");
				prepState.bindStringProperty("sourceSqiCd", BillSegmentServiceQuantity.properties.serviceQuantityIdentifier, notNull(sourceSQIID) ? sourceSQIID.getIdValue() : " ");
				// End Change - MPang - 2019-01-15 - Defect 4133027
				prepState.execute();

				// START CHANGES - JHERNA - 2015-06-17 - 3237365
				if (prepState.list().size() > 0) {
					SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
					BigDecimal bsegInitSQ = (BigDecimal) sqlRow.getBigDecimal("TOT_INITSQ");
					BigDecimal bsegBillSQ = (BigDecimal) sqlRow.getBigDecimal("TOT_BILLSQ");

					if (isNull(bsegInitSQ) 
							|| isNull(bsegBillSQ)) {
						
						String uom = " ";
						String tou = " ";
						String sqi = " ";
						
						if (notNull(sourceUOMID)) {
							uom = uom.concat("UOM (");
							// Start Change - MPang - 2019-01-15 - Defect 4133027
							//uom = uom.concat(sourceUOMID.getTrimmedValue());
							uom = uom.concat(sourceUOMID.getIdValue().trim());
							// End Change - MPang - 2019-01-15 - Defect 4133027
							uom = uom.concat(") ");
						}
						if (notNull(sourceTOUID)) {
							// Start Change - MPang - 2019-01-15 - Defect 4133027
							//tou = uom.concat("TOU (");
							//tou = tou.concat(sourceTOUID.getTrimmedValue());
							//tou = uom.concat(") ");
							tou = tou.concat("TOU (");
							tou = tou.concat(sourceTOUID.getIdValue().trim());
							tou = tou.concat(") ");
							// End Change - MPang - 2019-01-15 - Defect 4133027
						}
						if (notNull(sourceSQIID)) {
							// Start Change - MPang - 2019-01-15 - Defect 4133027
							//sqi = uom.concat("SQI (");
							//sqi = sqi.concat(sourceSQIID.getTrimmedValue());
							//sqi = uom.concat(") ");
							sqi = sqi.concat("SQI (");
							sqi = sqi.concat(sourceSQIID.getIdValue().trim());
							sqi = sqi.concat(") ");
							// End Change - MPang - 2019-01-15 - Defect 4133027
						}
						prepState.close();
						// UOM/TOU/SQI : %1 /%2 /%3  quantity not found in SQ Collection
						addError(CustomMessageRepositoryMGE.ccb011CannotRetrieveSQCollection(uom, tou, sqi));
					}
					totalInitSQ = totalInitSQ.add(bsegInitSQ);
					totalBillSQ = totalBillSQ.add(bsegBillSQ);					
				}				
				else {
					String uom = "UOM ";
					String tou = "TOU ";
					String sqi = "SQI ";
					
					if (notNull(sourceUOMID)) {
						uom = uom.concat("(");
						// Start Change - MPang - 2019-01-15 - Defect 4133027
						//uom = uom.concat(sourceUOMID.getTrimmedValue());
						uom = uom.concat(sourceUOMID.getIdValue().trim());
						// End Change - MPang - 2019-01-15 - Defect 4133027
						uom = uom.concat(") ");
					}
					if (notNull(sourceTOUID)) {
						// Start Change - MPang - 2019-01-15 - Defect 4133027
						//tou = uom.concat("(");
						//tou = tou.concat(sourceTOUID.getTrimmedValue());
						//tou = uom.concat(") ");
						tou = tou.concat("(");
						tou = tou.concat(sourceTOUID.getIdValue().trim());
						tou = tou.concat(") ");
						// End Change - MPang - 2019-01-15 - Defect 4133027
					}
					if (notNull(sourceSQIID)) {
						// Start Change - MPang - 2019-01-15 - Defect 4133027
						//sqi = uom.concat("(");
						//sqi = sqi.concat(sourceSQIID.getTrimmedValue());
						//sqi = uom.concat(") ");
						sqi = sqi.concat("(");
						sqi = sqi.concat(sourceSQIID.getIdValue().trim());
						sqi = sqi.concat(") ");
						// End Change - MPang - 2019-01-15 - Defect 4133027
					}
					prepState.close();

					// UOM/TOU/SQI : %1 /%2 /%3  quantity not found in SQ Collection
					addError(CustomMessageRepositoryMGE.ccb011CannotRetrieveSQCollection(uom, tou, sqi));
				}
				prepState.close();
				// END CHANGES - JHERNA - 2015-06-17 - 3237365
			}				
		}
		
		// Populate the Algorithm's Service Quantity
		UnitOfMeasure_Id bsegSqIdUOM = UnitOfMeasure_Id.NULL;
		TimeOfUse_Id bsegSqIdTOU = TimeOfUse_Id.NULL;
		ServiceQuantityIdentifier_Id bsegSqIdSQI = ServiceQuantityIdentifier_Id.NULL;
		
		if (notNull(parmSourceUOM)) {
			bsegSqIdUOM = hpUomID;
		}
		if (notNull(parmSourceTOU)) {
			bsegSqIdTOU = hpTouID;
		}
		if (notNull(parmSourceSQI)) {
			bsegSqIdSQI = hpSqiID;
		}
		
		BillSegmentServiceQuantity_Id bsegSQID = new BillSegmentServiceQuantity_Id(bsegSqIdUOM, 
				bsegSqIdTOU, bsegSqIdSQI, BillSegment_Id.NULL);
		
		BillSegmentServiceQuantity_DTO bsegSQDTO = new BillSegmentServiceQuantity_DTO();
		bsegSQDTO.setInitialServiceQuantity(totalInitSQ);
		bsegSQDTO.setBillableServiceQuantity(totalBillSQ);
		bsegSQDTO.setId(bsegSQID);
		
		BillSegmentServiceQuantityData bsegSQData = BillSegmentServiceQuantityData.Factory.newInstance();
		bsegSQData.setBillSegmentServiceQuantityDto(bsegSQDTO);
		hpCollOfBsegSQData.add(bsegSQData);
	}
	/** 
	 * Custom method which retrieves the service agreement's frozen bill segments
	 * which spans the period that the marketer is being billed for.
	 * @param saIdInColl service agreement
	 * @param startPeriodDate marketer's bill period start date
	 * @param endPeriodDate marketer's bill period end date
	 * @return returnValue collection of the retrieved bill segments which passes the criteria.
	 */
	private Iterator<BillSegment_Id> cmRetrieveBillSegments(ServiceAgreement_Id saIdInColl, 
			Date startPeriodDate, Date endPeriodDate) {
		
		Iterator<BillSegment_Id> returnValue = new ArrayList<BillSegment_Id>().iterator();
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT BSEG.BSEG_ID ");
		stringBuilder.append("FROM CI_BSEG BSEG "); 
		stringBuilder.append("WHERE BSEG.SA_ID = :saIdInColl ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = :frozen ");
		stringBuilder.append("AND BSEG.END_DT > :startPeriodDate ");
		stringBuilder.append("AND BSEG.END_DT <= :endPeriodDate ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        prepState.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		prepState.bindId("saIdInColl", saIdInColl);
		prepState.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		prepState.bindDate("startPeriodDate", startPeriodDate);
		prepState.bindDate("endPeriodDate", endPeriodDate);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
		
			List<BillSegment_Id> collOfBseg = new ArrayList<BillSegment_Id>();
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			
			while (iter.hasNext()) {
			
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				BillSegment_Id bsegID = (BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class);
				collOfBseg.add(bsegID);
			}
			returnValue = collOfBseg.iterator();
		}
		prepState.close();
		return returnValue;
	}
}