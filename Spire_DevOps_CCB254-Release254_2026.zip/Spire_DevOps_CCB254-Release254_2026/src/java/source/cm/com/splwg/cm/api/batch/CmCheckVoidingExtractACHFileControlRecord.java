/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - ACH File
 * Control Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 ACH File Control
 *                   	   Record
 * 2021-12-14   JLumbre    Mercury#47156. Updated format of debit and credit 
 * 							amounts fields.                   
 *                   
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractACHFileControlRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractACHFileControlRecord() {
		super(8);
	}

	public void setRecordTypeCode(String value) {
		rightPadColumn(1, 1, value);
	}
	
	public void setBatchCount(String value) {
		rightPadColumn(2, 6, value);
	}
	
	public void setBlockCount(String value) {
		rightPadColumn(3, 6, value);
	}
	
	public void setEntryAddendaCount(String value) {
		rightPadColumn(4, 8, value);
	}
	
	public void setEntryHash(String value) {
		rightPadColumn(5, 10, value);
	}
	
	public void setTotalDebitEntryDollarAmtInFile(String value) {
		leftPadColumnWithZeros(6, 12, value);
	}
	
	public void setTotalCreditEntryDollarAmtInFile(String value) {		
		leftPadColumnWithZeros(7, 12, value);
	}
	
	public void setReservedField(String value) {		
		rightPadColumn(8, 39, value);
	}
	
}
