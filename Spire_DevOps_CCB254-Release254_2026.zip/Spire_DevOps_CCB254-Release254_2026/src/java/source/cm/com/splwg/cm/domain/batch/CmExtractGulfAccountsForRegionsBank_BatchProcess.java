/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Customer Data Extract Batch for Gulf Accounts for Regions Bank
 * 
 * This batch will extract customer data for Gulf Accounts for Regions Bank.
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2021-05-26  JVitug      CCB031.3 Initial Version        
 * 2021-06-24  GCrisp	   CCB031.Issue1. Allow multithreading and add
 *						   the thread number at the end of the file 
 *						   name before the file extension.
 * 						   Add null checker for Account's Billing 
 *						   Premise ID. 
 *******************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;

import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.api.batch.CmGulfCustomerDataRecordForRegionsBank;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author JVitug
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision , name = CIS_DIVISION, required = true, type = entity)})
 */
public class CmExtractGulfAccountsForRegionsBank_BatchProcess extends
	CmExtractGulfAccountsForRegionsBank_BatchProcess_Gen {
	
    //Soft Parameters
    private CisDivision cisDivision;
    
    @Override
	public void validateSoftParameters(boolean isNewRun) {
        //Get all the soft parameters
    	String filePath = getParameters().getFILE_PATH();
    	cisDivision = getParameters().getCIS_DIVISION();
    	
    	// Validate that File Path is a valid directory
    	File file = new File(filePath);
    	if (!file.isDirectory()){
            addError(CustomMessageRepositorySpireOne.CCB031_3_batchParmInvalidFilePath(getBatchParameterName(10), filePath));
        }
	}
    
    /**
     * This method will return the batch parameter name given the sequence number input
     * @param numSeq
     * @return
     */
    private String getBatchParameterName(int numSeq){

        String parmName = "";
        
        BatchControlParameter_Id batchControlParameterId = 
                new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
        BatchControlParameter_LanguageId batchControlParameterLanguageId = 
                new BatchControlParameter_LanguageId(batchControlParameterId, getActiveContextLanguage().getId());
        parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();
        
        return parmName;
    }

    @Override
	public JobWork getJobWork() {
		StringBuilder stringSql = new StringBuilder();
		
		stringSql.append("SELECT ");
		stringSql.append(   "ACCT.ACCT_ID ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_ACCT ACCT ");
		stringSql.append("WHERE ");
		stringSql.append(   "ACCT.CIS_DIVISION = :cisDivision ");
		stringSql.append("AND ");
		stringSql.append(   "EXISTS ( ");
		stringSql.append(      "SELECT ");
		stringSql.append(         "'X' ");
		stringSql.append(      "FROM ");
		stringSql.append(         "CI_SA SA ");
		stringSql.append(      "WHERE ");
		stringSql.append(         "SA.ACCT_ID = ACCT.ACCT_ID ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.CIS_DIVISION = ACCT.CIS_DIVISION ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.SA_STATUS_FLG < :closed ");
		stringSql.append(   ") ");
		
		PreparedStatement getMainPreparedStatement = createPreparedStatement(stringSql.toString(), getClass().getName());	
		getMainPreparedStatement.bindId("cisDivision" , cisDivision.getId());
		getMainPreparedStatement.bindLookup("closed" , ServiceAgreementStatusLookup.constants.CLOSED);
		
		QueryIterator iterator = getMainPreparedStatement.iterate();
		
		return createJobWorkForQueryIterator(iterator, this);	
    }
	
    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
    
    	String accountIdString = (String) queryResultRow.get("ACCT_ID");
    	Account_Id accountId = new Account_Id(accountIdString);
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
    	threadWorkUnit.setPrimaryId(accountId);
    	
    	return threadWorkUnit;
	}

	public Class<CmExtractGulfAccountsForRegionsBank_BatchProcessWorker> getThreadWorkerClass() {
        return CmExtractGulfAccountsForRegionsBank_BatchProcessWorker.class;
    }

    public static class CmExtractGulfAccountsForRegionsBank_BatchProcessWorker extends 
    	CmExtractGulfAccountsForRegionsBank_BatchProcessWorker_Gen {
        
        //Working Variables
        Account account;
        private File extractFile;
        private BufferedWriter extractFileWriter;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }     

        @Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
        	
        	// Retrieve parameters. Also retrieve the other parameters to prevent lazy initialization exception
        	String filePath = getParameters().getFILE_PATH();
        	String fileName = getParameters().getFILE_NAME();
			
			// Start Add - GCrisp - 06-24-2021 - CCB031.Issue1
			//Add Batch thread number at the end of the file name before the file extension
			DecimalFormat decimalFormat = new DecimalFormat("00");
			int periodIndex = fileName.lastIndexOf('.');
			//If filename has file extension
			if(periodIndex > 0){
				String fileNameWithoutFileExtension = fileName.substring(0, fileName.lastIndexOf('.'));
				String fileExtension = fileName.substring(fileName.lastIndexOf('.')).trim();
				
				fileName = fileNameWithoutFileExtension.trim()
						.concat(decimalFormat.format(getBatchThreadNumber()).trim().concat(fileExtension));
			//If filename has no file extension
			} else{
				fileName = fileName.trim()
						.concat(decimalFormat.format(getBatchThreadNumber()).trim());
			}
			// End Add - GCrisp - 06-24-2021 - CCB031.Issue1
        	
            // Open Extract File
            try {
            	extractFile = new File(filePath,fileName);   
            	extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
            }
            catch(Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_3_errorInOpeningFile(extractFile.getAbsolutePath()));
            }

		}

        @Override
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
        	
        	Account_Id accountId = (Account_Id) unit.getPrimaryId();
        	account = accountId.getEntity();
        	
        	// Write Information to extract file
        	writeInformationToExtractFile(account);

            return true;
        }             
        
        /**
         * This method will write information retrieved to extract file
         */
        private void writeInformationToExtractFile(Account account) {
        	CmGulfCustomerDataRecordForRegionsBank record = new CmGulfCustomerDataRecordForRegionsBank();
        	
        	record.setAccount(account.getId().getTrimmedValue());
        	
            try {
            	extractFileWriter.write(record.createRecordString());
            	extractFileWriter.newLine();
            }
            catch (Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_3_errorInWritingToFile(extractFile.getAbsolutePath()));
            }
        }
        
		@Override 
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
            // Close Extract File
            try {
            	extractFileWriter.close();    
            }
            catch(Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_3_errorInClosingFile(extractFile.getAbsolutePath()));
            }
		}
    }
}
