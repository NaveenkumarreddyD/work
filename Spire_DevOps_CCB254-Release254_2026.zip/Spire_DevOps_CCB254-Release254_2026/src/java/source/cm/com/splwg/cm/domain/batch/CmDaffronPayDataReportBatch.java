/*********************************************************************************************
 * Program Name: CmDaffronPayDataReportBatch
 * Program Title: CmDaffronPayDataReportBatch
 * Author: Naga Yada
 * Creation Date: 2021-06-07
 * Purpose: This batch process will create a text file of recent payments from Walmart and send to Daffron.
 * 
 **********************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * WmartRTP  	      46685  	  Naga Yada      2021-06-07    - Initial Version            
 *                                                      
 *****************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffFSCFPPayData;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffFSCFPPayData_DTO;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffFSCFPPayData_Id;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.common.StringUtilities;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 42422
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {} ,
 *      softParameters = { @BatchJobSoftParameter (name = DAFF_CIS_DIVISON, required = true, type = string)
 *      	  ,	@BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */
public class CmDaffronPayDataReportBatch extends
		CmDaffronPayDataReportBatch_Gen {

	String parmFileName;
	String parmFilePath;
			
	@Override
	public void validateSoftParameters(boolean arg0) {

		// Validate that parameter is a valid file path	
		parmFilePath = getParameters().getFILE_PATH().trim();
		File fileValidator = new File(parmFilePath);		
		if (isNull(fileValidator)
				|| !fileValidator.isDirectory()) {
			// Batch Parameter File Path %1 is an invalid file path.
			addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFilePath(parmFilePath));
		}
		
	}
	
	public JobWork getJobWork() {
		// Create Job Work with dummy work unit
		List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
		threadWorkUnitList.add(new ThreadWorkUnit());
		return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
	}

	public Class<CmDaffronPayDataReportBatchWorker> getThreadWorkerClass() {
		return CmDaffronPayDataReportBatchWorker.class;
	}

	public static class CmDaffronPayDataReportBatchWorker extends
			CmDaffronPayDataReportBatchWorker_Gen {

		Logger logger = LoggerFactory.getLogger(CmDaffronPayDataReportBatchWorker.class);
		
		// Soft Parameters
		private String parmFileName;
		private String parmFilePath;
		private String daffCisDivCd;

		// Constants
		private static final String BACKSLASH = "/";
		private static final String FORWARDSLASH = "\\";
		private static final String UNDERSCORE = "_";
		private static final String CARRIAGE_RETURN_LINE_FEED = "\r\n";
		private static final String SPACE = " ";
		private static final String TXT = "txt";
		private static final String DOT = ".";
		private static final String CONST_R = "R";
		private static final String BLANK = "";
		
		private static final int FILLER_1_LENGTH=5;
		private static final int FILLER_2_LENGTH=14;
		private static final int FILLER_3_LENGTH=44;
		private static final int FILLER_4_LENGTH=9;
		private static final int FILLER_5_LENGTH=129;
	
		// Work Variables
		private String resultingFilePathName;
		private BufferedWriter buffWriter;
		
		private CmDaffFSCFPPayData_Id payId;
		private String daffAccountId;
		private BigDecimal payAmount;
		private Date payDate;
		private String extractNum;
		private DateFormat extractNumFormat = new DateFormat("YYYYMMddHHmmss");
		private DateFormat payDateFormate = new DateFormat("YYYYMMdd");
		private boolean isFileOpened;
		private Bool hadError = Bool.FALSE;
		private ServerMessage errorMsg ;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			List<SQLResultRow> payRecs = null;
			//Retrieve unreported/empty extraction Daffron Payment records
			try {				
				payRecs = retrieveEmptyExtactRecs();
			} catch(Exception e) {
				logger.error("Exception while fetching Daffron account payments " +e.getMessage());
				hadError = Bool.TRUE;
				errorMsg = CustomMessageRepositorySpireOne.getSQLErrorMsg();
				return false;
			}
			if(notNull(payRecs) && !payRecs.isEmpty()) {
				// Open the file
				openFile(resultingFilePathName);
				isFileOpened = true;
				for(SQLResultRow paymentInfoRow : payRecs) {
					payId = (CmDaffFSCFPPayData_Id) paymentInfoRow.getId("CM_DAFF_PAY_CONF_ID", CmDaffFSCFPPayData.class);
					daffAccountId = paymentInfoRow.getString("CM_DAFF_ACCT_ID");
					payAmount =  paymentInfoRow.getBigDecimal("CM_DAFF_PAY_AMT");
					payDate = paymentInfoRow.getDate("CM_DAFF_PAY_DT");
					writeToFile();
				}
			} else {
				addWarning(CustomMessageRepositorySpireOne.getNoRecordsMsg());
			}
			return true;
		}
		
		/**
		 * Base method which is invoked once per thread (executed before the main processing)
		 */		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			parmFilePath = getParameters().getFILE_PATH().trim();
			// Retrieve File Name
			parmFileName = getParameters().getFILE_NAME().trim();
			daffCisDivCd = getParameters().getDAFF_CIS_DIVISON().trim();
			
			// Form file path name
			formFilePathName();
			
		
		}
		
		/**
		 * Custom Method which forms the resulting file path 
		 * 
		 * FILE_PATH.concat(FILE_NAME.concat(_BatchCode.concat(_BatchThreadNumber.concat(_ProcessDateTime
		 *
		 */
		private void formFilePathName() {

			// Filepath = replace all \ with / and make sure that the file path ends with a /
			String filePath = parmFilePath;
			if (!filePath.endsWith(FORWARDSLASH)
					&& !filePath.endsWith(BACKSLASH)) {
				filePath = filePath.concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);

			// Filename = parameter 20_batchCode_batchNumber_batchThreadNumber
			String fileName = parmFileName;

//			String batchDetails = getBatchControlId().getTrimmedValue();
			
			extractNum = getProcessDateTime().toString(extractNumFormat);
			
//			batchDetails = batchDetails.concat(UNDERSCORE).concat(extractNum);

//			fileName = parmFileName.concat(UNDERSCORE).concat(batchDetails).concat(DOT).concat(TXT);

			resultingFilePathName = filePath.concat(fileName);						
		}
		
		/**
		 * Fetch the recent(unreported) Payments from Walmart by using the Extract_Run_num as empty.
		 * @return
		 * @throws Exception 
		 */
		private List<SQLResultRow> retrieveEmptyExtactRecs() throws Exception {
			StringBuilder getEmptyExtractQry = new StringBuilder();
			getEmptyExtractQry.append(" SELECT CM_DAFF_ACCT_ID, CM_DAFF_PAY_CONF_ID, CM_DAFF_PAY_AMT, CM_DAFF_PAY_DT ");
			getEmptyExtractQry.append(" FROM CM_DAFF_FS_CFP_PAY ");
			getEmptyExtractQry.append(" WHERE CM_DAFF_EXTRACT_RUN = :extractRun ");
			getEmptyExtractQry.append(" AND CM_DAFF_CIS_DIV = :cisDiv ");
			
			PreparedStatement payRecPrepState = createPreparedStatement(getEmptyExtractQry.toString(), getClass().getName());
			payRecPrepState.bindStringProperty("extractRun", CmDaffFSCFPPayData.properties.cmDaffExtractRun, SPACE);
			payRecPrepState.bindStringProperty("cisDiv", CmDaffFSCFPPayData.properties.cmDaffCisDivision, daffCisDivCd);
			payRecPrepState.setAutoclose(false);
						
			List<SQLResultRow> results = payRecPrepState.list();
			payRecPrepState.close();
			return results;
		}
		
		/**
		 * Custom method which opens the file
		 * @param fileName
		 */
		private void openFile(String fileName) {
			try {
				File file = new File(fileName);
				buffWriter = new BufferedWriter(new FileWriter(file));
			} catch (Exception e) { 
				// Error encountered opening file (%1%2%3%4)
				addError(CustomMessageRepositorySpireOne.errorOpeningFile(fileName));
			}
		}
		
		/**
		 * Custom method which writes to the file
		 * @param stringToWrite
		 */
		private void writeToFile(String stringToWrite) {
			
			try {
				buffWriter.write(stringToWrite);
				buffWriter.write(CARRIAGE_RETURN_LINE_FEED);
			} catch (Exception e) {
				// Error encountered writing to file
				addError(CustomMessageRepositorySpireOne.errorWritingToFile(resultingFilePathName));
			}
		}
		
		/**
		 * Custom method which closes the file
		 *
		 */
		private void closeFile() {
			try {
				buffWriter.close();
			} catch (Exception e) {
				// Error encountered closing file
				addError(CustomMessageRepositorySpireOne.errorClosingFile(resultingFilePathName));
			}
		}
		
		
		/**
		 * Custom method which process Meter Read Download record and forming different record type and write to flat file
		 * @param mrSchedRte the Meter Read Schedule Route
		 * @param mrSched the Meter Read Schedule
		 */
		private void writeToFile() {
			if(notNull(daffAccountId) && notNull(payId) && notNull(payAmount)){
				
				String record = payDate.toString(payDateFormate).concat(daffAccountId)
						.concat(StringUtilities.padRight(null, FILLER_1_LENGTH))
						.concat(StringUtilities.leftPadWithZeros(BLANK, FILLER_2_LENGTH))
						.concat(StringUtilities.padRight(null, FILLER_3_LENGTH))
						.concat(StringUtilities.leftPadWithZeros(payAmount.toString().replaceAll("\\.", BLANK), FILLER_4_LENGTH))
						.concat(StringUtilities.padRight(null, FILLER_5_LENGTH))
						.concat(CONST_R);
				writeToFile(record);
				updateExtractRun(payId);
			}
		}
		
		/**
		 * once the pay data is extracted, update the EXTRACT_RUN_NUM
		 * @param payId
		 */
		private void updateExtractRun(CmDaffFSCFPPayData_Id payId) {
			try {
				CmDaffFSCFPPayData payEntity = payId.getEntity();
				CmDaffFSCFPPayData_DTO payDTO = payEntity.getDTO();
				payDTO.setCmDaffExtractRun(extractNum);
				payDTO.setCmDaffUpdatedDt(getProcessDateTime().toDate());
				payDTO.setCmDaffUpdatedBy(getActiveContextUser().getId().getTrimmedValue());
				payEntity.setDTO(payDTO);
			} catch (Exception e) {
				logger.error("Exception while updating the CM_DAFF_EXTRACT_RUN for payment Id" +payId.getTrimmedValue());
				logger.error(e.getMessage());
			}
		}

		/**
		 * Base method which is called at the end after processing all records for each thread. This is called only once per thread
		 */
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			if(isFileOpened) {				
				closeFile();
			}
			if(hadError.isTrue()) {
				addError(errorMsg);
			}
		}

	}

}
