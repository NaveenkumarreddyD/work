/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Cancel Active Severance Landlord Reversion SA Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2022-04-28   Carlos Atilano  400576 - This algorithm will cancel any active severance process on
 * 								the Tenant, if an EnRoute disconnect FA exists, it will create a To-Do
 * 								It will cancel all Pending disconnect FAs
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 ******************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.landlordReversion;

import java.math.BigInteger;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.CustomerEventLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusReasonLookup;
import com.splwg.ccb.api.lookup.StartStopEventTypeLookup;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.landlordReversion.SaTypeLandlordReversionAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.cm.domain.constants.CustomConstantsRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customMessages.CustomMessagesSpireOne;

/**
 * @author OGC04023
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = fieldActivityType, name = fatype, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = faEligibleIntermStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = toDoMessage, required = true, type = string)})
 */
public class CmLLReversionCancelSeveranceProcessAlgComp_Impl extends
		CmLLReversionCancelSeveranceProcessAlgComp_Gen implements
		SaTypeLandlordReversionAlgorithmSpot {
	
	private static final String TD_TYPE_CMLANDLD = "CMLANDLD";
	private static final String TD_TYPE_CMLLMGE = "CMLLMGE";
	private static final String TD_TYPE_CMSELL = "CMSELL";
	private static final String CLICK_FC = "CM-CLKMWM";
	private static final String INT_STAT_PREV_FA_CANCEL = "ISFC";
	
	ServiceAgreement stopSa;
	ServiceAgreement startSa;
	Bool reverseSw;
	Bool createFa;
	StartStopEventTypeLookup eventTypeLookup;
	ServicePoint sp;
	String[] statuses;
	Account acct;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// TODO Auto-generated method stub
		super.extraSoftParameterValidations(forAlgorithmValidation);
		statuses = getFaEligibleIntermStatus().split(",");
		for(String status : statuses){
			if (!verfifyLookupVal(status)){
				addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.CCB204_ALG_PARM_MSG_CAT_MSG_NBR_COMBO_INVALID, this.getAlgorithm().getId().getIdValue()
						,"faEligibleIntermStatus"
						,status
						,"FA_INT_STATUS_FLG"
						,"Feature Configuration"));
			}
		}
	}

	

	public void invoke() {
		if(!eventTypeLookup.isInitiateStop()){
			return;
		}
		sp = stopSa.getServicePoints().iterator().next().getServicePoint();
		acct = stopSa.getAccount();
		String cisDiv = acct.getDivisionId().getIdValue().trim();
		//Cancel Severance Process on Tenant
		for(SeveranceProcess sev : getActiveSeverance()){
			//allow reconnect
			sev.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, Bool.TRUE);
		}
		if(verifyEnRouteFA()){
			
			if(cisDiv.equals(CustomConstantsRepository.CIS_DIV_ALABAMA) || cisDiv.equals(CustomConstantsRepository.CIS_DIV_GULF))
				createToDo(TD_TYPE_CMSELL, acct);
			
			else if(cisDiv.equals(CustomConstantsRepository.CIS_DIV_MISSOURI_EAST))
				createToDo(TD_TYPE_CMLANDLD, acct);
			
			else if(cisDiv.equals(CustomConstantsRepository.CIS_DIV_MISSOURI_WEST))
				createToDo(TD_TYPE_CMLLMGE, acct);
		}
		QueryIterator<SQLResultRow> discFas= getDisconnectFas();
		while(discFas.hasNext()){
			FieldActivity fa = new FieldActivity_Id(discFas.next().getString("FA_ID")).getEntity();
			FieldActivityCancelProcessorData fac = FieldActivityCancelProcessorData.Factory.newInstance();
			fac.setFieldActivity(fa);
			fac.setCancelReason(new FieldActivityCancelReason_Id("SASP").getEntity());
			fa.cancel(fac);
		}
		discFas.close();
		
	}


	
	public List<SeveranceProcess> getActiveSeverance(){
		
		String hql = " from SeveranceProcess sev where sev.serviceAgreement = :sa"
				+ " and sev.severanceStatus = :active"
				+ " and exists (select sevt.id from SeveranceEvent sevt, SeveranceEventType sevty where sevt.id.severanceProcess = sev"
				+ " 			and sevt.severanceEventType = sevty and sevty.customerEvent = :cutNoPayEvt)";
		
		Query<SeveranceProcess> qry = createQuery(hql, "Verfiy Severance");
		qry.bindEntity("sa", stopSa);
		qry.bindLookup("active", SeveranceStatusLookup.constants.ACTIVE);
		qry.bindLookup("cutNoPayEvt", CustomerEventLookup.constants.CUTFOR_NON_PAYMENT);
		qry.addResult("sev", "sev");
		
		return qry.list();
			
	}
	
	public Boolean verifyEnRouteFA(){
		StringBuilder verifyFa= new StringBuilder();
		verifyFa.append("SELECT FA.FA_ID FROM CI_FA FA");
		verifyFa.append(" WHERE FA.FA_STATUS_FLG = :pend");
		verifyFa.append(" AND FA.SP_ID = :spId");
		verifyFa.append(" AND FA.FA_TYPE_CD = :faType");
		verifyFa.append(" AND FA.FA_INT_STATUS_FLG IN ( " + parseParamaterToQueryParm(getFaEligibleIntermStatus()) + ") ");
		
		
		PreparedStatement faQuery = createPreparedStatement(verifyFa.toString(), "verifyEnRouteFA");
		faQuery.bindEntity("faType", this.getFatype());
		faQuery.bindEntity("spId", sp);
		faQuery.bindLookup("pend", FieldActivityStatusLookup.constants.PENDING);

		
		if(faQuery.list().size() > 0){
			faQuery.close();
			return true;
		}
		faQuery.close();	
		return false;
		
	}
	
    private String parseParamaterToQueryParm(String parameter){
        StringBuilder queryParm = new StringBuilder();

        String[] valueList =  parameter.split(",");

        for(String value : valueList){
            if(queryParm.length() == 0){
                queryParm.append("\'");
                queryParm.append(value.trim());
                queryParm.append("\'");
            } else {
                queryParm.append(",\'");
                queryParm.append(value.trim());
                queryParm.append("\'");
            }
        }
        return queryParm.toString();
    }
    
    private Boolean verfifyLookupVal(String val){
    	String sql = "SELECT FIELD_VALUE FROM CI_LOOKUP_VAL WHERE FIELD_NAME = 'FA_INT_STATUS_FLG'"
    			+ " AND FIELD_VALUE = '"+val+"'";
    	PreparedStatement verfifyLookupPs = createPreparedStatement(sql.toString(), "verfifyLookupVal");
		
		if(verfifyLookupPs.list().size() > 0){
			verfifyLookupPs.close();
			return true;
		}
		verfifyLookupPs.close();
		return false;
		
    }
    
    private void createToDo(String toDoTypeStr, Account acct) {

        ToDoType toDoType = new ToDoType_Id(toDoTypeStr).getEntity();
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();          
        toDoEntryDTO.setCreationDateTime(getProcessDateTime());
        toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoEntryDTO.setToDoTypeId(toDoType.getId());
   
        toDoCreator.setToDoDTO(toDoEntryDTO);   
        toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, new BigInteger("1")).getEntity(), getActiveContextUser().getId().getIdValue());
        toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, new BigInteger("2")).getEntity(), getActiveContextUser().getInfo());
        toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, new BigInteger("3")).getEntity(), getToDoMessage());

        CharacteristicValue cisDivCharVal = new CharacteristicValue_Id(new CharacteristicType_Id(CustomConstantsRepository.CHAR_TYPE_CMDIV).getEntity(), acct.getDivisionId().getIdValue()).getEntity();
        toDoCreator.addPredefinedCharacteristic(cisDivCharVal);
        toDoCreator.addForeignKeyCharacteristic(new CharacteristicType_Id(CustomConstantsRepository.CHAR_TYPE_PER).getEntity(), acct.getMainPerson());
        toDoCreator.addForeignKeyCharacteristic(new CharacteristicType_Id(CustomConstantsRepository.CHAR_TYPE_ACCT).getEntity(), acct);
        toDoCreator.addForeignKeyCharacteristic(new CharacteristicType_Id(CustomConstantsRepository.CHAR_TYPE_PREM).getEntity(), sp.getPremise());
        
        
        ToDoEntry td = toDoCreator.create();
        td.addToDoEntryMessageParam(getToDoMessage());
        ToDoDrillKeyValue_DTO dkDTO = td.getDrillKeyValues().newChildDTO();
        dkDTO.setKeyValue(td.getId().getIdValue());
        
        td.getDrillKeyValues().add(dkDTO, BigInteger.ONE);
    } 
    

	public QueryIterator<SQLResultRow> getDisconnectFas(){
		
		String query = "SELECT FA.FA_ID FROM CI_FA FA"
				+ " WHERE FA.FA_STATUS_FLG = :pend"
				+ " AND FA.SP_ID = :sp"
				+ " AND FA.FA_TYPE_CD = :discNp"
				+ " AND FA.FA_INT_STATUS_FLG NOT IN"
				+ " (SELECT WFM_OPT_VAL FROM CI_WFM_OPT WHERE WFM_NAME = '"+CLICK_FC+"' AND EXT_OPT_TYPE = '"+INT_STAT_PREV_FA_CANCEL+"')";
		

		PreparedStatement ps = createPreparedStatement(query, "getDisconnectFas");
		ps.bindEntity("sp", sp);
		ps.bindEntity("discNp", getFatype());
		ps.bindLookup("pend",FieldActivityStatusLookup.constants.PENDING);
		return ps.iterate();
		
	}
	
	@Override
	public void setCreateFieldActivitySwitch(Bool arg0) {
		createFa = arg0;

	}

	@Override
	public void setEventTypeFlag(StartStopEventTypeLookup arg0) {
		// TODO Auto-generated method stub
		eventTypeLookup = arg0;
	}
	
	@Override
	public void setPendingStartSA(ServiceAgreement arg0) {
		startSa = arg0;

	}

	@Override
	public void setPendingStopSA(ServiceAgreement arg0) {
		stopSa = arg0;

	}

	@Override
	public void setReversionSwitch(Bool arg0) {
		reverseSw = arg0;

	}



	// start update - equint - 2025-11-14 - CCB25.4 Upgrade
	@Override
	public Bool getCreateFieldActivitySwitch() {
		return reverseSw;
	}

	@Override
	public Bool getReversionSwitch() {
		return reverseSw;
	}
	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

}
