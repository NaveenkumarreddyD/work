/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-05-08   Jagadeesh        NI0026.5 Initial Version.
 * 2014-02-24   Neha			IM-046043 & IM-043344. As per Rhonda, Credit
 *								is "C" instead of "D"
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation.
 * 2018-04-17	DarrylH		SA:247179 Altered Java variables
 * 							intialization. Static variable did not work well
 * 							in AE (uc4 schedule)
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadContextLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.tenderType.TenderType;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_Id;*/

import com.splwg.ccb.domain.admin.tenderType.entity.TenderType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.StringUtilities;

/**
 * @author
 *
 @BatchJob ( modules = {}
 *              , multiThreaded = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName= notificationExternalId, name = EXTERNAL_SOURCE_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderType, name = TENDER_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PAYOR_ACCT_ID, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = RETURN_REASON_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAYEE_ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAY_TYPE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETURN_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETURN_REASON_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_NAME_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_ADRSS_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = CUR_HEAT_SEASON_START_DATE, required = true, type = string)
 *            })
 */

public class CmEAPledgePaymentUpload_BatchProcess extends CmEAPledgePaymentUpload_BatchProcess_Gen {
	// START CHANGE-DarrylH -2018-04-17 SA-247179
    /*
	private static String parmFilePath;
    private static String parmFileName;
    private static NotificationExternalId parmExternalSourceId;
    private static TenderType parmTenderType;
    private static String parmPayorAcct;
    private static NotificationUploadExtensionType parmNotificationType;
    private static String parmReturnReason;
    private static NotificationUploadContextLookup parmPayeeAcctIdNotificationContextType;
    private static NotificationUploadContextLookup parmAmountPaidNotificationContextType;
    private static NotificationUploadContextLookup parmPayTypeNotificationContextType;
    private static NotificationUploadContextLookup parmOrgPayDateNotificationContextType;
    private static NotificationUploadContextLookup parmReturnPayDateNotificationContextType;
    private static NotificationUploadContextLookup parmReturnReasonNotificationContextType;
    private static NotificationUploadContextLookup parmCustomerNameNotificationContextType;
    private static NotificationUploadContextLookup parmCustomerAddressNotificationContextType;
    private static String parmCurrentHeatingSeason;
    private static final String CURR_HEAT_SEASON_DATE_FORMAT = "MM-dd";
    private static Date refPaydate = null;
    private static File inputFile = null;
    */
	private String parmFilePath;
    private String parmFileName;

    private NotificationExternalId parmExternalSourceId;
    private TenderType parmTenderType;
    private String parmPayorAcct;
    private NotificationUploadExtensionType parmNotificationType;
    private String parmReturnReason;
    private NotificationUploadContextLookup parmPayeeAcctIdNotificationContextType;
    private NotificationUploadContextLookup parmAmountPaidNotificationContextType;
    private NotificationUploadContextLookup parmPayTypeNotificationContextType;
    private NotificationUploadContextLookup parmOrgPayDateNotificationContextType;
    private NotificationUploadContextLookup parmReturnPayDateNotificationContextType;
    private NotificationUploadContextLookup parmReturnReasonNotificationContextType;
    private NotificationUploadContextLookup parmCustomerNameNotificationContextType;
    private NotificationUploadContextLookup parmCustomerAddressNotificationContextType;

    private String parmCurrentHeatingSeason;
    private final String CURR_HEAT_SEASON_DATE_FORMAT = "MM-dd";
    private Date refPaydate = null;
    private File inputFile = null;

    // END CHANGE-DarrylH -2018-04-17 SA-247179

    public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit workUnit = new ThreadWorkUnit();
        workUnits.add(workUnit);
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    public void validateSoftParameters(boolean isNewRun){
        parmFilePath = getParameters().getFILE_PATH().trim();
        parmFileName = getParameters().getFILE_NAME().trim();

        File folder = new File(parmFilePath);
        if(!folder.exists()){
            addError(CustomMessageRepository.ni0026_5InvalidFilePath(parmFilePath));
        }

        // Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
        inputFile = new File(parmFilePath, parmFileName);
        if(!inputFile.exists() || !inputFile.canRead()){
            addError(CustomMessageRepository.ni0026_5InvalidFileName(parmFileName));
        }

        parmExternalSourceId = getParameters().getEXTERNAL_SOURCE_ID();
        parmTenderType = getParameters().getTENDER_TYPE_CD();
        parmPayorAcct =getParameters().getPAYOR_ACCT_ID();
        parmReturnReason = getParameters().getRETURN_REASON_VAL();

        parmNotificationType = getParameters().getNOTIFICATION_TYPE();
        parmPayeeAcctIdNotificationContextType = getParameters().getPAYEE_ACCT_ID_NT_CTXT_TYPE();
        parmAmountPaidNotificationContextType = getParameters().getAMT_PAID_NT_CTXT_TYPE();
        parmPayTypeNotificationContextType = getParameters().getPAY_TYPE_NT_CTXT_TYPE();
        parmOrgPayDateNotificationContextType = getParameters().getORG_PAY_DATE_NT_CTXT_TYPE();
        parmReturnPayDateNotificationContextType = getParameters().getRETURN_PAY_DATE_NT_CTXT_TYPE();
        parmReturnReasonNotificationContextType = getParameters().getRETURN_REASON_NT_CTXT_TYPE();
        parmCustomerNameNotificationContextType = getParameters().getCUST_NAME_NT_CTXT_TYPE();
        parmCustomerAddressNotificationContextType = getParameters().getCUST_ADRSS_NT_CTXT_TYPE();
        parmCurrentHeatingSeason = getParameters().getCUR_HEAT_SEASON_START_DATE();

        try{
            refPaydate = Date.fromString(parmCurrentHeatingSeason, new DateFormat(CURR_HEAT_SEASON_DATE_FORMAT));
        } catch (DateFormatParseException e) {
            addError(CustomMessageRepository.ni0026_5InvalidHeatSeasonFormat(parmCurrentHeatingSeason,CURR_HEAT_SEASON_DATE_FORMAT));
        }
        refPaydate = new Date(getProcessDateTime().getYear(), refPaydate.getMonth(), refPaydate.getDay());
        if(refPaydate.isAfter(getProcessDateTime().getDate())){
            refPaydate = refPaydate.addYears(-1);
        }
    }


    public Class<CmEAPledgePaymentUpload_BatchProcessWorker> getThreadWorkerClass() {
        return CmEAPledgePaymentUpload_BatchProcessWorker.class;
    }

    public static class CmEAPledgePaymentUpload_BatchProcessWorker extends
    CmEAPledgePaymentUpload_BatchProcessWorker_Gen {

        //Working Variables
        private BufferedReader inputBufferReader = null;
        private BigInteger lineCounter = BigInteger.ZERO;
        private BigInteger totalCreditCount = BigInteger.ZERO;
        private NotificationUpload notificationUpload;
        private BigDecimal totalCreditAmount = BigDecimal.ZERO;
        private BigInteger numberOfRecordsInError = BigInteger.ZERO;
        private String externalTransmitId;
        private String recordType;
        private Bool isStagingCreated = Bool.FALSE;
        private TenderControlStaging tenderControlStaging = null;
        private DepositControlStaging depositControlStaging = null;

        // CONSTANT NAMES
        private static final String CONST_EXT_TRANSMIT = "EXTERNAL TRANSMIT ID";
        private static final String CONST_PAYEE_ACCOUNT_ID = "PAYEE ACCOUNT ID";
        private static final String CONST_AMOUNT_PAID = "AMOUNT PAID";
        private static final Currency_Id usdCurr = new Currency_Id("USD");
        private static final String DATE_DELIMITER = "-";

        //DETAIL RECORD
        private static final int PAYEE_ACCOUNT_ID_INDEX = 108;
        private static final int PAYEE_ACCOUNT_ID_LENGTH = 20;
        private static final int AMOUNT_PAID_INDEX = 133;
        private static final int AMOUNT_PAID_LENGTH = 6;
        private static final int CUST_LAST_NAME_INDEX = 10;
        private static final int CUST_LAST_NAME_LENGTH = 18;
        private static final int CUST_FIRST_NAME_INDEX = 28;
        private static final int CUST_FIRST_NAME_LENGTH = 12;
        private static final int CUST_INIT_INDEX = 40;
        private static final int CUST_INIT_LENGTH = 1;
        private static final int CUST_ADRS_INDEX = 42;
        private static final int CUST_ADRS_LENGTH = 22;
        private static final int CR_DB_INDEX = 140;
        private static final int CR_DB_LENGTH = 1;

        //BATCH TRAILER
        private static final String BATCH_TRAILER_RECORD_TYPE = "CONTROL";
        private static final int RECORD_TYPE_INDEX = 0;
        private static final int RECORD_TYPE_LENGTH = 7;
        private static final int EXT_TRANSMIT_ID_INDEX = 47;
        private static final int EXT_TRANSMIT_ID_LENGTH = 8;

        // START CHANGE-DarrylH -2018-04-17 SA-247179
    	private String parmFilePath;
        private String parmFileName;

        private NotificationExternalId parmExternalSourceId;
        private TenderType parmTenderType;
        private String parmPayorAcct;
        private NotificationUploadExtensionType parmNotificationType;
        private String parmReturnReason;
        private NotificationUploadContextLookup parmPayeeAcctIdNotificationContextType;
        private NotificationUploadContextLookup parmAmountPaidNotificationContextType;
        private NotificationUploadContextLookup parmPayTypeNotificationContextType;
        private NotificationUploadContextLookup parmOrgPayDateNotificationContextType;
        private NotificationUploadContextLookup parmReturnPayDateNotificationContextType;
        private NotificationUploadContextLookup parmReturnReasonNotificationContextType;
        private NotificationUploadContextLookup parmCustomerNameNotificationContextType;
        private NotificationUploadContextLookup parmCustomerAddressNotificationContextType;

        private String parmCurrentHeatingSeason;
        private final String CURR_HEAT_SEASON_DATE_FORMAT = "MM-dd";
        private Date refPaydate = null;
        private File inputFile = null;

        // END CHANGE-DarrylH -2018-04-17 SA-247179
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
        throws ThreadAbortedException, RunAbortedException {
        	// START CHANGE-DarrylH -2018-04-17 SA-247179
            parmFilePath = getParameters().getFILE_PATH().trim();
            parmFileName = getParameters().getFILE_NAME().trim();
            inputFile = new File(parmFilePath, parmFileName);

            parmExternalSourceId = getParameters().getEXTERNAL_SOURCE_ID();
            parmTenderType = getParameters().getTENDER_TYPE_CD();
            parmPayorAcct =getParameters().getPAYOR_ACCT_ID();
            parmReturnReason = getParameters().getRETURN_REASON_VAL();

            parmNotificationType = getParameters().getNOTIFICATION_TYPE();
            parmPayeeAcctIdNotificationContextType = getParameters().getPAYEE_ACCT_ID_NT_CTXT_TYPE();
            parmAmountPaidNotificationContextType = getParameters().getAMT_PAID_NT_CTXT_TYPE();
            parmPayTypeNotificationContextType = getParameters().getPAY_TYPE_NT_CTXT_TYPE();
            parmOrgPayDateNotificationContextType = getParameters().getORG_PAY_DATE_NT_CTXT_TYPE();
            parmReturnPayDateNotificationContextType = getParameters().getRETURN_PAY_DATE_NT_CTXT_TYPE();
            parmReturnReasonNotificationContextType = getParameters().getRETURN_REASON_NT_CTXT_TYPE();
            parmCustomerNameNotificationContextType = getParameters().getCUST_NAME_NT_CTXT_TYPE();
            parmCustomerAddressNotificationContextType = getParameters().getCUST_ADRSS_NT_CTXT_TYPE();
            parmCurrentHeatingSeason = getParameters().getCUR_HEAT_SEASON_START_DATE();

            try{
                refPaydate = Date.fromString(parmCurrentHeatingSeason, new DateFormat(CURR_HEAT_SEASON_DATE_FORMAT));
            } catch (DateFormatParseException e) {
                addError(CustomMessageRepository.ni0026_5InvalidHeatSeasonFormat(parmCurrentHeatingSeason,CURR_HEAT_SEASON_DATE_FORMAT));
            }
            refPaydate = new Date(getProcessDateTime().getYear(), refPaydate.getMonth(), refPaydate.getDay());
            if(refPaydate.isAfter(getProcessDateTime().getDate())){
                refPaydate = refPaydate.addYears(-1);
            }
            // END CHANGE-DarrylH -2018-04-17 SA-247179

            openFile();
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            processFile();
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(lineCounter.intValue());
            workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
            return workUnitResult;
        }

        private Boolean isRecordDebit(String record){
            String crdrStr = getFieldValue(record, CR_DB_INDEX, CR_DB_LENGTH);
			// Start changes Neha IM-046043 & IM-043344 2014-02-24
            //if (crdrStr.equalsIgnoreCase("C")){
			if (crdrStr.equalsIgnoreCase("D")){
			// End changes Neha IM-046043 & IM-043344 2014-02-24
                return true;
            }else{
                return false;
            }
        }

        private void processFile(){

            // Open File to read batch trailer record and calculate credit amount.
            openFile();
            String trailerRecord = null;
            while(notNull(trailerRecord = readRecord())){
                recordType = getFieldValue(trailerRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();
                if(recordType.equalsIgnoreCase(BATCH_TRAILER_RECORD_TYPE)){
                    externalTransmitId = getFieldValue(trailerRecord, EXT_TRANSMIT_ID_INDEX, EXT_TRANSMIT_ID_LENGTH);
                    validateField(externalTransmitId, CONST_EXT_TRANSMIT, EXT_TRANSMIT_ID_INDEX+1, EXT_TRANSMIT_ID_INDEX+EXT_TRANSMIT_ID_LENGTH);
                }
            }
           closeFile();

            // Open File to read detail records.
         openFile();
            String detailRecord = null;

            while(notNull(detailRecord = readRecord())){
                //Increment line counter
                lineCounter = lineCounter.add(BigInteger.ONE);
                recordType = getFieldValue(detailRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();


                try{
                    if(!recordType.equalsIgnoreCase(BATCH_TRAILER_RECORD_TYPE)){
                        if(isRecordDebit(detailRecord))
                            processDebitRecord(detailRecord);
                        else
                            processCreditRecord(detailRecord);
                    }
                }catch(ApplicationError ae){
                    if(isNull(ae.getServerMessage().getMessageText())){
                        numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
                        addError(CustomMessageRepository.ni0026_5RecordInError(lineCounter.toString(), ae.getMessage().trim()));
                    }else{
                        numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
                        addError(CustomMessageRepository.ni0026_5RecordInError(lineCounter.toString(), ae.getServerMessage().getMessageText().trim()));
                    }
                }
            }

            //Update Deposit Control Amount
            if(notNull(depositControlStaging)){
                DepositControlStaging_DTO depositControlStagingDTO = depositControlStaging.getDTO();
                depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalCreditAmount,usdCurr));
                depositControlStaging.setDTO(depositControlStagingDTO);
            }

            if(notNull(tenderControlStaging)){
                TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStaging.getDTO();
                tenderControlStagingDTO.setTotalTendersAmount(new Money(totalCreditAmount,usdCurr));
                tenderControlStagingDTO.setTotalNumberOfTender(totalCreditCount);
                tenderControlStaging.setDTO(tenderControlStagingDTO);
            }

            closeFile();
        }

        private void processCreditRecord(String record){
            if(isStagingCreated.isFalse()){
                startChanges();
                DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(parmExternalSourceId.getId().getIdValue(),externalTransmitId);
                DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();
                depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
                depositControlStagingDTO.setTransmissionDateTime(getProcessDateTime());
                depositControlStagingDTO.setCurrencyId(usdCurr);
                depositControlStagingDTO.setTenderControlTotalAmount(new Money("1",usdCurr));
                depositControlStagingDTO.setTotalTenderControl(BigInteger.ONE);
                depositControlStaging = depositControlStagingDTO.newEntity();
                saveChanges();

                //Create and insert a Tender Control staging record
                startChanges();
                TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, externalTransmitId);
                TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStagingId.newDTO();
                tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);
                tenderControlStagingDTO.setTotalTendersAmount(new Money("1",usdCurr));
                tenderControlStagingDTO.setTotalNumberOfTender(totalCreditCount);
                tenderControlStaging = tenderControlStagingDTO.newEntity();
                saveChanges();
                isStagingCreated = Bool.TRUE;
            }
            startChanges();
            // TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, batchNumber);
            String lineCounterStr = lineCounter.toString();
            if (lineCounterStr.length() < 5)  lineCounterStr = StringUtilities.leftPadWithZeros(lineCounterStr, 5);
            else  lineCounterStr = lineCounterStr.substring(0, 5);

            String parmExternalSourceStr = parmExternalSourceId.getId().getIdValue().substring(0,6);
            String payeeAcctNumStr = getFieldValue(record, PAYEE_ACCOUNT_ID_INDEX , PAYEE_ACCOUNT_ID_LENGTH );
            validateField(payeeAcctNumStr, CONST_PAYEE_ACCOUNT_ID, PAYEE_ACCOUNT_ID_INDEX +1, PAYEE_ACCOUNT_ID_INDEX +PAYEE_ACCOUNT_ID_LENGTH );
            String extRef = parmExternalSourceStr.concat(lineCounterStr).concat(externalTransmitId).concat(":").concat(payeeAcctNumStr);
            PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStaging, extRef);

            PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO();
            paymentTenderUploadDTO.setCustomerId(parmPayorAcct);

            paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);

            String amtPaidStr = getFieldValue(record, AMOUNT_PAID_INDEX , AMOUNT_PAID_LENGTH );
            validateField(amtPaidStr, CONST_AMOUNT_PAID, AMOUNT_PAID_INDEX +1, AMOUNT_PAID_INDEX +AMOUNT_PAID_LENGTH );
            BigDecimal creditAmount = new BigDecimal(new BigInteger(amtPaidStr),2);
            totalCreditAmount = totalCreditAmount.add(creditAmount);
            totalCreditCount = totalCreditCount.add(BigInteger.ONE);
            paymentTenderUploadDTO.setTenderAmount(new Money(creditAmount,usdCurr));

            paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());

            paymentTenderUploadDTO.setTenderTypeId(parmTenderType.getId());

            paymentTenderUploadDTO.setMicrId(payeeAcctNumStr);

            String custLastNameStr = getFieldValue(record, CUST_LAST_NAME_INDEX  , CUST_LAST_NAME_LENGTH  );
            String custFirstNameStr = getFieldValue(record, CUST_FIRST_NAME_INDEX   , CUST_FIRST_NAME_LENGTH   );
            paymentTenderUploadDTO.setName(custLastNameStr.concat(",").concat(custFirstNameStr));
            PaymentTenderUpload payTndrUpload = paymentTenderUploadDTO.newEntity();
            saveChanges();
        }

        private void processDebitRecord(String record){

            startChanges();
            NotificationUpload_DTO notificationUploadDto = createDTO(NotificationUpload.class);
            notificationUploadDto.setNotificationExternalId(parmExternalSourceId.getId());
            notificationUploadDto.setNotificationUploadTypeId(parmNotificationType.getId());
            notificationUploadDto.setCreationDateTime(getProcessDateTime());
            notificationUploadDto.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
            notificationUploadDto.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);
            notificationUpload = notificationUploadDto.newEntity();

            NotificationUploadContext_DTO notificationUploadContextDTO = new NotificationUploadContext_DTO();
            String payeeAcctNumStr = getFieldValue(record, PAYEE_ACCOUNT_ID_INDEX , PAYEE_ACCOUNT_ID_LENGTH );
            validateField(payeeAcctNumStr, CONST_PAYEE_ACCOUNT_ID, PAYEE_ACCOUNT_ID_INDEX +1, PAYEE_ACCOUNT_ID_INDEX +PAYEE_ACCOUNT_ID_LENGTH );
            notificationUpload.getContexts().add(notificationUploadContextDTO, parmPayeeAcctIdNotificationContextType , payeeAcctNumStr);
            Account_Id payeeAccountId = new Account_Id(payeeAcctNumStr);

            String amtPaidStr = getFieldValue(record, AMOUNT_PAID_INDEX , AMOUNT_PAID_LENGTH );
            validateField(amtPaidStr, CONST_AMOUNT_PAID, AMOUNT_PAID_INDEX +1, AMOUNT_PAID_INDEX +AMOUNT_PAID_LENGTH );
            BigDecimal debitAmount = new BigDecimal(new BigInteger(amtPaidStr),2);
            notificationUpload.getContexts().add(notificationUploadContextDTO, parmAmountPaidNotificationContextType , debitAmount.toString());

            notificationUpload.getContexts().add(notificationUploadContextDTO, parmPayTypeNotificationContextType ,parmTenderType.getId().getIdValue());

            Date origPayDateStr = retrieveOrigPayDate(payeeAccountId,debitAmount);
            if(notNull(origPayDateStr)){
                notificationUpload.getContexts().add(notificationUploadContextDTO, parmOrgPayDateNotificationContextType ,origPayDateStr.toString());
            }

            String returnPayDateStr = getProcessDateTime().getDate().toString();


             // Start Changes - TIR_1 - MLekkala - 05/30/2012 -
            // For making the Return Pay Date in Notification Upload Context in the format MMDDYY
            StringTokenizer strTokenizer = new StringTokenizer(returnPayDateStr,DATE_DELIMITER);


           String yyStr =  strTokenizer.nextToken().substring(2); // Needs only YY
           String mmStr = strTokenizer.nextToken();
           String ddStr   = strTokenizer.nextToken();

           String returnPayDateFrmtStr = mmStr.concat(ddStr).concat(yyStr);

           notificationUpload.getContexts().add(notificationUploadContextDTO, parmReturnPayDateNotificationContextType ,returnPayDateFrmtStr);

            // End Changes - TIR 1 - MLekkala - 05/30/2012


            notificationUpload.getContexts().add(notificationUploadContextDTO, parmReturnReasonNotificationContextType ,parmReturnReason );

            String custLastNameStr = getFieldValue(record, CUST_LAST_NAME_INDEX  , CUST_LAST_NAME_LENGTH  );
            String custFirstNameStr = getFieldValue(record, CUST_FIRST_NAME_INDEX   , CUST_FIRST_NAME_LENGTH   );
            String custInitialStr = getFieldValue(record, CUST_INIT_INDEX   , CUST_INIT_LENGTH   );
            notificationUpload.getContexts().add(notificationUploadContextDTO, parmCustomerNameNotificationContextType
                    ,custLastNameStr.concat(",").concat(custFirstNameStr).concat(" ").concat(custInitialStr));

            String custAddStr = getFieldValue(record, CUST_ADRS_INDEX , CUST_ADRS_LENGTH );
            notificationUpload.getContexts().add(notificationUploadContextDTO, parmCustomerAddressNotificationContextType ,custAddStr);
            saveChanges();
        }

        private Date retrieveOrigPayDate(Account_Id payeeAccountId,BigDecimal amount ){

            StringBuilder origPayDateQueryString = new StringBuilder();
            Date origPayDate = null;
            origPayDateQueryString.append("SELECT P.PAY_DT PAY_DT FROM CI_PAY_TNDR PT, CI_PAY_EVENT P, CI_PAY PY  ");
            origPayDateQueryString.append("WHERE PY.ACCT_ID = :acctId AND PT.TENDER_TYPE_CD = :tender AND PT.TENDER_AMT = :amt ");
            origPayDateQueryString.append("AND PT.PAY_EVENT_ID = P.PAY_EVENT_ID AND P.PAY_EVENT_ID = PY.PAY_EVENT_ID AND P.PAY_DT >= :refDate ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement origPayDatePrepStmt = createPreparedStatement(origPayDateQueryString.toString());
            PreparedStatement origPayDatePrepStmt = createPreparedStatement(origPayDateQueryString.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            origPayDatePrepStmt.bindId("acctId", payeeAccountId);
            origPayDatePrepStmt.bindId("tender", parmTenderType.getId());
            origPayDatePrepStmt.bindBigDecimal("amt", amount) ;
            origPayDatePrepStmt.bindDate("refDate", refPaydate);

            if(origPayDatePrepStmt.list().isEmpty()){
                logMessage(CustomMessageRepository.ni0026_5OrigPayDateNotAvail(lineCounter.toString().trim(),payeeAccountId.getIdValue()), MessageSeverityLookup.constants.INFORMATIONAL);
                origPayDatePrepStmt.close();
                return null;
            }
            else{
                origPayDate = (origPayDatePrepStmt.firstRow().getDate("PAY_DT"));
                origPayDatePrepStmt.close();
                return origPayDate;
            }

        }

        private void openFile() {

            try {
                inputBufferReader = new BufferedReader(new FileReader(inputFile));
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepository.ni0026_5ErrorInFile(e.getMessage().trim()));
            }
        }

        private void closeFile() {

            try {
                if(notNull(inputBufferReader))
                    inputBufferReader.close();
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepository.ni0026_5ErrorInFile(e.getMessage().trim()));
            }
        }

        private String readRecord() {

            String record = null;
            try {
                record =  inputBufferReader.readLine();
            } catch (IOException exception) {

                throw new RunAbortedException(CustomMessageRepository.ni0026_5ErrorInFile(exception.getMessage().trim()));
            }
            return record;
        }

        private String getFieldValue(String record, int startPos, int length) {

            String value = "";
            if(record.length() >= startPos+length){
                value = record.substring(startPos, startPos+length).trim();
            }
            return value;
        }

        private void validateField(String value, String name, int startPos, int endPos){
            if(isBlankOrNull(value)){
                addError(CustomMessageRepository.ni0026_5MandatoryfieldIsBlank(
                        name,
                        String.valueOf(startPos),
                        String.valueOf(endPos+1)));
            }
        }

        public void finalizeThreadWork()
        throws ThreadAbortedException, RunAbortedException {

            try {
                if(notNull(inputBufferReader)){
                    inputBufferReader.close();
                }
            } catch (IOException exception) {

                throw new RunAbortedException(CustomMessageRepository.ni0026_5ErrorInFile(exception.getMessage().trim()));
            }
        }
    }

}
