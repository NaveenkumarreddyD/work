/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm would perform payment matching (apply Spire Credit)
 * whenever a customer on FARP Payment Arrangement makes a payment.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-08-22  JHERNA		SysAid#245408 Initial Version.
 * 2018-11-08  JHERNA		SysAid#271021 Add a parameter for the Adjustment
 *                          Type to use for payment matching (currently this
 *                          is using the same Adjustment Type as Budget 
 *                          Credit retrieved from the Low Income Feature 
 *                          Configuration but it was found out that a 
 *                          different adjustment type should be used).
 * 2019-02-27  JHERNA		SysAid#280910 ensure that payment matching
 * 							would only happen if there are left over balance.
 * 2019-03-15  JHERNA		SysAid#280910/271018. Ensure that the payment matching
 * 							amount does not exceed the payoff balance.
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.payFreeze;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.payFreeze.SaTypePaymentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
import com.splwg.ccb.domain.payment.tenderControl.entity.TenderControl;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = lowIncomeProgramFeatConf, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = exemptedTenderSources, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypePaymentEventId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjustmentTypePaymentMatching, required = true, type = entity)})
 */
public class CmLowIncomePaymentMatchingOnPASAAlgComp_Impl 
		extends CmLowIncomePaymentMatchingOnPASAAlgComp_Gen 
		implements SaTypePaymentFreezeAlgorithmSpot {

	
	/* Hard Parameter */
	@SuppressWarnings("unused")
	private FinancialTransaction hpFT;
	private Payment hpPayment;
	private PaymentSegment hpPaymentSegment;
	private ServiceAgreement hpSA;
	
	/* Soft Parameter */
	@SuppressWarnings("unused")
	private FeatureConfiguration parmLIPFeatConfig;
	private List<TenderSource> parmListOfExemptedTenderSources;
	private CharacteristicType parmCharTypePayEventID;
	/*START ADD - JHERNA - 2018-11-08 - SysAid#271021 */
	private AdjustmentType parmAdjTypePayMatching;
	/*END ADD - JHERNA - 2018-11-08 - SysAid#271021 */
	
	/* Work Variables */
	private String wAlgorithm;
	/*START DELETE - JHERNA - 2018-11-08 - SysAid#271021 */
	//private AdjustmentType wAdjTypeSpireCredit;
	/*END DELETE - JHERNA - 2018-11-08 - SysAid#271021 */
	private Date wPaymentDate;
	
	/* Constants */
	private static final String COMMA = ",";
	@SuppressWarnings("unused")
	private static final CmMGEFeatureConfigurationOptionsRetriever FCHELPER = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		wAlgorithm = this.getAlgorithmId().getTrimmedValue();
		parmListOfExemptedTenderSources = new ArrayList<TenderSource>();
		
		// Retrieve Parameter 10: Low Income Program Feature Configuration
		parmLIPFeatConfig = this.getLowIncomeProgramFeatConf();
		// Retrieve Parameter 20: List of Exempted Tender Sources
		String temp = this.getExemptedTenderSources();
		StringTokenizer st = new StringTokenizer(temp, COMMA);
		while (st.hasMoreTokens()) {
			String tenderSourceStr = st.nextToken();
			TenderSource_Id tenderSourceID = new TenderSource_Id(tenderSourceStr.trim());
			if (isNull(tenderSourceID.getEntity())) {
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(
						wAlgorithm,
						"Exempted Tender Source", 
						tenderSourceStr));
			}
			parmListOfExemptedTenderSources.add(tenderSourceID.getEntity());			
		}	
		/*START DELETE - JHERNA - 2018-11-08 - SysAid#271021 */
		/*
		wAdjTypeSpireCredit = FCHELPER.getAdjustmentTypeFeatureOptionValue(
				parmLIPFeatConfig.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.SPIRE_CREDIT_ADJUSTMENT_TYPE,
				Bool.TRUE, 
				Bool.FALSE).getEntity();
		*/
		/*END DELETE - JHERNA - 2018-11-08 - SysAid#271021 */
		
		parmCharTypePayEventID = this.getCharTypePaymentEventId();
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(parmCharTypePayEventID, CharacteristicEntityLookup.constants.ADJUSTMENT);
		if (isNull(charEntityID.getEntity())) {
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(wAlgorithm,
					"Characteristic Type for SA ID",
					parmCharTypePayEventID.getId().getTrimmedValue(),
					"Adjustment"));
		}
		
		/*START ADD - JHERNA - 2018-11-08 - SysAid#271021 */
		parmAdjTypePayMatching = this.getAdjustmentTypePaymentMatching();
		/*END ADD - JHERNA - 2018-11-08 - SysAid#271021 */
	}

	@Override
	public void setFinancialTransaction(FinancialTransaction arg0) {
		hpFT = arg0;
	}

	@Override
	public void setPayment(Payment arg0) {
		hpPayment = arg0;
		wPaymentDate = hpPayment.getPaymentEvent().getPaymentDate();
	}

	@Override
	public void setPaymentSegment(PaymentSegment arg0) {
		hpPaymentSegment = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		hpSA = arg0;
	}
	
	@Override
	public void invoke() {

		// START ADD - JHERNA - 2018-02-27 - SysAid#280910
		// Do not perform any payment matching if the customer's payment will result in a zero payoff balance.
		Money payoffBalance = hpSA.getPayoffBalance();
		if (payoffBalance.isLessThanOrEqual(Money.ZERO)) {
			return;
		}		
		// END ADD - JHERNA - 2018-02-27 - SysAid#280910
		
		PaymentEvent payEvent = hpPayment.getPaymentEvent();
		Iterator<PaymentTender> collPaymentTender = payEvent.getPaymentTenders().iterator();
		while (collPaymentTender.hasNext()) {
			
			PaymentTender payTender = collPaymentTender.next();
			TenderControl tenderControl = payTender.fetchTenderControl();
			TenderSource tenderSource = tenderControl.getTenderSource();
			
			// If tender source matches any on the exempted tender source, skip to the next payment tender
			if (parmListOfExemptedTenderSources.contains(tenderSource)) {
				continue;
			}			

			// START CHANGES - JHERNA - 2019-03-15 - SysAid#280910
//			/*Prepare the Frozen Adjustment Data*/
//			CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
//			data.setServiceAgreement(hpSA);
//			/*START CHANGE - JHERNA - 2018-11-08 - SysAid#271021 */
//			//data.setAdjustmentType(wAdjTypeSpireCredit);
//			data.setAdjustmentType(parmAdjTypePayMatching);
//			/*END CHANGE - JHERNA - 2018-11-08 - SysAid#271021 */
//			data.setAdjustmentAmount(hpPaymentSegment.getPaySegmentAmount().negate());  
//			data.setAdjustmentDate(wPaymentDate);
//			data.setCalculationDate(wPaymentDate);
//			data.setArrearsDate(wPaymentDate);
//			data.setAllowZeroAmount(Bool.FALSE);
//			data.setTransferServiceAgreement(null);
			Money adjAmount = hpPaymentSegment.getPaySegmentAmount();
			if (adjAmount.isGreaterThan(payoffBalance)) {
				adjAmount = payoffBalance;
			}
			
			/*Prepare the Frozen Adjustment Data*/
			CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
			data.setServiceAgreement(hpSA);
			data.setAdjustmentType(parmAdjTypePayMatching);
			data.setAdjustmentAmount(adjAmount.negate());  
			data.setAdjustmentDate(wPaymentDate);
			data.setCalculationDate(wPaymentDate);
			data.setArrearsDate(wPaymentDate);
			data.setAllowZeroAmount(Bool.FALSE);
			data.setTransferServiceAgreement(null);
			// END CHANGES - JHERNA - 2019-03-15 - SysAid#280910
			
			Adjustment newSpireCreditAdj = cmCreateAdustment(hpSA, data);
			
			/*Create Adjustment Characteristic*/
			cmCreateAdjChar(newSpireCreditAdj, parmCharTypePayEventID, hpPayment.getPaymentEvent().getId().getTrimmedValue());
			
			break;
		}		
	}	
	
	private Adjustment cmCreateAdustment(ServiceAgreement sa, CreateFrozenAdjustmentData input) {
		
		Adjustment returnValue = null;
		CreateFrozenAdjustmentData output = sa.createFrozenAdjustment(input);
		returnValue = output.getAdjustment();
		return returnValue;
	}	
	
	private void cmCreateAdjChar(Adjustment adj, CharacteristicType charType, String charValue) {
		
		if (notBlank(charValue)) {
			
			AdjustmentCharacteristic_Id adjCharID = new AdjustmentCharacteristic_Id(charType, adj, BigInteger.TEN);
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			
			if (notNull(adjCharID.getEntity())) {
				
				
				AdjustmentCharacteristic_DTO adjCharDTO = adjCharID.getEntity().getDTO();
				
				if (charTypeLookup.isForeignKeyValue()) {
					adjCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
				}
				else if (charTypeLookup.isPredefinedValue()) {
					adjCharDTO.setCharacteristicValue(charValue.trim());
				}
				else {
					adjCharDTO.setAdhocCharacteristicValue(charValue.trim());
				}
				adjCharID.getEntity().setDTO(adjCharDTO);
				
			}
			else {
				
				AdjustmentCharacteristic_DTO adjCharDTO = new AdjustmentCharacteristic_DTO();
				
				if (charTypeLookup.isForeignKeyValue()) {
					adjCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
				}
				else if (charTypeLookup.isPredefinedValue()) {
					adjCharDTO.setCharacteristicValue(charValue.trim());
				}
				else {
					adjCharDTO.setAdhocCharacteristicValue(charValue.trim());
				}
				adjCharDTO.setId(adjCharID);
				adjCharDTO.newEntity();
			}
		}						
	}
}
