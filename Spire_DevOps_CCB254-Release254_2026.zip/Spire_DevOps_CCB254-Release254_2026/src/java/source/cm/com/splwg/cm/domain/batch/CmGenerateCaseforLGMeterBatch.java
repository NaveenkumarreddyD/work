/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Generate L+G Case for Small/Large Meters
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 * 2024-05-01   IReyes  E-08700. Initial version.
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseTypeCaseStatues;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author OGC04200
 *
@BatchJob (multiThreaded = false, rerunnable = true, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_CHAR_TYPE_SP, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_CHAR_TYPE_MTR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_CHAR_TYPE_BDG, required = true, type = entity)})
 */
public class CmGenerateCaseforLGMeterBatch extends
		CmGenerateCaseforLGMeterBatch_Gen {

    // Batch Parameters
    private String parmFilePath;
    private String parmFileName;

    @Override
    public void validateSoftParameters(boolean arg0) {

        // File Path must be an existing directory
        String filePath = getParameters().getFILE_PATH();
        File folder = new File(filePath);
        if (!folder.isDirectory()) {
            addError(CustomMessageRepositorySpireOne.E08700_InvalidFilePath("FILE_PATH"));
        }
    }
	
	public JobWork getJobWork() {
		
		List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = null;

        parmFilePath = getParameters().getFILE_PATH();
        parmFileName = getParameters().getFILE_NAME();        
        
        File file = new File(parmFilePath, parmFileName);
        BufferedReader bufferedReader = null;
        try {
			
        	bufferedReader = new BufferedReader(new FileReader(file));
			
            while (bufferedReader.ready()) {
                String record = bufferedReader.readLine();

                if (isBlankOrNull(record.trim())){
                    // Skip blank lines
                    continue;
                }
                
                ServicePoint_Id servicePointId = new ServicePoint_Id(record.trim()); 
                
                threadWorkUnit = new ThreadWorkUnit();
                threadWorkUnit.setPrimaryId(servicePointId);
                threadWorkUnitList.add(threadWorkUnit);
            }
            
            bufferedReader.close();
        } catch (FileNotFoundException fe) {
            addError(CustomMessageRepositorySpireOne.E08700_FileNotFound());
        } catch (IOException ioe) {
             addError(CustomMessageRepositorySpireOne.E08700_ErrorFileReading(ioe.getMessage()));
             ioe.printStackTrace();
        }
		
		return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
	}

	public Class<CmGenerateCaseforLGMeterBatchWorker> getThreadWorkerClass() {
		return CmGenerateCaseforLGMeterBatchWorker.class;
	}

	public static class CmGenerateCaseforLGMeterBatchWorker extends
			CmGenerateCaseforLGMeterBatchWorker_Gen {

        // Batch Parameters
		private CaseType parmCaseType;
        private CharacteristicType parmCharTypeSp;
        private CharacteristicType parmCharTypeMtr;
        private CharacteristicType parmCharTypeBdg;
        
        private ArrayList <CaseCharacteristic_DTO> charList;
        
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			// Retrieve Batch Parameters
			parmCaseType = getParameters().getCASE_TYPE();
			parmCharTypeSp = getParameters().getCASE_CHAR_TYPE_SP();
			parmCharTypeMtr = getParameters().getCASE_CHAR_TYPE_MTR();
			parmCharTypeBdg = getParameters().getCASE_CHAR_TYPE_BDG();
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			ServicePoint_Id servicePointId = (ServicePoint_Id) unit.getPrimaryId();
			ServicePoint servicePoint = servicePointId.getEntity();
			
			charList = new ArrayList<CaseCharacteristic_DTO>();
			
			
			//Check if Case already exist for the SP
			if (notNull(servicePoint) && lgMeterChangeCaseExist(servicePoint.getId().getIdValue()).isFalse()){
				//Retrieve the latest active gas SA linked to the SP 
				ServiceAgreement_Id gasSa = getLatestGasSa(servicePointId);
				
				if(isNull(gasSa)) {
					//Raise an error if no active gas SA is found
					addError(CustomMessageRepositorySpireOne.E08700_NoGasSaFound(servicePointId.getIdValue()));
				}
				
				//Retrieve the meter currently installed on the SP
				Meter_Id meterId = getMeterId(servicePointId);
				if(isNull(meterId)) {
					//Raise an error if no active gas SA is found
					addError(CustomMessageRepositorySpireOne.E08700_NoMeterInstalled(servicePointId.getIdValue()));
				}
				
				//Retrieve the account and the main customer
				Account_Id acctId = gasSa.getEntity().getAccount().getId();
				Person_Id mainPersonId = cmGetMainPerson(acctId);
				
				//Create case
				createCase(servicePointId, meterId, acctId, mainPersonId);
				
			}
			
			return true;
		}
		
        private Bool lgMeterChangeCaseExist(String spId) {

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.append("SELECT ");
            stringBuilder.append(  "CC.CASE_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "CI_CASE CS, CI_CASE_CHAR CC ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "CS.CASE_TYPE_CD = :caseType ");
            stringBuilder.append(  "AND CS.CASE_COND_FLG = :open ");
            stringBuilder.append(  "AND CS.CASE_ID = CC.CASE_ID ");
            stringBuilder.append(  "AND CC.CHAR_TYPE_CD = :charType ");
            stringBuilder.append(  "AND TRIM(CC.SRCH_CHAR_VAL) = :spId ");

            PreparedStatement getCase = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getCase.bindId("caseType", parmCaseType.getId());
            getCase.bindLookup("open", CaseConditionLookup.constants.OPEN);
            getCase.bindId("charType", parmCharTypeSp.getId());
            getCase.bindStringProperty("spId", CaseCharacteristic.properties.searchCharacteristicValue, spId);
            
            if (getCase.list().size() == 0) {
                return Bool.FALSE;
            }
            
            return Bool.TRUE;
        }
        
        private ServiceAgreement_Id getLatestGasSa(ServicePoint_Id servicePointId) {
            	
        	ServiceAgreement_Id latestGasSA = null;
        	
        	StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.append("SELECT ");
            stringBuilder.append(  "SA.SA_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "CI_SA_SP SASP, CI_SA SA ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "SASP.SP_ID = :spId ");
            stringBuilder.append(  "AND SASP.SA_ID = SA.SA_ID ");
            stringBuilder.append(  "AND SA.SA_STATUS_FLG = :active ");
            stringBuilder.append(  "ORDER BY SA.START_DT DESC ");

            PreparedStatement getGasSa = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getGasSa.bindId("spId", servicePointId);
            getGasSa.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            
    		SQLResultRow row = getGasSa.firstRow(); 		
    		
    		if(notNull(row)) {
    			latestGasSA = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
    		}
    		getGasSa.close();
    		
    		return latestGasSA;
        }

    	private Person_Id cmGetMainPerson(Account_Id accountId) {
    		
    		Person_Id mainPersonId = null;

    		StringBuilder stringBuilder = new StringBuilder();
    		stringBuilder.append("SELECT ");
    		stringBuilder.append(  "AP.PER_ID ");
    		stringBuilder.append("FROM ");
    		stringBuilder.append(  "CI_ACCT_PER AP ");
    		stringBuilder.append("WHERE ");
    		stringBuilder.append(	 "AP.ACCT_ID = :accountId ");
    		stringBuilder.append(  "AND AP.MAIN_CUST_SW = 'Y' ");
            
    		PreparedStatement query = createPreparedStatement(stringBuilder.toString(), getClass().getName());	
            query.bindId("accountId", accountId);            
            query.execute();
            
            if(query.list().size() > 0){
            	mainPersonId = (Person_Id) query.firstRow().getId("PER_ID", Person.class);
            }
            query.close();
            
    		return mainPersonId;
    	}
    	
        private Meter_Id getMeterId (ServicePoint_Id spId) {
            
        	Meter_Id meterId = null;
            
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT ");
            stringBuilder.append(  "SPMH.MTR_CONFIG_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "CI_SP_MTR_HIST SPMH ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "SPMH.SP_ID = :spId ");
            stringBuilder.append(  "AND (SPMH.REMOVAL_DTTM IS NULL ");
            stringBuilder.append(  "OR SPMH.REMOVAL_DTTM > :currentDate)");

            PreparedStatement getMeter = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getMeter.bindId("spId", spId);
            getMeter.bindDate("currentDate", getProcessDateTime().getDate());

            SQLResultRow sqlRow = getMeter.firstRow();
            
            if (notNull(sqlRow)) {
                MeterConfiguration_Id meterConfigId = (MeterConfiguration_Id) sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
                meterId = meterConfigId.getEntity().getMeter().getId();
            }
            getMeter.close();
            
            return meterId;
        }
    	
        private void createCase(ServicePoint_Id servicePointId, Meter_Id meterId, Account_Id acctId, Person_Id personId){

            ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
            parmCaseType = parmCaseType.getId().getEntity();
            CaseTypeCaseStatues statuses = parmCaseType.getCaseStatues();
            for (CaseStatus status : statuses){
                if(status.getStatusCondition().isInitial()){
                    toDoCaseDTO.setCaseStatusId(status.getId());
                }
            }
        	
            toDoCaseDTO.setAccountId(acctId);
            toDoCaseDTO.setPersonId(personId);
            toDoCaseDTO.setPremiseId(servicePointId.getEntity().getPremise().getId());
            toDoCaseDTO.setCaseCondition(CaseConditionLookup.constants.OPEN);
            toDoCaseDTO.setContactPersonId(personId);
            toDoCaseDTO.setUserId(getActiveContextUser().getId());

            addCharacteristic(parmCharTypeMtr, meterId.getTrimmedValue());
            addCharacteristic(parmCharTypeSp, servicePointId.getTrimmedValue());
            addCharacteristic(parmCharTypeBdg, meterId.getEntity().getBadgeNumber());
            
            CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
            caseCreatorData.setToDoCaseDTO(toDoCaseDTO);             
            caseCreatorData.setCaseCharacteristics(charList);

            CaseCreator caseCreator = CaseCreator.Factory.newInstance();
            caseCreatorData = caseCreator.createCase(caseCreatorData);
        }
        
        private void addCharacteristic(CharacteristicType charType, String charVal){
            
        	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            CaseCharacteristic_DTO caseCharacteristicDTO;   
            CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), ToDoCase_Id.NULL, BigInteger.ONE);            
            caseCharacteristicDTO = caseCharacteristicId.newDTO();
            caseCharacteristicDTO.setId(caseCharacteristicId);
            if(charTypeLookup.isAdhocValue()){
                caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
            } else if (charTypeLookup.isPredefinedValue()){
                caseCharacteristicDTO.setCharacteristicValue(charVal);
            } else if (charTypeLookup.isForeignKeyValue()){
                caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
            }
            charList.add(caseCharacteristicDTO);
        }        
	}
}
