/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0011.2 Appointment Reminder Callouts       
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2012-04-02   Arun    NI0011.2. Initial Version.
 * 2013-05-20   Karthik KL20130520 - Fix for TIR3 - Customer Contact  
 *                      created should not be in Open state.
 * 2013-06-12   Karthik KL20130612 - Defect fix for #2162 - Placed null checks
 * 2015-05-11   JHERNA  Defect#3218755 - Updated the main selection criteria
 *                      to fix the issue with the offset day.
 * 2015-06-15   BMarque SF-3236623. If APRMACCT or APRMPHN are missing from
 *                      Field Activity, derive values and create FA
 *                      Extracted Customer Contact.
 * 2015-10-02	JHERNA	Defect#3312236 - request to log an informational error 
 * 						message on the batch run tree. 
 * 2016-01-27	MPang	Updated for CCB v2.4 compilation.
 * 2021-05-20 	JMeden	B-18775. Update logic to not create an extract and 
 * 						create a reminder customer contact and outbound		
 * 2021-08-02	JMeden	B-18775.Issue1. Added Address and Postal to Outbound
 * 						Message 
 * 2021-08-25	JMeden  Defect 4582581. Update logic to get the Account
 * 						of FA Between the Start and Stop DATE of Service 
 * 						Agreement. 
 * 2021-08-26	JMeden  Defect 4582582. Add Text Destination if the 
 * 						Communication Type is C.
 * 2021-11-18   GCrisp  Defect 4582581. Add SA Status filter when getting 
 *                      the Account
 * 2022-08-24   Kiran   Send the CIS division in parameter 9   
 * 2022-11-09   Kiran   Clearing issue                  
 * 2023-05-04   Kiran   if the FA has a Account char already then no need to add again
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.lookup.TodoPriorityFlagLookup;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.message.MessageCategory;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage_Id;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator_Impl;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeCharacteristicType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountPerson;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.PersonPhone;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;*/

import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.dispatchGroupAppointmentSchedule.entity.DispatchGroupAppointmentSchedule;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityTypeCharacteristicType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonPhone;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;

/*
 * Start Change - Defect 3236623 - 2015-06-15
 */
///**
// * @author adevaraj001
// * 
// * @BatchJob ( modules = {}
// *              , multiThreaded = false
// *              , rerunnable = true
// *              , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string )
// *              , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string )
// *              , @BatchJobSoftParameter (name = OFFSET_DAYS, required = true, type = integer)
// *              , @BatchJobSoftParameter (name = FA_CHAR_TYPE_PHONE, required = true, type = entity, entityName = characteristicType)
// *              , @BatchJobSoftParameter (name = FA_CHAR_TYPE_ACCOUNT, required = true, type = entity, entityName = characteristicType)
// *              , @BatchJobSoftParameter (name = FA_CHAR_TYPE_ELIGIBILITY, required = true, type = entity, entityName = characteristicType)
// *              , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE, required = true, type=string)
// *              , @BatchJobSoftParameter (name = CUSTMER_CONTACT_CLASS, entityName = customerContactClass, required = true, type = entity)
// *              , @BatchJobSoftParameter (name = CC_CHAR_TYPE_FA_ID, required = true, type = entity, entityName = characteristicType)
// *              , @BatchJobSoftParameter (name = CC_CHAR_TYPE_CALL_DATE, required = true, type = entity, entityName = characteristicType) 
// *              , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE_ERROR, required = true, type=string)
// *              , @BatchJobSoftParameter (name = CUSTMER_CONTACT_CLASS_ERROR, entityName = customerContactClass, required = true, type = entity)})
// */
//Start Change - JMeden - B-18775 - 2021-05-20
///**
// * @author adevaraj001
// * 
// * @BatchJob (multiThreaded = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *            , @BatchJobSoftParameter (name = OFFSET_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_PHONE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_ACCOUNT, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_ELIGIBILITY, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTMER_CONTACT_CLASS, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CHAR_TYPE_FA_ID, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CHAR_TYPE_CALL_DATE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE_ERROR, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTMER_CONTACT_CLASS_ERROR, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = PRI_PER_PHONETYPE, required = true, type = string)
// *            , @BatchJobSoftParameter (name = PRI_BUS_PHONETYPE, required = true, type = string)})
// */
/**
 * @author adevaraj001
 * 
 * @BatchJob (multiThreaded = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = OFFSET_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_PHONE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_ACCOUNT, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE_ELIGIBILITY, required = true, type = entity) 
 *            , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTMER_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CHAR_TYPE_FA_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTMER_CONTACT_TYPE_ERROR, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTMER_CONTACT_CLASS_ERROR, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PRI_PER_PHONETYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PRI_BUS_PHONETYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCTBILL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EMAIL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = SMS_CUST_CL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = messageCategory, name = MESSAGE_CATEGORY, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MESSAGE_NUM, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = BO_OUTBOUND_MSG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = OUTBOUND_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CHAR_TYPE_CALL_DATE, required = true, type = entity)})
 */
//End Change - JMeden - B-18775 - 2021-05-20
/*
 * End Change - Defect 3236623 - 2015-06-15
 */

public class CmAppReminderCallouts_BatchProcess 
		extends CmAppReminderCallouts_BatchProcess_Gen {

    // Soft Parameters
    /*
     * Start Change - Defect 3236623 - 2015-06-15
     */
    //private static String parmFileName;
    //private static String parmFilePath;
    //private static BigInteger parmOffsetDays;
    //private static CharacteristicType parmPhoneCharType;   
    //private static CharacteristicType parmAccountCharType; 
    //private static CharacteristicType parmEligibilityCharType;
    //private static String parmCustomerContactType;
    //private static CustomerContactClass parmCustomerContactClass;
    //private static CharacteristicType parmFaIdCharType;   
    //private static CharacteristicType parmCallDateCharType;
    //private static String parmCustomerContactTypeError;
    //private static CustomerContactClass parmCustomerContactClassError;
    //private static CustomerContactType_Id custContactType = null;
    //private static CustomerContactType_Id custContactTypeError = null;
	//Start Delete - JMeden - B-18775 - 2021-05-20
    //private String parmFilePath;
    //End Delete - JMeden - B-18775 - 2021-05-20
    private BigInteger parmOffsetDays;
    private CharacteristicType parmPhoneCharType;   
    private CharacteristicType parmAccountCharType; 
    private CharacteristicType parmEligibilityCharType;
    private String parmCustomerContactType;
    private CustomerContactClass parmCustomerContactClass;
    private CharacteristicType parmFaIdCharType;   
    private CharacteristicType parmCallDateCharType;
    private String parmCustomerContactTypeError;
    private CustomerContactClass parmCustomerContactClassError;
    private CustomerContactType_Id custContactType = null;
    private CustomerContactType_Id custContactTypeError = null;
    //Start Add - JMeden - B-18775 - 2021-05-20
    private String parmSmsCustomerClasses;
    private MessageCategory parmMessageCategory;
    private BigInteger parmMessageNumber;
	//End Add - JMeden - B-18775 - 2021-05-20
    /*
     * End Change - Defect 3236623 - 2015-06-15
     */

    // Constants
    /*
     * Start Remove - Defect 3236623 - 2015-06-15
     */
    //private static DateFormat dateFormat = new DateFormat("yyyyMMdd");
    /*
     * End Remove - Defect 3236623 - 2015-06-15
     */
    private static final String COMMA_DELIMITER = ",";
    //Start Add - JMeden - B-18775 - 2021-05-20
	private static final String PMOC_GROUP_INPUT = "input";
	private static final String PMOC_GROUP_OUTPUT = "output";
	private static final String PMOC_ACCOUNT_ID = "accountId";
	private static final String CM_PMOCINFO="CM-PmocInfo";
	//End Add - JMeden - B-18775 - 2021-05-20

    public void validateSoftParameters(boolean isNewRun) {
        initializeSoftParams();
     	//Start Delete - JMeden - B-18775 - 2021-05-20
        // Raise an error if the FILE_PATH is invalid.
        //File folder = new File(parmFilePath);
        //if(!(folder.exists() && folder.isDirectory())){
        //    addError(CustomMessageRepository.ni0011_2InvalidFilePath(parmFilePath));
        //}
        //End Delete - JMeden - B-18775 - 2021-05-20

        if (notNull(parmOffsetDays) && parmOffsetDays.intValue() < 0) {
            addError(CustomMessageRepository.ni0011_2OffSetDaysCannotBeLessThanZero(parmOffsetDays.toString().trim()));
        }

        validateChar(parmPhoneCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
        validateChar(parmAccountCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
        validateChar(parmEligibilityCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);        
        validateChar(parmFaIdCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);    
        validateChar(parmCallDateCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);

        custContactType = new CustomerContactType_Id(parmCustomerContactClass, parmCustomerContactType);
        if(isNull(custContactType.getEntity())){
            addError(CustomMessageRepository.ni0011_2InvalidCustomerContactType(parmCustomerContactClass.getId().getTrimmedValue(), parmCustomerContactType.toString().trim()));  
        }

        custContactTypeError = new CustomerContactType_Id(parmCustomerContactClassError, parmCustomerContactTypeError);
        if(isNull(custContactTypeError.getEntity())){
            addError(CustomMessageRepository.ni0011_2InvalidCustomerContactType(parmCustomerContactClassError.getId().getTrimmedValue(), parmCustomerContactTypeError.toString().trim()));  
        }
        
        //Start Add - JMeden - B-18775 - 2021-05-20
        String[] arrCustomerClass =  parmSmsCustomerClasses.split(",");
        CustomerClass_Id ccId = null;
        for(String customerClassId : arrCustomerClass){
        	ccId = new CustomerClass_Id(customerClassId);
        	
        	if(isNull(ccId.getEntity())){
        		addError(CustomMessageRepository.B_18775_InvalidCustomerClass(customerClassId));  
        	}
        }
        
        Message_Id messageId = new Message_Id(parmMessageCategory, parmMessageNumber);
        if(isNull(messageId.getEntity())){
        	addError(CustomMessageRepository.B_18775_InvalidMessageCombination(parmMessageCategory.getId().getIdValue().toString(), parmMessageNumber.toString()));  
        }

        //End Add - JMeden - B-18775 - 2021-05-20
        
        /*
         * Start Add - Defect 3236623 - 2015-06-15
         */
        for (String phoneTypeIdString : getParameters().getPRI_PER_PHONETYPE().split(COMMA_DELIMITER)) {
            phoneTypeIdString = phoneTypeIdString.trim();
            if (phoneTypeIdString.length() > PhoneType_Id.FIELD_SIZE) {
                addError(CustomMessageRepositoryMGE.ni0011_2InvalidPriorityPersonPhoneType(phoneTypeIdString));
            }
            PhoneType_Id phoneTypeId = new PhoneType_Id(phoneTypeIdString);
            if (isNull(phoneTypeId.getEntity())) {
                addError(CustomMessageRepositoryMGE.ni0011_2InvalidPriorityPersonPhoneType(phoneTypeIdString));
            }
        }
        
        for (String phoneTypeIdString : getParameters().getPRI_BUS_PHONETYPE().split(COMMA_DELIMITER)) {
            phoneTypeIdString = phoneTypeIdString.trim();
            if (phoneTypeIdString.length() > PhoneType_Id.FIELD_SIZE) {
                addError(CustomMessageRepositoryMGE.ni0011_2InvalidPriorityBusinessPhoneType(phoneTypeIdString));
            }
            PhoneType_Id phoneTypeId = new PhoneType_Id(phoneTypeIdString);
            if (isNull(phoneTypeId.getEntity())) {
                addError(CustomMessageRepositoryMGE.ni0011_2InvalidPriorityBusinessPhoneType(phoneTypeIdString));
            }
        }
        /*
         * End Add - Defect 3236623 - 2015-06-15
         */
        
    }

    private void validateChar(CharacteristicType charType,CharacteristicEntityLookup charEntity){
        CharacteristicEntity_Id charEntityId; 
        charEntityId = new CharacteristicEntity_Id(charType, charEntity);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.ni0011_2InvalidCharType(charType.getId().getTrimmedValue(),charEntity.getLookupValue().fetchLanguageDescription()));
        }
    }

    /**
     * @return void
     *  This method retrieves Batch Param varaibles and initializes the class variables
     */   
    private void initializeSoftParams(){
        /*
         * Start Delete - Defect 3236623 - 2015-06-15
         */
        //parmFileName = getParameters().getFILE_NAME(); 
        /*
         * End Delete - Defect 3236623 - 2015-06-15
         */
    	//Start Delete - JMeden - B-18775 - 2021-05-20
        //parmFilePath = getParameters().getFILE_PATH();
        //End Delete - JMeden - B-18775 - 2021-05-20
        parmOffsetDays = getParameters().getOFFSET_DAYS();
        parmPhoneCharType = getParameters().getFA_CHAR_TYPE_PHONE();
        parmAccountCharType = getParameters().getFA_CHAR_TYPE_ACCOUNT();
        parmEligibilityCharType = getParameters().getFA_CHAR_TYPE_ELIGIBILITY();
        parmCustomerContactType = getParameters().getCUSTMER_CONTACT_TYPE();
        parmCustomerContactClass = getParameters().getCUSTMER_CONTACT_CLASS();
        parmFaIdCharType = getParameters().getCC_CHAR_TYPE_FA_ID();
        parmCallDateCharType = getParameters().getCC_CHAR_TYPE_CALL_DATE();
        parmCustomerContactTypeError = getParameters().getCUSTMER_CONTACT_TYPE_ERROR();
        parmCustomerContactClassError = getParameters().getCUSTMER_CONTACT_CLASS_ERROR();
        //Start Add - JMeden - B-18775 - 2021-05-20
        parmSmsCustomerClasses = getParameters().getSMS_CUST_CL();
        parmMessageCategory = getParameters().getMESSAGE_CATEGORY();
        parmMessageNumber = getParameters().getMESSAGE_NUM();
        //End Add - JMeden - B-18775 - 2021-05-20
    }
    
    @SuppressWarnings("unchecked")
    public JobWork getJobWork() {
        QueryIterator mainIter = getAppointmentFA().iterate();
        return createJobWorkForQueryIterator(mainIter, this);
    }
    
    private PreparedStatement getAppointmentFA(){
        StringBuilder getAppointmentFAQueryStr = new StringBuilder();
        getAppointmentFAQueryStr.append("SELECT FA.FA_ID, FA.FA_TYPE_CD, trunc(FA.SCHED_DTTM) SCHED_DTTM, ");
        // START ADD - JHERNA - 2015-05-11 - DEFECT#3218755
        getAppointmentFAQueryStr.append("       APS.START_DTTM APPT_SCHED_DT, ");
        // END ADD - JHERNA - 2015-05-11 - DEFECT#3218755
        getAppointmentFAQueryStr.append("TO_CHAR(APS.START_DTTM, 'HH24') START_HOUR, TO_CHAR(APS.END_DTTM, 'HH24') END_HOUR ");
        getAppointmentFAQueryStr.append("FROM CI_FA FA, CI_DG_APP_SCHED APS ");
        getAppointmentFAQueryStr.append("WHERE FA.APP_SCHED_ID = APS.APP_SCHED_ID ");
        getAppointmentFAQueryStr.append("AND TRUNC(FA.SCHED_DTTM) = :faSchedDate ");
        // START DELETE - JHERNA - 2015-05-11 - DEFECT#3218755
        //getAppointmentFAQueryStr.append("AND FA.SCHED_DTTM - FA.CRE_DTTM >= :days  ");
        // END DELETE - JHERNA - 2015-05-11 - DEFECT#3218755
        getAppointmentFAQueryStr.append("AND FA.FA_STATUS_FLG = :faPendingStatus ");
        getAppointmentFAQueryStr.append("AND EXISTS ( SELECT 'X' FROM CI_FA_CHAR FC WHERE FA.FA_ID = FC.FA_ID AND FC.CHAR_TYPE_CD = :eligibilityCharType) ");
        //Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement appointmentFAQueryPrepStmt = createPreparedStatement(getAppointmentFAQueryStr.toString());
        PreparedStatement appointmentFAQueryPrepStmt = createPreparedStatement(getAppointmentFAQueryStr.toString(), getClass().getName());
        //End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        appointmentFAQueryPrepStmt.bindDate("faSchedDate", getProcessDateTime().getDate().addDays(parmOffsetDays.intValue()));
        // START DELETE - JHERNA - 2015-05-11 - DEFECT#3218755
        //appointmentFAQueryPrepStmt.bindBigInteger("days", BigInteger.valueOf(3));
        // END DELETE - JHERNA - 2015-05-11 - DEFECT#3218755
        appointmentFAQueryPrepStmt.bindLookup("faPendingStatus",  FieldActivityStatusLookup.constants.PENDING);
        appointmentFAQueryPrepStmt.bindId("eligibilityCharType", parmEligibilityCharType.getId());

        if(appointmentFAQueryPrepStmt.list().isEmpty()){
        	// START CHANGE - JHERNA - 2015-10-02 - 3312236
            //addError(CustomMessageRepository.ni0011_2NoEligibleAppointmentFaNotFound());
        	cmCreateToDoEntry();
        	// END CHANGE - JHERNA - 2015-10-02 - 3312236
        }
        return appointmentFAQueryPrepStmt; 
    }

    //START ADD - JHERNA - 2015-10-02 - 3312236
    private static final ToDoType_Id TD_TYPE_ID = new ToDoType_Id("CMAPPREM");
    private ToDoEntry cmCreateToDoEntry() {
    	
    	ToDoEntry newTdEntry = null;

    	// Create To Do Entry DTO    	
    	ToDoEntry_DTO tdEntryDTO = new ToDoEntry_DTO();
    	tdEntryDTO.setBatchControlId(this.getBatchControlId());
    	tdEntryDTO.setBatchNumber(this.getBatchNumber());
    	tdEntryDTO.setCreationDateTime(this.getProcessDateTime());
    	tdEntryDTO.setMessageId(new Message_Id(new MessageCategory_Id(BigInteger.valueOf(90003)), BigInteger.valueOf(5504)));
    	tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
    	tdEntryDTO.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_5_0);
    	tdEntryDTO.setToDoTypeId(TD_TYPE_ID);
    	tdEntryDTO.setToDoRoleId(TD_TYPE_ID.getEntity().getDefaultRole().fetchIdToDoRole().getId());

    	// Instantiate To Do Creator
    	ToDoCreator_Impl tdCreator = new ToDoCreator_Impl();
    	tdCreator.setToDoDTO(tdEntryDTO);        	    	
    	tdCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(TD_TYPE_ID.getEntity(), BigInteger.valueOf(1)).getEntity(), this.getBatchControlId().getTrimmedValue());
    	tdCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(TD_TYPE_ID.getEntity(), BigInteger.valueOf(2)).getEntity(), this.getBatchNumber().toString());
    	tdCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(TD_TYPE_ID.getEntity(), BigInteger.valueOf(3)).getEntity(), this.getBatchRerunNumber().toString());    	
    	tdCreator.addSortKeyValue(new ToDoSortKeyType_Id(TD_TYPE_ID.getEntity(), BigInteger.valueOf(1)).getEntity(), this.getBatchControlId().getTrimmedValue());
    	
    	newTdEntry = tdCreator.create();
    	    	
    	return newTdEntry;
    }
    //END ADD - JHERNA - 2015-10-02 - 3312236
    
    @Override
    public ThreadWorkUnit createWorkUnit(QueryResultRow row){
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
        FieldActivity_Id faId = (FieldActivity_Id)row.getId("FA_ID", FieldActivity.class);
        threadUnit.setPrimaryId(faId);
        threadUnit.addSupplementalData("FA_TYPE_CD", row.getString("FA_TYPE_CD"));
        threadUnit.addSupplementalData("SCHED_DTTM", row.getDate("SCHED_DTTM"));
        threadUnit.addSupplementalData("START_HOUR", row.getString("START_HOUR"));
        threadUnit.addSupplementalData("END_HOUR", row.getString("END_HOUR"));
        // START ADD - JHERNA - 2015-05-11 - DEFECT#3218755
        threadUnit.addSupplementalData("APPT_SCHED_DT", row.getDate("APPT_SCHED_DT"));
        // END ADD - JHERNA - 2015-05-11 - DEFECT#3218755
        
        return threadUnit;
    }  

    public Class<CmAppReminderCallouts_BatchProcessWorker> getThreadWorkerClass() {
        return CmAppReminderCallouts_BatchProcessWorker.class;
    }

    public static class CmAppReminderCallouts_BatchProcessWorker extends
    CmAppReminderCallouts_BatchProcessWorker_Gen {

        // Thread Class Variables
    	//Start Delete - JMeden - B-18775 - 2021-05-20
        //private BufferedWriter bufferedWriter;
        //private File inputFilePathAndName;
        //private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;
        //End Delete - JMeden - B-18775 - 2021-05-20
        private FieldActivity fa;
        private String phoneCharValue;
        private String acctCharValue;
        //Start Add - JMeden - B-18775 - 2021-05-20
        private String emailCharVal = "";
    	private String smsNumPMOC = "";
    	private String smsContactId = "";
    	
    	private static final String COMM_TYPE_EMAIL = "E";
    	private static final String COMM_TYPE_SMS = "T";
    	private static final String COMM_TYPE_CALL = "C";
        //End Add - JMeden - B-18775 - 2021-05-20
        private Person_Id mainPersonId = null;
        private User_Id userId;
        private Account acctId;

        // Constants
        //Start Delete - JMeden - B-18775 - 2021-05-20
//        private static final Integer ACCOUNT_LENGTH = 30;
//        private static final Integer CUST_LENGTH = 40;
//        private static final Integer PHONE_LENGTH = 20;
//        private static final Integer FA_TYPE_LENGTH = 50;
//        private static final String HEADER_REC_TYPE = "H";
//        private static final String FROM_TIME = "0900";
//        private static final String TO_TIME = "1700";
//        private static final String NUMBER_OF_TRIES = "3";
//        private static final String CALL_AFTER_MINS = "180";
//        private static final String DETAIL_REC_TYPE = "Q";
        //End Delete - JMeden - B-18775 - 2021-05-20
        /*
         * Start Add - Defect 3236623 - 2015-06-15
         */
        //Start Delete - JMeden - B-18775 - 2021-05-20
        //private DateFormat dateFormat = new DateFormat("yyyyMMdd");
        //End Delete - JMeden - B-18775 - 2021-05-20
        /*
         * End Add - Defect 3236623 - 2015-06-15
         */
        
        /*
         * Start Add - Defect 3236623 - 2015-06-15
         */
        // Batch Parameters
        //Start Delete - JMeden - B-18775 - 2021-05-20
        //private String parmFileName;
        //private String parmFilePath;
        //End Delete - JMeden - B-18775 - 2021-05-20
        private CharacteristicType parmPhoneCharType;   
        private CharacteristicType parmAccountCharType; 
        private CharacteristicType parmFaIdCharType; 
        private CharacteristicType parmCallDateCharType;
        private CustomerContactType_Id custContactType = null;
        private CustomerContactType_Id custContactTypeError = null;
        private List<PhoneType_Id> priorityPersonPhoneTypeList;
        private List<PhoneType_Id> priorityBusinessPhoneTypeList;
        /*
         * End Add - Defect 3236623 - 2015-06-15
         */
        //Start Add - JMeden - B-18775 - 2021-05-20
        private CharacteristicType parmBillAccountCharType; 
        private CharacteristicType parmEmailCharType; 
        private String parmSmsCustomerClasses;
        private MessageCategory parmMessageCategory;
        private BigInteger parmMessageNumber;
        private CharacteristicType parmOutboundMessageCharType;
        private BusinessObject parmBusinessObjectOutbound;
        private DateFormat dateFormat = new DateFormat("MM/dd/yyyy");
        //End Add - JMeden - B-18775 - 2021-05-20

        //Member Variable
        //Start Delete - JMeden - B-18775 - 2021-05-20
        //private static Boolean PRINT_HEADER = true;
        //End Delete - JMeden - B-18775 - 2021-05-20
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException,
        RunAbortedException {
            
            /*
             * Start Add - Defect 3236623 - 2015-06-15
             */
        	//Start Delete - JMeden - B-18775 - 2021-05-20
            //parmFileName = getParameters().getFILE_NAME(); 
            //parmFilePath = getParameters().getFILE_PATH();
            //End Delete - JMeden - B-18775 - 2021-05-20
            parmPhoneCharType = getParameters().getFA_CHAR_TYPE_PHONE();
            parmAccountCharType = getParameters().getFA_CHAR_TYPE_ACCOUNT();
            parmFaIdCharType = getParameters().getCC_CHAR_TYPE_FA_ID();
            parmCallDateCharType = getParameters().getCC_CHAR_TYPE_CALL_DATE();
            //Start Add - JMeden - B-18775 - 2021-05-20
            parmBillAccountCharType = getParameters().getACCTBILL_CHAR_TYPE(); 
            parmEmailCharType = getParameters().getEMAIL_CHAR_TYPE(); 
            parmSmsCustomerClasses = getParameters().getSMS_CUST_CL();
            parmMessageCategory = getParameters().getMESSAGE_CATEGORY();
            parmMessageNumber = getParameters().getMESSAGE_NUM();     
            parmOutboundMessageCharType = getParameters().getOUTBOUND_CHAR_TYPE();
            parmBusinessObjectOutbound = getParameters().getBO_OUTBOUND_MSG();
            //End Add - JMeden - B-18775 - 2021-05-20
            
            custContactType = new CustomerContactType_Id(getParameters().getCUSTMER_CONTACT_CLASS(), getParameters().getCUSTMER_CONTACT_TYPE());
            custContactTypeError = new CustomerContactType_Id(getParameters().getCUSTMER_CONTACT_CLASS_ERROR(), getParameters().getCUSTMER_CONTACT_TYPE_ERROR());


            priorityPersonPhoneTypeList = new ArrayList<PhoneType_Id>();
            for (String phoneTypeIdString : getParameters().getPRI_PER_PHONETYPE().split(COMMA_DELIMITER)) {
                priorityPersonPhoneTypeList.add(new PhoneType_Id(phoneTypeIdString));
            }
            
            priorityBusinessPhoneTypeList = new ArrayList<PhoneType_Id>();
            for (String phoneTypeIdString : getParameters().getPRI_BUS_PHONETYPE().split(COMMA_DELIMITER)) {
                priorityBusinessPhoneTypeList.add(new PhoneType_Id(phoneTypeIdString));
            }
            /*
             * End Add - Defect 3236623 - 2015-06-15
             */
            //Start Delete - JMeden - B-18775 - 2021-05-20
            //openFileWriter();
            //End Delete - JMeden - B-18775 - 2021-05-20
        }
        
        //Start Delete - JMeden - B-18775 - 2021-05-20
//        private void populateHeaderRecord(){
//            String fromDateStr = getProcessDateTime().getDate().toString(dateFormat);
//            String toDateStr = getProcessDateTime().getDate().toString(dateFormat);
//
//            StringBuilder headerRecord = new StringBuilder();
//            headerRecord.append(HEADER_REC_TYPE);
//            headerRecord.append(COMMA_DELIMITER);
//            headerRecord.append(fromDateStr);
//            headerRecord.append(COMMA_DELIMITER);
//            headerRecord.append(toDateStr);
//            headerRecord.append(COMMA_DELIMITER);
//            headerRecord.append(FROM_TIME);
//            headerRecord.append(COMMA_DELIMITER);
//            headerRecord.append(TO_TIME);
//            headerRecord.append(COMMA_DELIMITER);
//            headerRecord.append(NUMBER_OF_TRIES);
//            headerRecord.append(COMMA_DELIMITER);""
//            headerRecord.append(CALL_AFTER_MINS);
//            writeLine(headerRecord.toString());
//        }
        //End Delete - JMeden - B-18775 - 2021-05-20
        
        
        
        //Start  Update - JMeden - B-18775 - 2021-05-20        
//        public boolean executeWorkUnit(ThreadWorkUnit unit)
//        throws ThreadAbortedException, RunAbortedException {
//
//            String accountIdStr;
//            String custName = "";
//            String phoneNumber = "";
//            String faTypeStr = "";
//            Date appScheduleDate = null;
//            String appScheduleDateStr = "";
//            String appScheduleFromTime ;
//            String appScheduleToTime = "";
//
//            FieldActivity_Id faId = (FieldActivity_Id) unit.getPrimaryId();
//            fa = faId.getEntity();
//            userId = getActiveContextUser().getId();
//            retrieveFaChar();
//            SQLResultRow acctOfFaResRow = getAccountOfFa();
//            // KL20130612 - Start of Defect fix for #2162 - Introducing null checks
//            if(notNull(acctOfFaResRow)){
//                acctId = acctOfFaResRow.getEntity("ACCT_ID", Account.class);
//            } else {
//                logError(CustomMessageRepository.ni0011_2AccountIdNotFound());
//                return false;
//            }
//            // KL20130612 - End of Defect fix for #2162
//
//            /*
//             * Start Change - Defect 3236623 - 2015-06-15
//             */
//            //if(isEmptyOrNull(phoneCharValue) || isEmptyOrNull(acctCharValue)){
//            //  // KL20130612 - Start of Defect fix for #22162
//            //  //if(isNull(acctOfFaResRow)){
//            //  //     addError(CustomMessageRepository.ni0011_2AccountIdNotFound());
//            //  //}
//            //  // KL20130612 - End of Defect fix for #22162
//            //  for (AccountPerson acctPerson : acctId.getPersons()){
//            //      if(acctPerson.getIsMainCustomer().isTrue()){
//            //          mainPersonId = acctPerson.fetchIdPerson().getId();
//            //      }
//            //  }
//            //  if(isNull(mainPersonId)){
//            //      addError(CustomMessageRepository.ni0011_2MainPersonNotFound(acctId.getId().getIdValue().trim()));
//            //  }
//            //  createCustomerContact();
//            //}
//            //else{
//            //
//            //    // START ADD - JHERNA - 2015-05-11 - DEFECT#3218755
//            //    /* 
//            //     *  Validate that the Field Activity creation date was created 
//            //     *  three days prior to Field Activity appointment schedule date 
//            //     *  (page 10 of design)
//            //     */
//            //    // Retrieve FA's Appointment Schedule Date
//            //    Date faAppointmentDate = (Date) unit.getSupplementallData("APPT_SCHED_DT");
//            //    if (faAppointmentDate.difference(fa.getCreationDateTime().getDate()).getTotalDays() != 3) {
//            //        return false;
//            //    }
//            //    
//            //    // END ADD - JHERNA - 2015-05-11 - DEFECT#3218755
//            
//            Person mainPerson = null;
//            
//            for (AccountPerson acctPerson : acctId.getPersons()) {
//                if (acctPerson.getIsMainCustomer().isTrue()) {
//                    mainPerson = acctPerson.fetchIdPerson();
//                }
//            }
//            
//            if (isNull(mainPerson)) {
//                addError(CustomMessageRepository.ni0011_2MainPersonNotFound(acctId.getId().getIdValue().trim()));
//            }
//
//            mainPersonId = mainPerson.getId();
//            
//            /* 
//             *  Validate that the Field Activity creation date was created 
//             *  three days prior to Field Activity appointment schedule date 
//             *  (page 10 of design)
//             */
//            // Retrieve FA's Appointment Schedule Date
//            Date faAppointmentDate = (Date) unit.getSupplementallData("APPT_SCHED_DT");
//            if (faAppointmentDate.difference(fa.getCreationDateTime().getDate()).getTotalDays() != 3) {
//                return false;
//            }
//
//            if (isEmptyOrNull(phoneCharValue)) {
//                
//                if (mainPerson.getPersonOrBusiness().isPerson()) {
//                    
//                    for (PersonPhone personPhone : mainPerson.getPhones()) {
//
//                        phoneCharValue = personPhone.getPhone();
//                        
//                        // If the phone number is not a priority Phone Type, keep looping
//                        if (priorityPersonPhoneTypeList.contains(personPhone.getPhoneType().getId())) {
//                            break;
//                        }
//                        
//                    }
//                    
//                } else if (mainPerson.getPersonOrBusiness().isBusiness()) {
//
//                    for (PersonPhone personPhone : mainPerson.getPhones()) {
//                        
//                        phoneCharValue = personPhone.getPhone();
//                        
//                        // If the phone number is not a priority Phone Type, keep looping
//                        if (priorityBusinessPhoneTypeList.contains(personPhone.getPhoneType().getId())) {
//                            break;
//                        }
//                        
//                    }
//                    
//                }
//                
//                // If no Phone number was found
//                if (isEmptyOrNull(phoneCharValue)) {
//                    createCustomerContact();
//                    return true;
//                }
//                
//                // Add FA Char only when record will be extracted
//                addFieldActivityCharacteristic(fa, parmPhoneCharType, phoneCharValue);
//                
//            }
//            
//            if (isEmptyOrNull(acctCharValue)) {
//                acctCharValue = acctId.getId().getTrimmedValue();
//                
//                // Add FA Char only when record will be extracted
//                addFieldActivityCharacteristic(fa, parmAccountCharType, acctCharValue);
//                
//            }
//            /*
//             * End Change - Defect 3236623 - 2015-06-15
//             */
//            
//            if(PRINT_HEADER){
//                populateHeaderRecord();
//                PRINT_HEADER = false;
//            }
//            
//            /*
//             * Start Remove - Defect 3236623 - 2015-06-15
//             */
//            //for (AccountPerson acctPerson : acctId.getPersons()){
//            //    if(acctPerson.getIsMainCustomer().isTrue()){
//            //        mainPersonId = acctPerson.fetchIdPerson().getId();
//            //    }
//            //}
//            //if(isNull(mainPersonId)){
//            //    addError(CustomMessageRepository.ni0011_2MainPersonNotFound(acctId.getId().getIdValue().trim()));
//            //}
//            /*
//             * End Remove - Defect 3236623 - 2015-06-15
//             */
//
//            appScheduleDate = (Date) unit.getSupplementallData("SCHED_DTTM");
//            appScheduleDateStr = appScheduleDate.toString(dateFormat);
//            createFaExtractedCustomerContact(appScheduleDate);
//
//            StringBuilder faRecord = new StringBuilder();
//            accountIdStr = StringUtilities.padRight(acctCharValue,ACCOUNT_LENGTH);
//            custName = mainPersonId.getEntity().getPersonPrimaryName().replaceAll("[,]", " ");
//            custName = StringUtilities.padRight(custName, CUST_LENGTH);
//            phoneNumber = StringUtilities.padRight(phoneCharValue,PHONE_LENGTH);
//            faTypeStr = (String) unit.getSupplementallData("FA_TYPE_CD");
//            faTypeStr = StringUtilities.padRight(faTypeStr.trim(),FA_TYPE_LENGTH);
//
//            appScheduleFromTime = (String) unit.getSupplementallData("START_HOUR");
//            appScheduleToTime = (String) unit.getSupplementallData("END_HOUR");
//
//            faRecord.append(DETAIL_REC_TYPE);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(accountIdStr);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(custName);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(phoneNumber);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(faTypeStr);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(appScheduleDateStr);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(appScheduleFromTime);
//            faRecord.append(COMMA_DELIMITER);
//            faRecord.append(appScheduleToTime);
//
//            writeLine(faRecord.toString());
//            numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
//            /*
//             * Start Delete - Defect 3236623 - 2015-06-15
//             */
//            //}
//            /*
//             * End Delete - Defect 3236623 - 2015-06-15
//             */
//            
//            return true;
//        }
        
        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            Bool hasPhoneNumberInFAChar = Bool.FALSE;
            Bool hasEmailInFAChar = Bool.FALSE;
            Bool hasBillAccountChar = Bool.FALSE;
            Bool hasAddedAccountChar = Bool.FALSE;
            Bool isSmsToPhoneProcess= Bool.FALSE;
            // Kiran 10-18-2022 clear the variables start
			phoneCharValue = "";
			emailCharVal = "";
			acctCharValue = "";
            acctId = null;
			
			// Kiran 10-18-2022 clear the variables end
            FieldActivity_Id faId = (FieldActivity_Id) unit.getPrimaryId();
            fa = faId.getEntity();
			
            //Get if there is an existing Customer Contact Characteristic in Field Activity
            CustomerContact_Id existingCCId;
            QueryResultRow qrrCustInfo = getCharValueFromCustomerContact(null, parmFaIdCharType.getId(), fa.getId().getTrimmedValue());
            
            if(notNull(qrrCustInfo)){
            	existingCCId = (CustomerContact_Id) qrrCustInfo.getId("ccId", CustomerContact.class);
            	//get if there is an existing Outbound message from the customer contact.
            	qrrCustInfo = getCharValueFromCustomerContact(existingCCId, parmOutboundMessageCharType.getId(), null);
            	
            	//check if outbound message exists
            	if(notNull(qrrCustInfo)){
            		OutboundMessage_Id outMsgId = new OutboundMessage_Id(qrrCustInfo.getString("fkVal"));
            		if(outMsgId.getEntity().getCreationDateTime().getDate().equals(getProcessDateTime().getDate())){
            			return true;
            		}
            	}
            }
			
            // Get FA Characteristics
           	Iterator<FieldActivityCharacteristic> itr = faId.getEntity().getCharacteristics().iterator();
        	FieldActivityCharacteristic faChar;
    		while(itr.hasNext()){
    			faChar = itr.next();

    			if(faChar.fetchIdCharacteristicType().getId().equals(parmPhoneCharType.getId())){
    				phoneCharValue = getFaCharacteristicValue(faChar);
    				hasPhoneNumberInFAChar = Bool.TRUE;
    			} else if(faChar.fetchIdCharacteristicType().getId().equals(parmBillAccountCharType.getId())){
    				acctCharValue = getFaCharacteristicValue(faChar);
    				hasBillAccountChar = Bool.TRUE;
    			}
    			else if(faChar.fetchIdCharacteristicType().getId().equals(parmEmailCharType.getId())){
    				emailCharVal = getFaCharacteristicValue(faChar);
    				hasEmailInFAChar = Bool.TRUE;
    			}
    		}
			
			if(hasBillAccountChar.isFalse()){
	            userId = getActiveContextUser().getId();
	            SQLResultRow acctOfFaResRow = getAccountOfFa();

	            if(notNull(acctOfFaResRow)){
	                acctId = acctOfFaResRow.getEntity("ACCT_ID", Account.class);
	            } 
	            if(isNull(acctOfFaResRow) || isNull(acctId)) {
	                return true;
	            }
	            
			} else {
				acctId = new Account_Id(acctCharValue).getEntity();
			}
			
			Person mainPerson = acctId.getMainPerson();
            if (isNull(mainPerson)) {
                addError(CustomMessageRepository.ni0011_2MainPersonNotFound(acctId.getId().getIdValue().trim()));
            }

            mainPersonId = mainPerson.getId();
			
    		if(hasEmailInFAChar.isTrue()){
    			//Create Customer Contact for Email
	            createCustomerContactEmail(emailCharVal);
	        //    return true;
    		} 
    		
    		if(hasPhoneNumberInFAChar.isFalse()){	
	            if (isEmptyOrNull(phoneCharValue)) {
	            	getMainPersonPhoneNumber();
	                // If no Phone number was found
	                if (isEmptyOrNull(phoneCharValue)) {
	                    createCustomerContact();
	                    return true;
	                }
	            }
	            
	            if (isEmptyOrNull(acctCharValue)) {
	                acctCharValue = acctId.getId().getTrimmedValue();
	            }
	            
                // Add FA Char only when record will be extracted
                addFieldActivityCharacteristic(fa, parmAccountCharType, acctCharValue);
                hasAddedAccountChar = Bool.TRUE;
                
                //Retrieve Account PMOC
	            retrievePMOC(CM_PMOCINFO, acctId.getId());
	            if(parmSmsCustomerClasses.contains(acctId.getCustomerClass().getId().getTrimmedValue()) && !isBlankOrNull(smsContactId)){
	            	//Create Customer Contact for SMS
		            createCustomerContactSMS();
		         //   return true;
	            }

	            //Add FA Char phone number if no SMS Contact is present from the account.
	            addFieldActivityCharacteristic(fa, parmPhoneCharType, phoneCharValue);
	            hasPhoneNumberInFAChar = Bool.TRUE;
	            isSmsToPhoneProcess = Bool.TRUE;
    		} 

    		if(hasPhoneNumberInFAChar.isTrue()){
    			if(isSmsToPhoneProcess.isFalse()){
    				if(isValidPhoneNumberFormat(phoneCharValue).isFalse()){
    					phoneCharValue = "";
    					getMainPersonPhoneNumber();
    	                // If no Phone number was found
    	                if (isEmptyOrNull(phoneCharValue)) {
    	                    createCustomerContact();
    	                    return true;
    	                }
    				}
    				
    				//Retrieve Account PMOC
		            retrievePMOC(CM_PMOCINFO, acctId.getId());
	            	if(parmSmsCustomerClasses.contains(acctId.getCustomerClass().getId().getTrimmedValue()) && !isBlankOrNull(smsContactId)){
		            	//Create Customer Contact for SMS
			            createCustomerContactSMS();
	            	}
    			}
    			
    			createCustomerContactPhoneCall(phoneCharValue);
	            if(hasAddedAccountChar.isFalse()){
	            	// Add Account Characteristic for Field Activity
	                addFieldActivityCharacteristic(fa, parmAccountCharType, acctId.getId().getTrimmedValue());
	            }
	            
    			return true;
    		}
      
            return true;
        }
        //End Update - JMeden - B-18775 - 2021-05-20
        
        //Start Add - JMeden - B-18775 - 2021-05-20
        /**
         * This method will get the Priority Person Phone Number
         */
        private void getMainPersonPhoneNumber(){
            if (mainPersonId.getEntity().getPersonOrBusiness().isPerson()) {
                for (PersonPhone personPhone : mainPersonId.getEntity().getPhones()) {
                    phoneCharValue = personPhone.getPhone();
                    
                    // If the phone number is not a priority Phone Type, keep looping
                    if (priorityPersonPhoneTypeList.contains(personPhone.getPhoneType().getId())) {
                        break;
                    }
                }
                
            } else if (mainPersonId.getEntity().getPersonOrBusiness().isBusiness()) {
                for (PersonPhone personPhone : mainPersonId.getEntity().getPhones()) {
                    phoneCharValue = personPhone.getPhone();
                    
                    // If the phone number is not a priority Phone Type, keep looping
                    if (priorityBusinessPhoneTypeList.contains(personPhone.getPhoneType().getId())) {
                        break;
                    }
                }
            }
        }
        
        /**
         * This method will validate the format of phone number
         * Valid format:
         * 1. (XXX) XXX-XXXX
         * 2. XXX-XXX-XXXX
         * 3. XXXXXXXXXX
         * 
         * @param phoneNumberValue
         * @return Bool
         */
        private Bool isValidPhoneNumberFormat(String phoneNumberValue){
        	String format1 = "(XXX) XXX-XXXX";
        	String format2 = "XXX-XXX-XXXX";
        	String format3 = "XXXXXXXXXX";
    		
        	phoneNumberValue = phoneNumberValue.replaceAll("[0-9]", "X");
        	
        	if(phoneNumberValue.equals(format1) ||
        			phoneNumberValue.equals(format2) ||
        			phoneNumberValue.equals(format3)){
        		return Bool.TRUE;
        	}
  
        	return Bool.FALSE;
        }
        
        /**
         * This method will create an outbound message depending on the communication type
         * @param commType
         * @param fa
         * @param acctId
         * @param email
         * @param smsNumber
         * @param phoneNumber
         * @return Outbound Message Id
         */
        private String createOutboundMessage(String commType, FieldActivity fa, Account_Id acctId, String email, String smsNumber, String phoneNumber){
        	Message_Id msgId = new Message_Id(parmMessageCategory, parmMessageNumber);
        	DateFormat format24Hour = new DateFormat("hh:mm a"); // HH:mm
        	DateFormat formatDate = new DateFormat("MM/dd/YYYY");
        	String message = msgId.getEntity().fetchActiveMessageText(); 

        	DispatchGroupAppointmentSchedule appointmentSchedule = fa.getAppointmentScheduleId().getEntity();
        	BusinessObjectInstance outboundBOInstance = null;
        	outboundBOInstance = BusinessObjectInstance.create(parmBusinessObjectOutbound.getId().getTrimmedValue());
        	outboundBOInstance.set("creationDateTime", getProcessDateTime());

        	COTSInstanceNode notifDetails = outboundBOInstance.getGroup("notificationDetails");
        	notifDetails.set("communicationType", commType);        	
        	notifDetails.set("account", acctId.getTrimmedValue());
        	
        	notifDetails.set("emailParameter2", fa.getFieldActivityType().getId().getTrimmedValue());
        	notifDetails.set("emailParameter3", fa.getScheduleDateTimeStart().getDate().toString());
        	notifDetails.set("emailParameter4", appointmentSchedule.getStartDateTime().toString());
        	notifDetails.set("emailParameter5", appointmentSchedule.getEndDateTime().toString());
        	notifDetails.set("emailParameter6", fa.getId().getTrimmedValue());
        	//Start Add - JMeden - B-18775.Issue1 - 2021-08-02
        	notifDetails.set("emailParameter7", fa.getServicePoint().getPremise().getAddress1());
        	notifDetails.set("emailParameter8", fa.getServicePoint().getPremise().getPostal());
        	notifDetails.set("emailParameter9", fa.getServicePoint().getPremise().getDivisionId().toString());
        	//End Add - JMeden - B-18775.Issue1 - 2021-08-02
        	
        	if(commType.equals(COMM_TYPE_CALL)){
        		notifDetails.set("emailParameter1", phoneNumber);
        		//Start Add - JMeden - Defect 4582582 - 2021-08-26
        		notifDetails.set("textDestination", phoneNumber);
        		//End Add - JMeden - Defect 4582582 - 2021-08-26
        	} else if (commType.equals(COMM_TYPE_EMAIL)){
        		notifDetails.set("emailDestination", email);
        	} else if (commType.equals(COMM_TYPE_SMS)){
        		notifDetails.set("textDestination", smsNumber);
            	message = message.replace("%1", fa.getServicePoint().getPremise().getAddress1());
            	message = message.replace("%2", fa.getScheduleDateTimeStart().getDate().toString(formatDate));
            	message = message.replace("%3", appointmentSchedule.getStartDateTime().toString(format24Hour));
            	message = message.replace("%4", appointmentSchedule.getEndDateTime().toString(format24Hour));
            	notifDetails.set("textMessage", message);
        	}
        	
        	outboundBOInstance = BusinessObjectDispatcher.add(outboundBOInstance);
        	
        	return outboundBOInstance.getString("outboundMsgId");
        }
        
        /**
         * This method will return the Customer Contact Id, and Characteristic Value
         * 
         * Option 1: Customer Contact Id is null
         *           This will search the Characteristic Type with Specific Char Value
         *           from the Appointment Reminder Customer Contacts
         *           
         * Option 2: Characteristic Value is null
         *           This will search the Characteristic Type 
         *           from the a specific Customer Contact Id Appointment Reminder 
         *           Customer Contact
         * 
         * @param ccId
         * @param charType
         * @param charValue
         * @return QueryResultRow
         */
        private QueryResultRow getCharValueFromCustomerContact(CustomerContact_Id ccId, CharacteristicType_Id charType, String charValue){
			CharacteristicTypeLookup charTypeLookup = charType.getEntity().getCharacteristicType();
    		StringBuilder getCCCharSql = new StringBuilder();
    		
    		getCCCharSql.append(" FROM CustomerContact CC, CustomerContactCharacteristic CCH ");
    		getCCCharSql.append(" WHERE CC.customerContactType.id.contactType = :ccType ");
    		getCCCharSql.append(" AND CC.customerContactType.id.contactClass.id = :ccClass ");
    		getCCCharSql.append(" AND CC.id = CCH.id.customerContact.id ");
    		getCCCharSql.append(" AND CCH.id.characteristicType.id = :char ");
    		
    		if(notNull(ccId)){
    			getCCCharSql.append(" AND CC.id = :ccId ");
    		}

    		if(!isBlankOrNull(charValue)){
    			if(charTypeLookup.isPredefinedValue()){
    				getCCCharSql.append(" AND CCH.characteristicValue = :value ");
    			} else if (charTypeLookup.isForeignKeyValue()){
    				getCCCharSql.append(" AND CCH.characteristicValueForeignKey1 = :value ");
    			} else {
    				getCCCharSql.append(" AND CCH.adhocCharacteristicValue = :value ");
    			}
    		}
    		
    		Query<QueryResultRow> queryCCCharSql = createQuery(getCCCharSql.toString(), getClass().getName());
    		queryCCCharSql.bindStringProperty("ccType", CustomerContactType.properties.contactType, custContactType.getContactType());
    		queryCCCharSql.bindId("ccClass", custContactType.getContactClassId());
    		queryCCCharSql.bindId("char", charType);
    		
    		if(notNull(ccId)){
    			queryCCCharSql.bindId("ccId", ccId);
    		}
    		
    		if(!isBlankOrNull(charValue)){
    			if(charTypeLookup.isPredefinedValue()){
    				queryCCCharSql.bindStringProperty("value", CustomerContactCharacteristic.properties.characteristicValue, charValue);
    			} else if (charTypeLookup.isForeignKeyValue()){
    				queryCCCharSql.bindStringProperty("value", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, charValue);
    			} else {
    				queryCCCharSql.bindStringProperty("value", CustomerContactCharacteristic.properties.adhocCharacteristicValue, charValue);
    			}
    		}
    		
    		queryCCCharSql.addResult("ccId", "CC.id");
    		queryCCCharSql.addResult("fkVal", "CCH.characteristicValueForeignKey1");
    		queryCCCharSql.addResult("charVal", "CCH.characteristicValue");
    		queryCCCharSql.addResult("adhocVal", "CCH.adhocCharacteristicValue");

        	return queryCCCharSql.firstRow();
        }
        
        /**
         * This method will add then Characteristic to the Customer Contact
         * @param customerContactId
         * @param charType
         * @param charValue
         */
        private void addCustomerContactChar(CustomerContact_Id customerContactId, CharacteristicType charType, String charValue){
        	CustomerContactCharacteristic_DTO customerContactCharDTO = new CustomerContactCharacteristic_DTO();
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			customerContactCharDTO.setId(new CustomerContactCharacteristic_Id( charType, customerContactId.getEntity()));

			if (charTypeLookup.isPredefinedValue()){
				customerContactCharDTO.setCharacteristicValue(charValue);
			} else if (charTypeLookup.isForeignKeyValue()){
				customerContactCharDTO.setCharacteristicValueForeignKey1(charValue);
			} else{
				customerContactCharDTO.setAdhocCharacteristicValue(charValue);
			}

			customerContactCharDTO.newEntity();
		}
        
        /**
         * This method will return the Characteristic Value of FA Characteristic
         * @param faChar
         * @return String
         */
        private String getFaCharacteristicValue(FieldActivityCharacteristic faChar){
        	String charVal = "";
        	
        	if(faChar.fetchIdCharacteristicType().getCharacteristicType().isAdhocValue()){
        		charVal = faChar.getAdhocCharacteristicValue();
        	} else if(faChar.fetchIdCharacteristicType().getCharacteristicType().isPredefinedValue()){
        		charVal = faChar.getCharacteristicValue();
        	} else {
        		charVal = faChar.getCharacteristicValueForeignKey1();
        	}
        	
        	return charVal;
        }
        
    	/**
    	 * This method will retrieve the PMOC email and sms of the account 
    	 * using a specific service
    	 * @param service
    	 * @param accountId
    	 */
    	private void retrievePMOC(String service, Account_Id accountId){
    		ServiceScriptInstance serviceScriptInstance = null;
    		COTSInstanceNode scriptInput = null;
    		COTSInstanceNode scriptOutput = null;
    		smsNumPMOC = "";
    		smsContactId = "";
    		// Create an instance of the service script
    		serviceScriptInstance = ServiceScriptInstance.create(service);
    		
    		// Retrieve the script's input node
    		scriptInput = serviceScriptInstance.getGroup(PMOC_GROUP_INPUT);
    		
    		// Account Id
    		scriptInput.set(PMOC_ACCOUNT_ID, accountId.getTrimmedValue());
    		
    		// Invoke the service script
    		try {
    			ServiceScriptDispatcher.invoke(serviceScriptInstance);
    			scriptOutput = serviceScriptInstance.getGroup(PMOC_GROUP_OUTPUT);
    			if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){
    				if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("smsPhone"))){					
    					smsNumPMOC = scriptOutput.getGroup("pmoc").getString("smsPhone");							
    				}
    	
    				if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("smsContactId"))){					
    					smsContactId = scriptOutput.getGroup("pmoc").getString("smsContactId");							
    				}
    			}
    			
    		} catch (ApplicationError ae){
    			ae.getServerMessage();
    		}
    	}
    	
    	/**
    	 * This method will create the Customer Contact for SMS
    	 */
        private void createCustomerContactSMS() {
        	String strOutboundMessageId = "";
            CustomerContact_DTO customerContactDto = createDTO(CustomerContact.class);
            customerContactDto.setPersonId(mainPersonId);
            customerContactDto.setCustomerContactTypeId(custContactType);
            customerContactDto.setContactDateTime(getProcessDateTime());
            customerContactDto.setUserId(userId);

            CustomerContact custContact = customerContactDto.newEntity();
            CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

            // Create a new Characteristic for FA Id
            CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
            CustomerContactCharacteristic_Id ccFaId = new CustomerContactCharacteristic_Id(parmFaIdCharType, custContact);
            custContactCharacteristicDTO.setId(ccFaId);
            CharacteristicTypeLookup faCharTypeLookup = parmFaIdCharType.getCharacteristicType();
            String faIdValue = fa.getId().getTrimmedValue();
            if(faCharTypeLookup.isAdhocValue()){
                custContactCharacteristicDTO.setAdhocCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isPredefinedValue()){
                custContactCharacteristicDTO.setCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isForeignKeyValue()){
                custContactCharacteristicDTO.setCharacteristicValueForeignKey1(faIdValue);
            }  
            custContactCharacteristicDTO.newEntity();
            
            //Add Call Date Characteristic
            addCustomerContactChar(custContact.getId(), parmCallDateCharType, getProcessDateTime().getDate().toString(dateFormat));
            
            //Create Outbound
            strOutboundMessageId = createOutboundMessage(COMM_TYPE_SMS, fa, acctId.getId(), null, smsNumPMOC, null);
            		
    		//Add Outbound Message Characteristic
            addCustomerContactChar(custContact.getId(), parmOutboundMessageCharType, strOutboundMessageId);
        }
        
    	/**
    	 * This method will create the Customer Contact for Email
    	 */
        private void createCustomerContactEmail(String emailAddress) {
        	String strOutboundMessageId = "";
            CustomerContact_DTO customerContactDto = createDTO(CustomerContact.class);
            customerContactDto.setPersonId(mainPersonId);
            customerContactDto.setCustomerContactTypeId(custContactType);
            customerContactDto.setContactDateTime(getProcessDateTime());
            customerContactDto.setUserId(userId);

            CustomerContact custContact = customerContactDto.newEntity();
            CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

            // Create a new Characteristic for FA Id
            CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
            CustomerContactCharacteristic_Id ccFaId = new CustomerContactCharacteristic_Id(parmFaIdCharType, custContact);
            custContactCharacteristicDTO.setId(ccFaId);
            CharacteristicTypeLookup faCharTypeLookup = parmFaIdCharType.getCharacteristicType();
            String faIdValue = fa.getId().getTrimmedValue();
            if(faCharTypeLookup.isAdhocValue()){
                custContactCharacteristicDTO.setAdhocCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isPredefinedValue()){
                custContactCharacteristicDTO.setCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isForeignKeyValue()){
                custContactCharacteristicDTO.setCharacteristicValueForeignKey1(faIdValue);
            }  
            custContactCharacteristicDTO.newEntity();
            
            //Add Call Date Characteristic
            addCustomerContactChar(custContact.getId(), parmCallDateCharType, getProcessDateTime().getDate().toString(dateFormat));
            //create Outbound Message
            strOutboundMessageId = createOutboundMessage(COMM_TYPE_EMAIL, fa, acctId.getId(), emailAddress, null, null);
            //Add Outbound Message Characteristic
            addCustomerContactChar(custContact.getId(), parmOutboundMessageCharType, strOutboundMessageId);
        }
        //End Add - JMeden - B-18775 - 2021-05-20

        public static String formatPhone(String phone) {
            phone = phone.replaceAll("[-() ]","");
            return phone;  
        }

        private void createCustomerContact() {
            CustomerContact_DTO customerContactDto = createDTO(CustomerContact.class);
            customerContactDto.setPersonId(mainPersonId);
            customerContactDto.setCustomerContactTypeId(custContactTypeError);
            customerContactDto.setContactDateTime(getProcessDateTime());
            //KL20130520 - Start of Fix for TIR3 - Customer Contact should not be in open state
            //customerContactDto.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
            //KL20130520 - End of Fix for TIR3
            customerContactDto.setUserId(userId);
            /*
             * Start Add - Defect 3236623 - 2015-06-15
             */
            customerContactDto.setLongDescription(CustomMessageRepositoryMGE.ni0011_2NoPhoneNumber().getMessageText());
            /*
             * End Add - Defect 3236623 - 2015-06-15
             */
            CustomerContact custContact = customerContactDto.newEntity();
            CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

            // Create a new Characteristic for FA Id
            CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
            CustomerContactCharacteristic_Id ccFaId = new CustomerContactCharacteristic_Id(parmFaIdCharType, custContact);
            custContactCharacteristicDTO.setId(ccFaId);
            CharacteristicTypeLookup faCharTypeLookup = parmFaIdCharType.getCharacteristicType();
            String faIdValue = fa.getId().getTrimmedValue();
            if(faCharTypeLookup.isAdhocValue()){
                custContactCharacteristicDTO.setAdhocCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isPredefinedValue()){
                custContactCharacteristicDTO.setCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isForeignKeyValue()){
                custContactCharacteristicDTO.setCharacteristicValueForeignKey1(faIdValue);
            }  
            custContactCharacteristicDTO.newEntity();
        }

        //Start Change - JMeden - B-18775 - 2021-05-20
        //private void createFaExtractedCustomerContact(Date schDate) {
        private void createCustomerContactPhoneCall(String phoneCharValue) {
        //End Change - JMeden - B-18775 - 2021-05-20
        	String strOutboundMessageId = "";
            CustomerContact_DTO customerContactDto = createDTO(CustomerContact.class);
            customerContactDto.setPersonId(mainPersonId);
            customerContactDto.setCustomerContactTypeId(custContactType);
            customerContactDto.setContactDateTime(getProcessDateTime());
            //KL20130520 - Start of Fix for TIR3 - Customer Contact should not be in open state
            //customerContactDto.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
            //KL20130520 - End of Fix for TIR3
            customerContactDto.setUserId(userId);

            CustomerContact custContact = customerContactDto.newEntity();
            CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

            // Create a new Characteristic for FA Id
            CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
            CustomerContactCharacteristic_Id ccFaId = new CustomerContactCharacteristic_Id(parmFaIdCharType, custContact);
            custContactCharacteristicDTO.setId(ccFaId);
            CharacteristicTypeLookup faCharTypeLookup = parmFaIdCharType.getCharacteristicType();
            String faIdValue = fa.getId().getTrimmedValue();
            if(faCharTypeLookup.isAdhocValue()){
                custContactCharacteristicDTO.setAdhocCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isPredefinedValue()){
                custContactCharacteristicDTO.setCharacteristicValue(faIdValue);
            } else if (faCharTypeLookup.isForeignKeyValue()){
                custContactCharacteristicDTO.setCharacteristicValueForeignKey1(faIdValue);
            }
            custContactCharacteristicDTO.newEntity();
            
            //Start Change - JMeden - B-18775 - 2021-05-20
            // Create a new Characteristic for Call Date
//            custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
//            CustomerContactCharacteristic_Id ccCallDate = new CustomerContactCharacteristic_Id(parmCallDateCharType, custContact);
//            custContactCharacteristicDTO.setId(ccCallDate);
//            CharacteristicTypeLookup callDateCharTypeLookup = parmCallDateCharType.getCharacteristicType();
//            String callDateValue = schDate.addDays(-1).toString();
//            if(callDateCharTypeLookup.isAdhocValue()){
//                custContactCharacteristicDTO.setAdhocCharacteristicValue(callDateValue);
//            } else if (callDateCharTypeLookup.isPredefinedValue()){
//                custContactCharacteristicDTO.setCharacteristicValue(callDateValue);
//            } else if (callDateCharTypeLookup.isForeignKeyValue()){
//                custContactCharacteristicDTO.setCharacteristicValueForeignKey1(callDateValue);
//            }
//            custContactCharacteristicDTO.newEntity();
            
            //Add Call Date Characteristic
            addCustomerContactChar(custContact.getId(), parmCallDateCharType, getProcessDateTime().getDate().toString(dateFormat));
            
            //Create Outbound
            strOutboundMessageId = createOutboundMessage(COMM_TYPE_CALL, fa, acctId.getId(), null, null, phoneCharValue);
            		
    		//Add Outbound Message Characteristic
            addCustomerContactChar(custContact.getId(), parmOutboundMessageCharType, strOutboundMessageId);
            //End Change - JMeden - B-18775 - 2021-05-20
        }
        
        //Start Delete - JMeden - B-18775 - 2021-05-20
//        private void retrieveFaChar(){
//            FieldActivityCharacteristics faCharacteristics = fa.getCharacteristics();            
//            for (FieldActivityCharacteristic fieldActivityCharacteristic : faCharacteristics) {
//                CharacteristicTypeLookup charTypeLookup = fieldActivityCharacteristic.getId().getCharacteristicType().getCharacteristicType();
//                if(fieldActivityCharacteristic.fetchIdCharacteristicType().getId().getIdValue().equals(parmPhoneCharType.getId().getIdValue())){
//                    if(charTypeLookup.isAdhocValue()){
//                        phoneCharValue = fieldActivityCharacteristic.getAdhocCharacteristicValue();
//                    } else if (charTypeLookup.isPredefinedValue()){
//                        phoneCharValue = fieldActivityCharacteristic.getCharacteristicValue();
//                    } else if (charTypeLookup.isForeignKeyValue()){
//                        phoneCharValue = fieldActivityCharacteristic.getCharacteristicValueForeignKey1();
//                    }
//                }
//                if(fieldActivityCharacteristic.fetchIdCharacteristicType().equals(parmAccountCharType)){
//                    if(charTypeLookup.isAdhocValue()){
//                        acctCharValue = fieldActivityCharacteristic.getAdhocCharacteristicValue();
//                    } else if (charTypeLookup.isPredefinedValue()){
//                        acctCharValue = fieldActivityCharacteristic.getCharacteristicValue();
//                    } else if (charTypeLookup.isForeignKeyValue()){
//                        acctCharValue = fieldActivityCharacteristic.getCharacteristicValueForeignKey1();
//                    } 
//                }
//            }            
//        }

        
//        /**
//         * Open File Writer
//         */
//        private void openFileWriter(){       
//            inputFilePathAndName = new File(parmFilePath, parmFileName);
//            try { 
//                bufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
//            } catch (IOException e) {
//                addError(CustomMessageRepository.ni0011_2ErrorInFile(e.getMessage())); 
//            }
//        }
//
//        /**
//         * Write Line to File
//         */
//        private void writeLine(String recordline){              
//            try {
//                bufferedWriter.write(recordline);
//                bufferedWriter.newLine();
//            } catch (IOException e) {
//                addError(CustomMessageRepository.ni0011_2ErrorInFile(e.getMessage()));  
//            }
//        }
        //End Delete - JMeden - B-18775 - 2021-05-20

        private SQLResultRow getAccountOfFa() {
            SQLResultRow firstRow = null;
            StringBuilder getAccountString = new StringBuilder();
            getAccountString.append("SELECT SA.ACCT_ID FROM CI_FA FA, CI_SP SP, CI_SA_SP SS, CI_SA SA ");
            getAccountString.append("WHERE FA.FA_ID = :inputFaId AND FA.SP_ID = SP.SP_ID ");
            getAccountString.append("AND SP.SP_ID = SS.SP_ID AND SS.SA_ID = SA.SA_ID ");
			//Start Add - GCrisp - 4582581 - 2021-11-18
			getAccountString.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :stopped, :reactivated) ");
			//End Add - GCrisp - 4582581 - 2021-11-18
            //Start Change - JMeden - B-18775 - 2021-05-20	
            //getAccountString.append("AND ((SYSDATE BETWEEN SS.START_DTTM AND SS.STOP_DTTM ) OR (SS.STOP_DTTM IS NULL)) ");
            //Start Change - JMeden - Defect 4582581 - 2021-08-25	
            //getAccountString.append(" AND ((FA.SCHED_DTTM BETWEEN SS.START_DTTM AND SS.STOP_DTTM ) OR (SS.STOP_DTTM IS NULL)) ");
            getAccountString.append(" AND TRUNC(FA.SCHED_DTTM) >= SA.START_DT AND (SA.END_DT IS NULL OR TRUNC(FA.SCHED_DTTM) <= SA.END_DT) ");
            //End Change - JMeden - Defect 4582581 - 2021-08-25
            //End Change - JMeden - B-18775 - 2021-05-20
            //Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement accountPrepStmt = createPreparedStatement(getAccountString.toString()); 
            PreparedStatement accountPrepStmt = createPreparedStatement(getAccountString.toString(), getClass().getName()); 
            //End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
            accountPrepStmt.bindId("inputFaId", fa.getId());
			//Start Add - GCrisp - 4582581 - 2021-11-18
			accountPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			accountPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			accountPrepStmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			accountPrepStmt.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
			accountPrepStmt.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			//End Add - GCrisp - 4582581 - 2021-11-18
            firstRow = accountPrepStmt.firstRow();
            // KL20130612 - Start of Defect fix for #2162
            //acctId = firstRow.getEntity("ACCT_ID", Account.class);
            // KL20130612 - End of Defect fix for #2162
            accountPrepStmt.close();
            return firstRow;
        }
        
        //Start Delete - JMeden - B-18775 - 2021-05-20
//        @Override
//        public void finalizeThreadWork() throws ThreadAbortedException,
//        RunAbortedException {
//            try {
//                bufferedWriter.close();
//            } catch (IOException e) {
//                addError(CustomMessageRepository.ni0011_2ErrorInFile(e.getMessage()));  
//            }
//        }
        //End Delete - JMeden - B-18775 - 2021-05-20
        
        /*
         * Start Add - Defect 3236623 - 2015-06-15
         */
        /**
         * Create the FA Characteristic with the FA Type Char Type Sort Sequence.
         */
        private void addFieldActivityCharacteristic(FieldActivity fieldActivity, CharacteristicType characteristicType, String value) {
            // check if the char type already exists or not
        	
            // Get FA Characteristics
           	Iterator<FieldActivityCharacteristic> itr = fieldActivity.getCharacteristics().iterator();
        	FieldActivityCharacteristic faChar;
    		while(itr.hasNext()){
    			faChar = itr.next();

    			if(faChar.fetchIdCharacteristicType().getId().equals(characteristicType.getId())){
    				return;
    			}
    				
    			}
            FieldActivityCharacteristics fieldActivityCharacteristics = fieldActivity.getCharacteristics();
            BigInteger sortSequence = BigInteger.ZERO;
            for (FieldActivityTypeCharacteristicType fieldActivityTypeCharacteristicType : fieldActivity.getFieldActivityType().getCharacteristicTypes()) {
                if (fieldActivityTypeCharacteristicType.getId().getCharacteristicType().equals(characteristicType)) {
                    sortSequence = fieldActivityTypeCharacteristicType.getSortSequence();
                }
            }
            
            if (sortSequence.compareTo(BigInteger.ZERO) == 0) {
                logError(CustomMessageRepositoryMGE.ni0011_2InvalidCharacteristicForFieldActivity(characteristicType, fieldActivity));
                return;
            }
            
            FieldActivityCharacteristic_DTO fieldActivityCharacteristicDTO = fieldActivityCharacteristics.newChildDTO();
            CharacteristicTypeLookup characteristicTypeLookup = characteristicType.getCharacteristicType();
            if (characteristicTypeLookup.isForeignKeyValue()) {
                fieldActivityCharacteristicDTO.setCharacteristicValueForeignKey1(value);
            } else if (characteristicTypeLookup.isPredefinedValue()) {
                fieldActivityCharacteristicDTO.setCharacteristicValue(value);
            } else {
                fieldActivityCharacteristicDTO.setAdhocCharacteristicValue(value);
            }
            
            fieldActivityCharacteristics.add(fieldActivityCharacteristicDTO, characteristicType.getId(), sortSequence);
            
        }
        /*
         * End Add - Defect 3236623 - 2015-06-15
         */
    }
}
