/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0072 -  Break Payment Arrangement Algorithm
 *
 *********************************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-01-02   Rakesh          NA0072. Initial Version.
 * 2013-05-28   MLekkala        Fix for CET Error - 05/28/2013 - Modified logic to retrieve the PA SA's 
 *                                                               associated with Account needs to be broken 
 *                                                               based on SA Type Char Type and Char Value 
 *                                                               needs to be broken 
 *                                                               
 * 2016-01-25   MPang			Updated for CCB v2.4 compilation. 
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.      
 * 2020-01-14	JHERNA			SysAid#307380. Found out that the original code is erroneous and picks up duplicate
 *                              PA SAs all the time. Updated the SQL so that it would not pick up duplicate SAIDs. 
 * 2021-01-18   JLUMBRE			Incident#357548. Updated to call SA Type _Break PA algo for CWR SAs    
 * 2021-10-20   NMendo          Defect 4603697. Make serviceAgreementType optional.                                                                                   
 ****************************************************************************************************************/
package com.splwg.cm.domain.admin.collectionEventType;


import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementTypeAlgorithmLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentCancelReason.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.collectionEventType.CollectionEventTypeCollectionEventAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementTypeCharacteristic;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CreditAndCollectionEvent;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.collectionEventType.algorithm.collection.CollectionEventAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.breakPayArrangement.SaTypeBreakPayArrangementAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementTypeAlgorithm;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementTypeCharacteristic;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CreditAndCollectionEvent;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = brokenPayArrangeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = brokenPayArrangeCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjCancelReason, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = breakPayArrangeSATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = breakPayArrangeSATypeCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = serviceAgreementType, type = string)})
 */


public class CmBreakPaymentArrangement_Impl 
        extends CmBreakPaymentArrangement_Gen 
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        //implements CollectionEventTypeCollectionEventAlgorithmSpot {
        implements CollectionEventAlgorithmSpot { 
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation

    @SuppressWarnings("unused")
	private CreditAndCollectionEvent crAndCollEvent;

    private AdjustmentType transferAdjType;
    private CharacteristicType brokenPayArrangeCharType;
    private CharacteristicValue_Id brokenPayArrangeCharValue_Id;
    

    // Start - CET Error 

    /* This Char indicates whether the SA needs to be broken or not as a part of collection process. This will be on the SA Type. 
     Only those SA's that have these Characteristic needs to be broken during the Collection Event
     */

    private CharacteristicType breakPayArrangeSATypeCharType;
    private String breakPayArrangeSATypeCharValue;

    private CharacteristicValue_Id breakPayArrangeSATypeCharValue_Id;

    // End - Defect - CET Error

    private String brokenPayArrangeCharVal;
    private AdjustmentCancelReason adjCancelReason;
    private Account account;
    
    //Start Add - JLumbre - 2021-01-18
    private ServiceAgreementType saType;
    //End Add - JLumbre - 2021-01-18

    public void setAccount(Account acct) {
        account = acct;
    }

    public void setAddWorkDays(Bool arg0) {

    }

    public void setCreditAndCollectionEvent(CreditAndCollectionEvent cace) {
        crAndCollEvent = cace;

    }

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {

        initializeSoftParams();

        brokenPayArrangeCharValue_Id = new CharacteristicValue_Id(brokenPayArrangeCharType.getId(),brokenPayArrangeCharVal.trim());
        if(isNull(brokenPayArrangeCharValue_Id.getEntity())){
            addError(CustomMessageRepository.na0072InvaildCharTypeForEntity(brokenPayArrangeCharType.getId().getIdValue(),brokenPayArrangeCharVal.trim()));  
        }

        //Start - For Defect CET Error - 05/28/2013

        breakPayArrangeSATypeCharValue_Id = new CharacteristicValue_Id(breakPayArrangeSATypeCharType.getId(),breakPayArrangeSATypeCharValue.trim());
        if(isNull(breakPayArrangeSATypeCharValue_Id.getEntity())){
            addError(CustomMessageRepository.na0072InvaildCharTypeForEntity(breakPayArrangeSATypeCharType.getId().getIdValue(),breakPayArrangeSATypeCharValue.trim()));  
        }

        //End - For Defect CET Error - 05/28/2013
    }

    private void initializeSoftParams(){
        transferAdjType = getTransferAdjType();
        brokenPayArrangeCharType = getBrokenPayArrangeCharType();
        brokenPayArrangeCharVal = getBrokenPayArrangeCharVal();
        adjCancelReason = getAdjCancelReason();        
        breakPayArrangeSATypeCharType = getBreakPayArrangeSATypeCharType();
        breakPayArrangeSATypeCharValue = getBreakPayArrangeSATypeCharValue();
        
    }

    public void invoke() {
    	
    	ServiceAgreement payArrangeSA;
    	//Start Add - JLumbre - 2021-01-18
    	String paSaType;
    	//End Add - JLumbre - 2021-01-18

        //Start - For Defect CET Error - 05/28/2013

        List<SQLResultRow> payArrangementSAResultList =   getPayArrangementSA();
        for(SQLResultRow resultRow : payArrangementSAResultList){
        	payArrangeSA = resultRow.getEntity("SA_ID", ServiceAgreement.class);
        	
        	// Start Add - NMendo - Defect 4603697 - 2021-10-20
        	if(isNull(getServiceAgreementType())) {
        		payArrangeSA.cancelPaymentArrangement(brokenPayArrangeCharValue_Id.getEntity(), transferAdjType, adjCancelReason,payArrangeSA.getServiceAgreementType().getAdjustmentTypeXferId().getEntity());
        		continue;
        	}
        	// End Add - NMendo - Defect 4603697 - 2021-10-20

        	//Start Add - JLumbre - 2021-01-18
        	saType = new ServiceAgreementType_Id(payArrangeSA.getAccount().getDivisionId(), getServiceAgreementType().trim()).getEntity();
        	if(isNull(saType)){
    			addError(CustomMessageRepositorySpireOne.s1_saTypeInvalidForCisDivision(getServiceAgreementType(), 
    					payArrangeSA.getAccount().getDivisionId().getTrimmedValue()));
    		}
        	paSaType = payArrangeSA.getServiceAgreementType().getId().getSaType();
        	if(paSaType.trim().compareTo(saType.fetchIdSaType().trim()) == 0){
        		ListFilter<ServiceAgreementTypeAlgorithm> breakPaAlgoLf = saType.getAlgorithms().createFilter("where this.id.saTypeAlgorithmFlag = :BKPA ", "Break PA");
        		breakPaAlgoLf.bindLookup("BKPA", ServiceAgreementTypeAlgorithmLookup.constants.BREAK_PAY_ARRANGEMENT);
        		ServiceAgreementTypeAlgorithm algorithm = breakPaAlgoLf.firstRow();
        		Algorithm algo = algorithm.getAlgorithm();
        		
				SaTypeBreakPayArrangementAlgorithmSpot breakPASpot = algo.getAlgorithmComponent(SaTypeBreakPayArrangementAlgorithmSpot.class);
        		breakPASpot.setAccount(payArrangeSA.getAccount());
        		breakPASpot.setServiceAgreement(payArrangeSA);
        		breakPASpot.setTransferAdjustmentType(payArrangeSA.getServiceAgreementType().getAdjustmentTypeXferId().getEntity());
        		breakPASpot.invoke();
        		
        	}
        	else{
        		//End Add - JLumbre - 2021-01-18       		

        		payArrangeSA.cancelPaymentArrangement(brokenPayArrangeCharValue_Id.getEntity(), transferAdjType, adjCancelReason,payArrangeSA.getServiceAgreementType().getAdjustmentTypeXferId().getEntity());
        		//Start Add - JLumbre - 2021-01-18
        	}
        	//End Add - JLumbre - 2021-01-18
        }
        /* CollectionProcessServiceAgreements cpsas = crAndCollEvent.fetchIdCollectionProcess().getServiceAgreements();

           for(CollectionProcessServiceAgreement cpsa :cpsas){
			payArrangeSA = cpsa.fetchIdServiceAgreement();
			payArrangeSA.cancelPaymentArrangement(charValue_Id.getEntity(), transferAdjType, adjCancelReason,payArrangeSA.getServiceAgreementType().getAdjustmentTypeXferId().getEntity());

		}	

         */

    }

    /**
     *  Retrieve all the Payment Arrangement SA's that needs to be broken as part of Collection Process. 
     *  The Payment Arrangement SA's that needs to broken as part of Collection Process are identified by Char Type and Char Value that is specified on SA Type.
     *  Only those Payment Arrangement SA's of the Account that have Char Type and Char Value will be broken.
     *  
     * @return
     */

    private List<SQLResultRow> getPayArrangementSA() {

        StringBuilder getPayArrangementSAStr = new StringBuilder();

        getPayArrangementSAStr.append("SELECT SA_ID FROM CI_SA SA, CI_SA_TYPE ST, CI_SA_TYPE_CHAR SACHAR ");
        getPayArrangementSAStr.append("WHERE SA.ACCT_ID = :accountID ");
        getPayArrangementSAStr.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active) ");
        getPayArrangementSAStr.append("AND SA.SA_TYPE_CD = ST.SA_TYPE_CD "); 
        getPayArrangementSAStr.append("AND SA.CIS_DIVISION = ST.CIS_DIVISION  "); 
        getPayArrangementSAStr.append("AND ST.SPECIAL_ROLE_FLG = :paRoleFlag ");
        getPayArrangementSAStr.append("AND ST.SA_TYPE_CD = SACHAR.SA_TYPE_CD ");
        // START ADD - JHERNA - 2020-01-09 - SysAid#307380 
        getPayArrangementSAStr.append("AND ST.CIS_DIVISION = SACHAR.CIS_DIVISION ");
        // END ADD - JHERNA - 2020-01-09 - SysAid#307380
        getPayArrangementSAStr.append("AND SACHAR.CHAR_TYPE_CD = :breakPASACharType ");

        CharacteristicTypeLookup characteristicTypeLookup = breakPayArrangeSATypeCharType.getCharacteristicType();

        if(characteristicTypeLookup.isPredefinedValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getPayArrangementSAStr.append("AND @trim(SACHAR.CHAR_VAL) = :breakPASACharValue ");
            getPayArrangementSAStr.append("AND SACHAR.CHAR_VAL = :breakPASACharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getPayArrangementSAStr.append("AND @trim(SACHAR.CHAR_VAL_FK1) = :breakPASACharValue ");
            getPayArrangementSAStr.append("AND SACHAR.CHAR_VAL_FK1 = :breakPASACharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getPayArrangementSAStr.append("AND @trim(SACHAR.ADHOC_CHAR_VAL) = :breakPASACharValue ");
            getPayArrangementSAStr.append("AND SACHAR.ADHOC_CHAR_VAL = :breakPASACharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getPayArrangementSAPrepStmt = createPreparedStatement(getPayArrangementSAStr.toString()); 
        PreparedStatement getPayArrangementSAPrepStmt = createPreparedStatement(getPayArrangementSAStr.toString(), getClass().getName()); 
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getPayArrangementSAPrepStmt.bindId("accountID", account.getId());
        getPayArrangementSAPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        getPayArrangementSAPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        getPayArrangementSAPrepStmt.bindLookup("paRoleFlag", SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT);
        getPayArrangementSAPrepStmt.bindId("breakPASACharType", breakPayArrangeSATypeCharType.getId());

        if(characteristicTypeLookup.isPredefinedValue()){
            getPayArrangementSAPrepStmt.bindStringProperty("breakPASACharValue", ServiceAgreementTypeCharacteristic.properties.characteristicValue ,breakPayArrangeSATypeCharValue.trim());    
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            getPayArrangementSAPrepStmt.bindStringProperty("breakPASACharValue", ServiceAgreementTypeCharacteristic.properties.characteristicValue ,breakPayArrangeSATypeCharValue.trim());         
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            getPayArrangementSAPrepStmt.bindStringProperty("breakPASACharValue", ServiceAgreementTypeCharacteristic.properties.characteristicValue ,breakPayArrangeSATypeCharValue.trim());
        }


        List<SQLResultRow> resultList = getPayArrangementSAPrepStmt.list();  
        getPayArrangementSAPrepStmt.close();
        return resultList;

    }

    //End - For Defect CET Error - 05/28/2013

}
