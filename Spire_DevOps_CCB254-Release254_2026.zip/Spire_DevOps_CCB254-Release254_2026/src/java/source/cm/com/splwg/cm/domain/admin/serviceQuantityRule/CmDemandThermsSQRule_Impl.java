/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0054 - Demand Therms SQ Rule
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-12-05   RGullapalli    NA0054-Initial Version.
 * 2016-01-26   MPang		   Updated for CCB v2.4 compilation.
 **************************************************************************/
package com.splwg.cm.domain.admin.serviceQuantityRule;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.ccb.api.lookup.ServiceQuantityLookup;
import com.splwg.ccb.cobol.CobolConstants;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billFactor.BillFactor;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.billFactor.BillFactor_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceQuantityRule.MessageRepository;
import com.splwg.ccb.domain.admin.serviceQuantityRule.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentItemData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.common.characteristic.CharacteristicData;
import com.splwg.ccb.domain.rate.ApplyRateData;*/

import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.data.BillFactorValueData;
import com.splwg.ccb.domain.admin.common.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceQuantityRule.MessageRepository;
import com.splwg.ccb.domain.admin.data.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author rgullapall003
 * @BusinessComponent (customizationReplaceable = false, customizationCallable = true)
 */

public class CmDemandThermsSQRule_Impl 
		extends GenericBusinessComponent
		implements CmDemandThermsSQRule,ServiceQuantityRuleComponent {

    private UnitOfMeasure_Id uomIdBase;
    private TimeOfUse_Id touIdBase;
    private ServiceQuantityIdentifier_Id sqiIdBase;


    private ApplyRateData applyRateData;
    private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData;
    private List<BillSegmentItemData> billSegmentItemData;
    private List<BillSegmentReadData> billSegmentReadData;
    private List<CharacteristicData> characteristicData;
    private ServiceQuantityLookup serviceQuantityLookup;
    private Bool createBillingError;
    private BigDecimal initialServiceQuantity;


    //Input Parameters
    private String paramStrInputUOM;
    private String paramStrInputTOU;
    private String paramStrInputSQI;
    private String paramInputBillDaysSQI;
    private String paramInputStandardFactCd;
    private String paramInputEffSeasonalPeriod;
    private String paramInputSeasonalStartDt;
    private String paramInputSeasonalEndDt;
    private String paramInputSeasonalFactCd;

    private BillFactor paramInputSeasonalFactor ;
    private BillFactor  paramInputStandardFactor;
    private UnitOfMeasure inputUOM;
    private TimeOfUse inputTOU ;
    private ServiceQuantityIdentifier inputSQI ;
    private ServiceQuantityIdentifier inputSQIDays;


    private int serviceQuantityIndex = 0;
    private BigDecimal serviceQuantity =BigDecimal.ZERO;

    private static final int ZERO =0;
    private static final int TWELVE =12;
    private static final int THIRTY_ONE =31;
    private static final int ONE =1;
    private static final int MINUS_ONE=-1;


    //String Constants
    private static final String DATE_DELIMITER = "-";
    private static final String START="S";
    private static final String END="E";
    private static final String DATE_FORMAT = "MM-dd-yyyy";

    public ApplyRateData getApplyRateData() {

        return applyRateData;
    }

    public List<BillSegmentItemData> getBillSegmentItemData() {

        return billSegmentItemData;
    }

    public List<BillSegmentReadData> getBillSegmentReadData() {

        return billSegmentReadData;
    }

    public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {

        return billSegmentServiceQuantityData;
    }

    public List<CharacteristicData> getCharacteristicData() {

        return characteristicData;
    }

    public String getSQRuleParameter1() {

        return paramStrInputUOM;
    }

    public String getSQRuleParameter10() {

        return null;
    }

    public String getSQRuleParameter2() {

        return paramStrInputTOU;
    }

    public String getSQRuleParameter3() {

        return paramStrInputSQI;
    }

    public String getSQRuleParameter4() {

        return paramInputBillDaysSQI;
    }

    public String getSQRuleParameter5() {

        return paramInputStandardFactCd;
    }

    public String getSQRuleParameter6() {

        return paramInputEffSeasonalPeriod;
    }

    public String getSQRuleParameter7() {

        return paramInputSeasonalStartDt;
    }

    public String getSQRuleParameter8() {

        return paramInputSeasonalEndDt;
    }

    public String getSQRuleParameter9() {

        return paramInputSeasonalFactCd;
    }

    public ServiceQuantityIdentifier_Id getServiceQuantityIdentifierId() {

        return sqiIdBase;
    }

    public ServiceQuantityLookup getServiceQuantityLookup() {

        return serviceQuantityLookup;
    }

    public Bool getShouldCreateBillingError() {

        return createBillingError;
    }

    public TimeOfUse_Id getTimeOfUseId() {

        return touIdBase;
    }

    public UnitOfMeasure_Id getUnitOfMeasureId() {

        return uomIdBase;
    }

    public void setApplyRateData(ApplyRateData rateData) {

        applyRateData = rateData;
    }

    public void setBillSegmentItemData(List<BillSegmentItemData> arg0) {

        this.billSegmentItemData=arg0;
    }

    public void setBillSegmentReadData(List<BillSegmentReadData> arg0) {

        this.billSegmentReadData=arg0;
    }

    public void setBillSegmentServiceQuantityData(List<BillSegmentServiceQuantityData> billSegSQData) {

        billSegmentServiceQuantityData = billSegSQData;
    }

    public void setCharacteristicData(List<CharacteristicData> arg0) {

        characteristicData = arg0;
    }

    public void setSQRuleParameter1(String strUOM) {

        paramStrInputUOM = strUOM.trim();
    }

    public void setSQRuleParameter10(String arg0) {

    }

    public void setSQRuleParameter2(String strTOU) {

        paramStrInputTOU = strTOU.trim() ;
    }

    public void setSQRuleParameter3(String strSQI) {

        paramStrInputSQI = strSQI.trim();
    }

    public void setSQRuleParameter4(String strBillDaySQI) {

        paramInputBillDaysSQI = strBillDaySQI.trim();
    }

    public void setSQRuleParameter5(String strStandFactCd) {

        paramInputStandardFactCd = strStandFactCd;
    }

    public void setSQRuleParameter6(String strEffSeasonalPeriod) {

        paramInputEffSeasonalPeriod = strEffSeasonalPeriod.trim();
    }

    public void setSQRuleParameter7(String strSeasonalStartDt) {

        paramInputSeasonalStartDt = strSeasonalStartDt.trim();
    }

    public void setSQRuleParameter8(String strSeasonalEndDt) {

        paramInputSeasonalEndDt = strSeasonalEndDt.trim();
    }

    public void setSQRuleParameter9(String strSeasonalFactCd) {

        paramInputSeasonalFactCd = strSeasonalFactCd.trim();
    }

    public void setServiceQuantityIdentifierId(ServiceQuantityIdentifier_Id sqiId) {

        sqiIdBase = sqiId;
    }

    public void setServiceQuantityLookup(ServiceQuantityLookup arg0) {

        this.serviceQuantityLookup=arg0;
    }

    public void setShouldCreateBillingError(Bool arg0) {

        this.createBillingError=arg0;
    }

    public void setTimeOfUseId(TimeOfUse_Id touId) {

        touIdBase = touId;
    }

    public void setUnitOfMeasureId(UnitOfMeasure_Id uomId) {

        uomIdBase = uomId;
    }

    public void invoke() {

        validateInputParameters();
        BigDecimal inputBillableServiceQuantity = retrieveBillableServiceQuantity(inputUOM,inputTOU,inputSQI,false);
        BigDecimal inputSQIDaysBillableServiceQuantity = retrieveBillableServiceQuantity(null,null,inputSQIDays,false);
        if(isNull(inputSQIDaysBillableServiceQuantity)){
        	addError(CustomMessageRepository.na0054ServiceQuantityNotFoundForUomTouSqiCombination(" "," ",inputSQIDays.getId().getIdValue().trim()));
        }
        if(isNull(inputBillableServiceQuantity)){

            String uom= " ";
            String tou= " ";
            String sqi= " ";
            if(!isNull(inputUOM)){
                uom=inputUOM.getId().getIdValue().trim();
            }
            if(!isNull(inputTOU)){
                tou=inputTOU.getId().getIdValue().trim();
            }
            if(!isNull(inputSQI)){
                sqi=inputSQI.getId().getIdValue().trim();
            }
            addError(CustomMessageRepository.na0054ServiceQuantityNotFoundForUomTouSqiCombination(uom,tou,sqi));
        }
        if(inputSQIDaysBillableServiceQuantity.compareTo(BigDecimal.ZERO)==ZERO){
            serviceQuantity = BigDecimal.ZERO;
            addError(CustomMessageRepository.na0054DivisionByZeroBillDaysIsZero(inputSQIDaysBillableServiceQuantity.longValue()));
        }
        BigDecimal stndFactorVal = retrieveBillFactorValue(paramInputStandardFactor);
        if(isNull(stndFactorVal)){
        	addError(CustomMessageRepository.na0054InvalidBillFactorValue(paramInputStandardFactor.getId().getIdValue()));
        }

        if((stndFactorVal.compareTo(BigDecimal.ZERO) ==ZERO) ){
            addError(CustomMessageRepository.na0054StandardFactorValueCannotBeZero());
        }
        serviceQuantity = (inputBillableServiceQuantity.divide(inputSQIDaysBillableServiceQuantity).multiply(stndFactorVal));

        if(isBlankOrNull(paramInputEffSeasonalPeriod)){
            retrieveBillableServiceQuantity(uomIdBase.getEntity(),touIdBase.getEntity(),sqiIdBase.getEntity(),true);
            addOrUpdateServiceQuantity();
        }else{
            calculateSeasonalDemand();
        }
    }

    /**
     * This method is the central method for all the Validation methods for the input parameters
     */ 
    private void validateInputParameters(){

        inputUOM = validateUOM();
        inputTOU = validateTOU();
        inputSQI  = validateSQI();
        inputSQIDays = validateSQIDays();
        paramInputStandardFactor = validateStandardFactor();
        validateSeasonalPeriod();
        validateOutputParam();
    }

    /**
     * This method is to validate the inputUOM value.
     */
    private UnitOfMeasure validateUOM(){

        UnitOfMeasure inputUOM  = new UnitOfMeasure_Id(paramStrInputUOM).getEntity();
        if(isNull(inputUOM)){

            addError(CustomMessageRepository.na00054InvalidInputUOM(paramStrInputUOM));
        }
        return inputUOM;
    }

    /**
     * This method is to validate the inputTOU value.
     */
    private TimeOfUse validateTOU(){

        TimeOfUse inputTOU = null;

        if(!isBlankOrNull(paramStrInputTOU)){

            inputTOU  = new TimeOfUse_Id(paramStrInputTOU).getEntity();
            if(isNull(inputTOU)){

                addError(CustomMessageRepository.na00054InvalidInputTOU(paramStrInputTOU));
            }
        }
        return inputTOU;
    }

    /**
     * This method is to validate the inputSQI value.
     */
    private ServiceQuantityIdentifier validateSQI(){

        ServiceQuantityIdentifier inputSQI = null;
        if(!isBlankOrNull(paramStrInputSQI)){

            inputSQI  = new ServiceQuantityIdentifier_Id(paramStrInputSQI).getEntity();
            if(isNull(inputSQI)){

                addError(CustomMessageRepository.na00054InvalidInputSQI(paramStrInputSQI));
            }
        }
        return inputSQI;
    }

    /**
     * This method is to validate the inputSQIDays value.
     */
    private ServiceQuantityIdentifier validateSQIDays(){

        ServiceQuantityIdentifier inputSQIDays  = new ServiceQuantityIdentifier_Id(paramInputBillDaysSQI).getEntity();
        if(isNull(inputSQIDays)){

            addError(CustomMessageRepository.na00054InvalidInputSQIDays(paramInputBillDaysSQI));
        }

        return inputSQIDays;
    }

    /**
     * This method is to validate the standardFactor value.
     */
    private BillFactor validateStandardFactor(){

        BillFactor paramInputStandardFactor  = new BillFactor_Id(paramInputStandardFactCd).getEntity();
        if(isNull(paramInputStandardFactor)){

            addError(CustomMessageRepository.na00054InvalidInputStandardBillFactor(paramInputStandardFactCd));
        }
        return paramInputStandardFactor;
    }

    /**
     * This method is to validate the seasonalPeriod values.
     */
    private void validateSeasonalPeriod(){

        if(!isBlankOrNull(paramInputEffSeasonalPeriod)){

            if(!(paramInputEffSeasonalPeriod.equals(START) || paramInputEffSeasonalPeriod.equals(END))){

                addError(CustomMessageRepository.na00054SeasonalPeriodEffectiveMustBeEitherSorE(paramInputEffSeasonalPeriod));
            }


            if(isBlankOrNull(paramInputSeasonalStartDt))  {

                addError(CustomMessageRepository.na00054SeasonalStartDateRequiredIfSeasonalPeriodEffectiveIsProvided());
            }else{

                if( validateDateString(paramInputSeasonalStartDt).isFalse()){

                    addError(CustomMessageRepository.na00054StartDateMustBeMMDDFormat(paramInputSeasonalStartDt));
                }
            }

            if(isBlankOrNull(paramInputSeasonalEndDt))    {

                addError(CustomMessageRepository.na00054SeasonalEndDateRequiredIfSeasonalPeriodEffectiveIsProvided());
            }else{

                if( validateDateString(paramInputSeasonalEndDt).isFalse()){

                    addError(CustomMessageRepository.na00054EndDateMustBeMMDDFormat(paramInputSeasonalEndDt));
                }
            }

            if(isBlankOrNull(paramInputSeasonalFactCd))   {

                addError(CustomMessageRepository.na00054SeasonalFactorRequiredIfSeasonalPeriodEffectiveIsProvided());
            }
            paramInputSeasonalFactor  = new BillFactor_Id(paramInputSeasonalFactCd).getEntity();
            if(isNull(paramInputSeasonalFactor)){

                addError(CustomMessageRepository.na00054InvalidInputSeasonalBillFactor(paramInputSeasonalFactCd));
            }
        }
    }

    /**
     * This method is to validate the program outputs TOU,UOM,SQI Base values.
     */
    private void validateOutputParam(){

        if(isNull(touIdBase) && isNull(uomIdBase) && isNull(sqiIdBase)){

            addError(CustomMessageRepository.na00054AtleastOneOfUOMOrSQIMustBeConfiguredInSQRule());
        }
    }

    /**
     * 
     * @param strDate
     * @return Bool
     * This method is used to validate the strDate.
     */
    private Bool validateDateString(String strDate){

        Bool isValid = Bool.FALSE;
        String strDateString = null;
        StringTokenizer strTokenizer = new StringTokenizer(strDate,DATE_DELIMITER);
        if(strTokenizer.countTokens()!=2){

            return isValid;
        }
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
        formatter.setLenient(false);
        strDateString= strDate.concat(DATE_DELIMITER+ getProcessDateTime().getYear());
        try{

            java.util.Date date = formatter.parse(strDateString);
            if (!formatter.format(date).equals(strDateString)){

                return isValid;
            } 

        }catch(ParseException e){

            e.printStackTrace();
            return isValid;
        }
        return Bool.TRUE;
    }

    //<---------------Validations ending Here No further Validation Methods--------------->
    /**
     * 
     * @param UnitOfMeasure,TimeOfUse,ServiceQuantityIdentifier and boolCount
     * @return BigDecimal
     * This method is used to validate the strDate.
     */
    private BigDecimal retrieveBillableServiceQuantity(UnitOfMeasure uom, TimeOfUse tou, ServiceQuantityIdentifier sqi, boolean boolCount){

        int i = ZERO;
        BillSegmentServiceQuantityData billSegSqData;
        BillSegmentServiceQuantity_DTO billSegmentSQDto;
        BillSegmentServiceQuantity_Id id;

        for (Iterator<BillSegmentServiceQuantityData> iter = getBillSegmentServiceQuantityData().iterator(); iter.hasNext(); i++) {

            billSegSqData = iter.next();
            billSegmentSQDto = billSegSqData.getBillSegmentServiceQuantityDto();

            id = billSegmentSQDto.getId();

            if (id == null) continue;
            if (matchUOM(id,uom) && matchTOU(id,tou) && matchSQI(id,sqi)) {

                if(boolCount){
                    serviceQuantityIndex = i;
                    initialServiceQuantity=billSegmentSQDto.getInitialServiceQuantity();
                }
                return billSegmentSQDto.getBillableServiceQuantity();
            }
        }

        if(boolCount)
            serviceQuantityIndex = MINUS_ONE;
        return null;
    }

    /**
     * This method is to compare the uom and the unit of measure of id and return the corresponding boolean value 
     * @param id
     * @param uom
     * @return Boolean
     */
    private boolean matchUOM(BillSegmentServiceQuantity_Id id,UnitOfMeasure uom) {

        return compareValues(id.getUnitOfMeasure(), (isNull(uom)==true ? null :uom.getId()));
    }

    /**
     * This method is to compare the tou and the terms of use of id and return the corresponding boolean value 
     * @param id
     * @param tou
     * @return Boolean
     */
    private boolean matchTOU(BillSegmentServiceQuantity_Id id,TimeOfUse tou) {

        return compareValues(id.getTimeOfUse(), (isNull(tou)==true ? null :tou.getId()));
    }

    /**
     * This method is to compare the sqi and the ServiceQuantityIdentifier of id and return the corresponding boolean value 
     * @param id
     * @param sqi
     * @return Boolean
     */
    private boolean matchSQI(BillSegmentServiceQuantity_Id id,ServiceQuantityIdentifier sqi) {

        return compareValues(id.getServiceQuantityIdentifier(), (isNull(sqi)==true ? null :sqi.getId()));
    }

    /**
     * This method is to compare the stringValue and the id value and return the corresponding boolean value 
     * @param stringValue
     * @param id
     * @return Boolean
     */
    private boolean compareValues(String stringValue, StringId id) {

        String string1 = (stringValue == null) ? "" : stringValue.trim();
        String string2 = (id == null) ? "" : id.getIdValue().trim();
        return string1.equals(string2);
    }

    /**
     * This method is to retreive the bill factor Value. 
     * @param billFactor
     * @return BigDecimal
     */
    private BigDecimal retrieveBillFactorValue(BillFactor billFactor){

        BillFactorValueInfoRetriever bfValueinfoRetriever = BillFactorValueInfoRetriever.Factory.newInstance();
        BillFactorValueInfoRetrieverData bfValueInfo = BillFactorValueInfoRetrieverData.Factory.newInstance();
        Date accountingDate = applyRateData.getAccountingDate();

        bfValueInfo.setToGetBillFactor(Bool.TRUE);
        bfValueInfo.setBillFactor(billFactor);
        bfValueInfo.setBillFactorPeriodStartDate(accountingDate);
        bfValueInfo.setBillFactorPeriodEndDate(accountingDate);
        bfValueInfo.setNoProrationAccountingDate(accountingDate);
        bfValueInfo.setNoProrationStartDate(accountingDate);
        bfValueInfo.setNoProrationEndDate(accountingDate);
        bfValueInfo.setToFillTheGap(Bool.FALSE);
        bfValueInfo.setServiceAgreement(applyRateData.getServiceAgreement());
        bfValueInfo.setApplyRateData(applyRateData);

        bfValueinfoRetriever.retrieveBillFactorValueInfo(bfValueInfo);
        List<BillFactorValueData> bfValueInfoCollection = bfValueInfo.getBillFactorValueInfoData().getBillFactorValueDataList();
        BigDecimal bfValue = bfValueInfoCollection.get(ZERO).getBfValue();
        return bfValue;

    }

    /**
     * This method is to add or update the serviceQuantity as per the serviceQuantityIndex value. 
     */
    private void  addOrUpdateServiceQuantity(){

        BigInteger scaleValue=null;
        if(!isNull(sqiIdBase)){
        
            scaleValue= sqiIdBase.getEntity().getDecimalPositions(); 
        }else if(isNull(sqiIdBase)){
        
            scaleValue= uomIdBase.getEntity().getDecimalPositions();
        }
        serviceQuantity= serviceQuantity.setScale(scaleValue.intValue(),BigDecimal.ROUND_HALF_UP);
        if(serviceQuantityIndex >=ZERO){ 
           
            billSegmentServiceQuantityData.set(serviceQuantityIndex, populateServiceQuantityData(serviceQuantity));
        } else {
            
            if (billSegmentServiceQuantityData.size() < CobolConstants.CI_CONST_BI_MAX_BSEG_SQ_COLL) {
                
                billSegmentServiceQuantityData.add(populateServiceQuantityData(serviceQuantity));
            } else {
                
                addError(MessageRepository.serviceQuantityCollectionComputationOverflow());
            }
        }
    }

    /**
     * This method is to populate the Service Quantity Date in the Bill Segment. 
     * @param serviceQuantity
     * @return BillSegmentServiceQuantityData
     */
    private BillSegmentServiceQuantityData populateServiceQuantityData(BigDecimal serviceQuantity) {

        BillSegmentServiceQuantityData billSegmentSqData = BillSegmentServiceQuantityData.Factory.newInstance();
        BillSegmentServiceQuantity_DTO billSegSqDto = (BillSegmentServiceQuantity_DTO) createDTO(BillSegmentServiceQuantity.class);

        billSegSqDto.setId(new BillSegmentServiceQuantity_Id(BillSegment_Id.NULL, uomIdBase == null ? "" : uomIdBase
                .getIdValue().trim(), touIdBase == null ? "" : touIdBase.getIdValue().trim(), sqiIdBase == null ? ""
                        : sqiIdBase.getIdValue().trim()));

        billSegSqDto.setBillableServiceQuantity(serviceQuantity);
        billSegSqDto.setInitialServiceQuantity(initialServiceQuantity);
        if(serviceQuantityIndex < ZERO){
            
            billSegSqDto.setInitialServiceQuantity(serviceQuantity); 
        }
        billSegmentSqData.setBillSegmentServiceQuantityDto(billSegSqDto);
        return billSegmentSqData;
    }
    
    /**
     * This method is to calculate the Seasonal Demand for the specific SA. 
     */
    private void calculateSeasonalDemand(){

        BigDecimal sasnlFactorVal = null;
        boolean isExists = false;

        if(paramInputEffSeasonalPeriod.equals(START)){
           if(isBillSegDateBetweenStartAndEndDates(applyRateData.getBillSegmentPeriodStart()).isTrue()){
            	isExists = true;
           }
        }else{
           if(isBillSegDateBetweenStartAndEndDates(applyRateData.getBillSegmentPeriodEnd()).isTrue()){
                isExists = true;
           }
        }
        
        if(isExists){
        	sasnlFactorVal = retrieveBillFactorValue(paramInputSeasonalFactor);
            if(isNull(sasnlFactorVal)){
               addError(CustomMessageRepository.na0054InvalidBillFactorValue(paramInputSeasonalFactor.getId().getIdValue().trim()));
            }
           if(sasnlFactorVal.compareTo(BigDecimal.ZERO)==ZERO){
              addError(CustomMessageRepository.na0054SeasonalBillFactorValueCannotBeZero(paramInputSeasonalFactor.getId().getIdValue().trim()));
           }
           serviceQuantity = serviceQuantity.multiply(sasnlFactorVal);
        }
        
        
        retrieveBillableServiceQuantity(uomIdBase.getEntity(),touIdBase.getEntity(),sqiIdBase.getEntity(),true);
        addOrUpdateServiceQuantity(); 
    }

    /**
     * @return Bool 
     * @param String Start Date (MM/DD), String End Date(MM/DD) and Meter Read Date
     * This method returns true if the Meter Read date falls between the Start and End Dates.
     * 
     */     
    private Bool isBillSegDateBetweenStartAndEndDates(Date billSegDate){

        Date startDateIRU = null;
        Date endDateIRU = null;

        int startMonth = Integer.parseInt(paramInputSeasonalStartDt.substring(ZERO, paramInputSeasonalStartDt.indexOf(DATE_DELIMITER)));
        int startDate = Integer.parseInt(paramInputSeasonalStartDt.substring(paramInputSeasonalStartDt.indexOf(DATE_DELIMITER) + 1));

        int endMonth = Integer.parseInt(paramInputSeasonalEndDt.substring(ZERO, paramInputSeasonalEndDt.indexOf(DATE_DELIMITER)));
        int endDate = Integer.parseInt(paramInputSeasonalEndDt.substring(paramInputSeasonalEndDt.indexOf(DATE_DELIMITER) + 1));

        int currentYearInt = billSegDate.getYear();
        int nextYearInt = currentYearInt + 1;

        if (startMonth <= endMonth) {
            
            startDateIRU = new Date(currentYearInt, startMonth, startDate);
            endDateIRU = new Date(currentYearInt, endMonth, endDate);

            if (isInputDateInTheRange(startDateIRU, endDateIRU,billSegDate).isTrue()) return Bool.TRUE;
        } else {
            
            startDateIRU = new Date(currentYearInt, startMonth, startDate);
            endDateIRU = new Date(currentYearInt, TWELVE, THIRTY_ONE);

            if (isInputDateInTheRange(startDateIRU, endDateIRU,billSegDate).isTrue()) return Bool.TRUE;

            startDateIRU = new Date(nextYearInt, ONE, ONE);
            endDateIRU = new Date(nextYearInt, endMonth, endDate);
            billSegDate = billSegDate.addYears(1);

            if (isInputDateInTheRange(startDateIRU, endDateIRU,billSegDate).isTrue()) return Bool.TRUE;
        }
        return Bool.FALSE;
    }

    /**
     * @return Bool 
     * @param Date Start Date , Date End Date and Meter Read Date
     * This method returns true if the Meter Read date falls between the Start and End Dates.
     * 
     */                     

    private Bool isInputDateInTheRange(Date startDate, Date endDate, Date meterReadDate) {

        int intStartVal = meterReadDate.compareTo(startDate);
        int intEndVal = meterReadDate.compareTo(endDate);
        if ((intStartVal >= ZERO) && (intEndVal <= ZERO)) {
            
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }


}
