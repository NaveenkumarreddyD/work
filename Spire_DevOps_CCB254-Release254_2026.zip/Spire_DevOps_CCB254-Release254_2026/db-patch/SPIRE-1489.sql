create or replace PROCEDURE  CM_PROC_DUPL_FT (V_ACCT_ID CHAR)
AS
BEGIN
  BEGIN
    -- For accounts having duplicate adjustment cancellation financial transactions, update the redundant switch to 'N' so that the duplicate does not affect the account balance
    UPDATE CI_FT
    SET REDUNDANT_SW = 'Y'
    WHERE FT_ID IN
      ( SELECT FT.FT_ID
        FROM CI_FT FT
        WHERE FT.SIBLING_ID = ( SELECT ADJ_ID
                                FROM CI_ADJ ADJ
                                WHERE SA_ID IN (SELECT SA_ID
                                                FROM CI_SA
                                                WHERE ACCT_ID = V_ACCT_ID
                                                  AND SA_STATUS_FLG < '70')
                                  AND ADJ_STATUS_FLG = '60'
                                  AND (SELECT ABS(SUM(TOT_AMT))
                                       FROM CI_FT FTA
                                       WHERE FTA.FT_TYPE_FLG = 'AD'
                                         AND FTA.SIBLING_ID = ADJ.ADJ_ID
                                         AND FTA.FREEZE_SW = 'Y'
                                         AND FTA.REDUNDANT_SW = 'N')
                                      <>
                                      (SELECT ABS(SUM(TOT_AMT ))
                                       FROM CI_FT FTX
                                       WHERE FTX.FT_TYPE_FLG = 'AX'
                                         AND FTX.SIBLING_ID = ADJ.ADJ_ID
                                         AND FTX.FREEZE_SW = 'Y'
                                         AND FTX.REDUNDANT_SW = 'N')
                                  AND 1 < (SELECT COUNT(FT.FT_ID)
                                           FROM CI_FT FTC
                                           WHERE FTC.SIBLING_ID = ADJ.ADJ_ID
                                           AND FTC.FT_TYPE_FLG = 'AX'
                                           AND FTC.REDUNDANT_SW = 'N'))
          AND FT.FT_TYPE_FLG = 'AX'
          AND FT.FREEZE_SW = 'Y'
          AND FT.REDUNDANT_SW = 'N'
          AND FT.CRE_DTTM = (SELECT MAX(FTD.CRE_DTTM)
                             FROM CI_FT FTD
                             WHERE FTD.SIBLING_ID = FT.SIBLING_ID)
      );
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END;
  COMMIT;
END CM_PROC_DUPL_FT;