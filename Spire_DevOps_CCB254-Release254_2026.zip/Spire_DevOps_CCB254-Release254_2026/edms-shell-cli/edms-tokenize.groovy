// EDMS Request CLI

def cli = new CliBuilder(
  usage: 'edms-tokenize.groovy -d payload.json -t template.json -p edms.properties',
  header: '\nAvailable options (use -h for help):\n',
  footer: '\nInformation provided via above options is used to generate printed string.\n'
)

import org.apache.commons.cli.Option
import groovy.json.JsonSlurper

cli.with
{
  h(longOpt: 'help', 'Usage Information', required: false)
  d(longOpt: 'data', 'Payload Data', args: 1, required: true)
  t(longOpt: 'template', 'Payload Template', args: 1, required: true)
  f(longOpt: 'file', 'Properties File', args: 1, required: true)
}
def opt = cli.parse(args)

if (!opt) return
if (opt.h) cli.usage()

String payload = opt.d
String template = opt.t
String properties = opt.f

String templateText = new File(template).text
def payloadObj = new File(payload)
payloadObj.write "${templateText}"

Properties propertiesObj = new Properties()
File propertiesFile = new File(properties)
AntBuilder ant = new AntBuilder()

propertiesFile.withInputStream
{
  propertiesObj.load(it)
}

propertiesObj.each
{
  ant.replace(file: "${payload}", token: "--${it.getKey()}--", value: "${it.getValue()}")
}
