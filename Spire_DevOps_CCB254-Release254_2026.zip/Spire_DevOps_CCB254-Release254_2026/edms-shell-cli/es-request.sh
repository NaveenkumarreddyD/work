#!/bin/bash

# ES Request CLI
# url: $1
# payload: $2
# output: $3

CURL_OUTPUT=$(curl XPUT "$1" -d @$2)
echo $CURL_OUTPUT >> $3
