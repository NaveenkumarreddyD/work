// EDMS Request CLI

@Grab(group='org.apache.httpcomponents', module='httpclient', version='4.5.2')

import groovy.json.*
import groovy.json.JsonSlurper
import org.codehaus.groovy.modules.*
import org.apache.http.client.methods.*
import org.apache.http.entity.*
import org.apache.http.impl.client.*
import org.apache.commons.cli.Option

def cli = new CliBuilder(
  usage: 'edms-request.groovy -u http://jsonplaceholder.typicode.com/posts -d payload.json -o output.json',
  header: '\nAvailable options (use -h for help):\n',
  footer: '\nInformation provided via above options is used to generate printed string.\n'
)

cli.with
{
  h(longOpt: 'help', 'Usage Information', required: false)
  u(longOpt: 'url', 'Endpoint URL', args: 1, required: true)
  d(longOpt: 'payload', 'Payload', args: 1, required: true)
  f(longOpt: 'file', 'Properties File', args: 1, required: true)
  o(longOpt: 'output', 'Output File', args: 1, required: true)
}
def opt = cli.parse(args)

if (!opt) return
if (opt.h) cli.usage()

String url = opt.u
String payload = opt.d
String properties = opt.f
String output = opt.o

// Create HTTP Client
def client = HttpClientBuilder.create().build()

// Set Payload
String payloadBody = new File(payload).text
payloadEntity = new StringEntity(payloadBody, "UTF8")

// Set Authorization
Properties propertiesObj = new Properties()
File propertiesFile = new File(properties)
propertiesObj.load(propertiesFile.newDataInputStream())
String user = propertiesObj.getProperty("user")
String password = propertiesObj.getProperty("password")
String authorization = "${user}:${password}"
String encoding = authorization.bytes.encodeBase64().toString()

// Request
def request = new HttpPost(url)
request.addHeader("Authorization", "Basic " + encoding);
request.addHeader("content-type", "application/json")
request.setEntity(payloadEntity)
println "request=${request}"
println "payload=${payloadBody}"
println "entity=${payloadEntity}"
println payloadEntity.getContent()

// Response
def response = client.execute(request)
def bufferedReader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
def jsonResponse = bufferedReader.getText()
println "jsonResponse=${jsonResponse}"

// Output
File outputFile = new File(output)
outputFile.write(jsonResponse)
