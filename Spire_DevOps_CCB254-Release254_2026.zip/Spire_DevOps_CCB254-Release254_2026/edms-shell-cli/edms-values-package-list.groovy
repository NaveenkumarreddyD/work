// EDMS Values CLI

def cli = new CliBuilder(
  usage: 'edms-values.groovy -f output.json -k key.key',
  header: '\nAvailable options (use -h for help):\n',
  footer: '\nInformation provided via above options is used to generate printed string.\n'
)

import org.apache.commons.cli.Option
import groovy.json.*

cli.with
{
  h(longOpt: 'help', 'Usage Information', required: false)
  f(longOpt: 'file', 'Config file', args: 1, required: true)
  k(longOpt: 'key', 'keys (separated by dot)', args: 1, required: true)
  j(longOpt: 'json', 'json output')
  l(longOpt: 'list', 'list output')
}
def opt = cli.parse(args)

if (!opt) return
if (opt.h) cli.usage()

String file = opt.f
String key = opt.k

String fileText = new File(file).text
def jsonSlurper = new JsonSlurper()

def fileJson = jsonSlurper.parseText(fileText)

def obj = fileJson
def keys = key.split("\\.")
String list = ""

if (opt.l) {
  obj.each { item ->
    //list.add(item.packageId)
    list += item."${key}" + ","
  }
}
else {
  keys.each
  {
    if ("${it}" == "[0]") obj = obj[0]
    else obj = obj."${it}"
  }
}

if (opt.j) println JsonOutput.toJson(obj)
if (opt.l) println list
else println obj
