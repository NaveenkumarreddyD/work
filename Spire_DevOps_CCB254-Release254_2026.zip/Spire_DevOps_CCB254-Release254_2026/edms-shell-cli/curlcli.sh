#!/bin/bash
# Curl CLI
# This CLI enables you to call to REST API's specify headers, payload and attributes

# payload file: $1
# template file: $2
# properties file: $3

# Create new payload file
cp $2 $1

# Replace properties in file
while read -r line
do
    KEY=`echo $line | cut -d"=" -f1`
    VAL=`echo $line | cut -d"=" -f2`
    sed -i "s/--$KEY--/$VAL/g" $1
done < "$3"
