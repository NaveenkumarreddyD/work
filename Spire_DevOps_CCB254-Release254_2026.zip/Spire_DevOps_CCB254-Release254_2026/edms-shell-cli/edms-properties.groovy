def cli = new CliBuilder(
  usage: 'edms-properties.groovy -f edms.properties -k MyKey -v MyValue',
  header: '\nAvailable options (use -h for help):\n',
  footer: '\nInformation provided via above options is used to generate printed string.\n'
)

import org.apache.commons.cli.Option
import groovy.json.JsonSlurper

cli.with
{
  h(longOpt: 'help', 'Usage Information', required: false)
  f(longOpt: 'file', 'Properties File', args: 1, required: true)
  k(longOpt: 'key', 'Key', args: 1, required: true)
  v(longOpt: 'val', 'Value', args: 1, required: true)
}
def opt = cli.parse(args)

if (!opt) return
if (opt.h) cli.usage()

def file = opt.f
def key = opt.k
def value = opt.v

Properties properties = new Properties()
File fileObj = new File(file)

fileObj.createNewFile()
properties.load(fileObj.newDataInputStream())
properties.setProperty("${key}", "${value}")
properties.store(fileObj.newWriter(), null)

println "[EDMS CLI] Set property: ${key}"
