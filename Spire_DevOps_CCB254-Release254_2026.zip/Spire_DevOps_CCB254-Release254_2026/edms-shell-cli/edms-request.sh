#!/bin/bash
 
# EDMS Request CLI
# url: $1
# auth: $2
# payload: $3
# output: $4
 
# 1. Sanity Check: Ensure all 4 arguments are provided
if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ]; then
    echo "[ERROR] EDMS Request: Missing required arguments."
    echo "Usage: $0 <url> <auth> <payload_file> <output_file>"
    exit 1
fi
 
# 1a. FORM login (mmmWeb uses FORM auth, not BASIC)
COOKIE_JAR=$(mktemp)
trap 'rm -f "$COOKIE_JAR"' EXIT
BASE=$(echo "$1" | sed -E 's#(https?://[^/]+/[^/]+).*#\1#')
curl -s -k -c "$COOKIE_JAR" -o /dev/null "$1"
curl -s -k -b "$COOKIE_JAR" -c "$COOKIE_JAR" -o /dev/null \
     -X POST "$BASE/j_security_check" \
     --data-urlencode "j_username=${2%%:*}" \
     --data-urlencode "j_password=${2#*:}"
 
# 2. Execute Request
CURL_OUTPUT=$(curl -s -k -b "$COOKIE_JAR" -X POST -H "Content-Type: application/json" -d @"$3" "$1")
 
# 3. Validate Request Success
res=$?
if test "$res" != "0"; then
   echo "[ERROR] EDMS Request: EDMS Host Unreachable or Down"
   exit 1
else
   # 3a. Fail on a login page / HTML instead of JSON
   case "$CURL_OUTPUT" in
      *"<html"*|*"<HTML"*|*"mlip.jsp"*)
         echo "[ERROR] EDMS Request: got login page / HTML instead of JSON"
         echo "$CURL_OUTPUT" > "$4"
         exit 1
         ;;
   esac
   # 4. Safely Write Output
   echo "$CURL_OUTPUT" > "$4"
fi