#!/bin/bash

# Sensu Request CLI
# url: $1
# payload: $2
# output: $3

CURL_OUTPUT=$(curl -X POST -H "Content-Type: application/json" -d @$2 $1)
echo $CURL_OUTPUT >> $3
