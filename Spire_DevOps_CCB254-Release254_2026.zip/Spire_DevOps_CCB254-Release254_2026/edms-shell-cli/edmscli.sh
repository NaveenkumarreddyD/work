#!/bin/bash
echo "[EDMS CLI] Package Management: Start Package Management"

echo "[EDMS CLI] Package Management: Setting EDMS properties"
groovy edms-properties.groovy -f edms.properties -k user -v mycelium
groovy edms-properties.groovy -f edms.properties -k password -v mycelium@123
groovy edms-properties.groovy -f edms.properties -k authorization -v "mycelium:mycelium@123"
groovy edms-properties.groovy -f edms.properties -k masterPackageId -v "EDMS_Demo_Spire$1"
groovy edms-properties.groovy -f edms.properties -k packageType -v CONFIG
groovy edms-properties.groovy -f edms.properties -k description -v '#testing0913'
groovy edms-properties.groovy -f edms.properties -k environmentTypeMode -v CCB26
groovy edms-properties.groovy -f edms.properties -k migrationRequestTarget -v CCB26_CI
groovy edms-properties.groovy -f edms.properties -k migrationRequestComments -v "Migrating Code to TargetCCBDemo"

echo "[EDMS CLI] Package Management: Creating packageCreate.json Payload"
groovy edms-tokenize.groovy -d packageCreate.json -t packageCreateTemplate.json -f edms.properties

echo "[EDMS CLI] Package Management: Executing Request - Creating Package"
sh edms-request.sh "http://[EDMS_IP]:[PORT]/mmmREST/mia/packageMaint/write" "mycelium:mycelium@123" "packageCreate.json" "packageCreateOutput.json"

echo "[EDMS CLI] Package Management: Reading packageCreateOutput.json Output"
mainRecordKey=`groovy edms-values.groovy -f packageCreateOutput.json -k mainRecordKey`
creationDate=`groovy edms-values.groovy -f packageCreateOutput.json -k packages.[0].creationDate`
creationDateFormatted=`groovy edms-values.groovy -f packageCreateOutput.json -k packages.[0].creationDateFormatted`
groovy edms-properties.groovy -f edms.properties -k mainRecordKey -v $mainRecordKey
groovy edms-properties.groovy -f edms.properties -k packageId -v $mainRecordKey
groovy edms-properties.groovy -f edms.properties -k creationDate -v $creationDate
groovy edms-properties.groovy -f edms.properties -k creationDateFormatted -v $creationDateFormatted
groovy edms-properties.groovy -f edms.properties -k logCreationDate -v $creationDate
groovy edms-properties.groovy -f edms.properties -k logCreationDateFormatted -v $creationDateFormatted

echo "[EDMS CLI] Package Management: Creating packageSync.json Payload"
groovy edms-tokenize.groovy -d packageSync.json -t packageSyncTemplate.json -f edms.properties

echo "[EDMS CLI] Package Management: Executing Request - Sync Code"
sh edms-request.sh "http://[EDMS_IP]:[PORT]/mmmREST/mia/packageMaint/write" "mycelium:mycelium@123" "packageSync.json" "packageSyncOutput.json"

echo "[EDMS CLI] Package Management: Creating packageRead.json Payload"
groovy edms-tokenize.groovy -d packageRead.json -t packageReadTemplate.json -f edms.properties

echo "[EDMS CLI] Package Management: Executing Request - Read Package"
sh edms-request.sh "http://[EDMS_IP]:[PORT]/mmmREST/mia/packageMaint/read" "mycelium:mycelium@123" "packageRead.json" "packageReadOutput.json"

echo "[EDMS CLI] Package Management: Reading packageReadOutput.json Output"
versionedItems=`groovy edms-values.groovy -f packageReadOutput.json -k packages.[0].versionedItems -j`
echo "versionedItems=$versionedItems" >> edms.properties

echo "[EDMS CLI] Package Management: Creating packageMigrationRequest.json Payload"
groovy edms-tokenize.groovy -d packageMigrationRequest.json -t packageMigrationRequestTemplate.json -f edms.properties

echo "[EDMS CLI] Package Management: Executing Request - Migration Request"
sh edms-request.sh "http://[EDMS_IP]:[PORT]/mmmREST/mia/packageMaint/write" "mycelium:mycelium@123" "packageMigrationRequest.json" "packageMigrationRequestOutput.json"
